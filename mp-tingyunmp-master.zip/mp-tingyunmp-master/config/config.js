module.exports = {
  apiRoot: "https://reportalpha1.tingyun.com/demo-server",
  // apiRoot: "https://demo.tingyun.com/mp-mock",
  // apiRoot: "http://127.0.0.1:8080",
  // 下面是我自己加的
  KDinterface: "https://reportalpha1.tingyun.com/demo-server",
  apiSecretKey: '4c65815b0cc6dc97bbd4fd4721f1a613'
};