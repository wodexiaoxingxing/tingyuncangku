// pages/detail/detail.js
const util = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentParamData: '',
    wjnNum2: 1,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('detail page loaded', options)
    util.sleep(500);
    this.param = options;
    this.setData({
      currentParamData: JSON.stringify(options)
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    console.log('detail page onReady', this.param);
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log('detail page show', this.param);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  gotoDetail1: function() {
    wx.navigateTo({
      // url: '../detail1/detail1?detail1=2',
      url: `../detail1/detail1?a=${Math.random()}`,
      // url: `../detail/detail?a=${this.data.wjnNum2}`,

    })
    // var that = this;
    // that.addone();
  },
  addone: function () {
    var that = this;
    that.setData({
      wjnNum2: that.data.wjnNum2 + 1
    });
    console.log('wjnNum2:'+this.data.wjnNum2);
  },
})