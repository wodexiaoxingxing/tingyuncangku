// pages/login/login.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  gotoLogin1: function() {
    wx.navigateTo({
      url: '../login1/login1',
    })
    // wx.navigateTo({
    //   url: '../about/about',
    // })
  },
})