// pages/cptest/cptest.js
const config = require('../../config/config.js');
const wjn_pay = require('./pay.js');

Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    random: Math.random(),
    imageUrl: "https://www.baidu.com/img/PCtm_d9c8750bed0b3c7d089fa7d55720d6cf.png",
  },

  /**
   * 组件的方法列表
   */
  methods: {
    onLoad() {
      console.log('component onLoad');
      this.setData({
        random: Math.random()
      });
      // this.getpf()
      
    },
    onShow() {
      // console.log('component onShow');
      
    },
    triggerJsError: function() {
      throw new Error('jserror');
    },
    sendToServer: function (e) {
      wx.request({
        url: config.apiRoot + '/api/index?city=' + this.data.currentCity + '&counts=' + this.data.counts + '&start=' + this.data.start,
        // url: config.apiRoot + '/api/index?city=' + this.data.currentCity + '&counts=' + this.data.counts + '&start=' + this.data.start + `?qq=${Math.random()}`,
        success: function(res) {
        }
      })
      wx.request({
        url: config.apiRoot + '/api/moviesDetail',
      })
    },
    getpf: function() {
      // 获取网络静态资源性能数据
      const performance = wx.getPerformance()
      const observer = performance.createObserver((entryList) => {
        // console.log(entryList.getEntriesByType('script'))
        console.log(entryList.getEntries())
      })
      observer.observe({ entryTypes: ['render', 'script'] });
    },
    sendPay: function () {
      const that = this;
  
      app = getApp();
      wjn_pay.Payment()
    },
    sendRequest1: function () {
      const that = this;
  
      app = getApp();
      wjn_pay.RequestPay1()
    },
    RequestPay1 : function () {
      // let subPayCode = await Payment(options)
      // console.log(subPayCode)
      let promise = new Promise((resolve, reject) => {
          wx.request({
            url: 'http://localhost:8089/shop/list',
            success:res=>{
              resolve(res);
              wjn_pay.Payment()
              console.log('wjn____RequestPay1__success')
           },
            fail:res=>{
              reject(res);
              wjn_pay.Payment()
              console.log('wjn____RequestPay1__fail')
            }
          })
      })
    }
  },
  
})
