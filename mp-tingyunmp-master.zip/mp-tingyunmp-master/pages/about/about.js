// pages/about/about.js
const wjn_pay = require('../../pay/pay.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    about: 1,
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    email: '',
    sendEmailStatus: '',
    items: [],
    smallItem: 111,
    // 下面是我自己加的
    productList: [],
    wjnNum: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // wx.request({
    //   url: 'https://demo.tingyun.com/mp-mock/test/custom-code?r=1'
    // })
    // this.getpf()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  // getpf: function() {
  //   // 获取网络静态资源性能数据
  //   const performance = wx.getPerformance()
  //   const observer = performance.createObserver((entryList) => {
  //     // console.log(entryList.getEntriesByType('script'))
  //     // pf_datas = entryList.getEntries()
  //     console.log(entryList.getEntries())
  //   })
  //   observer.observe({ entryTypes: ['render', 'script'] });
  // },
  // RequestPay1 : function () {
  //   // let subPayCode = await Payment(options)
  //   // console.log(subPayCode)
  //   let promise = new Promise((resolve, reject) => {
  //       wx.request({
  //         url: 'http://localhost:8089/shop/list',
  //         success:res=>{
  //           resolve(res);
  //           wjn_pay.Payment()
  //           console.log('wjn____RequestPay1__success')
  //        },
  //         fail:res=>{
  //           reject(res);
  //           wjn_pay.Payment()
  //           console.log('wjn____RequestPay1__fail')
  //         }
  //       })
  //   })
  // },
  gotoAbout: function() {
    wx.switchTab({
      url: '../about/about',
    })
  },
  sendToServer2: function (e) {
    wx.request({
      url: config.apiRoot + '/api/index?city=' + this.data.currentCity + '&counts=' + this.data.counts + '&start=' + this.data.start,
      // url: config.apiRoot + '/api/index?city=' + this.data.currentCity + '&counts=' + this.data.counts + '&start=' + this.data.start + `?qq=${Math.random()}`,
      success: function(res) {
      }
    })
    wx.request({
      url: config.apiRoot + '/api/moviesDetail',
    })
  },
  apiTest: function() {
    console.log('接口测试');
    wx.previewImage({
        urls: [
          "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1553083836622&di=ce9098a8211c3d5c625737182c11ea7d&imgtype=0&src=http%3A%2F%2Fpic2.16pic.com%2F00%2F11%2F70%2F16pic_1170466_b.jpg",
          "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1553083836622&di=f9729d85ec4fd6ff79f0a29a98eae05d&imgtype=0&src=http%3A%2F%2Fimg17.3lian.com%2Fd%2Ffile%2F201702%2F14%2F3d1d78481dbe5db4802f4b1eb548f365.jpg",
          "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1553083836622&di=6cf355d9ec11293a2c21653f2fb7d0b8&imgtype=0&src=http%3A%2F%2Fpic1.win4000.com%2Fpic%2Fb%2F18%2Fc1601227067.jpg"
        ],
        success: function() {
          console.log('run finished');
          wx.request({
            url: 'https://reportalpha1.tingyun.com/mpserver/filesuccess?a=1-009',
          })
        }
    })
  },
})