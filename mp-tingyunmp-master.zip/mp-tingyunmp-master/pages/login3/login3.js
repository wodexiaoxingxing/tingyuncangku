// pages/login3/login3.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  gotoLogin4: function() {
    wx.navigateTo({
      url: '../login4/login4',
    })
  },
})