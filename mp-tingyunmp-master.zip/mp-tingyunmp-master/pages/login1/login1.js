// pages/login1/login1.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  gotoLogin2: function() {
    wx.navigateTo({
      url: '../login2/login2',
    })
  },
  
})