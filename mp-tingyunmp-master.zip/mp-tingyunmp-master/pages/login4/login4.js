// pages/login4/login4.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  gotoLogin1: function() {
    wx.navigateTo({
      url: '../login1/login1',
    })
  },
})