// pages/login2/login2.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  gotoLogin3: function() {
    wx.navigateTo({
      url: '../login3/login3',
    })
  },
})