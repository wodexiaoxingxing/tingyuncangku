//index.js
//获取应用实例
// const monitor = require('../../agent/bundle.js');
// const monitor = require('../../agent/tingyun-mp-agent.js');

let app = getApp()

const config = require('../../config/config.js');
const util = require('../../utils/util.js');
const wjn_pay = require('./pay.js');

Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    email: '',
    sendEmailStatus: '',
    items: [],
    smallItem: 111,
    // 下面是我自己加的
    productList: [],
    wjnNum: 0,
  },
  freSetDataCount: 0,
  //事件处理函数
  bindViewTap: function () {
    wx.navigateTo({
      url: '../logs/logs'
    });
  },
  setDataOnce: function() {

    getApp().mtj.trackEvent('order', {
      product: '手机',
      price: 10.00
    });
    this.setData({
      smallItem: 1
    })
  },
  setDataOnceCallback: function() {
    this.setData({
      smallItem: 2
    }, function() {
      console.log(this);
      console.log('setData callback finished');
    })
  },
  onLoad: function (options) {
    console.log('index page loaded', options);
    util.sleep(500);
    // 下面是我自己加的
    //this.loadProductList();
    this.shopId = options.shopId
    wx.request({
      method: 'POST',
      url: 'http://localhost:8089/shop/list',
      data: {
        shopId: this.shopId
      },
      success: (res) => {
        const {code, data} = res.data;
        
        // this.setData({
        //   loading: false,
        //   productList: this.duplicateArray(data)
        // });
      }
    });

    
    // 获取静态资源
    // const performance = wx.getPerformance()
    // const observer = performance.createObserver((entryList) => {
    //   console.log(entryList.getEntries())
    // })
    // if (app.globalData.userInfo) {
    //   this.setData({
    //     userInfo: app.globalData.userInfo,
    //     hasUserInfo: true
    //   })
    // } else if (this.data.canIUse) {
    //   // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
    //   // 所以此处加入 callback 以防止这种情况
    //   app.userInfoReadyCallback = res => {
    //     this.setData({
    //       userInfo: res.userInfo,
    //       hasUserInfo: true
    //     })
    //   }
    // } else {
    //   // 在没有 open-type=getUserInfo 版本的兼容处理
    //   wx.getUserInfo({
    //     success: res => {
    //       app.globalData.userInfo = res.userInfo
    //       this.setData({
    //         userInfo: res.userInfo,
    //         hasUserInfo: true
    //       })
    //     }
    //   })
    // }
  
    // this.setData({
    //   smallItem: this.createSmallData()
    // }, function() {
    //   console.log('setData finished', this);
    // })

    // this.setData({
    //   items: [...this.createHugeData()]
    // })
    // this.sendSimpleRequest();
    // this.sendLongDuRequest();
  },
  sendLongDuRequest: function() {
    wx.request({
      url: `${config.apiRoot}/index/seatdata`,
    })
  },
  onShow: function() {
    // throw new Error('11111');
    // console.log(a);
    // console.log('current context', monitor.getContext());
    // util.sleep(2500);
    // throw new Error('jserro 001');
    this.freSetDataCount = 0;
    this.wjnNum = 0;
    // this.recordTyTime();
    // console.log(this.recordTyData)
    // this.recordTyTime();
    // this.sendToServer();
    // this.sendSimpleRequest();
  
    this.sendVerySimpleRequest();
    this.sendTimeoutRequest();

    
  },
  onReady: function() {
    console.log('onReady trigger');
    const timeout = 2000;
    const self = this;
    wx.request({
      url: `${config.apiRoot}/test/custom-request?timeout=${timeout}`,
      success: function() {
        self.setData({
          name: 'test001'
        })
      }
    })
  },
  // 下面是我自己加的
  // 下面是我自己加的支付
  getReport2: function () {
    console.log(`sending report to ${this.email}!`)
    const that = this;

    app = getApp();
    wjn_pay.Payment()
  },
  loadProductList() {
    wx.request({
      method: 'POST',
      url: config.apiRoot + '/product/list',
      data: {
        shopId: this.shopId
      },
      success: (res) => {
        const {code, data} = res.data;
        
        this.setData({
          loading: false,
          productList: this.duplicateArray(data)
        });
      }
    })
  },
  createHugeData: function(num) {
    return Array(num || 1000).fill(Object.assign({}, {
      // name: Array(Math.floor(Math.random() * 175)).fill('x').join(','), 
      name: '1',
      src: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1565012262752&di=4503f8592705a4112f547f0ac3556d1b&imgtype=0&src=http%3A%2F%2Fimages6.fanpop.com%2Fimage%2Fphotos%2F39700000%2FThe-Amazing-Spider-Man-spider-man-39719053-3812-1925.jpg'
    
    // src:`https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1565011431616&di=2e34b57970082bd6606154a8dabeb00b&imgtype=0&src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201610%2F23%2F20161023091149_hF8Hs.jpeg?t=${+new Date}` 
    
    }))
  },
  createSmallData: function(num) {
    // return Array(num || 1).fill(Object.assign({}, { name: Math.random() }));
    // return Object.assign({}, {name: Math.random()});
    return Math.random();
  },
  onPageScroll: function() {
    // console.log('on scroll');
    // // 设置一点数据
    // this.setData({
    //   smallItem: this.createSmallData()
    // })
  },
  onHide: function() {
    console.log('onHide trigger');
    console.log('频繁setData的回调触发次数', this.freSetDataCount);
  },
  // getUserInfo: function (e) {
  //   app.globalData.userInfo = e.detail.userInfo
  //   this.setData({
  //     userInfo: e.detail.userInfo,
  //     hasUserInfo: true
  //   })
  // },
  sendReportEmail: function () {
    const that = this;
    wx.request({
      url: `${config.apiRoot}/mail/sendEmail?email=${this.email}`,
      success: function (res) {
        const message = res.data.status > 0 ? '发送成功' : '发送失败';
        that.setEmailStatus(message);
      }
    })
  },
  setEmailStatus: function (message) {
    this.setData({
      sendEmailStatus: message
    });
    setTimeout(() => {
      this.setData({
        sendEmailStatus: ''
      })
    }, 2000)
  },
  getReport: function () {
    console.log(`sending report to ${this.email}!`)
    const that = this;
    // generate order in backend
    app = getApp();
    wx.request({
      url: `${config.apiRoot}/pay/requestPay?openid=${app.globalData.openid}`, 
      success: function (res) {
        const resData = res.data.data;
        if (res.statusCode === 200 && resData) {
          const { prepay_id, nonce_str, appid } = resData;
          const requestParam = {
            appId: appid,
            timeStamp: Math.floor(+new Date / 1000) + '',
            nonceStr: nonce_str,
            package: `prepay_id=${prepay_id}`,
            signType: 'MD5',
          }
          const paySign = util.genSign(requestParam)
          console.log('paySign in client:' + paySign);
          wx.requestPayment({
            timeStamp: requestParam.timeStamp,
            nonceStr: requestParam.nonceStr,
            package: requestParam.package,
            // paySign: paySign,
            signType: requestParam.signType,
            success: function (res) {
              console.log('支付成功', arguments);
              console.log(res);
              that.sendReportEmail();
            },
            fail: function (res) {
              console.log('支付失败', arguments);
              that.setEmailStatus('发送失败(支付失败)')
            },
            complete: function (res) {
              console.log('complete:', arguments);
            }
          })
          console.log(1111);
        }
      }
    })
  },
  
  sendSimpleRequest: function () {
    wx.request({
      url: `${config.apiRoot}/test/custom-code?r=1`,
      success: function (res) {
        wx.request({
          url: `${config.apiRoot}/test/custom-code?r=2`,
          success: function (res) {
          }
        })
      }
    })
  },
  sendVerySimpleRequest: function() {
    wx.request({
      url: `${config.apiRoot}/test/custom-statuscode?r=a&statusCode=500`,
      success: function (res) {
        util.sleep(500);
      }
    })
  },
  sendLongRequest() {
    wx.request({
      url: `${config.apiRoot}/test/custom-request?timeout=${5000}`,
      success: function() {
      }
    })
  },
  callData: function() {
    console.log('callData', this);
    return 123;
  },
  sendMixRequest: function() {
    const data = this.callData();
    console.log(data);
    util.sleep(500);
    wx.request({
      url: `${config.apiRoot}/test/custom-code?r=mix1`,
      success: function (res) {
        console.log('it called');
        // util.sleep(500);
      },
      complete: function() {
        console.log('complete called');
      }
    })

    wx.request({
      url: `${config.apiRoot}/test/custom-code?r=mix2`,
      success: function (res) {
        // util.sleep(500);
      }
    })
  },
  sendMixRequestWithOneError: function() {
    wx.request({
      url: `${config.apiRoot}/test/custom-code?r=mix001`
    })
    wx.request({
      url: `${config.apiRoot}/test/custom-code1?r=mix002`
    })
  },
  inputchange: function (e) {
    this.email = e.detail.value;
  },
  clickButton: function (e) {
    console.log(e)
    const self = this;
    self.sendSimpleRequest();
  },
  sendToServer: function (e) {
    wx.request({
      url: config.apiRoot + '/api/index?city=' + this.data.currentCity + '&counts=' + this.data.counts + '&start=' + this.data.start,
      // url: config.apiRoot + '/api/index?city=' + this.data.currentCity + '&counts=' + this.data.counts + '&start=' + this.data.start + `?qq=${Math.random()}`,
      success: function(res) {
      }
    })
    wx.request({
      url: config.apiRoot + '/api/moviesDetail',
    })
  },
  sendToShopList: function (e) {
    wx.request({
      url: 'http://localhost:8089/shop/list?queryTodayContentMarketingTask=637c25d1-e813-4592-bc25-d1e813f59256&queryTodayContentMarketingTask22=0904e83a-9d3d-4bda-84e8-3a9d3debda69&queryTodayContentMarketingTask33=330904e83a-9d3d-4bda-84e8-3a9d3debda69&queryTodayContentMarketingTask44=440904e83a-9d3d-4bda-84e8-3a9d3debda69',
      method: 'POST',
      data: {
        "delay":"2000",
      },
      header: {
        test001 : "wjn_header",
      },
      // url: config.apiRoot + '/api/index?city=' + this.data.currentCity + '&counts=' + this.data.counts + '&start=' + this.data.start + `?qq=${Math.random()}`,
      success: function(res) {
      }
    })
    // wx.request({
    //   url: config.apiRoot + '/api/moviesDetail',
    // })
  },

  triggerOpera: function(e) {
    wx.request({
      url: 'https://reportalpha1.tingyun.com/mpserver/filesuccess?a=1-1',
      success() {
        wx.request({
          url: 'https://reportalpha1.tingyun.com/mpserver/filesuccess',
          success() {
            wx.request({
              url: 'https://reportalpha1.tingyun.com/mpserver/filesuccess',
              success() {
                wx.request({
                  url: 'https://reportalpha1.tingyun.com/mpserver/filesuccess',
                })
              }
            })
            wx.request({
              url: 'https://reportalpha1.tingyun.com/mpserver/filesuccess',
            })
          }
        })

        wx.request({
          url: 'https://reportalpha1.tingyun.com/mpserver/filesuccess',
        })
        // wx.previewImage({
        //   current: 'http://b-ssl.duitang.com/uploads/blog/201408/23/20140823155558_znT8m.thumb.700_0.jpeg',
        //   urls: ['http://b-ssl.duitang.com/uploads/blog/201408/23/20140823155558_znT8m.thumb.700_0.jpeg']
        // })
      }
    })
    wx.request({
      url: 'https://reportalpha1.tingyun.com/mpserver/filesuccess?a=1-2',
    })
    wx.request({
      url: 'https://reportalpha1.tingyun.com/mpserver/filesuccess?a=1-',
    })
  },
  apiTest: function() {
    console.log('接口测试');
    wx.previewImage({
        urls: [
          "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1553083836622&di=ce9098a8211c3d5c625737182c11ea7d&imgtype=0&src=http%3A%2F%2Fpic2.16pic.com%2F00%2F11%2F70%2F16pic_1170466_b.jpg",
          "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1553083836622&di=f9729d85ec4fd6ff79f0a29a98eae05d&imgtype=0&src=http%3A%2F%2Fimg17.3lian.com%2Fd%2Ffile%2F201702%2F14%2F3d1d78481dbe5db4802f4b1eb548f365.jpg",
          "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1553083836622&di=6cf355d9ec11293a2c21653f2fb7d0b8&imgtype=0&src=http%3A%2F%2Fpic1.win4000.com%2Fpic%2Fb%2F18%2Fc1601227067.jpg"
        ],
        success: function() {
          console.log('run finished');
          wx.request({
            url: 'https://reportalpha1.tingyun.com/mpserver/filesuccess?a=1-009',
          })
        }
    })
  },
  justTap: function() {
    console.log('justTap')
  },
  sendTimeoutRequest: function() {
    console.log('发送超时请求');
    wx.request({
      url: 'https://reportalpha1.tingyun.com/mpserver/filesuccess?a=timeout',
    })
  },
  triggerJsError: function() {
      throw new Error('jserror');
      // this.sdInterval = setInterval(() => {
      //   this.setData({
      //     wjnNum: this.wjnNum++
      //   });
      //   wjn = Math.min()
      // }, 10);
  },
  beginSetData: function() {
    this.sdInterval = setInterval(() => {
      console.log('SetInterval works');
      this.setData({
        smallItem: this.createSmallData()
      }, function() {
        this.freSetDataCount++;
      })
    }, 10);
  },
  endSetData: function() {
    console.log('End setInterval');
    this.sdInterval && clearInterval(this.sdInterval);
  },
  sendOneRequest: function() {
    wx.request({
      // url: 'https://reportalpha1.tingyun.com/mpserver/filesuccess',
      url: `https://reportalpha1.tingyun.com/mpserver/filesuccess?ww=${Math.random()}`,
      // url: 'http://localhost:8089/shop/list',
    })
  },
  gotoDetail: function() {
    wx.navigateTo({
      url: `../detail/detail?a=${Math.random()}`,
      // url: `../detail/detail?a=${this.data.wjnNum+1}`,
    })
    // wx.navigateTo({
    //   url: '../about/about',
    // })
  },
  gotoComponentDetail: function() {
    wx.navigateTo({
      url: `../cptest1/cptest1?a=${Math.random()}`,
    })
    // wx.navigateTo({
    //   url: '../about/about',
    // })
  },
  gotoLogin: function() {
    wx.navigateTo({
      url: '../login/login',
    })
    // wx.navigateTo({
    //   url: '../about/about',
    // })
  },
  gotoIndex: function() {
    wx.switchTab({
      url: '../index/index',
    })
  },
  gotoAbout: function() {
    wx.switchTab({
      url: '../about/about',
    })
  },
  beginSendInterval() {
    this.stopSendInterval();
    this.requestInterval = setInterval(function() {
      wx.request({
        url: `${config.apiRoot}/test/custom-code?r=interval`,
      })
    }, 200)
  },
  stopSendInterval() {
    this.requestInterval && clearInterval(this.requestInterval);
  },

})
