/**
 * 支付分装
 */
let app = getApp()
const config = require('../../config/config.js');

async function H5SubmitPay() {

  new Promise((resolve, reject) => {
    wx.request({
      url: `${config.apiRoot}/pay/requestPay?openid=${app.globalData.openid}`, 
      success: function (res) {
        const resData = res.data.data;
        if (res.statusCode === 200 && resData) {
          resolve(resData);
          console.log(`success_wjn, ${this.resData}!`)
        }
      }
    })
  })
  
}

const GetPayParams = (options) => {
    let app = getApp();
    let promise = new Promise(async (resolve, reject) =>{
        let payInfo = options;
        // let params = {
        //     PAYURL: true,
        //     payType: 'weixinpayapplet',
        //     payObjList: JSON.stringify(payInfo.params?payInfo.params.payObjList:payInfo.payObjList),
        //     extend: {
        //       openId: app.globalData.localUserInfo.openId
        //     },
        //     timestamp: Date.parse(new Date()),
        // }
        let res = await H5SubmitPay();
        const { prepay_id, nonce_str, appid } = res || {};
        const requestParam = {
          appId: appid,
          timeStamp: Math.floor(+new Date / 1000) + '',
          nonceStr: nonce_str,
          package: `prepay_id=${prepay_id}`,
          signType: 'MD5',
        }
        // const paySign = util.genSign(requestParam)
        // requestParam.paySign = paySign;
        resolve(requestParam);
        // if(res.status ==200){
          
        //     let subPayCode = res.content.payCode
        //     resolve(subPayCode)
        // }else{
        //     reject()
        // }
    })
    return promise
}
const Payment = async (options) => {
    let subPayCode = await GetPayParams(options)
    console.log(subPayCode)
    let promise = new Promise((resolve, reject) => {
        wx.requestPayment({
            timeStamp: subPayCode.timeStamp,
            nonceStr: subPayCode.nonceStr,
            package: subPayCode.package,
            signType: subPayCode.signType,
            paySign: subPayCode.paySign,
            success:res=>{
                resolve(res);
            },
            fail:res=>{
                reject(res);
            }
        })
    })
    return promise
}

const rawRequest = () => {
  wx.request({
    url: `${config.apiRoot}/pay/requestPay?openid=${app.globalData.openid}`, 
    success: function (res) {
      const resData = res.data.data;
      if (res.statusCode === 200 && resData) {
        // resolve(resData);
      }
    }
  })
}
module.exports = {
    Payment,
    rawRequest
};