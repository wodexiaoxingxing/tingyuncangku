const MP_GLOBAL = wx;
function now() {
    return +new Date;
}

/**
 * 兼容各个小程序框架有区别的接口
 */

function getStorageSync(key) {
    let result;
    {
        try {
            result = MP_GLOBAL.getStorageSync(key);
        } catch (e) {}   
    }
    return result;
}
function setStorageSync(key, value) {
    {
        try {
            MP_GLOBAL.setStorageSync(key, value);
        } catch (e) {}   
    }
}

function getSystemInfoSync() {
    const systemInfo = MP_GLOBAL.getSystemInfoSync();
    return systemInfo;
}

function getStatusCode(response) {
    let statusCode;
    {
        statusCode = response.statusCode;
    }
    return statusCode;
}

function getDafaultHookApis() {
    let apis = [];
    {
        apis = [
            'requestPayment',
            'scanCode',
            'previewImage'
        ];
    }
    return apis;
}

// 应用级别路由链
let appRouteTrack = [];
let appData = {
    context: null,
    // launchOptions: undefined
};

let sysInfo = {
    networkType: "",
    system: getSystemInfoSync()
};

function addRoute(route) {
    appRouteTrack.push({
        timestamp: now(),
        route: route
    });
}

function clearRouteChain() {
    appRouteTrack = [];
}

function getRouteChain() {
    return appRouteTrack.slice();
}

function isType(type) {
    return function(arg) {
        if (type === 'Array' && Array.isArray) {
            return Array.isArray(arg);
        }
        return Object.prototype.toString.call(arg) === "[object " + type + "]";
    }
}

var isString = isType('String');
var isArray = isType('Array');
var isFunction = isType('Function');
var isObject = isType('Object');
var isBoolean = isType('Boolean');
var isNumber = isType('Number');

function hookBefore(original, beforeHandler) {
    return function () {
        if(isFunction(beforeHandler)) {
            try {
                beforeHandler.apply(this, arguments);
            }catch (e) {}
        }
        if (isFunction(original)) {
            return original.apply(this, arguments);
        }
    }
}

function hookAround(original, beforeHandler, afterHandler) {
    return function () {
        let result;
        if (isFunction(beforeHandler)) {
            try {
                beforeHandler.apply(this, arguments);
            }catch (e) {}
        }
        if(isFunction(original)) {
            result = original.apply(this, arguments);
        }
        if (isFunction(afterHandler)) {
            try {
                afterHandler.apply(this, arguments);
            }catch (e) {}
        }
        return result;
    }
}

function lifeCycleHook(hook, options) {
    if(isObject(hook) && isFunction(hook.handler)) {
      const {name, handler, afterHandler} = hook;
      options[name] = hookAround(options[name], handler, afterHandler);
      options[name]._ty_hook = true;
    }
}

/**
 * UUID.core.js: A small subset of UUID.js, the RFC-compliant UUID generator for JavaScript.
 *
 * @fileOverview
 * @author  LiosK
 * @version v3.3.0
 * @license The MIT License: Copyright (c) 2010-2016 LiosK.
 */
const UUID = (function() {
    /**
     * Returns an unsigned x-bit random integer.
     * @param {int} x A positive integer ranging from 0 to 53, inclusive.
     * @returns {int} An unsigned x-bit random integer (0 <= f(x) < 2^x).
     */
    function rand(x) { // _getRandomInt
        if (x < 0) return NaN;
        if (x <= 30) return (0 | Math.random() * (1 << x));
        if (x <= 53) return (0 | Math.random() * (1 << 30)) + (0 | Math.random() * (1 << x - 30)) * (1 << 30);
        return NaN;
    }

    /**
     * Converts an integer to a zero-filled hexadecimal string.
     * @param {int} num
     * @param {int} length
     * @returns {string}
     */
    function hex(num, length) { // _hexAligner
        let str = num.toString(16),
            i = length - str.length,
            z = "0";
        for (; i > 0; i >>>= 1, z += z) {
            if (i & 1) {
                str = z + str;
            }
        }
        return str;
    }

    /**
     * The simplest function to get an UUID string.
     * @returns {string} A version 4 UUID string.
     */
    return function() {
        return hex(rand(32), 8) // time_low
            + "-" + hex(rand(16), 4) // time_mid
            + "-" + hex(0x4000 | rand(12), 4) // time_hi_and_version
            + "-" + hex(0x8000 | rand(14), 4) // clock_seq_hi_and_reserved clock_seq_low
            + "-" + hex(rand(48), 12); // node
    };
})();

function parseJSON(data) {
    if (data && isString(data)) {
        return JSON.parse(data);
    }
    return data;
}

function safeParseJSON(json) {
    try {
        return parseJSON(json);
    } catch (e) {}
    return null;
}

function safeStringifyJSON(data, catchError) {
    let result = '';
    let error = false;
    try {
        result = JSON.stringify(data);
    }catch(e) {
        result = '';
        error = true;
    }
    if (catchError) {
        return {
            error: error,
            value: result
        }
    } else {
        return result;
    }
}

function toString(data) {
    return data + '';
}

function size(data) {
    if (!data) {
        return 0;
    }
    if (isObject(data)) {
        return safeStringifyJSON(data).length;
    }
    if (isString(data)) {
        return data.length;
    }
    if (data instanceof ArrayBuffer) {
        return data.byteLength;
    }
    if (data.length) {
        return data.length;
    }
    return 0;
}

function safeStringify(data, truncateLength) {
    let content;
    if (isObject(data)) {
        content = safeStringifyJSON(data);
    } else if (isString(data)) {
        content = data;
    } else {
        content = '';
    }
    if (truncateLength) {
        content = content.substring(0, truncateLength);
    }
    return content;
}

const PAGE_TY_DATA = "recordTyTime";
const TINGYUN_UID = "TINGYUN_UID";
const CUSTOM_CODE_FUNC = 'custom';
const TRIGGER_LIFECYCLE = 'TRIGGER_LIFECYCLE';
const PLUGIN_FREE_VERSION = '2.6.4';
// 事件超时时间(10min)
const DEFAULT_EVENT_TIME_OUT = 10 * 60 * 1000;
// event最大数量
const DEFAULT_EVENT_MAX_SIZE = 20;
const ACTION_TYPE_EVENT = 'event';
const ACTION_TYPE_REQUEST = 'request';
const ACTION_TYPE_API = 'api';
const ACTION_TYPE_TIMER = 'timer';

// setData卡顿阈值(ms)
const DEFAULT_SETDATA_STUCK_THRESHOLD = 1500;
const DEFAULT_SETDATA_TRACE = true;
const DEFAULT_SETDATA_TRACE_HINT = true;
// 每秒setData trace最大取值
const SETDATA_TRACE_COUNT = 5;
const TY_CONFIG_KEY = 'TY_CONFIG';
// TY_CONFIG_KEY keys:
const TY_SAMPLING = 'TY_SAMPLING';
const TY_SETDATA_THRESHOLD = 'TY_SETDATA_THRESHOLD';
const TY_SETDATA_TRACE = 'TY_SETDATA_TRACE';
const TY_SETDATA_TRACEHINT = 'TY_SETDATA_TRACEHINT';
const TY_IGNORE_ERRCODES = 'TY_IGNORE_ERRCODES';
const TY_SETDATA_TIME_INTERVAL = 'TY_SETDATA_TIME_INTERVAL';

const DEFAULT_SETDATA_TIME_INTERVAL = [500, 1500];

// 默认接口和请求允许获取的错误信息大小
const API_FAIL_MESSAGE_SIZE = 256;
const REQUEST_FAIL_MESSAGE_SIZE = 256;

// 暂存页面参数名称
const PAGE_NAME_VARIABLE = '__ty_page_param';

// global agentConfig

let agentConfig = {};
let init = false;
function setAgentConfig(config) {
    agentConfig = config || {};
    if (agentConfig.requestFailMessageSize == null) {
        agentConfig.requestFailMessageSize = REQUEST_FAIL_MESSAGE_SIZE;
    }
    if (agentConfig.apiFailMessageSize == null) {
        agentConfig.apiFailMessageSize = API_FAIL_MESSAGE_SIZE;
    }
}

function isInit() {
    return init;
}

function setInit(status) {
    init = status;
}

function firstNonNull () {
    for(let i = 0; i < arguments.length; i++) {
        if (arguments[i] != null) {
            return arguments[i];
        }
    }
}

const CHECK_SAMPLING_INTERVAL = 10 * 60 * 1000;

// TY_CONFIG_KEY keys:
// const TY_SAMPLING = 'TY_SAMPLING';
// const TY_SETDATA_THRESHOLD = 'TY_SETDATA_THRESHOLD';
// const TY_SETDATA_TRACE = 'TY_SETDATA_TRACE';
// const TY_SETDATA_TRACEHINT = 'TY_SETDATA_TRACEHINT';
// const TY_IGNORE_ERRCODES = 'TY_IGNORE_ERRCODES';
// const TY_SETDATA_TIME_INTERVAL = 'TY_SETDATA_TIME_INTERVAL';

// 采样率
let sampling = getConfStorage(TY_SAMPLING);
let isCollect = false;

function checkNumConfig(value) {
    return value != null && isNumber(value)
}

function checkBooleanConfig(value) {
    return value != null && isBoolean(value)
}

function checkArrayConfig(value) {
    return value != null && isArray(value)
}

function checkSetDataTimeInterval(value) {
    return checkArrayConfig(value) && value.length == 2;
}
/**
 *
 * @param key
 * @returns {*}
 */
function getConfStorage(key) {
    const conf = getStorageSync(TY_CONFIG_KEY);
    if (conf && isObject(conf)) {
        return conf[key];
    }
}

/**
 * @param confObj config object
 */
function setConfStorage(confObj) {
    let conf = getStorageSync(TY_CONFIG_KEY);
    if (!conf || !isObject(conf)) {
        conf = {};
    }
    if (confObj) {
        for (const key in confObj) {
            if (confObj.hasOwnProperty(key)) {
                conf[key] = confObj[key];
            }
        }
    }
    setStorageSync(TY_CONFIG_KEY, conf);
}

function syncAgentConfig(keyStorePairs, data) {
    const conf = {};
    keyStorePairs.forEach(keyStore => {
        const {key, storeKey, validFunc} = keyStore;
        const isValid = validFunc ? validFunc.call(this, data[key]) : false;
        if (isValid) {
            agentConfig[key] = data[key];
            conf[storeKey] = data[key];
        }
    });
    setConfStorage(conf);
}

function checkSampling(callback) {
    // console.log('TINGYUN AGENT checking sampling');
    if(agentConfig.key && agentConfig.beacon) {
        MP_GLOBAL.request({
            url: `${agentConfig.beacon}/mp-config/config/pullSampling?encodeMpId=${agentConfig.key}`,
            method: 'GET',
            _no_record: true,
            success: (result) => {
                const {code, data} = result.data || {};
                if(code === 200 && data) {
                    // set sampling
                    if (checkNumConfig(data.sampling)) {
                        sampling = data.sampling;
                        setConfStorage({[TY_SAMPLING]: sampling});
                    }

                    syncAgentConfig([
                        {key: 'setdataThreshold', storeKey: TY_SETDATA_THRESHOLD, validFunc: checkNumConfig},
                        {key: 'setdataTrace', storeKey: TY_SETDATA_TRACE, validFunc: checkBooleanConfig},
                        {key: 'setdataTraceHint', storeKey: TY_SETDATA_TRACEHINT, validFunc: checkBooleanConfig},
                        {key: 'ignoreErrorCodes', storeKey: TY_IGNORE_ERRCODES, validFunc: checkArrayConfig},
                        {key: 'setdataTimeInterval', storeKey: TY_SETDATA_TIME_INTERVAL, validFunc: checkSetDataTimeInterval},
                    ], data);
                }
            },
            complete: () => {
                callback && callback(sampling);
            }
        });
    }
}

function calcIfCollect() {
    // if no sampling storage, try to query and use user setting
    if(!sampling) {
        sampling = +agentConfig.sampleRate || 1;
    }
    const random = Math.random();
    isCollect = random <= sampling;
}

// Re check sampling every 10 minutes
setInterval(checkSampling, CHECK_SAMPLING_INTERVAL);

function genPageDataTemplate() {
    return {
        uniqueId : 0,
        requestId: 0,
        apiId: 0,
        otherActions: [],
        eventActions: [],
        setData: {
            threshold: firstNonNull(agentConfig.setdataThreshold, getConfStorage(TY_SETDATA_THRESHOLD), DEFAULT_SETDATA_STUCK_THRESHOLD),
            setDataTrace: firstNonNull(agentConfig.setdataTrace, getConfStorage(TY_SETDATA_TRACE), DEFAULT_SETDATA_TRACE),
            setDataTraceHint: firstNonNull(agentConfig.setdataTraceHint, getConfStorage(TY_SETDATA_TRACEHINT), DEFAULT_SETDATA_TRACE_HINT),
            setDataTimeInterval: firstNonNull(agentConfig.setdataTimeInterval, getConfStorage(TY_SETDATA_TIME_INTERVAL), DEFAULT_SETDATA_TIME_INTERVAL),
            stuck: false,
            max: 0,
            currentSegmentTime: 0,
            data: {},
            requestBridge: []
        },
        reqStat: {
            currentSegmentTime: 0,
            data: {}
        },
        lastSetDataInOnReady: 0,
        stuck: false,
        jsError: false,
        netError: false,
        recordFirstLoad: false
    };
}

function genPageDeferredDataTemplate() {
    return {
        stuck: false,
        firstLoad: 0,
        jsError: false,
        netError: false
    };
}

let pageEvent = {};
let pageErrs = [];
let pageCustomTime = 0;
let path = {}; //prev, current
let pageData = genPageDataTemplate();
// 页面延时数据
let pageDeferredData = genPageDeferredDataTemplate();

let pageStatus = {
    canSend: false,
    sent: false,
    apiRemain: 0,
    needClearDeferredData: false
};

function clearData() {
    // clear data
    pageEvent = {};
    pageErrs = [];
    pageCustomTime = 0;
    pageStatus.apiRemain = 0;
    pageData = genPageDataTemplate();

    pageStatus.needClearDeferredData = true;
}

function clearPageDeferredData() {
    pageDeferredData = genPageDeferredDataTemplate();
}

function addAction(action) {
    if(!pageData.eventActions) {
        pageData.eventActions = [];
    }
    if(!pageData.otherActions) {
        pageData.otherActions = [];
    }
    if (action) {
        if (action.type === ACTION_TYPE_EVENT) {
            // 超过event最大数量删除最先加入的event
            const EVENT_MAX_SIZE = (agentConfig && agentConfig.eventMaxSize) || DEFAULT_EVENT_MAX_SIZE;
            if(pageData.eventActions && pageData.eventActions.length >= EVENT_MAX_SIZE) {
                pageData.eventActions.shift();
            }
            pageData.eventActions.push(action);
        }else {
            pageData.otherActions.push(action);
        }
    }
}

function addStatData(dataList, data) {
    for (const key in data) {
        if (data.hasOwnProperty(key) && data[key] && data[key].count > 0) {
            dataList.push(Object.assign(data[key] || {}, {timestamp: +key}));
        }
    }
}

function composePageMetricData() {
    const setData = [];
    const reqStat = [];
    addStatData(setData, pageData.setData.data);
    addStatData(reqStat, pageData.reqStat.data);
    const metricData = {
        metric: {
            jsError: pageErrs && pageErrs.length > 0,
            netError: pageData.netError,
            stuck: pageData.stuck
        }
    };
    if (setData.length > 0) {
        metricData.setData = {
            threshold: firstNonNull(pageData.setData.threshold, DEFAULT_SETDATA_STUCK_THRESHOLD),
            setDataTrace: firstNonNull(pageData.setData.setDataTrace, DEFAULT_SETDATA_TRACE),
            setDataTraceHint: firstNonNull(pageData.setData.setDataTraceHint, DEFAULT_SETDATA_TRACE_HINT),
            setDataTimeInterval: firstNonNull(pageData.setData.setDataTimeInterval, DEFAULT_SETDATA_TIME_INTERVAL),
            max: pageData.setData.max,
            requestBridge: pageData.setData.requestBridge,
            data: setData
        };
    }
    if (reqStat.length > 0) {
        metricData.reqStat = reqStat;
    }
    if (pageEvent.onLoad) {
        let firstLoadTimeStamp = pageData.lastSetDataInOnReady;
        if (!firstLoadTimeStamp) {
            firstLoadTimeStamp = pageEvent.onReady;
        }
        if (firstLoadTimeStamp) {
            let firstLoad = firstLoadTimeStamp - pageEvent.onLoad;
            firstLoad = firstLoad > 0 ? firstLoad : 0;
            metricData.metric.firstLoad = firstLoad;
        }
    }
    // assign pageDeferred Data
    pageDeferredData = metricData.metric;

    return metricData;
}

function recordTyData() {
    pageCustomTime = now();
}

const DEFAULT_INFO = {
    uid: getStorageUUID(),
    sid: UUID(),
    v: "1.3.7",
    at: "wx"
};

function getStorageUUID() {
    let uid = getStorageSync(TINGYUN_UID);
    if (!uid) {
        uid = UUID();
        setStorageSync(TINGYUN_UID, uid);
    }
    return uid;
}

function sendAppData(params) {
    if(!isCollect) {
        return;
    }
    const data = Object.assign({}, DEFAULT_INFO, sysInfo || {}, {key: agentConfig.key}, params || {});
    data.launch = !params;
    if (data.launch) {
        // 启动参数
        data.launchOptions = appData.launchOptions; 
    }
    MP_GLOBAL.request({
        url: `${agentConfig.beacon}/mp-app`,
        data: data,
        method: 'POST',
        _no_record: true,
        success: function () {

        }
    });
}

function sendPageCombineData(trigger) {
    if(!isCollect) {
        return;
    }
    if(TRIGGER_LIFECYCLE === trigger) {
        pageStatus.canSend = true;
    }
    if(!pageStatus.sent && pageStatus.canSend) {
      //combine Data
      const pageCombineData = Object.assign({}, {
            path: path.current,
            pageEvent: Object.assign({}, pageEvent),
            errs: pageErrs.slice(),
            fromPath: path.prev || '',
            actions: (pageData.eventActions || []).concat(pageData.otherActions || [])
        },
        Object.assign({}, DEFAULT_INFO, sysInfo || {}, {key: agentConfig.key}),
        pageCustomTime > 0 ? {ct: pageCustomTime}: {},
        composePageMetricData()
      );
      // set route chain
      let routeChain = getRouteChain();
      if(routeChain) {
          pageCombineData.routeTrack = routeChain;
      }

      MP_GLOBAL.request({
        url: `${agentConfig.beacon}/mp-page`,
        data: pageCombineData,
        method: 'POST',
        _no_record: true,
        success: function () {

        }
      });

      // 清空数据
      clearData();
      pageStatus.sent = true;
      pageStatus.canSend = false;

    }
}

function onLaunch(options) {
    calcIfCollect();
    const { path, query, scene} = options;
    sysInfo.openPath = path;
    if (!agentConfig.disableFetchQuery) {
        sysInfo.query = query;
    }
    sysInfo.scene = scene;
    appData.launchOptions = options;

    /**网络类型获取 */
    MP_GLOBAL.getNetworkType({
        success: function (res) {
            // 返回网络类型, 有效值：
            // wifi/2g/3g/4g/unknown(Android下不常见的网络类型)/none(无网络)
            sysInfo.networkType = res.networkType;
        },
        complete: function () {
            sendAppData();
        }
    });
}

function onError(err) {
    let stack = '';
    let msg = '';
    if (isString(err)) {
        stack = err;
    } else if(err) {
        stack = err.stack;
        msg = err.message;
    }
    if(stack) {
        const errorObj = {
            time: now(),
            stack: stack
        };
        if(msg) {
            errorObj.msg = msg;
        }
        pageErrs.push(errorObj);
    }
}

function onHide() {
    let routeTrack = getRouteChain();
    clearRouteChain();
    let closePath = path.current;
    // clear path status
    path.prev = '';
    path.current = '';
    sendAppData({
        routeTrack,
        closePath,
        metric: pageDeferredData
    });
}

function compareVersion(v1, v2) {
    v1 = v1.split('.');
    v2 = v2.split('.');
    const len = Math.max(v1.length, v2.length);

    while (v1.length < len) {
        v1.push('0');
    }
    while (v2.length < len) {
        v2.push('0');
    }

    for (let i = 0; i < len; i++) {
        const num1 = parseInt(v1[i]);
        const num2 = parseInt(v2[i]);

        if (num1 > num2) {
            return 1;
        } else if (num1 < num2) {
            return -1;
        }
    }

    return 0;
}

function canAutoHook() {
    return  compareSysSDKVersion(sysInfo, PLUGIN_FREE_VERSION) >= 0 
}

function compareSysSDKVersion(sysInfo, v2) {
    let v1 = '';
    if(sysInfo && sysInfo.system) {
        v1 = sysInfo.system.SDKVersion;
    }
    if (!v1 || !v2) {
        return -1;
    }else {
        return compareVersion(v1, v2);
    }
}

const APP_ORIGINAL_HOOKS = [
    {
        name: 'onLaunch',
        handler: onLaunch
    },
    {
        name: 'onError',
        handler: onError
    },
    {
        name: 'onHide',
        handler: onHide
    }
];

function wrapApp(options) {
    APP_ORIGINAL_HOOKS.forEach(hook => {
        lifeCycleHook(hook, options);
    });
    return options;
}

function wrapAppApi(options) {
    if(canAutoHook() || !isInit()) {
        return options;
    }else {
        return wrapApp.apply(this, arguments);
    }
}

function hookApp() {
    /**
     * hook App
     */
    const originalApp = App;
    App = function (options) {
        options = wrapApp(options);
        if (originalApp) {
            return originalApp.call(this, options);
        }
    };
}

function isPage(page) {
    if (agentConfig.ignoredPages && isArray(agentConfig.ignoredPages)) {
        return agentConfig.ignoredPages.indexOf(page) < 0;
    } else if(agentConfig.pages && isArray(agentConfig.pages)) {
        return agentConfig.pages.indexOf(page) > -1;
    } else {
        return true;
    }
}

/**
 * @param  {} route 页面路径
 * @param  {} param 页面参数对象
 */
function getPageName(route, param) {
    if (!isObject(param)) {
        return route;
    }

    try {
        const paramStr = Object.keys(param).map(key => `${key}=${param[key]}`).join('&');
        if (paramStr) {
            route += `?${paramStr}`;
        }
    }catch (e) {}
    
    return route;
}

function hookSetData() {
    const originSetData = this.setData;

    const setDataThreshold = pageData.setData.threshold;
    const setDataTrace = pageData.setData.setDataTrace;
    const setDataTraceHint = pageData.setData.setDataTraceHint;
    const setDataTimeInterval = pageData.setData.setDataTimeInterval;

    this.setData = function () {
        const data = arguments[0];
        const originalCallback = arguments[1];
        const start = now();
        const store = {
            start: start
        };
        // 计算本条setData是否需要计算首次加载指标, 如果setData在onReady结束前触发, 或其上层的请求在onReady结束前触发, 此时计算
        const context = appData.context;
        const requestBeforeOnReadyEnd = context && context.type === ACTION_TYPE_REQUEST && context.data && context.data.recordFirstLoad;
        if (pageData.recordFirstLoad || requestBeforeOnReadyEnd) {
            store.calcFirstLoad = true;
        }
        try {
            const currentSegmentTime = pageData.setData.currentSegmentTime;
            if (start - currentSegmentTime > 1000) {
                pageData.setData.currentSegmentTime = start;
                pageData.setData.data[start] = {
                    count: 0,
                    grade: {
                        good: {
                            count: 0
                        },
                        normal: {
                            count: 0
                        },
                        bad: {
                            count: 0
                        }
                    },
                    traces: []
                };
                store.segmentTime = start;
            } else {
                store.segmentTime = currentSegmentTime;
            }
        }catch (e) {}

        const callback = (function() {
            return function () {
                try {
                    store.end = now();
                    if (store.calcFirstLoad && store.end > pageData.lastSetDataInOnReady) {
                        pageData.lastSetDataInOnReady = store.end;
                    }
                    store.duration = store.end - store.start;
                    const segmentData = pageData.setData.data[store.segmentTime];
                    segmentData.count++;
                    if (store.duration > pageData.setData.max) {
                        pageData.setData.max = store.duration;
                    }
                    // 计算区间次数
                    if (store.duration > setDataTimeInterval[1]) {
                        segmentData.grade.bad.count++;
                    }else if (store.duration > setDataTimeInterval[0]) {
                        segmentData.grade.normal.count++;
                    }else {
                        segmentData.grade.good.count++;
                    }
                    // 判断是否超出阈值, 超出阈值记录trace数据
                    // if (requestBeforeOnReadyEnd)
                    if (store.duration > setDataThreshold) {
                        if (!pageData.stuck) {
                            pageData.stuck = true;
                        }
                        if (segmentData.traces.length < SETDATA_TRACE_COUNT && setDataTrace) {
                            try {
                                const parsed = safeStringifyJSON(data, true);
                                const traceRecord = {
                                    timestamp: store.start,
                                    duration: store.duration,
                                    size: parsed.value.length
                                };
                                if (setDataTraceHint) {
                                    traceRecord.hint = parsed.value.substring(0, 200);
                                }
                                if (parsed.error) {
                                    traceRecord.error = parsed.error;
                                }
                                segmentData.traces.push(traceRecord);
                            }catch (e) {}
                        }
                    }

                    if (requestBeforeOnReadyEnd) {
                        pageData.setData.requestBridge.push({
                            start: store.start,
                            end: store.end,
                            requestId: context.data.requestId,
                            url: context.data.url
                        });
                    }
                }catch (e) {}

                return originalCallback && originalCallback.apply(this, arguments);
            }
        })();
        return originSetData.call(this, arguments[0], callback);
    };
}

function onLoad() {
    if(!isPage(this.route)) {
        return;
    }
    if (pageStatus.needClearDeferredData) {
        clearPageDeferredData();
        pageStatus.needClearDeferredData = false;
    }
    // begin record firstLoad
    pageData.recordFirstLoad = true;

    hookSetData.call(this);
    pageEvent.onLoad = now();
    // 存储参数
    this[PAGE_NAME_VARIABLE] = getPageName(this.route, arguments[0]);
}

function onShow() {
    if(!isPage(this.route)) {
        return;
    }
    if (pageStatus.needClearDeferredData) {
        clearPageDeferredData();
        pageStatus.needClearDeferredData = false;
    }
    pageEvent.onShow = now();
    // add to route chain
    const pageName = this[PAGE_NAME_VARIABLE] || this.route;
    addRoute(pageName);
    path.prev = path.current;
    path.current = pageName;

    pageStatus.sent = false;
}

function onReady() {
    if(!isPage(this.route)) {
        return;
    }
    pageEvent.onReady = now();
}

function afterOnReady() {
    if(!isPage(this.route)) {
        return;
    }
    pageData.recordFirstLoad = false;
}

function onHide$1() {
    if(!isPage(this.route)) {
        return;
    }
    pageEvent.onHide = now();
    //send page data
    sendPageCombineData(TRIGGER_LIFECYCLE);
}

function onUnload() {
    if(!isPage(this.route)) {
        return;
    }
    pageEvent.onUnload = now();
    //send page data
    sendPageCombineData(TRIGGER_LIFECYCLE);
}

const PAGE_ORIGINAL_HOOKS = [
    {
        name: 'onLoad',
        handler: onLoad
    },
    {
        name: 'onShow',
        handler: onShow
    },
    {
        name: 'onReady',
        handler: onReady,
        afterHandler: afterOnReady
    },
    {
        name: 'onHide',
        handler: onHide$1
    },
    {
        name: 'onUnload',
        handler: onUnload
    }
];

function methodHook(options, handler) {
    for (let field in options) {
        if(options.hasOwnProperty(field) && isFunction(options[field]) && !options[field]._ty_hook && isFunction(handler)) {
            const originalMethod = options[field];
            options[field] = handler.call(this, field, originalMethod);
            options[field]._ty_hook = true;
        }
    }
}

const FIELDS = [ACTION_TYPE_REQUEST, ACTION_TYPE_API, ACTION_TYPE_TIMER];
function initRemainObject() {
    const remain = {};
    FIELDS.forEach(field => {
        remain[field] = {
            current: 0,
            children: 0
        };
    });
    return remain;
}

/**
 * 关联Children context下层的数据
 * @param targets
 * @param childContext
 */
function assignChildContext(targets, childContext) {
    for (let i = 0; i < targets.length; i++) {
        if (targets[i].cid === childContext.id) {
            if (childContext.requests && childContext.requests.length > 0) {
                targets[i].requests = childContext.requests;
            }
            if (childContext.apis && childContext.apis.length > 0) {
                targets[i].apis = childContext.apis;
            }
            break;       
        }  
    }
}
/**
 * Context
 * @param  {} options
 * options.parent 父级context
 * options.name context名称
 * options.type 类型
 * options.subType 子类型
 * options.data context数据
 */
function Context(options) {
    if (!options) {
        options = {};
    }
    // id 标识
    this.id = ++pageData.uniqueId;
    // 父级context
    this.parent = options.parent || null;
    // 作用域名称: 默认为根节点
    this.name = options.name || '<root>';
    this.type = options.type || ACTION_TYPE_EVENT;
    // 事件子类型
    this.subType = this.type === ACTION_TYPE_EVENT ? (options.subType || 'tap') : options.subType;
    // 作用域中的requests
    this.requests = [];
    // 作用域中接口调用
    this.apis = [];

    // 作用域剩余对象
    this.remain = initRemainObject();

    // 事件开始时间
    this.s = now();
    // 事件结束时间
    this.e = null;
    // 节点数据信息
    this.data = options.data;

    const self = this;

    // 顶层超时自动结束
    if (this.parent == null) {
        const EVENT_TIME_OUT = (agentConfig && agentConfig.eventTimeout) || DEFAULT_EVENT_TIME_OUT;
        this.i = setTimeout(function () {
            self.timeout();
        }, EVENT_TIME_OUT);
    }
    
    // ========= others ==============
    // 标志此事件是否已被结束, 已经结束的事件不需要再次调用
    this.closed = false;
    // 记录事件触发时所在页面的path
    this.path = path.current;
    // 记录事件触发时所在页面的fromPath
    this.prevPath = path.prev;
    // 标记context数据是否已经完全赋值
    // this.dataComposed = options.dataComposed || false;
}

// 结束一个作用域, 某个作用域结束时，会依次寻找上层的父级作用域尝试结束
Context.prototype.end = function(childContext, isTimeout) {
    if(this.closed) {
        // console.warn('Current context is already closed');
        return;
    }
    if(childContext) {
        const items = this.getItemsByType(childContext.type);
        if (items && items.length > 0) {
            assignChildContext(items, childContext);
        }
        this.updateRemain(-1, childContext.type);
    }

    if(this.isNoRemain() || isTimeout) {
        // console.debug('Context: ', this.name, 'will close soon, name:', this.name);
        this.e = now();
        this.closed = true;
        this.i && clearTimeout(this.i);
        if(this.parent) {
            this.parent.end(this);
        }else {
            // 构造一条event数据
            const event = this.composeActionData();
            // 存储到全局event数组
            addAction(event);
            appData.context = null;
        }
    }
};

Context.prototype.getItemsByType = function(type) {
    let items;
    if (type === ACTION_TYPE_REQUEST) {
        items = this.requests;
    } else if (type === ACTION_TYPE_API) {
        items = this.apis;
    }
    return items;
};
/**
 * 检测是否已经没有剩余作用域
 * @param testCurrent 只检测当前作用域
 * @returns {boolean}
 */
Context.prototype.isNoRemain = function(testCurrent) {
    let noRemain = true;
    for (let field in this.remain) {
        if(this.remain.hasOwnProperty(field)) {
            const fieldNoRemain = this.remain[field].current <= 0 && (!testCurrent ? this.remain[field].children <= 0 : true);
            if (!fieldNoRemain) {
                noRemain = false;
                break;
            }
        }
    }
    return noRemain;
};

// 超时: 设置超时时间
Context.prototype.timeout = function() {
    this.end(null, true);
};

Context.prototype.setData = function(data) {
    this.data = data;
};

Context.prototype.hasPrevAssignedData = function() {
    return (this.requests && this.requests.length > 0) || (this.apis && this.apis.length > 0);
};

// 组装action数据
Context.prototype.composeActionData = function() {
    let eventData = {
        id: this.id,
        name: this.name,
        type: this.type,
        start: this.s,
        end: this.e,
        duration: this.e - this.s > 0 ? this.e - this.s : 0,
        path: this.path,
        prevPath: this.prevPath
    };
    if (this.requests && this.requests.length > 0) {
        eventData.requests = this.requests.slice();
    }
    if (this.apis && this.apis.length > 0) {
        eventData.apis = this.apis.slice();
    }
    if (this.data) {
        eventData.data = this.data;
    }
    if(this.type === ACTION_TYPE_REQUEST || this.type === ACTION_TYPE_API) {
        eventData = Object.assign({}, eventData, this.data);
        delete eventData['data'];
        if (this.type === ACTION_TYPE_REQUEST) {
            delete eventData['name'];
        }
    }
    return eventData;
};

Context.prototype.canEnd = function() {
    return this.isNoRemain(true);
};

Context.prototype.isEventChildContext = function() {
    let context = this.parent;
    let isEvent = false;
    while(context != null) {
        if(context.type === ACTION_TYPE_EVENT) {
            isEvent = true;
            break;
        }
        context = context.parent;
    }
    return isEvent;
};

/**
 * 修改剩余数量
 * @param value
 * @param type
 */
Context.prototype.updateRemain = function(value, type) {
    if(!type) {
        type = ACTION_TYPE_REQUEST;
    }
    const modifyValue = value || 0;
    this.remain[type].current = this.remain[type].current + modifyValue;
    let parent = this.parent;
    while (parent) {
        parent.remain[type].children  = parent.remain[type].children + modifyValue;
        parent = parent.parent;
    }
};

Object.defineProperty(Context.prototype, "current", {
    get: function () {
        return appData.context;
    },
    enumerable: true,
    configurable: true,
});

const EVENTNAME = 'tyname';

function checkIsIgnoreMethod(event) {
    return !event || event.type !== 'tap' || !isObject(event.target) || !isObject(event.currentTarget) || event.timeStamp == null;
}

function methodWrapperBefore(event, methodName) {
    const {offsetLeft, offsetTop, id, dataset} = event.target || {};
    const {x, y} = event.detail || {};
    // _relatedInfo is deprecated
    let targetName;
    if(event._relatedInfo) {
        targetName = event._relatedInfo.anchorTargetText;
    }
    const eventData = {
        target: {offsetLeft, offsetTop, id, x, y},
        dataset: {
            name: dataset[EVENTNAME],
            targetName: targetName,
            methodName: methodName
        }
    };

    const eventName = methodName || '';
    // create event context
    appData.context = new Context({
        name: eventName,
        type: ACTION_TYPE_EVENT,
        subType: event.type,
        data: eventData,
        // dataComposed: true
    });
}


function methodWrapperAfter() {
    if(appData.context && appData.context.canEnd()) {
        appData.context.end();
    }
    // 方法结束后清空全局作用域
    // 如果不清空，可能导致顶级请求或api关联到错误的点击事件
    appData.context = null;
}

function methodWrapper(methodName, originalMethod) {
    return function () {
        let result;
        // before run original callback (begin Context)
        const event = arguments[0] || {};
        const isNormalMethod = checkIsIgnoreMethod(event);
        if(!isNormalMethod) {
            try {
                methodWrapperBefore.call(this, event, methodName);
            }catch(e) {}
        }
        // run original method
        try {
            result = originalMethod.apply(this, arguments);
        }finally {
            if(!isNormalMethod) {
                // after run original callback (end Context)
                try {
                    methodWrapperAfter.call(this);
                }catch(e){}
            }
        }

        return result;
    }
}


/**
 * 对于异步回调函数, 需要暂存调用时的context。
 * 在回调真正被触发时，暂存当前context, 切换回之前注册回调函数的context去执行回调, 执行完毕之后再切换回当前的context
 *
 * @param original
 * @returns {__mp_async_wrapper}
 */
function wrapAsync(original) {
    const context = appData.context;
    return function __mp_async_wrapper() {
        let result;
        appData.context = context;
        try {
            result = original.apply(this, arguments);
        }finally {
            appData.context = null;
        }
        return result;
    };
}

function wrapPage(options) {
    // hook lifecycle
    PAGE_ORIGINAL_HOOKS.forEach(hook => {
        lifeCycleHook(hook, options);
    });
    // hook methods
    methodHook(options, methodWrapper);
    options[PAGE_TY_DATA] = recordTyData;
    return options;
}

function wrapPageApi(options) {
    if(canAutoHook() || !isInit()) {
        return options;
    }else {
        return wrapPage.apply(this, arguments);
    }
}

/**
 * Hook Page
 */
function hookPage() {
    const originalPage = Page;
    Page = function (options) {
        options = wrapPage(options);
        if (originalPage) {
            return originalPage.call(this, options);
        }
    };
}

function beforeCallbackRun(store) {
    appData.context = store.context;
}

function afterCallbackRun() {
    const contextCanEnd = appData.context && appData.context.canEnd();
    if(contextCanEnd) {
        appData.context.end();
    }
}

// original request
const originRequest = MP_GLOBAL.request;

/**
 * GET server response header
 * @param {*} header
 * @param {*} rand randNumber to tag a request
 */
function getTingyunTxData(header, rand) {
    if (!header) {
        return null;
    }
    let txData = null;
    {
        const serverHeaderData =  safeParseJSON(header['X-Tingyun-Tx-Data']);
        if (serverHeaderData && serverHeaderData.r && toString(serverHeaderData.r) === toString(rand)) {
            txData = serverHeaderData;
        }
    }
    return txData;
}

function setServerHeader(config, store) {
    if (!agentConfig.id) {
        return;
    }
    {
        config.header['X-Tingyun-Id'] = `${agentConfig.id};r=${store.r}`;
    }
}

/**
 * Get 'Content-Length' response header
 * @param {*} header
 */
function getContentLength(response) {
    if(!response) {
        return 0;
    }
    const {header, data} = response;
    let contentLength = 0;
    contentLength = +(header && header['Content-Length']);
    if(!contentLength || !isNumber(contentLength) || Number.isNaN(contentLength)) {
        contentLength = size(data) || 0;
    }
    return contentLength;
}

/**
 * 获取server 返回数据
 * @param response
 * @param store
 */
function getServerData(response, store) {
    let serverData = {};
    const data = getTingyunTxData(response.header, store.r);
    if (data) {
        {
            serverData.s_id = data['id'];
            serverData.s_name = data['action'];
            if (data.time) {
                serverData.s_du = data.time['duration'];
                serverData.s_qu = data.time['qu'];
            }
            serverData.t_id = data['trId'];
        }
    }

    return serverData;
}

function composeData(store, config, response) {
    return {
        requestId: store.requestId,
        type: ACTION_TYPE_REQUEST,
        url: store.url,
        method: store.method,
        start: store.start,
        end: store.end,
        cbTime: store.cbTime,
        duration: store.end - store.start > 0 ? store.end - store.start : 0,
        send: size(config.data),
        rec: getContentLength(response),
        statusCode: store.statusCode || 0,
        failMessage: store.failMessage || '',
        cid: store.cid
    };
}
/**
 * 创建request context, 绑定request数据到context
 * @param  {} store 请求存储对象
 * @param  {} prevContext 上级context
 */
function initRequestContext(store, prevContext) {
    if(!store.context) {
        // 创建回调作用域
        const requestContextName = `${store.url}-${store.requestId}`;
        store.context = new Context({
            parent: prevContext,
            name: requestContextName,
            type: ACTION_TYPE_REQUEST,
            data: store.data
        });
    }
}

const request = function mpRequest() {
    const config = arguments[0] || {};
    if (!config._no_record && config.url && isInit()) {
        // 统计每秒的请求调用次数
        const start = now();
        let currentSegmentTime = pageData.reqStat.currentSegmentTime;
        if (start - currentSegmentTime > 1000) {
            currentSegmentTime = start;
            pageData.reqStat.currentSegmentTime = start;
            pageData.reqStat.data[start] = {
                count: 0
            };
        }
        pageData.reqStat.data[currentSegmentTime].count++;

        // ====== 作用域相关初始化 BEGIN =======
        const prevContext = appData.context;
        const store = {
            requestId: ++pageData.requestId,
            url: config.url,
            method: config.method && config.method.toUpperCase() || 'GET',
            // 是否已经创建了上下文对象
            callbackContextCreated: false,
            cbTime: 0,
            recordFirstLoad: pageData.recordFirstLoad,
            // 请求数据
            data: {}
        };
        store.data = {
            url: store.url,
            requestId: store.requestId,
            recordFirstLoad: store.recordFirstLoad
        };
        // 初始化请求作用域
        initRequestContext(store, prevContext);
        if (store.context) {
            // store.context.setData(store.data);
            store.cid = store.context.id;
        }
        // ====== 作用域相关初始化 END =======

        // 随机标志位
        store.r = now() % 1e9;
        // set request header for server
        config.header = config.header || {};
        // 设置与server交互的请求头
        setServerHeader(config, store);

        // original callbacks...
        const originSuccess = config.success;
        const originFail = config.fail;
        const originComplete = config.complete;

        //callback time: (success + complete) or (fail + complete) runtime
        config.success = wrapAsync(function () {
            let result;
            if (!store.end) {
                store.end = now();
            }
            beforeCallbackRun(store);
            if (originSuccess) {
                const cbStart = now();
                try {
                    result = originSuccess.apply(this, arguments);
                } finally {
                    const successCbTime = now() - cbStart;
                    if (successCbTime > 0) {
                        store.cbTime += successCbTime;
                    }
                }
            }
            return result;
        });
        config.fail = wrapAsync(function () {
            let result;
            if (!store.end) {
                store.end = now();
            }
            beforeCallbackRun(store);
            if (originFail) {
                const cbStart = now();
                try {
                    result = originFail.apply(this, arguments);
                } finally {
                    const failCbTime = now() - cbStart;
                    if (failCbTime > 0) {
                        store.cbTime += failCbTime;
                    }
                }
            }
            return result;
        });
        //add network info in complete
        config.complete = wrapAsync(function (response) {
            let result;
            //calculate callback time
            if (!store.end) {
                store.end = now();
            }
            store.statusCode = getStatusCode(response);
            // custom code begin
            let customCodeRes;
            const customCodeFunc = agentConfig[CUSTOM_CODE_FUNC];
            if(customCodeFunc && isFunction(customCodeFunc)) {
                try {
                    const codeRes = customCodeFunc.apply(this, arguments);
                    if(isObject(codeRes)) {
                        customCodeRes = {custom: codeRes};
                    }
                }catch (e) {}
            }
            // custom code end

            beforeCallbackRun(store);

            // run original complete
            if (originComplete) {
                const cbStart = now();
                try {
                    result = originComplete.apply(this, arguments);
                } finally {
                    const completeCbTime = now() - cbStart;
                    if (completeCbTime > 0) {
                        store.cbTime += completeCbTime;
                    }
                }
            }

            let res = response;
            if (!res) {
                res = {};
            }
            let currentRequestError = false;
            // 标识网络错误
            if (res.statusCode >= 400 && (agentConfig.ignoreErrorCodes || []).indexOf(res.statusCode) < 0) {
                // http 状态码错误
                currentRequestError = true;
                const {data} = res;
                store.failMessage = safeStringify(data, agentConfig.requestFailMessageSize);
            } else if (res.errMsg && !res.statusCode) {
                // 尝试获取错误信息
                currentRequestError = true;
                store.failMessage = res.errMsg.substring(0, agentConfig.requestFailMessageSize);
            }

            if (currentRequestError && !pageData.netError) {
                pageData.netError = true;
            }

            const serverData = getServerData(res, store);
            const storeData = composeData(store, config, res);
            // if (store.context) {
            //     store.context.dataComposed = true;
            // }
            Object.assign(store.data, storeData, serverData || {}, customCodeRes || {});


            // after callback runs ...
            afterCallbackRun();

            return result;
        });

        // 记录请求开始时间点
        store.start = start;

        // action handler begin
        // get current context
        if(prevContext) {
            prevContext.updateRemain(1);
            prevContext.requests.push(store.data);
        }
        // action handler end
    }

    // network request begin
    return originRequest.apply(this, arguments);
};

function hookNetwork() {
    Object.defineProperty(MP_GLOBAL, 'request', {
        configurable: true,
        enumerable: true,
        writable: true,
        value: request
    });
}

function wrapComponent(options) {
    if(!options.methods) {
        options.methods = {};
    }
    PAGE_ORIGINAL_HOOKS.forEach(hook => {
        lifeCycleHook(hook, options.methods);
    });
    methodHook(options.methods, methodWrapper);
    return options;
}

function wrapComponentApi(options) {
    if(canAutoHook() || !isInit()) {
        return options;
    }else {
        return wrapComponent.apply(this, arguments);
    }
}

/**
 * Only hook page component.
 */
function hookComponent() {
    const originalComponent = Component;
    Component = function (options) {
        options = wrapComponent(options);
        if (originalComponent) {
            originalComponent.call(this, options);
        }
    };
}

function setUser(userId, metaObject) {
    sysInfo.uid = userId;
    setStorageSync(TINGYUN_UID, userId);
}

function getContext() {
    return appData.context;
}
const api = {
    version: "1.3.7",
    setUser: setUser,
    hookApp: wrapAppApi,
    hookPage: wrapPageApi,
    hookComponent: wrapComponentApi,
    request: request,
    getContext: getContext
};

let HOOK_APIS;
const HOOK_CALLBACKS = ['success', 'fail'];
const hookApiNames = [];

// A handler will replace the default behaviour of success/fail determination,
// by default, fail count plus one when 'fail' callback called, success count plus one when 'success' callback called.
const handler = {
    requestPayment: {
        fail: function () {
            // 识别取消
            const res = arguments && arguments[0];
            let fieldName = 'fail';
            if(res && isObject(res) && res.errMsg === 'requestPayment:fail cancel') {
                fieldName = 'cancel';
            }
            return fieldName;
        }
    }
};

function initHookApis() {
    HOOK_APIS = agentConfig.hookApis || getDafaultHookApis();

    HOOK_APIS.forEach(hookApi => {
        if(hookApiNames.indexOf(hookApi) > -1 || hookApi === 'request') {
            return;
        }
        hookApiNames.push(hookApi);
    });

}

function composeApiData(store) {
    return {
        apiId: store.apiId,
        type: ACTION_TYPE_API,
        name: store.name,
        success: store.success || 0,
        fail: store.fail || 0,
        cancel: store.cancel || 0,
        start: store.start,
        end: store.end,
        duration: store.end - store.start > 0 ? store.end - store.start : 0,
        count: 1,
        failMessage: store.failMessage || '',
        cid: store.cid
    };
}
/**
 * 创建api context, 绑定api数据到context
 * @param  {} store api存储对象
 * @param  {} prevContext 上级context
 */
function initApiContext(store, prevContext) {
    if(!store.context) {
        // 创建request作用域
        const apiContextName = `${store.name}-${store.apiId}`;
        store.context = new Context({
            parent: prevContext,
            name: apiContextName,
            type: ACTION_TYPE_API,
            data: store.data
        });
    }
}

/**
 * api wrapper
 * @param apiName
 * @returns {function(): *}
 */
function wrapApi(apiName) {
    const originalApi = MP_GLOBAL[apiName];
    return function () {
        const config = arguments[0] || {};

        // ======== 初始化api context BEGIN =========
        const prevContext = appData.context;   
        const store = {
            apiId: ++pageData.apiId,
            name: apiName,
            data: {}
        };
        initApiContext(store, prevContext);
        if (store.context) {
            // store.context.setData(store.data);
            store.cid = store.context.id;
        }
        // ======== 初始化api context END =========
        // callbacks begin...
        HOOK_CALLBACKS.forEach((field) => {
            config[field] = wrapAsync(hookBefore(config[field], function () {
                if(!store.end) {
                    store.end = now();
                }
                beforeCallbackRun(store);
                let fieldName;
                if(handler[apiName] && handler[apiName][field] && isFunction(handler[apiName][field])) {
                    fieldName = handler[apiName][field].apply(this, arguments);
                }else {
                    fieldName = field;
                }
                if(fieldName) {
                    store[fieldName] = 1;
                }
                if ('fail' === fieldName) {
                    const res = arguments && arguments[0];
                    store.failMessage = safeStringify(res, agentConfig.apiFailMessageSize);
                }
            }));
        });
        config['complete'] = wrapAsync(hookAround(config['complete'], function () {
            if(!store.end) {
                store.end = now();
            }
            beforeCallbackRun(store);
        }, function () {
            Object.assign(store.data, composeApiData(store));
            // if (store.context) {
            //     store.context.dataComposed = true;
            // }
            afterCallbackRun();
        }));
        // callbacks end

        if(prevContext) {
            prevContext.updateRemain(1, ACTION_TYPE_API);
            prevContext.apis.push(store.data);
        }
        store.start = now();
        return originalApi.apply(this, arguments);
    }
}

function hookApi(apiName) {
    if(!apiName) {
        return;
    }
    const originalApi = MP_GLOBAL[apiName];
    if(originalApi) {
        Object.defineProperty(MP_GLOBAL, apiName, {
            configurable: true,
            enumerable: true,
            writable: true,
            value: wrapApi(apiName)
        });
    }
}

/**
 * 导出附加到探针对象上的方法
 */
function exportedMpApis() {
    if(!HOOK_APIS) {
        initHookApis();
    }
    const api = {};
    hookApiNames.forEach(apiName => {
        api[apiName] = wrapApi(apiName);
    });
    return api;
}

function hookApis() {
    if(!HOOK_APIS) {
        initHookApis();
    }
    hookApiNames.forEach(apiName => {
        hookApi(apiName);
    });
}

// 监听网络变化
MP_GLOBAL.onNetworkStatusChange(function (res) {
    sysInfo.networkType = res.networkType;
});

function bootstrap(plugin) {
    if(!plugin || canAutoHook()) {
        hookApp();
        hookPage();
        hookNetwork();
        {
            hookComponent();
        }
        hookApis();
    }

    // 为了兼容低版本SDK, 添加MP_GLOBAL[api]只要plugin : true就需要添加
    if(plugin) {
        // add All MP_GLOBAL api to ty api object
        Object.assign(api, exportedMpApis() || {});
    }
}

/**
 * init config
 * @param config
 */
function setConfig(config) {
    if(!isInit()) {
        setAgentConfig(config || {});
        setInit(true);
        // check Sampling at startup
        checkSampling();
        let plugin = true;
        if (agentConfig.plugin != null) {
            plugin = agentConfig.plugin;
        }
        bootstrap(plugin);
    }
}

function run() {
    api.config = setConfig;
    return api;
}

var index = run();

module.exports = index;
