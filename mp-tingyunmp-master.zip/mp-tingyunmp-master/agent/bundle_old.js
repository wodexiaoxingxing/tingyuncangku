// global agentConfig
let agentConfig = {};

function setAgentConfig(config) {
  agentConfig = config || {};
}

// 应用级别路由链
let appRouteChain = [];

let sysInfo = {
  networkType: "",
  system: {},
};

function addRoute(route) {
  appRouteChain.push(route);
}

function clearRouteChain() {
  appRouteChain = [];
}

function getRouteChain() {
  return appRouteChain.slice();
}

function isType(type) {
  return function (arg) {
    if (type === 'Array' && Array.isArray) {
      return Array.isArray(arg);
    }
    return Object.prototype.toString.call(arg) === "[object " + type + "]";
  }
}

var isString = isType('String');
var isArray = isType('Array');
var isFunction = isType('Function');
var isObject = isType('Object');

function hookBefore(originalHook, handler) {
  return function () {
    isFunction(handler) && handler.apply(this, arguments);
    isFunction(originalHook) && originalHook.apply(this, arguments);
  }
}

function lifeCycleHook(hook, options) {
  if (isObject(hook) && isFunction(hook.handler)) {
    const { name, handler } = hook;
    options[name] = hookBefore(options[name], handler);
  }
}

function now() {
  return +new Date;
}

/**
 * return page route array of current page
 */
function getPageRoutes() {
  return (getCurrentPages() || []).map(page => page.route);
}

function getPagePath() {
  let pageRoutes = getPageRoutes();
  return pageRoutes.length > 0 ? pageRoutes[pageRoutes.length - 1] : ''
}

/**
 * UUID.core.js: A small subset of UUID.js, the RFC-compliant UUID generator for JavaScript.
 *
 * @fileOverview
 * @author  LiosK
 * @version v3.3.0
 * @license The MIT License: Copyright (c) 2010-2016 LiosK.
 */
const UUID = (function () {
  /**
   * Returns an unsigned x-bit random integer.
   * @param {int} x A positive integer ranging from 0 to 53, inclusive.
   * @returns {int} An unsigned x-bit random integer (0 <= f(x) < 2^x).
   */
  function rand(x) { // _getRandomInt
    if (x < 0) return NaN;
    if (x <= 30) return (0 | Math.random() * (1 << x));
    if (x <= 53) return (0 | Math.random() * (1 << 30)) + (0 | Math.random() * (1 << x - 30)) * (1 << 30);
    return NaN;
  }

  /**
   * Converts an integer to a zero-filled hexadecimal string.
   * @param {int} num
   * @param {int} length
   * @returns {string}
   */
  function hex(num, length) { // _hexAligner
    let str = num.toString(16),
      i = length - str.length,
      z = "0";
    for (; i > 0; i >>>= 1, z += z) {
      if (i & 1) {
        str = z + str;
      }
    }
    return str;
  }

  /**
   * The simplest function to get an UUID string.
   * @returns {string} A version 4 UUID string.
   */
  return function () {
    return hex(rand(32), 8) // time_low
      + "-" + hex(rand(16), 4) // time_mid
      + "-" + hex(0x4000 | rand(12), 4) // time_hi_and_version
      + "-" + hex(0x8000 | rand(14), 4) // clock_seq_hi_and_reserved clock_seq_low
      + "-" + hex(rand(48), 12); // node
  };
})();

function parseJSON(data) {
  if (data && isString(data)) {
    return JSON.parse(data);
  }
  return data;
}

function safeParseJSON(json) {
  try {
    return parseJSON(json);
  } catch (e) { }
  return null;
}

function safeStringifyJSON(data) {
  let result = '';
  try {
    result = JSON.stringify(data);
  } catch (e) {
    result = '';
  }
  return result;
}

function toString(data) {
  return data + '';
}

function size(data) {
  if (!data) {
    return 0;
  }
  if (isObject(data)) {
    return safeStringifyJSON(data).length;
  }
  if (isString(data)) {
    return data.length;
  }
  if (data instanceof ArrayBuffer) {
    return data.byteLength;
  }
  if (data.length) {
    return data.length;
  }
  return 0;
}

let pageEvent = {};
let pageRequests = [];
let pageErrs = [];
let pageCustomTime = 0;
let path = {}; //prev, current
let apiData = {};
let pageStatus = {
  canSend: false,
  sent: false,
  apiRemain: 0
};

function clearData() {
  // clear data
  pageEvent = {};
  pageRequests = [];
  pageErrs = [];
  pageCustomTime = 0;
  apiData = {};
  pageStatus.apiRemain = 0;
}

// parse api data map to array
function composePageApiData() {
  let apis = [];
  if (apiData) {
    (Object.keys(apiData) || []).forEach(key => {
      const apiNameInfo = apiData[key] || {};
      const action = {
        type: 'api',
        name: key
      };
      for (let key in apiNameInfo) {
        if (apiNameInfo.hasOwnProperty(key)) {
          action[key] = apiNameInfo[key] || 0;
        }
      }
      apis.push(action);
    });
  }
  return apis;
}

function recordTyData() {
  pageCustomTime = now();
}

function addApiData(key, field, value) {
  if (!apiData[key]) {
    apiData[key] = {};
  }
  if (!apiData[key][field]) {
    apiData[key][field] = 0;
  }
  apiData[key][field] += value;
}

/**
 * Data
 */

const CHECK_SAMPLING_INTERVAL = 10 * 60 * 1000;
const TY_SAMPLING = 'TY_SAMPLING';
// 采样率
let sampling = wx.getStorageSync(TY_SAMPLING);
let isCollect = false;

function checkSampling(callback) {
  console.log('TINGYUN AGENT checking sampling');
  if (agentConfig.key && agentConfig.beacon) {
    wx.request({
      url: `${agentConfig.beacon}/mp-config/config/pullSampling?encodeMpId=${agentConfig.key}`,
      method: 'GET',
      _no_record: true,
      success: (result) => {
        const { code, data } = result.data || {};
        if (code === 200 && data) {
          sampling = data.sampling || 1;
          wx.setStorageSync(TY_SAMPLING, sampling);
        }
      },
      fail: () => {
        sampling = 1;
      },
      complete: () => {
        callback && callback(sampling);
      }
    });
  }
}

function calcIfCollect() {
  // if no sampling storage, use user setting
  if (sampling === '') {
    sampling = +agentConfig.sampleRate || 1;
    checkSampling();
  }
  const random = Math.random();
  isCollect = random <= sampling;
}

setInterval(checkSampling, CHECK_SAMPLING_INTERVAL);

function isPage(page) {
  if (agentConfig.pages && isArray(agentConfig.pages)) {
    return agentConfig.pages.includes(page);
  } else {
    return true;
  }
}

// ========== consts begin ======================
// Custom time api in Page instance
// usage: this.recordTyTime();
const PAGE_TY_DATA = "recordTyTime";
// tingyun uid storage
const TINGYUN_UID = "TINGYUN_UID";
const CUSTOM_CODE_FUNC = 'custom';
const TRIGGER_LIFECYCLE = 'TRIGGER_LIFECYCLE';
const TRIGGER_APIEND = 'TRIGGER_APIEND';

// ========== consts end =======================

wx.onNetworkStatusChange(function (res) {
  sysInfo.networkType = res.networkType;
});
/** Get system info */
sysInfo.system = wx.getSystemInfoSync();

const DEFAULT_INFO = {
  uid: getStorageUUID(),
  sid: UUID(),
  v: "1.2.0"
};

function getStorageUUID() {
  let uid = wx.getStorageSync(TINGYUN_UID);
  if (!uid) {
    uid = UUID();
    wx.setStorageSync(TINGYUN_UID, uid);
  }
  return uid;
}

function sendAppData(params) {
  if (!isCollect) {
    return;
  }
  const appData = Object.assign({}, DEFAULT_INFO, sysInfo || {}, { key: agentConfig.key }, params || {});
  appData.launch = !params;
  wx.request({
    url: `${agentConfig.beacon}/mp-app`,
    data: appData,
    method: 'POST',
    _no_record: true
  });
}

function sendPageData(trigger) {
  if (!isCollect) {
    return;
  }
  console.log('sending', trigger, pageStatus);
  if (TRIGGER_LIFECYCLE === trigger) {
    pageStatus.canSend = true;
  }
  if (!pageStatus.sent && pageStatus.apiRemain <= 0 && pageStatus.canSend) {
    //combine Data
    const pageData = Object.assign({}, {
      path: getPagePath(),
      pageEvent: Object.assign({}, pageEvent),
      requests: pageRequests.slice(),
      errs: pageErrs.slice(),
      fromPath: path.prev || '',
      actions: composePageApiData()
    },
      Object.assign({}, DEFAULT_INFO, sysInfo || {}, { key: agentConfig.key }),
      pageCustomTime > 0 ? { ct: pageCustomTime } : {}
    );

    // set route chain
    let routeChain = getRouteChain();
    if (routeChain) {
      pageData.routeChain = routeChain;
    }

    // 清空数据
    clearData();
    pageStatus.sent = true;
    pageStatus.canSend = false;

    wx.request({
      url: `${agentConfig.beacon}/mp-page`,
      data: pageData,
      method: 'POST',
      _no_record: true
    });
  }
}

function onLaunch(options) {
  calcIfCollect();
  const { path: path$$1, query, scene } = options;
  sysInfo.openPath = path$$1;
  sysInfo.query = query;
  sysInfo.scene = scene;

  /**网络类型获取 */
  wx.getNetworkType({
    success: function (res) {
      // 返回网络类型, 有效值：
      // wifi/2g/3g/4g/unknown(Android下不常见的网络类型)/none(无网络)
      sysInfo.networkType = res.networkType;
    },
    complete: function () {
      sendAppData();
    }
  });
}

function onError(err) {
  if (err) {
    const stacks = err.split(/\n/);
    const msg = stacks[2] || '';
    let filename = '';
    let lineno = 0;
    let colno = 0;
    stacks.every(stack => {
      const stackMesage = stack && stack.trim();
      if (stackMesage.indexOf('at ') === 0) {
        const beginIndex = stackMesage.indexOf('(');
        const endIndex = stackMesage.indexOf(')');
        if (beginIndex && endIndex) {
          let beginSplitIndex = beginIndex + 1;
          if (beginSplitIndex > endIndex) {
            beginSplitIndex = endIndex;
          }
          const filenameAndNo = stackMesage.substring(beginSplitIndex, endIndex);
          if (filenameAndNo) {
            const filenameAndNoParts = filenameAndNo.split(':');
            if (filenameAndNoParts && filenameAndNoParts.length > 2) {
              filename = (filenameAndNoParts.slice(0, filenameAndNoParts.length - 2) || []).join(':');
              lineno = +filenameAndNoParts[filenameAndNoParts.length - 2];
              colno = +filenameAndNoParts[filenameAndNoParts.length - 1];
            }
          }
          return false;
        }
      }
      return true;
    });
    if (!filename) {
      filename = getPagePath();
    }
    pageErrs.push({
      time: now(),
      msg: msg,
      filename: filename,
      lineno: lineno,
      colno: colno,
      stack: err
    });
  }
}

function onHide() {
  let routeChain = getRouteChain();
  clearRouteChain();
  let closePath = path.current;
  // clear path status
  path.prev = '';
  path.current = '';
  sendAppData({ routeChain, closePath });
}

const APP_ORIGINAL_HOOKS = [
  {
    name: 'onLaunch',
    handler: onLaunch
  },
  {
    name: 'onError',
    handler: onError
  },
  {
    name: 'onHide',
    handler: onHide
  }
];

function wrapApp(options) {
  APP_ORIGINAL_HOOKS.forEach(hook => {
    lifeCycleHook(hook, options);
  });
  return options;
}

function hookApp() {
  /**
   * hook App
   */
  const originalApp = App;
  App = function (options) {
    options = wrapApp(options);
    if (originalApp) {
      originalApp.call(this, options);
    }
  };
}

function onLoad() {
  if (!isPage(this.route)) {
    return;
  }
  pageEvent.onLoad = now();
}

function onShow() {
  if (!isPage(this.route)) {
    return;
  }
  pageEvent.onShow = now();
  // add to route chain
  addRoute(this.route);
  path.prev = path.current;
  path.current = this.route;

  pageStatus.sent = false;
}

function onReady() {
  if (!isPage(this.route)) {
    return;
  }
  pageEvent.onReady = now();
}

function onHide$1() {
  if (!isPage(this.route)) {
    return;
  }
  pageEvent.onHide = now();
  //send page data
  sendPageData(TRIGGER_LIFECYCLE);
}

function onUnload() {
  if (!isPage(this.route)) {
    return;
  }
  pageEvent.onUnload = now();
  //send page data
  sendPageData(TRIGGER_LIFECYCLE);
}

const PAGE_ORIGINAL_HOOKS = [
  {
    name: 'onLoad',
    handler: onLoad
  },
  {
    name: 'onShow',
    handler: onShow
  },
  {
    name: 'onReady',
    handler: onReady
  },
  {
    name: 'onHide',
    handler: onHide$1
  },
  {
    name: 'onUnload',
    handler: onUnload
  }
];

function wrapPage(options) {

  PAGE_ORIGINAL_HOOKS.forEach(hook => {
    lifeCycleHook(hook, options);
  });
  options[PAGE_TY_DATA] = recordTyData;
  return options;
}

/**
 * Hook Page
 */
function hookPage() {
  console.log('hook called');
  const originalPage = Page;
  Page = function (options) {
    console.log('it runs')
    options = wrapPage(options);
    if (originalPage) {
      originalPage.call(this, options);
    }
  };
}

// original request
const originRequest = wx.request;

/**
 * GET server response header
 * @param {*} header 
 * @param {*} rand randNumber to tag a request
 */
function getTingyunTxData(header, rand) {
  if (header) {
    var txData = safeParseJSON(header['X-Tingyun-Tx-Data']);
    if (txData && txData.r && toString(txData.r) === toString(rand)) {
      return txData;
    }
  }
  return null;
}

/**
 * Get 'Content-Length' response header
 * @param {*} header 
 */
function getContentLength(response) {
  if (!response) {
    return 0;
  }
  const { header, data } = response;
  let contentLength = 0;
  contentLength = header && header['Content-Length'];
  if (!contentLength) {
    contentLength = size(data) || 0;
  }
  return contentLength;
}

function request() {
  const config = arguments[0] || {};
  if (!config._no_record) {

    let r = now() % 1e9;
    config.header = config.header || {};
    config.header['X-Tingyun-Id'] = `${agentConfig.id};r=${r}`;

    let start;
    let end;
    // hook callbacks...
    let originSuccess;
    if (isFunction(config.success)) {
      originSuccess = config.success;
    }

    let originFail;
    if (isFunction(config.fail)) {
      originFail = config.fail;
    }

    let originComplete;
    if (isFunction(config.complete)) {
      originComplete = config.complete;
    }

    //callback time: success + complete or fail + complete
    let cbTime = 0;
    config.success = function () {
      if (!end) {
        end = now();
      }
      if (originSuccess) {
        let cbStart = now();
        try {
          originSuccess.apply(this, arguments);
        } catch (e) { }
        let successCbTime = now() - cbStart;
        if (successCbTime > 0) {
          cbTime += successCbTime;
        }
      }
    };
    config.fail = function () {
      if (!end) {
        end = now();
      }
      if (originFail) {
        let cbStart = now();
        try {
          originFail.apply(this, arguments);
        } catch (e) { }
        let failCbTime = now() - cbStart;
        if (failCbTime > 0) {
          cbTime += failCbTime;
        }
      }
    };
    //add network info in complete
    config.complete = function (response) {
      // fail request, return
      if (!response.statusCode) {
        return;
      }
      //calculate callback time
      if (!end) {
        end = now();
      }
      let customCodeRes;
      const customCodeFunc = agentConfig[CUSTOM_CODE_FUNC];
      if (customCodeFunc && isFunction(customCodeFunc)) {
        try {
          const codeRes = customCodeFunc.apply(this, arguments);
          if (isObject(codeRes)) {
            customCodeRes = { custom: codeRes };
          }
        } catch (e) { }
      }
      if (originComplete) {
        let cbStart = now();
        try {
          originComplete.apply(this, arguments);
        } catch (e) { }
        let completeCbTime = now() - cbStart;
        if (completeCbTime > 0) {
          cbTime += completeCbTime;
        }
      }
      let serverConfig = {};
      const data = getTingyunTxData(response.header, r);
      if (data) {
        serverConfig.s_id = data['id'];
        serverConfig.s_name = data['action'];
        if (data.time) {
          serverConfig.s_du = data.time['duration'];
          serverConfig.s_qu = data.time['qu'];
        }
        serverConfig.t_id = data['trId'];
      }

      var reqInfo = {
        url: config.url,
        method: config.method && config.method.toUpperCase() || 'GET',
        start: start,
        end: end,
        cbTime: cbTime,
        duration: end - start,
        send: size(config.data),
        rec: getContentLength(response),
        statusCode: response.statusCode || 0,
      };

      pageRequests.push(Object.assign({}, reqInfo, serverConfig, customCodeRes || {}));
    };
    start = now();
  }

  // network request begin
  return originRequest.apply(this, arguments);
}

function hookNetwork() {
  Object.defineProperty(wx, 'request', {
    configurable: true,
    enumerable: true,
    writable: true,
    value: request
  });
}

function wrapComponent(options) {
  if (!options.methods) {
    options.methods = {};
  }
  PAGE_ORIGINAL_HOOKS.forEach(hook => {
    lifeCycleHook(hook, options.methods);
  });
  return options;
}
/**
 * Only hook page component.
 */
function hookComponent() {
  const originalComponent = Component;
  Component = function (options) {
    options = wrapComponent(options);
    if (originalComponent) {
      originalComponent.call(this, options);
    }
  };
}

let HOOK_APIS;
const HOOK_CALLBACKS = ['success', 'fail'];
const hookApiNames = [];

// A handler will replace the default behaviour of success/fail determination,
// by default, fail count plus one when 'fail' callback called, success count plus one when 'success' callback called.
const handler = {
  requestPayment: {
    fail: function () {
      // 识别取消
      const res = arguments && arguments[0];
      let fieldName = 'fail';
      if (res && isObject(res) && res.errMsg === 'requestPayment:fail cancel') {
        fieldName = 'cancel';
      }
      addApiData('requestPayment', fieldName, 1);
    }
  }
};

function initHookApis() {
  HOOK_APIS = agentConfig.hookApis || [
    'requestPayment',
    'scanCode',
    'previewImage'
  ];

  HOOK_APIS.forEach(hookApi => {
    if (hookApiNames.includes(hookApi) || hookApi === 'request') {
      return;
    }
    hookApiNames.push(hookApi);
  });

}
/**
 * api wrapper
 * @param apiName
 * @returns {function(): *}
 */
function wrapApi(apiName) {
  const originalApi = wx[apiName];
  return function () {
    addApiData(apiName, 'count', 1);
    pageStatus.apiRemain++;
    const config = arguments[0] || {};
    HOOK_CALLBACKS.forEach((field) => {
      config[field] = hookBefore(config[field], function () {
        if (handler[apiName] && handler[apiName][field] && isFunction(handler[apiName][field])) {
          handler[apiName][field].apply(this, arguments);
        } else {
          addApiData(apiName, field, 1);
        }
      });
    });
    config['complete'] = hookBefore(config['complete'], function () {
      pageStatus.apiRemain--;
      if (pageStatus.apiRemain <= 0) {
        sendPageData(TRIGGER_APIEND);
      }
    });
    return originalApi.apply(this, arguments);
  }
}

function hookApi(apiName) {
  if (!apiName) {
    return;
  }
  const originalApi = wx[apiName];
  if (originalApi) {
    Object.defineProperty(wx, apiName, {
      configurable: true,
      enumerable: true,
      writable: true,
      value: wrapApi(apiName)
    });
  }
}

/**
 * 导出附加到探针对象上的方法
 */
function exportedWxApis() {
  if (!HOOK_APIS) {
    initHookApis();
  }
  const api = {};
  hookApiNames.forEach(apiName => {
    api[apiName] = wrapApi(apiName);
  });
  return api;
}

function hookApis() {
  if (!HOOK_APIS) {
    initHookApis();
  }
  hookApiNames.forEach(apiName => {
    hookApi(apiName);
  });
}

let init = false;

function bootstrap(plugin) {
  if (!plugin) {
    hookApp();
    hookPage();
    hookNetwork();
    hookComponent();
    hookApis();
  } else {
    // add All wx api to ty api object
    Object.assign(api, exportedWxApis() || {});
  }
}

/**
 * init config
 * @param config
 */
function setConfig(config) {
  if (!init) {
    setAgentConfig(config || {});
    init = true;
    bootstrap(agentConfig.plugin);
  }
}

function setUser(userId, metaObject) {
  sysInfo.uid = userId;
  wx.setStorageSync(TINGYUN_UID, userId);
}

const api = {
  version: "1.2.0",
  setUser: setUser,
  config: setConfig,
  hookApp: wrapApp,
  hookPage: wrapPage,
  hookComponent: wrapComponent,
  request: request
};

function run() {
  return api;
}

var index = run();

module.exports = index;
