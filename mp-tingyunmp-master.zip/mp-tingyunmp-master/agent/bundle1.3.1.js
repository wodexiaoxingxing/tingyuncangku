function now() {
    return +new Date;
}

// 应用级别路由链

let appRouteTrack = [];
let appData = {
    context: null
};

let sysInfo = {
    networkType: "",
    system: {},
};

function addRoute(route) {
    appRouteTrack.push({
        timestamp: now(),
        route: route
    });
}

function clearRouteChain() {
    appRouteTrack = [];
}

function getRouteChain() {
    return appRouteTrack.slice();
}

function isType(type) {
    return function(arg) {
        if (type === 'Array' && Array.isArray) {
            return Array.isArray(arg);
        }
        return Object.prototype.toString.call(arg) === "[object " + type + "]";
    }
}

var isString = isType('String');
var isArray = isType('Array');
var isFunction = isType('Function');
var isObject = isType('Object');
var isNumber = isType('Number');

function hookBefore(original, beforeHandler) {
    return function () {
        isFunction(beforeHandler) && beforeHandler.apply(this, arguments);
        isFunction(original) && original.apply(this, arguments);
    }
}

function hookAround(original, beforeHandler, afterHandler) {
    return function () {
        isFunction(beforeHandler) && beforeHandler.apply(this, arguments);
        isFunction(original) && original.apply(this, arguments);
        isFunction(afterHandler) && afterHandler.apply(this, arguments);
    }
}

function lifeCycleHook(hook, options) {
    if(isObject(hook) && isFunction(hook.handler)) {
      const {name, handler} = hook;
      options[name] = hookBefore(options[name], handler);
      options[name]._ty_hook = true;
    }
}

/**
 * return page route array of current page
 */
function getPageRoutes() {
    return (getCurrentPages() || []).map(page => page.route);
}

function getPagePath() {
    let pageRoutes = getPageRoutes();
    return pageRoutes.length > 0 ? pageRoutes[pageRoutes.length - 1] : ''
}

/**
 * UUID.core.js: A small subset of UUID.js, the RFC-compliant UUID generator for JavaScript.
 *
 * @fileOverview
 * @author  LiosK
 * @version v3.3.0
 * @license The MIT License: Copyright (c) 2010-2016 LiosK.
 */
const UUID = (function() {
    /**
     * Returns an unsigned x-bit random integer.
     * @param {int} x A positive integer ranging from 0 to 53, inclusive.
     * @returns {int} An unsigned x-bit random integer (0 <= f(x) < 2^x).
     */
    function rand(x) { // _getRandomInt
        if (x < 0) return NaN;
        if (x <= 30) return (0 | Math.random() * (1 << x));
        if (x <= 53) return (0 | Math.random() * (1 << 30)) + (0 | Math.random() * (1 << x - 30)) * (1 << 30);
        return NaN;
    }

    /**
     * Converts an integer to a zero-filled hexadecimal string.
     * @param {int} num
     * @param {int} length
     * @returns {string}
     */
    function hex(num, length) { // _hexAligner
        let str = num.toString(16),
            i = length - str.length,
            z = "0";
        for (; i > 0; i >>>= 1, z += z) {
            if (i & 1) {
                str = z + str;
            }
        }
        return str;
    }

    /**
     * The simplest function to get an UUID string.
     * @returns {string} A version 4 UUID string.
     */
    return function() {
        return hex(rand(32), 8) // time_low
            + "-" + hex(rand(16), 4) // time_mid
            + "-" + hex(0x4000 | rand(12), 4) // time_hi_and_version
            + "-" + hex(0x8000 | rand(14), 4) // clock_seq_hi_and_reserved clock_seq_low
            + "-" + hex(rand(48), 12); // node
    };
})();

function parseJSON(data) {
    if (data && isString(data)) {
        return JSON.parse(data);
    }
    return data;
}

function safeParseJSON(json) {
    try {
        return parseJSON(json);
    } catch (e) {}
    return null;
}

function safeStringifyJSON(data) {
    let result = '';
    try {
        result = JSON.stringify(data);
    }catch(e) {
        result = '';
    }
    return result;
}

function toString(data) {
    return data + '';
}

function size(data) {
    if (!data) {
        return 0;
    }
    if (isObject(data)) {
        return safeStringifyJSON(data).length;
    }
    if (isString(data)) {
        return data.length;
    }
    if (data instanceof ArrayBuffer) {
        return data.byteLength;
    }
    if (data.length) {
        return data.length;
    }
    return 0;
}

let pageEvent = {};
let pageErrs = [];
let pageCustomTime = 0;
let path = {}; //prev, current
let pageData = {
    uniqueId : 0,
    requestId: 0,
    apiId: 0,
    actions: []
};
let pageStatus = {
    canSend: false,
    sent: false,
    apiRemain: 0
};

function clearData() {
    // clear data
    pageEvent = {};
    pageErrs = [];
    pageCustomTime = 0;
    pageStatus.apiRemain = 0;
    pageData = {
        uniqueId : 0,
        requestId: 0,
        apiId: 0,
        actions: []
    };
}

function recordTyData() {
    pageCustomTime = now();
}

/**
 * Data
 */

// global agentConfig
let agentConfig = {};

function setAgentConfig(config) {
    agentConfig = config || {};
}

const CHECK_SAMPLING_INTERVAL = 10 * 60 * 1000;
const TY_SAMPLING = 'TY_SAMPLING';
// 采样率
let sampling = wx.getStorageSync(TY_SAMPLING);
let isCollect = false;

function checkSampling(callback) {
    console.log('TINGYUN AGENT checking sampling');
    if(agentConfig.key && agentConfig.beacon) {
        wx.request({
            url: `${agentConfig.beacon}/mp-config/config/pullSampling?encodeMpId=${agentConfig.key}`,
            method: 'GET',
            _no_record: true,
            success: (result) => {
                const {code, data} = result.data || {};
                if(code === 200 && data) {
                    sampling = data.sampling || 1;
                    wx.setStorageSync(TY_SAMPLING, sampling);
                }
            },
            fail: () => {
                sampling = 1;
            },
            complete: () => {
                callback && callback(sampling);
            }
        });
    }
}

function calcIfCollect() {
    // if no sampling storage, use user setting
    if(sampling === '') {
        sampling = +agentConfig.sampleRate || 1;
        checkSampling();
    }
    const random = Math.random();
    isCollect = random <= sampling;
}

setInterval(checkSampling, CHECK_SAMPLING_INTERVAL);

function isPage(page) {
    if(agentConfig.pages && isArray(agentConfig.pages)) {
        return agentConfig.pages.indexOf(page) > -1;
    }else {
        return true;
    }
}

const ACTION_TYPE_REQUEST = 'request';
const ACTION_TYPE_API = 'api';
const ACTION_TYPE_TIMER = 'timer';

// ========== consts begin ======================
const PAGE_TY_DATA = "recordTyTime";
const TINGYUN_UID = "TINGYUN_UID";
const CUSTOM_CODE_FUNC = 'custom';
const TRIGGER_LIFECYCLE = 'TRIGGER_LIFECYCLE';
const PLUGIN_FREE_VERSION = '2.6.4';
// 事件超时时间
const EVENT_TIME_OUT = 10 * 1000;
// ========== consts end =======================

wx.onNetworkStatusChange(function (res) {
    sysInfo.networkType = res.networkType;
});
/** Get system info */
sysInfo.system = wx.getSystemInfoSync();

const DEFAULT_INFO = {
    uid: getStorageUUID(),
    sid: UUID(),
    v: "1.3.1"
};

function getStorageUUID() {
    let uid = wx.getStorageSync(TINGYUN_UID);
    if (!uid) {
        uid = UUID();
        wx.setStorageSync(TINGYUN_UID, uid);
    }
    return uid;
}

function sendAppData(params) {
    if(!isCollect) {
        return;
    }
    const appData$$1 = Object.assign({}, DEFAULT_INFO, sysInfo || {}, {key: agentConfig.key}, params || {});
    appData$$1.launch = !params;
    wx.request({
        url: `${agentConfig.beacon}/mp-app`,
        data: appData$$1,
        method: 'POST',
        _no_record: true
    });
}

function sendPageCombineData(trigger) {
    if(!isCollect) {
        return;
    }
    if(TRIGGER_LIFECYCLE === trigger) {
        pageStatus.canSend = true;
    }
    if(!pageStatus.sent && pageStatus.canSend) {
      //combine Data
      const pageCombineData = Object.assign({}, {
            path: getPagePath(),
            pageEvent: Object.assign({}, pageEvent),
            errs: pageErrs.slice(),
            fromPath: path.prev || '',
            actions: pageData.actions || []
        }, 
        Object.assign({}, DEFAULT_INFO, sysInfo || {}, {key: agentConfig.key}),
        pageCustomTime > 0 ? {ct: pageCustomTime}: {}
      );

      // set route chain
      let routeChain = getRouteChain();
      if(routeChain) {
          pageCombineData.routeTrack = routeChain;
      }

      // 清空数据
      clearData();
      pageStatus.sent = true;
      pageStatus.canSend = false;

      wx.request({
        url: `${agentConfig.beacon}/mp-page`,
        data: pageCombineData,
        method: 'POST',
        _no_record: true
      });
    }
}

function onLaunch(options) {
    calcIfCollect();
    const { path: path$$1, query, scene} = options;
    sysInfo.openPath = path$$1;
    sysInfo.query = query;
    sysInfo.scene = scene;

    /**网络类型获取 */
    wx.getNetworkType({
        success: function (res) {
            // 返回网络类型, 有效值：
            // wifi/2g/3g/4g/unknown(Android下不常见的网络类型)/none(无网络)
            sysInfo.networkType = res.networkType;
        },
        complete: function () {
            sendAppData();
        }
    });
}

function onError(err) {
    if(err) {
        const stacks = err.split(/\n/);
        const msg = stacks[2] || '';
        let filename = '';
        let lineno = 0;
        let colno = 0;
        stacks.every(stack => {
           const stackMesage = stack && stack.trim();
           if(stackMesage.indexOf('at ') === 0) {
               const beginIndex = stackMesage.indexOf('(');
               const endIndex = stackMesage.indexOf(')');
               if(beginIndex && endIndex) {
                   let beginSplitIndex = beginIndex + 1;
                   if(beginSplitIndex > endIndex) {
                       beginSplitIndex = endIndex;
                   }
                   const filenameAndNo = stackMesage.substring(beginSplitIndex, endIndex);
                   if (filenameAndNo) {
                       const filenameAndNoParts = filenameAndNo.split(':');
                       if(filenameAndNoParts && filenameAndNoParts.length > 2) {
                           filename = (filenameAndNoParts.slice(0, filenameAndNoParts.length - 2) || []).join(':');
                           lineno = +filenameAndNoParts[filenameAndNoParts.length - 2];
                           colno = +filenameAndNoParts[filenameAndNoParts.length -1];
                       }
                   }
                   return false;
               }
           }
           return true;
        });
        if(!filename) {
            filename = getPagePath();
        }
        pageErrs.push({
            time: now(),
            msg: msg,
            filename: filename,
            lineno: lineno,
            colno: colno,
            stack: err
        });
    }
}

function onHide() {
    let routeTrack = getRouteChain();
    clearRouteChain();
    let closePath = path.current;
    // clear path status
    path.prev = '';
    path.current = '';
    sendAppData({routeTrack, closePath});
}

function compareVersion(v1, v2) {
    v1 = v1.split('.');
    v2 = v2.split('.');
    const len = Math.max(v1.length, v2.length);

    while (v1.length < len) {
        v1.push('0');
    }
    while (v2.length < len) {
        v2.push('0');
    }

    for (let i = 0; i < len; i++) {
        const num1 = parseInt(v1[i]);
        const num2 = parseInt(v2[i]);

        if (num1 > num2) {
            return 1;
        } else if (num1 < num2) {
            return -1;
        }
    }

    return 0;
}

function compareSysSDKVersion(sysInfo, v2) {
    let v1 = '';
    if(sysInfo && sysInfo.system) {
        v1 = sysInfo.system.SDKVersion;
    }
    if (!v1 || !v2) {
        return -1;
    }else {
        return compareVersion(v1, v2);
    }
}

const APP_ORIGINAL_HOOKS = [
    {
        name: 'onLaunch',
        handler: onLaunch
    },
    {
        name: 'onError',
        handler: onError
    },
    {
        name: 'onHide',
        handler: onHide
    }
];

function wrapApp(options) {
    APP_ORIGINAL_HOOKS.forEach(hook => {
        lifeCycleHook(hook, options);
    });
    return options;
}

function wrapAppApi(options) {
    if(compareSysSDKVersion(sysInfo, PLUGIN_FREE_VERSION) >= 0) {
        return options;
    }else {
        return wrapApp.apply(this, arguments);
    }
}

function hookApp() {
    /**
     * hook App
     */
    const originalApp = App;
    App = function (options) {
        options = wrapApp(options);
        if (originalApp) {
            originalApp.call(this, options);
        }
    };
}

function onLoad() {
    if(!isPage(this.route)) {
        return;
    }
    pageEvent.onLoad = now();
}

function onShow() {
    if(!isPage(this.route)) {
        return;
    }
    pageEvent.onShow = now();
    // add to route chain
    addRoute(this.route);
    path.prev = path.current;
    path.current = this.route;

    pageStatus.sent = false;
}

function onReady() {
    if(!isPage(this.route)) {
        return;
    }
    pageEvent.onReady = now();
}

function onHide$1() {
    if(!isPage(this.route)) {
        return;
    }
    pageEvent.onHide = now();
    //send page data
    sendPageCombineData(TRIGGER_LIFECYCLE);
}

function onUnload() {
    if(!isPage(this.route)) {
        return;
    }
    pageEvent.onUnload = now();
    //send page data
    sendPageCombineData(TRIGGER_LIFECYCLE);
}

const PAGE_ORIGINAL_HOOKS = [
    {
        name: 'onLoad',
        handler: onLoad
    },
    {
        name: 'onShow',
        handler: onShow
    },
    {
        name: 'onReady',
        handler: onReady
    },
    {
        name: 'onHide',
        handler: onHide$1
    },
    {
        name: 'onUnload',
        handler: onUnload
    }
];

function methodHook(options, handler) {
    for (let field in options) {
        if(options.hasOwnProperty(field) && isFunction(options[field]) && !options[field]._ty_hook && isFunction(handler)) {
            const originalMethod = options[field];
            options[field] = handler.call(this, field, originalMethod);
            options[field]._ty_hook = true;
        }
    }
}

const FIELDS = [ACTION_TYPE_REQUEST, ACTION_TYPE_API, ACTION_TYPE_TIMER];
function initRemainObject() {
    const remain = {};
    FIELDS.forEach(field => {
        remain[field] = {
            current: 0,
            children: 0
        };
    });
    return remain;
}

/**
 * 异步上下文
 * @param parent 父级action
 * @param name action name
 * @param type action type
 * @param subType 子类型
 * @param data action其他信息(节点名称等)
 * @constructor
 *
 */
function Context(parent, name, type, subType, data) {
    // id 标识
    this.id = ++pageData.uniqueId;
    // 父级context
    this.parent = parent || null;
    // 作用域名称: 默认为根节点
    this.name = name || '<root>';
    this.type = type || 'event';
    // not used 子类型: 例如对于点击事件: form submit, button click, a link ...
    this.subType = subType || 'tap';
    // 作用域中的requests
    this.requests = [];

    this.apis = [];

    this.remain = initRemainObject();
    // // 剩余的ajax
    // this.remain = 0;
    // this.childrenRemain = 0;
    // // 剩余未执行回调的timer
    // this.timerRemain = 0;
    // this.childrenTimerRemain = 0;

    // 事件开始时间
    this.s = now();
    // 事件结束时间
    this.e = null;
    // 节点数据信息
    this.data = data;

    const self = this;

    // 超时自动结束
    this.i = setTimeout(function () {
        self.timeout();
    }, EVENT_TIME_OUT);

    // ========= others ==============
    // 标志此事件是否已被结束, 已经彻底结束的事件不需要再次调用
    this.closed = false;
    // 记录事件触发时所在页面的path
    this.path = path.current;
    this.prevPath = path.prev;
}

/**
 * 清除并关闭不需要加入到层级关系的作用域
 */
Context.prototype.clear = function() {
    console.debug('Context: ', this.name, 'will clear soon, name:', this.name);
    this.e = now();
    this.closed = true;
    this.i && clearTimeout(this.i);
};

// 结束一个作用域, 某个作用域结束时，会依次寻找上层的父级作用域尝试结束
Context.prototype.end = function(childContext, isTimeout) {
    if(this.closed) {
        console.warn('Current context is already closed');
        return;
    }
    if(childContext) {
        if(childContext.type === ACTION_TYPE_REQUEST || childContext.type === ACTION_TYPE_API) {
            const childRequests = childContext.requests || [];
            const childApis = childContext.apis || [];
            this.requests.map(request => {
                const requestContextName = `${request.url}-${request.requestId}`;
                if(requestContextName === childContext.name) {
                    request.requests = childRequests;
                    request.apis = childApis;
                }
            });
            this.apis.map(api => {
                const apiContextName = `${api.name}-${api.apiId}`;
                if(apiContextName === childContext.name) {
                    api.requests = childRequests;
                    api.apis = childApis;
                }
            });
        } else if(childContext.type === ACTION_TYPE_TIMER) {
            // setTimeout 中的xhr与本层是同级别关系
            const childRequests = childContext.requests || [];
            const childApis = childContext.apis || [];
            this.requests = [].concat.call(this.requests || [], childRequests);
            this.apis = [].concat.call(this.apis || [], childApis);
        }
    }

    if(this.isNoRemain() || isTimeout) {
        console.debug('Context: ', this.name, 'will close soon, name:', this.name);
        this.e = now();
        this.closed = true;
        this.i && clearTimeout(this.i);
        if(this.parent) {
            this.parent.end(this);
        }else {
            // 构造一条event数据
            const event = this.composeActionData();
            // 存储到全局event数组
            this.addAction(event);
            appData.context = null;
            // retry send message
            // sendPageCombineData(TRIGGER_APIEND);
        }
    }
};

/**
 * 检测是否已经没有剩余作用域
 * @param testCurrent 只检测当前作用域
 * @returns {boolean}
 */
Context.prototype.isNoRemain = function(testCurrent) {
    let noRemain = true;
    for (let field in this.remain) {
        if(this.remain.hasOwnProperty(field)) {
            const fieldNoRemain = this.remain[field].current <= 0 && (!testCurrent ? this.remain[field].children <= 0 : true);
            if (!fieldNoRemain) {
                noRemain = false;
                break;
            }
        }
    }
    return noRemain;
};

// 超时: 设置超时时间
Context.prototype.timeout = function() {
    this.end(null, true);
};

Context.prototype.setData = function(data) {
    this.data = data;
};

// 组装action数据
Context.prototype.composeActionData = function() {
    let eventData = {
        id: this.id,
        name: this.name,
        type: this.type,
        start: this.s,
        end: this.e,
        duration: this.e - this.s > 0 ? this.e - this.s : 0,
        requests: (this.requests || []).slice(),
        apis: (this.apis || []).slice(),
        data: this.data || {},
        path: this.path,
        prevPath: this.prevPath
    };
    if(this.type === ACTION_TYPE_REQUEST || this.type === ACTION_TYPE_API) {
        eventData = Object.assign({}, eventData, this.data);
        delete eventData['data'];
    }
    return eventData;
};

Context.prototype.addAction = function(action) {
    if(!pageData.actions) {
        pageData.actions = [];
    }
    pageData.actions.push(action);
};

Context.prototype.canEnd = function(field, prevRemain) {
    // if(!prevRemain) {
    //     prevRemain = 0;
    // }
    // if(!field) {
    //     field = ACTION_TYPE_REQUEST;
    // }
    return this.isNoRemain(true);
};

Context.prototype.isEventChildContext = function() {
    let context = this.parent;
    let isEvent = false;
    while(context != null) {
        if(context.type === 'event') {
            isEvent = true;
            break;
        }
        context = context.parent;
    }
    return isEvent;
};

/**
 * 修改剩余数量
 * @param value
 * @param type
 */
Context.prototype.updateRemain = function(value, type) {
    if(!type) {
        type = ACTION_TYPE_REQUEST;
    }
    const modifyValue = value || 0;
    this.remain[type].current = this.remain[type].current + modifyValue;
    let parent = this.parent;
    while (parent) {
        parent.remain[type].children  = parent.remain[type].children + modifyValue;
        parent = parent.parent;
    }
};

Object.defineProperty(Context.prototype, "current", {
    get: function () {
        return appData.context;
    },
    enumerable: true,
    configurable: true,
});

/**
 * 创建作用域事件
 */
Object.defineProperty(Context, "createEvent", {
    value: function(parent, eventName, type, subType, data) {
        // 对于一个点击事件, 父级为null
        return new Context(parent, eventName, type || 'event', subType || null,  data);
    },
    enumerable: true,
    configurable: true,
    writable: true
});

const EVENTNAME = 'tyname';

function checkIsIgnoreMethod(event) {
    return !event || event.type !== 'tap' || !isObject(event.target) || !isObject(event.currentTarget) || event.timeStamp == null;
}

function methodWrapperBefore(event, methodName) {
    const {offsetLeft, offsetTop, id, dataset} = event.target;
    const {x, y} = event.detail;
    // _relatedInfo is deprecated
    let targetName;
    if(event._relatedInfo) {
        targetName = event._relatedInfo.anchorTargetText;
    }
    const eventData = {
        target: {offsetLeft, offsetTop, id, x, y},
        dataset: {
            name: dataset[EVENTNAME],
            targetName: targetName,
            methodName: methodName
        }
    };

    const eventName = targetName ? targetName : methodName;
    // create event context
    appData.context = Context.createEvent(null, eventName, 'event', event.type, eventData);
}


function methodWrapperAfter() {
    if(appData.context && appData.context.canEnd()) {
        appData.context.end();
    }
}

function methodWrapper(methodName, originalMethod) {
    return function () {
        // before run original callback (begin Context)
        const event = arguments[0] || {};
        const isNormalMethod = checkIsIgnoreMethod(event);
        if(!isNormalMethod) {
            try {
                methodWrapperBefore.call(this, event, methodName);
            }catch(e) {}
        }
        // run original method
        if(originalMethod) {
            try{
                return originalMethod.apply(this, arguments);
            }catch(e){}
        }
        if(!isNormalMethod) {
            // after run original callback (end Context)
            try {
                methodWrapperAfter.call(this);
            }catch(e){}
        }
    }
}

function wrapPage(options) {
    // hook lifecycle
    PAGE_ORIGINAL_HOOKS.forEach(hook => {
        lifeCycleHook(hook, options);
    });
    // hook methods
    methodHook(options, methodWrapper);
    options[PAGE_TY_DATA] = recordTyData;
    return options;
}

function wrapPageApi(options) {
    if(compareSysSDKVersion(sysInfo, PLUGIN_FREE_VERSION) >= 0) {
        return options;
    }else {
        return wrapPage.apply(this, arguments);
    }
}

/**
 * Hook Page
 */
function hookPage() {
    const originalPage = Page;
    Page = function (options) {
        options = wrapPage(options);
        if (originalPage) {
            originalPage.call(this, options);
        }
    };
}

// original request
const originRequest = wx.request;

/**
 * GET server response header
 * @param {*} header 
 * @param {*} rand randNumber to tag a request
 */
function getTingyunTxData(header, rand) {
    if(header) {
        var txData = safeParseJSON(header['X-Tingyun-Tx-Data']);
        if (txData && txData.r && toString(txData.r) === toString(rand)) {
            return txData;
        }
    }
    return null;
}

/**
 * Get 'Content-Length' response header
 * @param {*} header 
 */
function getContentLength(response) {
    if(!response) {
        return 0;
    }
    const {header, data} = response;
    let contentLength = 0;
    contentLength = +(header && header['Content-Length']);
    if(!contentLength || !isNumber(contentLength) || Number.isNaN(contentLength)) {
        contentLength = size(data) || 0;
    }
    return contentLength;
}

/**
 * 获取server 返回数据
 * @param response
 * @param store
 */
function getServerData(response, store) {
    let serverData = {};
    const data = getTingyunTxData(response.header, store.r);
    if (data) {
        serverData.s_id = data['id'];
        serverData.s_name = data['action'];
        if (data.time) {
            serverData.s_du = data.time['duration'];
            serverData.s_qu = data.time['qu'];
        }
        serverData.t_id = data['trId'];
    }

    return serverData;
}

function composeData(store, config, response) {
    return {
        requestId: store.requestId,
        type: ACTION_TYPE_REQUEST,
        url: store.url,
        method: store.method,
        start: store.start,
        end: store.end,
        cbTime: store.cbTime,
        duration: store.end - store.start > 0 ? store.end - store.start : 0,
        send: size(config.data),
        rec: getContentLength(response),
        statusCode: response.statusCode || 0,
    }
}

function beforeCallbackRun(store, prevContext) {
    if(!store.callbackContextCreated) {
        // 创建回调作用域
        const requestContextName = `${store.url}-${store.requestId}`;
        appData.context = Context.createEvent(prevContext, requestContextName, ACTION_TYPE_REQUEST);
        store.callbackContextCreated = true;
    }
}

function afterCallbackRun(store, prevContext, requestData) {
    // 如果回调中没有新的请求加入, 则结束作用域, 不手动结束会导致超时自动触发结束
    appData.context && appData.context.setData(requestData);
    const requestContextCanEnd = appData.context && appData.context.canEnd();
    if(requestContextCanEnd) {
        appData.context.end();
    }
    // 添加本次请求, 并判断上一层作用域的情况
    if(prevContext && prevContext.id === store.cid && requestData) {
        prevContext.requests.push(requestData);
        const prevRemain = prevContext.remain[ACTION_TYPE_REQUEST].current;
        prevContext.updateRemain(-1, ACTION_TYPE_REQUEST);
        // 需要判断嵌套回调层是否有timer, 否则导致关联不上timer中发的ajax
        if(prevContext.canEnd() && requestContextCanEnd) {
            prevContext.end();
        }
    }
    if(appData.context != null) {
        appData.context = prevContext;
    }
}

const request = function wxRequest() {
    const config = arguments[0] || {};
    if (!config._no_record) {
        const prevContext = appData.context;
        const store = {
            requestId: ++pageData.requestId,
            url: config.url,
            method: config.method && config.method.toUpperCase() || 'GET',
            // 是否已经创建了上下文对象
            callbackContextCreated: false
        };
        // 随机标志位
        store.r = now() % 1e9;
        // set request header for server
        config.header = config.header || {};
        config.header['X-Tingyun-Id'] = `${agentConfig.id};r=${store.r}`;

        // hook callbacks...
        let originSuccess;
        if (isFunction(config.success)) {
            originSuccess = config.success;
        }

        let originFail;
        if (isFunction(config.fail)) {
            originFail = config.fail;
        }

        let originComplete;
        if (isFunction(config.complete)) {
            originComplete = config.complete;
        }
        config.success = function () {
            if (!store.end) {
                store.end = now();
            }
            beforeCallbackRun(store, prevContext);
            if (originSuccess) {
                try {
                    originSuccess.apply(this, arguments);
                }catch(e) {}
            }
        };
        config.fail = function () {
            if (!store.end) {
                store.end = now();
            }
            beforeCallbackRun(store, prevContext);
            if (originFail) {
                try {
                    originFail.apply(this, arguments);
                }catch(e){}
            }
        };
        //add network info in complete
        config.complete = function (response) {
            // fail request, return
            if(!response.statusCode) {
                return;
            }
            //calculate callback time
            if (!store.end) {
                store.end = now();
            }
            // custom code begin
            let customCodeRes;
            const customCodeFunc = agentConfig[CUSTOM_CODE_FUNC];
            if(customCodeFunc && isFunction(customCodeFunc)) {
                try {
                    const codeRes = customCodeFunc.apply(this, arguments);
                    if(isObject(codeRes)) {
                        customCodeRes = {custom: codeRes};
                    }
                }catch (e) {}
            }
            // custom code end
            beforeCallbackRun(store, prevContext);

            if (originComplete) {
                try {
                    originComplete.apply(this, arguments);
                }catch (e) {}
            }

            const serverData = getServerData(response, store);
            const storeData = composeData(store, config, response);
            const requestData = Object.assign({}, storeData, serverData || {}, customCodeRes || {});
            // after callback runs ...
            afterCallbackRun(store, prevContext, requestData);

            // push to pageRequests
            // pageRequests.push(requestData);
            // push to actions(if it's end will auto stop)...
        };
        store.start = now();

        // action handler begin
        // get current context
        if(prevContext) {
            store.cid = prevContext.id;
            prevContext.updateRemain(1);
        }
        // action handler end
    }

    // network request begin
    return originRequest.apply(this, arguments);
};

function hookNetwork() {
    Object.defineProperty(wx, 'request', {
        configurable: true,
        enumerable: true,
        writable: true,
        value: request
    });
}

function wrapComponent(options) {
    if(!options.methods) {
        options.methods = {};
    }
    PAGE_ORIGINAL_HOOKS.forEach(hook => {
        lifeCycleHook(hook, options.methods);
    });
    return options;
}

function wrapComponentApi(options) {
    if(compareSysSDKVersion(sysInfo, PLUGIN_FREE_VERSION) >= 0) {
        return options;
    }else {
        return wrapComponent.apply(this, arguments);
    }
}

/**
 * Only hook page component.
 */
function hookComponent() {
    const originalComponent = Component;
    Component = function (options) {
        options = wrapComponent(options);
        if (originalComponent) {
            originalComponent.call(this, options);
        }
    };
}

function setUser(userId, metaObject) {
    sysInfo.uid = userId;
    wx.setStorageSync(TINGYUN_UID, userId);
}

const api = {
    version: "1.3.1",
    setUser: setUser,
    hookApp: wrapAppApi,
    hookPage: wrapPageApi,
    hookComponent: wrapComponentApi,
    request: request
};

let HOOK_APIS;
const HOOK_CALLBACKS = ['success', 'fail'];
const hookApiNames = [];

// A handler will replace the default behaviour of success/fail determination,
// by default, fail count plus one when 'fail' callback called, success count plus one when 'success' callback called.
const handler = {
    requestPayment: {
        fail: function () {
            // 识别取消
            const res = arguments && arguments[0];
            let fieldName = 'fail';
            if(res && isObject(res) && res.errMsg === 'requestPayment:fail cancel') {
                fieldName = 'cancel';
            }
            return fieldName;
        }
    }
};

function initHookApis() {
    HOOK_APIS = agentConfig.hookApis || [
        'requestPayment',
        'scanCode',
        'previewImage'
    ];

    HOOK_APIS.forEach(hookApi => {
        if(hookApiNames.indexOf(hookApi) > -1 || hookApi === 'request') {
            return;
        }
        hookApiNames.push(hookApi);
    });

}

function composeApiData(store) {
    return {
        apiId: store.apiId,
        type: ACTION_TYPE_API,
        name: store.name,
        success: store.success || 0,
        fail: store.fail || 0,
        cancel: store.cancel || 0,
        start: store.start,
        end: store.end,
        duration: store.end - store.start > 0 ? store.end - store.start : 0,
        count: 1
    };
}

function beforeCallbackRun$1(store, prevContext) {
    if(!store.callbackContextCreated) {
        // 创建request作用域
        const apiContextName = `${store.name}-${store.apiId}`;
        appData.context = Context.createEvent(prevContext, apiContextName, ACTION_TYPE_API);
        store.callbackContextCreated = true;
    }
}

function afterCallbackRun$1(store, prevContext, apiData) {
    // 如果回调中没有新的请求加入, 则结束作用域, 不手动结束会导致超时自动触发结束
    appData.context && appData.context.setData(apiData);
    const apiContextCanEnd = appData.context && appData.context.canEnd();
    if(apiContextCanEnd) {
        appData.context.end();
    }
    // 添加本次请求, 并判断上一层作用域的情况
    if(prevContext && prevContext.id === store.cid && apiData) {
        prevContext.apis.push(apiData);
        const prevRemain = prevContext.remain[ACTION_TYPE_API].current;
        prevContext.updateRemain(-1, ACTION_TYPE_API);
        // 需要判断嵌套回调层是否有timer, 否则导致关联不上timer中发的ajax
        if(prevContext.canEnd() && apiContextCanEnd) {
            prevContext.end();
        }
    }
    if(appData.context != null) {
        appData.context = prevContext;
    }
}

/**
 * api wrapper
 * @param apiName
 * @returns {function(): *}
 */
function wrapApi(apiName) {
    const originalApi = wx[apiName];
    return function () {
        const prevContext = appData.context;
        // pageStatus.apiRemain++;
        const config = arguments[0] || {};
        const store = {
            apiId: ++pageData.apiId,
            name: apiName,
            callbackContextCreated: false
        };
        // callbacks begin...
        HOOK_CALLBACKS.forEach((field) => {
            config[field] = hookBefore(config[field], function () {
                if(!store.end) {
                    store.end = now();
                }
                beforeCallbackRun$1(store, prevContext);
                let fieldName;
                if(handler[apiName] && handler[apiName][field] && isFunction(handler[apiName][field])) {
                    fieldName = handler[apiName][field].apply(this, arguments);
                }else {
                    fieldName = store[field] = 1;
                }
                if(fieldName) {
                    store[fieldName] = 1;
                }
            });
        });
        config['complete'] = hookAround(config['complete'], function () {
            if(!store.end) {
                store.end = now();
            }
            // pageStatus.apiRemain--;
            // if(pageStatus.apiRemain <=0) {
            //     // change to event end
            //     // sendPageCombineData(TRIGGER_APIEND);
            // }
        }, function () {
            const apiData = composeApiData(store);
            afterCallbackRun$1(store, prevContext, apiData);
        });
        // callbacks end

        if(prevContext) {
            store.cid = prevContext.id;
            prevContext.updateRemain(1, ACTION_TYPE_API);
        }
        store.start = now();
        return originalApi.apply(this, arguments);
    }
}

function hookApi(apiName) {
    if(!apiName) {
        return;
    }
    const originalApi = wx[apiName];
    if(originalApi) {
        Object.defineProperty(wx, apiName, {
            configurable: true,
            enumerable: true,
            writable: true,
            value: wrapApi(apiName)
        });
    }
}

/**
 * 导出附加到探针对象上的方法
 */
function exportedWxApis() {
    if(!HOOK_APIS) {
        initHookApis();
    }
    const api = {};
    hookApiNames.forEach(apiName => {
        api[apiName] = wrapApi(apiName);
    });
    return api;
}

function hookApis() {
    if(!HOOK_APIS) {
        initHookApis();
    }
    hookApiNames.forEach(apiName => {
        hookApi(apiName);
    });
}

// import './opera';

let init = false;

function bootstrap(plugin) {
    if(!plugin || compareSysSDKVersion(sysInfo, PLUGIN_FREE_VERSION) >= 0) {
        hookApp();
        hookPage();
        hookNetwork();
        hookComponent();
        hookApis();
    }

    // 为了兼容低版本SDK, 添加wx[api]只要plugin : true就需要添加
    if(plugin) {
        // add All wx api to ty api object
        Object.assign(api, exportedWxApis() || {});
    }
}

/**
 * init config
 * @param config
 */
function setConfig(config) {
    if(!init) {
        setAgentConfig(config || {});
        init = true;
        bootstrap(agentConfig.plugin);
    }
}

// import './timer'

function run() {
    api.config = setConfig;
    return api;
}

var index = run();

module.exports = index;
