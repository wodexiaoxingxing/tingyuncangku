const config = require('../config/config.js')
import md5 from './md5.js';

const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

const genSign = requestParam => {
  const queryString = Object.keys(requestParam).sort()
    .filter(key => requestParam.hasOwnProperty(key))
    .map(key => `${key}=${requestParam[key]}`)
    .join('&') + `&key=${config.apiSecretKey}`;
  return md5(queryString).toUpperCase();
}
function sleep(milli) {
  let time = +new Date;
  while (+new Date < time + milli) {

  }
}
module.exports = {
  formatTime: formatTime,
  genSign: genSign,
  sleep: sleep
}
