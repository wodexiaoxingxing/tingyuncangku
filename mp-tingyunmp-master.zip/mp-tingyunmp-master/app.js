
//app.js
// const monitor = require('./agent/tingyun-mp-agent-1.3.6');
// const monitor = require('./agent/tingyun-mp-agent-private.js');
// const monitor = require('./agent/tingyun-mp-agent-private-1.3.7');
// const monitor = require('./agent/tingyun-mp-agent-1.3.8');
// const monitor = require('./agent/tingyun-mp-agent-1.3.8-saas30-zhengshi');
// const monitor = require('./agent/tingyun-mp-agent-saas20-138');
const monitor = require('./agent/tingyun-mp-agent-1.3.9.js');
// const mtjwxsdk = require("./utils/mtj-wx-sdk.js");
// const monitor = require('./agent/tingyun-mp-agent-saas20');

monitor.config({
  // beacon: 'http://10.128.1.139:8588',      //139环境  wjntest
  // key: 'R7UxBnOBPC8',
  // id: 'wMkafLj7G64',
  // beacon: 'http://10.128.2.40:8588',      //40集成环境  wjntest
  // key: 'p35OnrDoP8k',
  // id: 'lNXvexXCq6I',
  // beacon: 'http://10.128.5.243:8588',      //243集成环境  wjntest
  // key: 'p35OnrDoP8k',
  // id: 'MbVbeLGiVew',
  // beacon: 'http://10.128.5.254:8588',
  // key: 'p35OnrDoP8k',
  // id: '4gA5HRiCw8g',
  // beacon: 'http://10.128.5.245:8588',
  // key: '4Nl_NnGbjwY',
  // id: '4Nl_NnGbjwY',
  // beacon: 'http://10.128.1.102:8588',      //102集成环境 
  // key: 'p35OnrDoP8k',
  // id: '4gA5HRiCw8g',
  // beacon: 'http://10.128.5.245:8588',      //245集成环境  wjntest
  // key: 'p35OnrDoP8k',
  // id: '4gA5HRiCw8g',
  // beacon: 'http://apm3brs.tingyun.com',       //demo环境   wangjn
  // key: 'VLw6nMkIkVw',
  // id: 'qUsxjuGJOvE',
  // beacon: 'https://beaconalpha2.tingyun.com',             //2.0内网环境  sina
  // key: '5aJJSi1tj1k',
  // id: 'QPo-y6LCVc8', 
  // beacon: 'https://beaconbeta-mp.tingyun.com',            //2.0-beta环境  cesuba
  // key: 'k3Ln-L_Crpw',
  // id: 'kJ_Jfb1Dn8k',
  // beacon: 'https://beaconalpha2.tingyun.com',      //2.0内网环境  lizhenc
  // key: 'vckXRSJ4L38',
  // id: 'yDgQY-UHaBQ',
  // beacon: 'https://beaconbeta-mp.tingyun.com',      //2.0-beta环境  miniapp
  // key: 'k3Ln-L_Crpw',
  // id: 'kJ_Jfb1Dn8k',
  // beacon: 'https://beacon-mp.tingyun.com',      //2.0-线上环境  miniapp
  // key: '8j6b8zeX4Zc',
  // id: 'aYqI2FQlmvU',
  // beacon: 'https://beacon-mp.tingyun.com',      //2.0-线上环境  cesuba
  // key: 'k3Ln-L_Crpw',
  // id: 'kJ_Jfb1Dn8k',
  // beacon: 'https://beacon-mp.tingyun.com',      //2.0-线上环境  demo
  // key: 'm8yziyDyrK4',
  // id: '4RpKvuN2QnU',
  // beacon: 'http://10.128.2.29:8588',      //saas3.0 内网  sina    wjn_app001
  // key: '4Nl_NnGbjwY',
  // id: 'QPo-y6LCVc8',
  // beacon: 'http://10.128.2.55:8588',
  // key: '4Nl_NnGbjwY',
  // id: 'QPo-y6LCVc8',
  // beacon: 'http://10.128.2.29:8588',      //saas3.0 内网  test_ly04     wjn_test001
  // key: 'P54-bRBPcGU',
  // id: 'OIrilPy8qMA',
  // beacon: 'https://wkmpt1.tingyun.com',      //saas3.0 beta  ceshi_my3
  // key: 'P54-bRBPcGU',
  // id: 'C2dgAtXtsPU',
  // beacon: 'https://wkmpt2.tingyun.com',      //saas3.0 beta-wukong2  test_bly01
  // key: 'gKJc_r7lv9E',
  // id: 'uazOcuIoeLI',
  // beacon: 'https://beacon-mp.tingyun.com',      //2.0-线上环境  免费账号-wangjianing@tingyun.com
  // key: 'A10-YEYsA7Y',
  // id: 'XxCYNvlXXiU',
  // beacon: 'https://beaconalpha2.tingyun.com',      //2.0-内网环境  sina
  // key: '2PJIB8naKvM',
  // id: 'QPo-y6LCVc8',
  // beacon: 'http://wkmp2.tingyun.com',      //saas3.0 正式-2桶  test_bly01
  // key: 'VLw6nMkIkVw',
  // id: 'uazOcuIoeLI',
  // beacon: 'https://wkmp1.tingyun.com',      //saas3.0 正式-1桶  ceshi_my3
  // key: 'P54-bRBPcGU',
  // id: 'fui3qc_SnwM',
  // beacon: 'https://wkmp2.tingyun.com',      //saas3.0 正式-2桶  test_bl
  // key: 'MbVbeLGiVew',
  // id: 'uazOcuIoeLI',  
  // beacon: 'http://wkmp1.tingyun.com',      //saas3.0 正式-1桶  demo
  // key: 'aEXAiPCQUeU',
  // id: '4RpKvuN2QnU',
  // beacon: 'http://192.168.1.35:8588',
  // key: 'p35OnrDoP8k',
  // id: '4Nl_NnGbjwY',
  // beacon: 'http://10.128.2.95:8588',
  // key: '4gA5HRiCw8g',
  // id: 'QPo-y6LCVc8',
  // beacon: 'http://10.128.2.55:8588',
  // key: 'VLw6nMkIkVw',
  // id: 'bR_jPenaZc4',
  // beacon: 'http://10.128.1.51:8588',
  // key: 'p35OnrDoP8k',
  // id: 'AsigsOTcnbw',
  // beacon: 'http://139.186.151.128:8588',
  // key: 'p35OnrDoP8k',
  // id: 'xoQp58Chn_A',
  beacon: 'http://10.128.2.24:8588',
  key: 'p35OnrDoP8k',
  id: 'MbVbeLGiVew',
  // beacon: 'http://192.168.1.47:8588',
  // key: 'p35OnrDoP8k',
  // id: 'lNXvexXCq6I',
  sampleRate: 1,
  custom: function (response) {
    return {
      code: response.data.code == null ? 'NULL' : response.data.code,
      status: ['success'].includes(response.data.code)
    }
  },
  eventTimeout: 1000
})
// const monitor = require('./agent/bundle.js');
// const monitor = require('./agent/tingyun-mp-agent-1.3.6.js');
// const monitor = require('./agent/tingyun-mp-agent-1.3.7.js');
// const monitor = require('./agent/tingyun-mp-agent.js');
// monitor.config({
//   beacon: 'https://beaconalpha2.tingyun.com',
//   key: 'AsigsOTcnbw',
//   id: 'QPo-y6LCVc8',
//   sampleRate: 1,
//   custom: function (response) {
//     return {
//       code: response.data.code == null ? 'NULL' : response.data.code,
//       status: ['success'].includes(response.data.code)
//     }
//   },
//   eventTimeout: 1000
// })

const config = require('./config/config.js');
// const accountInfo = wx.getAccountInfoSync()
// console.log(accountInfo)
// console.log(wx.getSystemInfoSync());

// 用户名
// monitor.setUser('wjn_use188')

App({
  onError: function (err) {
    // console.log('err triggered', err);
  },
  onLaunch: function () {
    //统计打开次数
    // wx.request({
    //   url: `${config.apiRoot}/stat/save-opencount?key=${key}&timestamp=${Date.now()}`,
    //   _no_record: true,
    //   success: function() {
    //   }
    // })
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    console.log('app start', this.setData);
    // 登录
    wx.login({
      success: res => {
        console.log(res)
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        const code = res.code;
        wx.request({
          url: `${config.apiRoot}/wx/login?code=${code}`,
          success: res => {
            if (res.statusCode === 200 && res.data.data) {
              // set openId
              console.log(res.data.data)
              this.globalData.openid = res.data.data.openid;
              console.log(`assign openid: ${this.globalData.openid}`);
            }
          }
        })
      }
    })
    // 获取用户信息
    wx.getSetting({
      success: res => {
        console.log(res)
        if (res.authSetting['scope.userInfo']) {
          this.getUserInfo();
        }
      }
    })
  },
  getUserInfo: function () {
    // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
    wx.getUserInfo({
      success: res => {
        // 可以将 res 发送给后台解码出 unionId
        console.log('userInfo', res.userInfo);
        this.globalData.userInfo = res.userInfo

        // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
        // 所以此处加入 callback 以防止这种情况
        if (this.userInfoReadyCallback) {
          this.userInfoReadyCallback(res)
        }
      }
    })
  },
  globalData: {
    userInfo: null,
    openid: '' 
  }
})