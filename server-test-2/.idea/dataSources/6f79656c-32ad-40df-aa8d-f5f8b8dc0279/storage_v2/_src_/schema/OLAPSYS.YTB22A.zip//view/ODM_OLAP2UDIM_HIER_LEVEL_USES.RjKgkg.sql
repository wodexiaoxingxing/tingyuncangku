create view ODM$OLAP2UDIM_HIER_LEVEL_USES as
SELECT distinct
  udl.owner
, udl.dimension_name
, nvl(h.hierarchy_name ,'NONE') hierarchy_name
, 'UL' solvedcode  -- ADD SOLVEDCODE
-- , pl.levelname parent_level_name
, udl.child_level_name
, h.position
FROM
  (SELECT
    u.username owner
  , d.obj# dimobj#
  , d.name dimension_name
  , dl.levelid#
  , dl.levelname child_level_name
   FROM
    dba_users     u
  , sys.obj$      d
  , sys.dimlevel$ dl
  , olapsys.cwm$level lev  -- used to insure that it is a cwm1 dimension
  WHERE u.user_id = d.owner#
  AND d.type# = 43 /* DIMENSION */
  AND (   cwm$util.dimension_tables_visible(d.obj#) = 'Y'
       OR EXISTS /* SELECT ANY TABLE, CREATE, ALTER, DROP ANY DIMENSION */
         (SELECT null FROM v$enabledprivs
          WHERE priv_number IN (-47,-215,-216,-217)))
  AND d.obj# = dl.dimobj#
  AND dl.dimobj#   = lev.dimension_irid
  AND dl.levelname = lev.physicalname
  ) udl
--
, (SELECT
    h.dimobj#
  , h.hierid#
  , h.hiername hierarchy_name
  , hl.pos# position
  , hl.levelid#
  FROM
    sys.hier$             h
  , sys.hierlevel$        hl
  , olapsys.cwm$hierarchy ch
  WHERE h.dimobj#  = hl.dimobj#
  AND   h.hierid#  = hl.hierid#
  AND   h.dimobj#  = ch.dimension_irid
  AND   h.hiername = ch.name
  ) h
WHERE
    udl.dimobj#  = h.dimobj#(+)
AND udl.levelid# = h.levelid#(+)
--   dba_users u
-- , sys.obj$  d
-- , sys.hier$ h
-- , olapsys.cwm$hierarchy ch
-- , (SELECT
--    pdl.dimobj#
--  , pdl.levelname
--  , phl.hierid#
--  , phl.pos#
--  FROM
--    sys.dimlevel$  pdl
--  , sys.hierlevel$ phl
--  WHERE pdl.dimobj#  = phl.dimobj#
--  AND   pdl.levelid# = phl.levelid#
--  ) pl
-- , (SELECT
--     cdl.dimobj#
--   , cdl.levelname
--   , chl.hierid#
--   , chl.pos#
--   FROM
--     sys.dimlevel$  cdl
--   , sys.hierlevel$ chl
--   WHERE cdl.dimobj#  = chl.dimobj#
--   AND   cdl.levelid# = chl.levelid#
--   ) cl
-- WHERE u.user_id = d.owner#
-- AND d.type# = 43 /* DIMENSION */
-- AND (   cwm$util.dimension_tables_visible(d.obj#) = 'Y'
--      OR EXISTS /* SELECT ANY TABLE, CREATE, ALTER, DROP ANY DIMENSION */
--        (SELECT null FROM v$enabledprivs
--         WHERE priv_number IN (-47,-215,-216,-217)))
-- AND d.obj# = h.dimobj#
-- AND d.obj# = ch.dimension_irid
-- AND h.hiername = ch.name
--
-- AND d.obj#        = cl.dimobj#
-- AND h.hierid#     = cl.hierid#
--
-- AND pl.pos#(+)    = cl.pos# + 1
-- AND pl.dimobj#(+) = cl.dimobj#
-- AND pl.hierid#(+) = cl.hierid#
--
union all
select owner, dimension_name, hierarchy_name, solvedcode, -- parent_level_name,  ADD SOLVEDCODE
       child_level_name, position
from olapsys.ODM$olap2_dim_hier_level_uses  -- SEE ABOVE
with read only
/

