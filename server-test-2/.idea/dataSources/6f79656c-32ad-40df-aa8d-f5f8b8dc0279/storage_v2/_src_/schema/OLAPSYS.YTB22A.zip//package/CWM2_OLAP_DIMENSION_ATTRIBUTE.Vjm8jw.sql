create package cwm2_olap_dimension_attribute as

  procedure Create_Dimension_Attribute(p_Dimension_Owner varchar2
                                      ,p_Dimension_Name varchar2
                                      ,p_Dimension_Attribute_Name varchar2
                                      ,p_Display_Name varchar2
                                      ,p_Short_Description varchar2
                                      ,p_Description varchar2
                                      ,p_Type varchar2);

  procedure Create_Dimension_Attribute(p_Dimension_Owner varchar2
                                      ,p_Dimension_Name varchar2
                                      ,p_Dimension_Attribute_Name varchar2
                                      ,p_Display_Name varchar2
                                      ,p_Short_Description varchar2
                                      ,p_Description varchar2
                                      ,p_Use_Name_As_Type boolean default FALSE);

  procedure Create_Dimension_Attribute_2(p_Dimension_Owner varchar2
                                        ,p_Dimension_Name varchar2
                                        ,p_Dimension_Attribute_Name varchar2
                                        ,p_Display_Name varchar2
                                        ,p_Short_Description varchar2
                                        ,p_Description varchar2
                                        ,p_Use_Name_As_Type number);


  procedure Set_Dimension_Attribute_Name(p_Dimension_Owner varchar2
                                        ,p_Dimension_Name varchar2
                                        ,p_Dimension_Attribute_Name varchar2
                                        ,p_Set_Dimension_Attribute_Name varchar2
                                        ,p_Type varchar2);

  procedure Set_Dimension_Attribute_Name(p_Dimension_Owner varchar2
                                        ,p_Dimension_Name varchar2
                                        ,p_Dimension_Attribute_Name varchar2
                                        ,p_Set_Dimension_Attribute_Name varchar2
                                        ,p_Use_Name_As_Type boolean default FALSE);

  procedure Set_Display_Name(p_Dimension_Owner varchar2
                            ,p_Dimension_Name varchar2
                            ,p_Dimension_Attribute_Name varchar2
                            ,p_Display_Name varchar2);

  procedure Set_Short_Description(p_Dimension_Owner varchar2
                                 ,p_Dimension_Name varchar2
                                 ,p_Dimension_Attribute_Name varchar2
                                 ,p_Short_Description varchar2);

  procedure Set_Description(p_Dimension_Owner varchar2
                           ,p_Dimension_Name varchar2
                           ,p_Dimension_Attribute_Name varchar2
                           ,p_Description varchar2);

  procedure Drop_Dimension_Attribute(p_Dimension_Owner varchar2
                                    ,p_Dimension_Name varchar2
                                    ,p_Dimension_Attribute_Name varchar2);

  procedure Lock_Dimension_Attribute(p_Dimension_Owner varchar2
                                    ,p_Dimension_Name varchar2
                                    ,p_Dimension_Attribute_Name varchar2
                                    ,p_Wait_For_Lock boolean default false);

end cwm2_olap_dimension_attribute;
/

