create view MRV$OLAP2_POP_CUBES as
select
 c.irid id
FROM
 cwm2$cube c
WHERE cwm2$security.fact_table_visible(c.irid) = 'Y'
/

