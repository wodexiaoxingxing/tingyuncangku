create view ALL$OLAP_DIM_ATTRIBUTES as
SELECT
  u.username owner
, d.name dimension_name
, att.physicalname attribute_name
, att.displayname display_name
, att.description description
FROM
  dba_users u
, sys.obj$ d
, cwm$dimensionattribute att
WHERE u.user_id = d.owner#
AND d.type# = 43 /* DIMENSION */
AND (   cwm$util.dimension_tables_visible(d.obj#) = 'Y'
     OR EXISTS /* SELECT ANY TABLE, CREATE, ALTER, DROP ANY DIMENSION */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number IN (-47,-215,-216,-217)))
AND d.obj# = att.itemcontainer_irid
WITH READ ONLY
/

