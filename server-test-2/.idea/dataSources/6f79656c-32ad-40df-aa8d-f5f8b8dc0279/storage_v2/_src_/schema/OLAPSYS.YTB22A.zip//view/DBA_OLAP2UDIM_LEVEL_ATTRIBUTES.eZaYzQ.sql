create view DBA$OLAP2UDIM_LEVEL_ATTRIBUTES as
select da.owner owner,
       da.dimension_name dimension_name,
       da.attribute_name attribute_name,
       da.display_name display_name,
       da.short_description short_description,
       da.long_description description,
       da.determined_by_level_name determined_by_level_name
from
(SELECT
  a.u_name owner
, a.d_name dimension_name
, nvl(la.lat_name, a.c_name) attribute_name
, la.lat_displayname display_name
, la.lat_description short_description
, la.lat_description long_description
, a.l_levelname determined_by_level_name
FROM
 (SELECT /*+ ORDERED*/
    u.username u_name
  , d.name d_name
  , l.dimobj# l_dimobj#
  , l.levelname l_levelname
  , c.obj# c_obj#
  , c.name c_name
 FROM
    dba_users u
  , sys.obj$ d
  , sys.dimlevel$ l
  , sys.dimattr$ a
  , sys.col$ c
  WHERE d.type# = 43 /* DIMENSION */
  AND u.user_id = d.owner#
  AND d.obj# = l.dimobj#
  AND l.dimobj# = a.dimobj#
  AND l.levelid# = a.levelid#
  AND a.detailobj# = c.obj#
  AND a.col# = c.col#) a
, (SELECT
    lat.name lat_name
    , lat.displayname lat_displayname
    , lat.description lat_description
    , lat.type_irid lat_type_irid
    , lat.physicalname lat_physicalname
    , lev.dimension_irid lev_dimension_irid
    , lev.physicalname lev_physicalname
  FROM cwm$level lev, cwm$levelattribute lat
  WHERE lev.irid = lat.itemcontainer_irid) la
WHERE a.l_dimobj# = la.lev_dimension_irid
AND a.l_levelname = la.lev_physicalname
AND a.c_obj# = la.lat_type_irid
AND a.c_name = la.lat_physicalname) da
union all
select owner, dimension_name, attribute_name, display_name, short_description,
       description, determined_by_level_name
from dba$olap2_dim_level_attributes
with read only
/

