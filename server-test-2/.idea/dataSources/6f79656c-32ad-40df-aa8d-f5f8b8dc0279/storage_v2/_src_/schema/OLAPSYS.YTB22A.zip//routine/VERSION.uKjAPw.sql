create function
  version ( comp_id in varchar2 := 'AMD' ) return varchar2
as
begin
  return sys.dbms_registry.version(comp_id);
end;
/

