create view MRV$OLAP2_LISTDIMS_CC as
select
  ld.owner owner,
  ld.dimension_name dimension_name,
  ld.plural_name plural_name,
  ld.display_name display_name,
  ld.shortdescription short_description,
  ld.description description,
  ld.descriptor_value descriptor_value,
  ld.table_owner table_owner,
  ld.table_name table_name,
  ld.column_name column_name,
  ld.column_position column_position,
  ld.data_type data_type,
  ld.data_length data_length,
  ld.data_precision data_precision,
  ld.level_name level_name
 from olapsys.cwm2$mrall_listdims ld
/

