create view DBA$OLAP_FOREIGN_KEYS as
SELECT
  u.username owner
, t.name table_name
, c.name foreign_key_name
, decode(bitand(cd.defer,32),32, 'Y', 'N') is_rely
FROM
  dba_users u
, sys.obj$ t
, sys.con$ c
, sys.cdef$ cd
WHERE u.user_id = t.owner#
AND t.type# IN (2,4) /* table, view */
AND t.obj# = cd.obj#
AND cd.con# = c.con#
AND cd.type# = 4 /* referential */
WITH READ ONLY
/

