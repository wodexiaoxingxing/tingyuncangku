create view ALL$OLAP2UDIM_LEVELS as
select dl1.owner owner,
       dl1.dimension_name dimension_name,
       dl1.level_name level_name,
       dl1.display_name display_name,
       dl1.shortdesc short_description,
       dl1.longdesc description,
       dl1.level_table_owner,
       dl1.level_table_name
from
(SELECT
  u.username owner
, d.name dimension_name
, l.levelname level_name
, lev.displayname display_name
, lev.description shortdesc
, lev.description longdesc
, tu.username level_table_owner
, t.name level_table_name
FROM
  dba_users u
, sys.obj$ d
, sys.dimlevel$ l
, sys.dimlevelkey$ k
, sys.obj$ t
, dba_users tu
, cwm$level lev
WHERE u.user_id = d.owner#
AND d.type# = 43 /* DIMENSION */
AND (   cwm$util.dimension_tables_visible(d.obj#) = 'Y'
     OR EXISTS /* SELECT ANY TABLE, CREATE, ALTER, DROP ANY DIMENSION */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number IN (-47,-215,-216,-217)))
AND d.obj# = l.dimobj#
AND l.dimobj# = k.dimobj#
AND l.levelid# = k.levelid#
AND k.detailobj# = t.obj#
AND t.owner# = tu.user_id
AND k.keypos# = 1
AND l.dimobj# = lev.dimension_irid
AND l.levelname = lev.physicalname (+)) dl1
union all
select owner, dimension_name, level_name, display_name, short_description,
       description, null level_table_owner, null level_table_name
from olapsys.all$olap2_dim_levels
with read only
/

