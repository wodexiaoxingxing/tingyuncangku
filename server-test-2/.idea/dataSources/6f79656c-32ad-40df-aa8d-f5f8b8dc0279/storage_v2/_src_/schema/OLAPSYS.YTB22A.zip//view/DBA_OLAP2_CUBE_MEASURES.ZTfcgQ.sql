create view DBA$OLAP2_CUBE_MEASURES as
select
  c.owner owner,
  c.name cube_name,
  m.name measure_name,
  m.displayname display_name,
  m.shortdescription short_description,
  m.description description
from olapsys.CwM2$Cube c,
     olapsys.CwM2$Measure m
where c.irid = m.cube_irid
with read only
/

