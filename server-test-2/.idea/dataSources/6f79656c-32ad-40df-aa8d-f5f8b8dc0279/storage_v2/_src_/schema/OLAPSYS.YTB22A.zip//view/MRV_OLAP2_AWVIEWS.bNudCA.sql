create view MRV$OLAP2_AWVIEWS as
select
 VIEW_OWNER,
 VIEW_NAME,
 ROWTOCELLCOL_NAME,
 AW_OWNER,
 AW_NAME
 from olapsys.cwm2$mrall_awviews
/

