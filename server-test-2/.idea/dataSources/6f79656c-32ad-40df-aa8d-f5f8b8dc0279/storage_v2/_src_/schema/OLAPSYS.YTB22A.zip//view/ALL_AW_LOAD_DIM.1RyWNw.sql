create view ALL$AW_LOAD_DIM as
select
    ldm.owner owner,
    ldm.dimension_name dimension_name,
    ldm.load_name load_name,
    lt.name load_type
  from olapsys.all$aw_load_dim_map ldm,
       olapsys.cwm2$awdimload l,
       olapsys.cwm2$awdimloadtype lt
  where ldm.dim_irid = l.dim_irid and
        ldm.load_irid = l.irid and
        l.loadtype_irid = lt.irid
  with read only
/

