create view DBA$OLAP2_DIM_LEVELS as
select
  d.owner owner,
  d.name dimension_name,
  l.name level_name,
  l.displayname display_name,
  l.shortdescription short_description,
  l.description description
from olapsys.CwM2$dimension d,
     olapsys.CwM2$level l
where d.irid = l.dimension_irid
with read only
/

