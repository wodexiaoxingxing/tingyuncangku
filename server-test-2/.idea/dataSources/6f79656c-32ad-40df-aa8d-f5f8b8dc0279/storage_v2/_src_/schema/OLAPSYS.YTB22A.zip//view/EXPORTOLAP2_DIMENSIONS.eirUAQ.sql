create view EXPORTOLAP2_DIMENSIONS as
select
  d.owner owner,
  d.name dimension_name,
  d.pluralname plural_name,
  d.displayname display_name,
  d.shortdescription short_description,
  d.description description,
  (case when h.hidden = 'N'
        then h.name else null end) default_display_hierarchy,
  d.invalid invalid,
  d.dimensiontype dimension_type,
  d.irid irid,  -- added for export
  'CWM2' model  -- added for export
from olapsys.CwM2$dimension d,
     olapsys.CwM2$hierarchy h
where
       d.DefaultHier_IRID = h.irid (+)
with read only
/

