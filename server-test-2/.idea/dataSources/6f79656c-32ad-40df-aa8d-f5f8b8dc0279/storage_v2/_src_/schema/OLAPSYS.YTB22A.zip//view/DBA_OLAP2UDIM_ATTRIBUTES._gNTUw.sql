create view DBA$OLAP2UDIM_ATTRIBUTES as
select owner, dimension_name, attribute_name, display_name,
       description short_description, description, desc_id
from dba$olapmr_dim_attributes
union all
select owner, dimension_name, attribute_name, display_name,
       short_description, description, desc_id
from dba$olap2_dim_attributes
with read only
/

