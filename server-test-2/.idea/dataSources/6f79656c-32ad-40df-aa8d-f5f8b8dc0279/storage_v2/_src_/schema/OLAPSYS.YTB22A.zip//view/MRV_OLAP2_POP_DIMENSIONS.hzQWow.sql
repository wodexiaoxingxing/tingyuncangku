create view MRV$OLAP2_POP_DIMENSIONS as
select
 d.irid id
FROM
 cwm2$dimension d
WHERE cwm2$security.dimension_tables_visible(d.irid) = 'Y'
/

