create package cwm$export as

  -- Generate a script of API calls to recreate the contents of the repository.
  --
  -- param script               handle to database clob containing script
  procedure export_all(script out nocopy clob);

  -- Generate a script of API calls to recreate the contents of a catalog
  --
  -- param catalog_id          the id of the catalog to export
  -- param script               handle to database clob containing script
  procedure export_catalog(catalog_id number, script out nocopy clob);
end;
/

