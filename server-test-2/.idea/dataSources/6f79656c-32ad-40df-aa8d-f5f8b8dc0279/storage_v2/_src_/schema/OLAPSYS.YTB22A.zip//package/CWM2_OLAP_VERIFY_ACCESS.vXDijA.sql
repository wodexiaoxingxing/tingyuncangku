create package cwm2_olap_verify_access authid current_user as

  procedure Verify_Cube_Access(p_Cube_Owner varchar2
                              ,p_Cube_Name  varchar2
                              ,p_Type_Of_Access varchar2 default 'DEFAULT'
                              ,p_Verbose_Report varchar2 default 'YES'
                              );

end cwm2_olap_verify_access;
/

