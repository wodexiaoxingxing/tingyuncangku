create view ALL$AW_LOAD_DIM_MAP as
select
  d.owner  OWNER,
  d.name  DIMENSION_NAME,
  l.name  LOAD_NAME,
  d.irid  DIM_IRID,
  l.irid  LOAD_IRID,
  l.version_id VERSION_ID
 from
   olapsys.cwm2$dimension d,
   olapsys.cwm2$awdimload l
 where
   d.irid = l.dim_irid and
   l.version_id = 'CWM2' and
   d.invalid = 'N' and
   (cwm2$security.dimension_tables_visible(d.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47, -215, -216, -217)))
union all
SELECT
  u.username  owner,
  o.name  dimension_name,
  l.name  LOAD_NAME,
  dim.irid DIM_IRID,
  l.irid LOAD_IRID,
  l.version_id VERSION_ID
FROM
  sys.dim$                d,
  dba_users               u,
  sys.obj$                o,
  cwm$dimension           dim,
   olapsys.cwm2$awdimload l
WHERE o.type# = 43 AND
      u.user_id = o.owner# AND
      o.obj#  = d.obj# AND
      d.obj#  = dim.irid AND
      (   cwm$util.dimension_tables_visible(d.obj#) = 'Y'
          OR EXISTS
          /* SELECT ANY TABLE, CREATE, ALTER, DROP ANY DIMENSION */
          (SELECT null FROM v$enabledprivs
           WHERE priv_number IN (-47,-215,-216,-217)))
      and
        dim.irid = l.dim_irid and
        l.version_id = 'CWM'
with read only
/

