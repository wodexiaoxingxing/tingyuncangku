create view DBA$OLAP_DIM_HIERARCHIES as
SELECT
  u.username owner
, d.name dimension_name
, h.hiername hierarchy_name
, hie.displayname display_name
, hie.description description
FROM
  dba_users u
, sys.obj$ d
, sys.hier$ h
, cwm$hierarchy hie
WHERE d.type# = 43 /* DIMENSION */
AND u.user_id = d.owner#
AND d.obj# = h.dimobj#
AND h.dimobj# = hie.dimension_irid (+)
AND h.hiername = hie.name (+)
WITH READ ONLY
/

