create package cwm2_olap_exceptions as

-- internal error
-- call "cwm2_olap_manager.Log_Message('internal_error' ,'my package.my procedure' ,up to 4 arguments);"
-- before raiseing this exception to help us identify the problem
Internal_Error exception;

-- entity not found
Not_Found exception;

-- entity already exists
Already_Exists exception;

-- entity in being accessed by another user
Entity_Busy exception;

-- parameter is not invalid, see log for details
Parameter_Not_Valid exception;

-- parameter is not invalid, see log for details
Parameter_Not_Valid_Starting exception;

-- metadata entry is invalid
Invalid exception;

-- exception has been logged and should not be reported as an unhanddled exception
-- THIS EXCEPTION WILL BE DROPED SOON, DO NOT USE IT.   NOV 18, 2001
Exception_Logged exception;

-- parent child transform
levels_null_levels_list_not exception;

-- parent child transform
levels_not_equal_levels_list exception;

end cwm2_olap_exceptions;
/

