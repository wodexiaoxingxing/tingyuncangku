create package cwm1_olap_validate_metadata as

  procedure Validate_Dimension(p_Dimension_IRID varchar2
                              ,p_Type_Of_Validation varchar2
                              );

  procedure Validate_Cube(p_Cube_IRID number
                         ,p_Type_Of_Validation varchar2
                         );

end cwm1_olap_validate_metadata;
/

