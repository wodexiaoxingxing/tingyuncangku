create view DBA$OLAP2UCUBE_MEASURE_MAPS as
SELECT distinct
  sch.physicalname owner
, cub.physicalname cube_name
, msr.physicalname measure_name
, 0 dim_hier_combo_id
, use2.object_owner fact_table_owner
, use2.object_name fact_table_name
, use2.secondary_object_name column_name
FROM
  dba_users u
, cwm$model sch
, cwm$cube cub
, cwm$measure msr
, cwm$itemuse use1
, cwm$itemuse use2
, cwm$cubedimensionuse cdu
, cwm$dimension cd
, dba_users du
, sys.obj$ do
WHERE u.username = sch.physicalname
AND sch.irid = cub.datamodel_irid
AND cub.irid = msr.itemcontainer_irid
AND msr.irid = use1.mappable_irid
AND use1.operation_irid = use2.operation_irid_1
AND cdu.cube_irid = cub.irid
AND cdu.dimension_owner = du.username
AND cdu.dimension_name = do.name
AND du.user_id = do.owner#
AND do.obj# = cd.irid
AND do.type# = 43
AND cd.irid = cdu.abstractdimension_irid
union all
select owner, cube_name, measure_name,
       dim_hier_combo_id, fact_table_owner,
       fact_table_name, column_name
from olapsys.dba$olap2_cube_measure_maps
with read only
/

