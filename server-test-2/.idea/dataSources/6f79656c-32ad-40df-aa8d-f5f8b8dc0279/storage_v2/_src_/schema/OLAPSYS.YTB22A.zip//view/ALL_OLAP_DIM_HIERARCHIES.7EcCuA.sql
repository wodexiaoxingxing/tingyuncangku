create view ALL$OLAP_DIM_HIERARCHIES as
SELECT
  u.username owner
, d.name dimension_name
, h.hiername hierarchy_name
, hie.displayname display_name
, hie.description description
FROM
  dba_users u
, sys.obj$ d
, sys.hier$ h
, cwm$hierarchy hie
WHERE u.user_id = d.owner#
AND d.type# = 43 /* DIMENSION */
AND (   cwm$util.dimension_tables_visible(d.obj#) = 'Y'
     OR EXISTS /* SELECT ANY TABLE, CREATE, ALTER, DROP ANY DIMENSION */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number IN (-47,-215,-216,-217)))
AND d.obj# = h.dimobj#
AND h.dimobj# = hie.dimension_irid (+)
AND h.hiername = hie.name (+)
WITH READ ONLY
/

