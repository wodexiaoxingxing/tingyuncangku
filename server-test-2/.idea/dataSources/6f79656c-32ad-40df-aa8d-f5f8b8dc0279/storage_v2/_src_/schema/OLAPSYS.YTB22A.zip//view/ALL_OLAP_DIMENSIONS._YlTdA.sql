create view ALL$OLAP_DIMENSIONS as
SELECT
  u.username owner
, o.name dimension_name
, dim.pluralname plural_name
, dim.displayname display_name
, dim.description description
, display_hierarchy_name default_display_hierarchy
, decode(o.status, 5, 'Y', 'N') invalid
, cwm$util.dim_valid(o.obj#) olap_valid
FROM
  dba_users u
, sys.obj$ o
, sys.dim$ d
, cwm$dimension dim
WHERE u.user_id = o.owner#
AND o.obj# = d.obj#
AND d.obj# = dim.irid (+)
AND (   cwm$util.dimension_tables_visible(d.obj#) = 'Y'
     OR EXISTS /* SELECT ANY TABLE, CREATE, ALTER, DROP ANY DIMENSION */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number IN (-47,-215,-216,-217)))
WITH READ ONLY
/

