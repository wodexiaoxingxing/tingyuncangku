create view DBA$OLAP_CUBES as
SELECT
  sch.physicalname owner
, cub.physicalname cube_name
, cwm$util.cube_invalid(cub.irid) invalid
, cub.displayname display_name
, cub.description description
FROM
  dba_users u
, cwm$model sch
, cwm$cube  cub
WHERE u.username = sch.physicalname
AND sch.irid = cub.datamodel_irid
WITH READ ONLY
/

