create view EXPORT2_CATALOGS as
select
 c.irid catalog_id,
 c.name catalog_name,
 cp.irid parent_catalog_id,
 c.description description,
 ce.name entry_name -- added for export
from
 olapsys.cwm$classification c,
 olapsys.cwm$classification cp,
 olapsys.cwm$classificationtype cty,
 olapsys.cwm$classificationentry ce
where cty.irid = c.classificationtype_irid and
      cty.name = 'ORACLE_OLAP2_CATALOG' and
      c.irid = ce.element_irid and
      ce.name = 'CATALOG2' and
      ce.classification_irid = cp.irid
UNION ALL select
 c.irid catalog_id,
 c.name catalog_name,
 null parent_catalog_id,
 c.description description,
 'CATALOG2' entry_name -- added
from
 olapsys.cwm$classification c,
 olapsys.cwm$classificationtype cty
where cty.irid = c.classificationtype_irid and
      cty.name = 'ORACLE_OLAP2_CATALOG' and
      NOT EXISTS
       (select null from olapsys.cwm$classificationentry ce
        where ce.name = 'CATALOG2' and
              ce.element_irid = c.irid)
with read only
/

