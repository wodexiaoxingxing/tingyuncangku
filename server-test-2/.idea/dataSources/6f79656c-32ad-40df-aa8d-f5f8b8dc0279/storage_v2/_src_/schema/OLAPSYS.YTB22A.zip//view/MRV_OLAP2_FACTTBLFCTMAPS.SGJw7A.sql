create view MRV$OLAP2_FACTTBLFCTMAPS as
select
  ftfm.owner owner,
  ftfm.cube_name cube_name,
  ftfm.measure_name measure_name,
  ftfm.dim_hier_combo_id dim_hier_combo_id,
  ftfm.fact_table_owner fact_table_owner,
  ftfm.fact_table_name fact_table_name,
  ftfm.column_name column_name,
  ftfm.data_type data_type,
  ftfm.data_length data_length,
  ftfm.data_precision data_precision,
  ftfm.olap_api_data_type olap_api_data_type
 from olapsys.cwm2$mrall_facttblfctmaps ftfm,
      olapsys.olap_session_objects oso
 where oso.version_id = ftfm.version_id and
       oso.id = ftfm.id
/

