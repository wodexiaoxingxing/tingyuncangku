create package cwm2_olap_cube as

  procedure Create_Cube(p_Cube_Owner varchar2
                       ,p_Cube_Name varchar2
                       ,p_Display_Name varchar2
                       ,p_Short_Description varchar2
                       ,p_Description varchar2);

  procedure Set_Cube_Name(p_Cube_Owner varchar2
                         ,p_Cube_Name varchar2
                         ,p_Set_Cube_Name varchar2);

  procedure Set_Display_Name(p_Cube_Owner varchar2
                            ,p_Cube_Name varchar2
                            ,p_Display_Name varchar2);

  procedure Set_Short_Description(p_Cube_Owner varchar2
                                 ,p_Cube_Name varchar2
                                 ,p_Short_Description varchar2);

  procedure Set_Description(p_Cube_Owner varchar2
                           ,p_Cube_Name varchar2
                           ,p_Description varchar2);

  procedure Set_MV_Summary_Code(p_Cube_Owner varchar2
                               ,p_Cube_Name varchar2
                               ,p_Summary_Code varchar2);

  procedure Drop_Cube(p_Cube_Owner varchar2
                     ,p_Cube_Name varchar2
                     ,p_Silent varchar2 default null);

  procedure Lock_Cube(p_Cube_Owner varchar2
                     ,p_Cube_Name varchar2
                     ,p_Wait_For_Lock boolean default false);

  procedure Add_Dimension_To_Cube(p_Cube_Owner varchar2
                                 ,p_Cube_Name varchar2
                                 ,p_Dimension_Owner varchar2
                                 ,p_Dimension_Name varchar2);

  procedure Set_Default_Cube_Dim_Calc_Hier(p_Cube_Owner varchar2
                                          ,p_Cube_Name varchar2
                                          ,p_Dimension_Owner varchar2
                                          ,p_Dimension_Name varchar2
                                          ,p_hierarchy_name varchar2);

  procedure Set_Aggregation_Operator(p_Cube_Owner varchar2
                                     ,p_Cube_Name varchar2
                                     ,p_AggOper_Spec varchar2);


  procedure Remove_Dimension_From_Cube(p_Cube_Owner varchar2
                                      ,p_Cube_Name varchar2
                                      ,p_Dimension_Owner varchar2
                                      ,p_Dimension_Name varchar2);

end cwm2_olap_cube;
/

