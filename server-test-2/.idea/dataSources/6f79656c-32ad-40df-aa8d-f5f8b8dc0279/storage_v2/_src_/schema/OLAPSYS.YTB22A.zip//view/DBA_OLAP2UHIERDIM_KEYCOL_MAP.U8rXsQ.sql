create view DBA$OLAP2UHIERDIM_KEYCOL_MAP as
select owner owner,
       dimension_name dimension_name,
       hierarchy_name hierarchy_name,
       level_name level_name,
       display_name display_name,
       short_description short_description,
       description description,
       pos hierarchy_position,
       table_owner table_owner,
       table_name table_name,
       column_name column_name,
       column_position column_position,
       data_type data_type,
       data_length data_length,
       data_precision data_precision
from olapsys.dba$olap2_dim_levels_keymaps
union all
select owner owner,
       dimension_name dimension_name,
       hierarchy_name hierarchy_name,
       level_name level_name,
       display_name display_name,
       short_description short_description,
       description description,
       pos hierarchy_position,
       table_owner table_owner,
       table_name table_name,
       column_name column_name,
       column_position column_position,
       data_type data_type,
       data_length data_length,
       data_precision data_precision
from olapsys.dba$olapmr_dim_levels_keymaps
with read only
/

