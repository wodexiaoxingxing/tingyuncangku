create view DBA$OLAP_FACT_LEVEL_USES as
SELECT
  sch.name owner
, cub.name cube_name
, cdu.dimension_owner
, cdu.dimension_name
, cdu.name dimension_alias
, flu.level_name
, fu.object_owner fact_table_owner
, fu.object_name fact_table_name
, flu.foreign_key_name
FROM
  cwm$factuse fu
, cwm$facttablemap fm
, cwm$model sch
, cwm$cube  cub
, dba_users u
, cwm$cubedimensionuse cdu
, cwm$factleveluse flu
WHERE u.username = sch.physicalname
AND sch.irid = cub.datamodel_irid
AND cub.irid = cdu.cube_irid
AND cdu.irid = flu.cubedimensionuse_irid
AND fm.mapcontainer_irid = cub.irid
AND fu.operation_irid_1 = fm.irid
WITH READ ONLY
/

