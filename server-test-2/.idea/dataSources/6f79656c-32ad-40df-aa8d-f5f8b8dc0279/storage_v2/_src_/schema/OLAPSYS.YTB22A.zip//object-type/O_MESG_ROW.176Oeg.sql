create type o_Mesg_Row wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
e9 9a
jGop251qhDAc/IgAzph7eQonZd4wg5n0dLhchdD+LmLc0CiXluqldCulv5vAMsuz523+MrKf
0P6ZgTLAsgml0plSMr+yBgnKHH3dWbjSMlznx3TAM7h0ZSV831AUxsgvseMvRqhg6BpYUd7X
pqYlQ1b1
/

