create view DBA$OLAP2UDIM_HIERARCHIES as
select dh.owner owner,
       dh.dimension_name dimension_name,
       dh.hierarchy_name hierarchy_name,
       dh.display_name display_name,
       dh.short_description short_description,
       dh.long_description description,
       dh.solved_code solved_code
from
(SELECT
  u.username owner
, d.name dimension_name
, h.hiername hierarchy_name
, hie.displayname display_name
, hie.description short_description
, hie.description long_description
, 'UL' solved_code
FROM
  dba_users u
, sys.obj$ d
, sys.hier$ h
, cwm$hierarchy hie
WHERE d.type# = 43 /* DIMENSION */
AND u.user_id = d.owner#
AND d.obj# = h.dimobj#
AND h.dimobj# = hie.dimension_irid
AND h.hiername = hie.name (+)) dh
union all
select owner, dimension_name, hierarchy_name, display_name, short_description,
       description, solved_code
from olapsys.dba$olap2_dim_hierarchies
with read only
/

