create view DBA$OLAP_FUNCTION_ARGUMENTS as
SELECT
/*+ ORDERED */
  a.functionuse_irid function_usage_id
, p.name parameter_name
, u.username entity_owner
, t.name entity_name
, c.name child_entity_name
, 'COLUMN' entity_type
FROM
  cwm$parameter p
, cwm$argument a
, sys.col$ c
, sys.obj$ t
, dba_users u
WHERE a.parameter_irid = p.irid
AND a.element_irid = c.obj#
AND a.secondary_object_name = c.name
AND t.obj# = c.obj#
AND t.type# IN (2,4)
AND t.owner# = u.user_id
WITH READ ONLY
/

