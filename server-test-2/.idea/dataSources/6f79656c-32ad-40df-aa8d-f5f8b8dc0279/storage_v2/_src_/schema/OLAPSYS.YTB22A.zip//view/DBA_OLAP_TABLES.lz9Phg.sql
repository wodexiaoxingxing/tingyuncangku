create view DBA$OLAP_TABLES as
SELECT
  u.username owner
, t.name table_name
, decode (t.type#, 2, 'TABLE', 'VIEW') table_type
FROM
  dba_users u
, sys.obj$ t
WHERE u.user_id = t.owner#
AND t.type# IN (2,4)
WITH READ ONLY
/

