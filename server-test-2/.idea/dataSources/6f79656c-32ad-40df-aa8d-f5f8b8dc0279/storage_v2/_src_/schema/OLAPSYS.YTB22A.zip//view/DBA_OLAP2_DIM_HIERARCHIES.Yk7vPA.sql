create view DBA$OLAP2_DIM_HIERARCHIES as
select
  d.owner owner,
  d.name dimension_name,
  h.name hierarchy_name,
  h.displayname display_name,
  h.shortdescription short_description,
  h.description description,
  h.solvedcode solved_code
from olapsys.CwM2$dimension d,
     olapsys.CwM2$hierarchy h
where d.irid = h.dimension_irid and
      h.hidden = 'N'
with read only
/

