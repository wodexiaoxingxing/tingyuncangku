create view MRV$OLAP2_AGG_USES as
select
 au.OWNER,
 au.CUBE_NAME,
 au.DIMENSION_OWNER,
 au.DIMENSION_NAME,
 au.HIERARCHY_NAME,
 au.DIM_HIER_COMBO_ID,
 au.AGGREGATION_NAME,
 au.AGGREGATION_ORDER,
 au.TABLE_OWNER,
 au.TABLE_NAME,
 au.COLUMN_NAME
 from olapsys.CWM2$MRALL_OLAP2_AGG_USES au,
      olapsys.olap_session_objects oso
 where oso.version_id = au.version_id and
       oso.id = au.id
/

