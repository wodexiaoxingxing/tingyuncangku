create view EXPORTOLAPMR_DIMENSIONS as
SELECT
  u.username                  owner,
  o.name                  dimension_name,
  dim.pluralname          plural_name,
  dim.displayname         display_name,
  dim.description         short_description,
  dim.description         description,
  display_hierarchy_name  default_display_hierarchy,
  o.status                status,
  dim.irid irid,  -- added for export
  'CWM1' model    -- added for export
FROM
  sys.dim$                d,
  dba_users               u,
  sys.obj$                o,
  cwm$dimension           dim
WHERE o.type# = 43 AND
      u.user_id = o.owner# AND
      o.obj#  = d.obj# AND
      d.obj#  = dim.irid
WITH READ ONLY
/

