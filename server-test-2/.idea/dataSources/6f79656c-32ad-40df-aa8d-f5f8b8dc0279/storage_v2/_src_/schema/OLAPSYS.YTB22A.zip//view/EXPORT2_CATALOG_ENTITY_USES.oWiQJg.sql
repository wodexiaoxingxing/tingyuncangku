create view EXPORT2_CATALOG_ENTITY_USES as
select
 ce.classification_irid catalog_id,
 cub.owner entity_owner,
 cub.name entity_name,
 meas.name child_entity_name,
 ce.name entry_name -- added for export
from /* MEASURES */
 olapsys.cwm$classification c,
 olapsys.cwm$classificationentry ce,
 olapsys.cwm$classificationtype cty,
 olapsys.cwm2$measure meas,
 olapsys.cwm2$cube cub
where cty.irid = c.classificationtype_irid and
      cty.name = 'ORACLE_OLAP2_CATALOG' and
      c.irid = ce.classification_irid and
      ce.name = 'MEASURE2' and
      ce.element_irid = meas.irid and
      meas.cube_irid = cub.irid
with read only
/

