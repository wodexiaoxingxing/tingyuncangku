create view ALL$OLAP2UFACT_TABLE_GID as
select
  owner,
  cube_name,
  dimension_owner,
  dimension_name,
  hierarchy_name,
  dim_hier_combo_id,
  fact_table_owner,
  fact_table_name,
  column_name
from all$olap2_fact_table_gid
with read only
/

