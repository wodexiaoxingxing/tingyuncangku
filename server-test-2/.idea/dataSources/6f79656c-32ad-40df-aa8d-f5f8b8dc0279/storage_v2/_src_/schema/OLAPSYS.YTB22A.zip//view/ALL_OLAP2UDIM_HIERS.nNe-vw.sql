create view ALL$OLAP2UDIM_HIERS as
select
 h.owner owner,
 h.dimension_name dimension_name,
 h.hierarchy_name hierarchy_name,
 h.display_name display_name,
 h.short_description short_description,
 h.description description,
 h.solved_code solved_code,
 'Y' is_default
from olapsys.all$olap2udimensions d,
     olapsys.all$olap2udim_hierarchies h
where d.owner = h.owner and d.dimension_name = h.dimension_name
and d.default_display_hierarchy = h.hierarchy_name
union
select
 h.owner owner,
 h.dimension_name dimension_name,
 h.hierarchy_name hierarchy_name,
 h.display_name display_name,
 h.short_description short_description,
 h.description description,
 h.solved_code solved_code,
 'N' is_default
from olapsys.all$olap2udim_hierarchies h
where not exists (select * from olapsys.all$olap2udimensions d
where d.owner = h.owner and d.dimension_name = h.dimension_name
and d.default_display_hierarchy = h.hierarchy_name)
/

