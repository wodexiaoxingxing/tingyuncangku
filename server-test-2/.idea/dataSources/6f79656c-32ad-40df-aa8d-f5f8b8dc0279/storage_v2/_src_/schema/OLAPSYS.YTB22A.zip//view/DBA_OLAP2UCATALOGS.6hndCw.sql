create view DBA$OLAP2UCATALOGS as
select
  catalog_id,
  catalog_name,
  parent_catalog_id,
  description
from olapsys.dba$olap_catalogs
union all
select catalog_id,
  catalog_name,
  parent_catalog_id,
  description
from olapsys.dba$olap2_catalogs
with read only
/

