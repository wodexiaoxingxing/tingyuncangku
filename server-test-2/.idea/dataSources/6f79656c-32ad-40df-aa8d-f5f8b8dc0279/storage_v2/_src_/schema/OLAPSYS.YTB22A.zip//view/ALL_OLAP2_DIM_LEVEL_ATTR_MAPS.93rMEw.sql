create view ALL$OLAP2_DIM_LEVEL_ATTR_MAPS as
select attr.owner owner,
  attr.dimension_name dimension_name,
  (case when attr.hidden = 'N'
        then attr.hierarchy_name else null end) hierarchy_name,
  attr.attribute_name attribute_name,
  attr.lvl_attribute_name lvl_attribute_name,
  attr.level_name level_name,
  attr.table_owner table_owner,
  attr.table_name table_name,
  attr.column_name column_name,
  attr.dtype dtype,
  attr.data_length data_length,
  attr.data_precision data_precision,
 (case when attr.dtype = 'NUMBER' then 0
              when attr.dtype = 'DOUBLE' then 5
              when attr.dtype = 'FLOAT' then 4
              when attr.dtype = 'DATE' then 7
              when attr.dtype = 'LONG' then 3
              else 1 end) olap_api_data_type
from (
select
  d.owner owner,
  d.name dimension_name,
  h.name hierarchy_name,
  da.name attribute_name,
  la.name lvl_attribute_name,
  l.name level_name,
  u.username table_owner,
  o.name table_name,
  col.name column_name,
  h.hidden hidden,
decode(col.type#, 1, decode(col.charsetform, 2, 'NVARCHAR2', 'VARCHAR2'),
                 2, decode(col.scale, null,
                           decode(col.precision#, null, 'NUMBER', 'FLOAT'),
                           'NUMBER'),
                 8, 'LONG',
                 9, decode(col.charsetform, 2, 'NCHAR VARYING', 'VARCHAR'),
                 12, 'DATE', 23, 'RAW', 24, 'LONG RAW',
                 69, 'ROWID',
                 96, decode(col.charsetform, 2, 'NCHAR', 'CHAR'),
                 105, 'MLSLABEL',
                 106, 'MLSLABEL',
                 112, decode(col.charsetform, 2, 'NCLOB', 'CLOB'),
                 113, 'BLOB', 114, 'BFILE', 115, 'CFILE',
                 178, 'TIME(' ||col.spare1|| ')',
                 179, 'TIME(' ||col.spare1|| ')' || ' WITH TIME ZONE',
                 180, 'TIMESTAMP(' ||col.spare1|| ')',
                 181, 'TIMESTAMP(' ||col.spare1|| ')' || ' WITH TIME ZONE',
                 182, 'INTERVAL YEAR(' ||col.spare2||') TO MONTH',
                 183, 'INTERVAL DAY(' ||col.spare2||') TO SECOND(' ||
                       col.spare1 || ')',
                 208, 'UROWID',
                 'UNDEFINED') dtype
, decode(col.length, null, 0, col.length) data_length
, decode(col.precision#, null, 0, col.precision#) data_precision
from olapsys.CwM2$Dimension d,
     olapsys.cwm2$dimensionattribute da,
     olapsys.cwm2$level l,
     olapsys.CwM2$LevelAttribute la,
     olapsys.CwM2$LevelAttributeMap lam,
     olapsys.CwM2$Hierarchy h,
     olapsys.CwM2$HierLevelRel hlr,
     dba_users u,
     sys.obj$ o,
     sys.col$ col
where d.irid = da.dimension_irid and
      la.dimattr_irid = da.irid and
      la.level_irid = l.irid and
      la.irid = lam.levelattr_irid and
      lam.hierlvlrel_irid = hlr.irid and
      hlr.hierarchy_irid = h.irid and
      lam.Table_ID = o.obj# and
      lam.Column_ID = col.col# and
      o.obj# = col.obj# and
      o.owner# = u.user_id and
       d.invalid = 'N' and
       (cwm2$security.dimension_tables_visible(d.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47, -215, -216, -217)))) attr
with read only
/

