create package cwm2_olap_olapapi_enable authid current_user as

  procedure aw_dimension_create_access(p_Dimension_Owner varchar2,
                                       p_Dimension_Name varchar2,
                                       p_AW_Owner varchar2,
                                       p_AW_Name varchar2,
                                       p_Prefix varchar2,
                                       p_Access_Type varchar2,
                                       p_Script_Directory varchar2,
                                       p_Script_Name varchar2,
                                       p_OpenMode varchar2,
                                       p_Caller varchar2 default null,
                                       p_SpreadsheetMode varchar2 default 'YES',
                                       p_AutoAdtMode varchar2 default 'YES');


  procedure aw_dimension_create_access(p_runid number,
                                       p_Dimension_Owner varchar2,
                                       p_Dimension_Name varchar2,
                                       p_AW_Owner varchar2,
                                       p_AW_Name varchar2,
                                       p_Prefix varchar2,
                                       p_Access_Type varchar2,
                                       p_SpreadsheetMode varchar2 default 'YES',
                                       p_AutoAdtMode varchar2 default 'YES');



  procedure aw_cube_create_access(p_Cube_Owner varchar2,
                                  p_Cube_Name varchar2,
                                  p_AW_Owner varchar2,
                                  p_AW_Name varchar2,
                                  p_Prefix varchar2,
                                  p_Access_Type varchar2,
                                  p_Script_Directory varchar2,
                                  p_Script_Name varchar2,
                                  p_OpenMode varchar2,
                                  p_Caller varchar2 default null,
                                  p_SpreadsheetMode varchar2 default 'YES',
                                  p_AutoAdtMode varchar2 default 'YES');


  procedure aw_cube_create_access(p_runid number,
                                  p_Cube_Owner varchar2,
                                  p_Cube_Name varchar2,
                                  p_AW_Owner varchar2,
                                  p_AW_Name varchar2,
                                  p_Prefix varchar2,
                                  p_Access_Type varchar2,
                                  p_SpreadsheetMode varchar2 default 'YES',
                                  p_AutoAdtMode varchar2 default 'YES');



  procedure aw_dimension_drop_access(p_Target_Dim_Name varchar2,
                                     p_AW_Owner varchar2,
                                     p_AW_Name varchar2,
                                     p_Access_Type varchar2,
                                     p_Script_Directory varchar2,
                                     p_Script_Name varchar2,
                                     p_OpenMode varchar2);


  procedure aw_dimension_drop_access(p_runid number,
                                     p_Target_Dim_Name varchar2,
                                     p_AW_Owner varchar2,
                                     p_AW_Name varchar2,
                                     p_Access_Type varchar2,
                                     p_caller varchar2 default null);


  procedure aw_cube_drop_access(p_Target_Cube_Name varchar2,
                                p_AW_Owner varchar2,
                                p_AW_Name varchar2,
                                p_Access_Type varchar2,
                                p_Script_Directory varchar2,
                                p_Script_Name varchar2,
                                p_OpenMode varchar2);


  procedure aw_cube_drop_access(p_runid number,
                                p_Target_Cube_Name varchar2,
                                p_AW_Owner varchar2,
                                p_AW_Name varchar2,
                                p_Access_Type varchar2,
                                p_caller varchar2 default null);



  procedure update_enabled_dim_view(p_AWOwner varchar2,
                                    p_AWName varchar2,
                                    p_DimName varchar2,
                                    p_HierName varchar2,
                                    p_UserViewName varchar2);

  procedure update_enabled_cube_view(p_AWOwner varchar2,
                                     p_AWName varchar2,
                                     p_CubeName varchar2,
                                     p_HierComboNum number,
                                     p_UserViewName varchar2);


end cwm2_olap_olapapi_enable;
/

