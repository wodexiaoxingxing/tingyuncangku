create view DBA$OLAP_DIM_ATTRIBUTES as
SELECT
  u.username owner
, d.name dimension_name
, att.physicalname attribute_name
, att.displayname display_name
, att.description description
FROM
  dba_users u
, sys.obj$ d
, cwm$dimensionattribute att
WHERE d.type# = 43 /* DIMENSION */
AND u.user_id = d.owner#
AND d.obj# = att.itemcontainer_irid
WITH READ ONLY
/

