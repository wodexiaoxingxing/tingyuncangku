create view EXPORT2_DIM_HIER_LEVEL_USES as
select
  d.owner owner,
  d.name dimension_name,
--  (case when h.hidden = 'Y'
--        then null else h.name end) hierarchy_name,
  h.name hierarchy_name,
  pl.name parent_level_name,
  cl.name child_level_name,
  hlr.leveldepth position
from olapsys.CwM2$dimension d,
     olapsys.CwM2$level pl,
     olapsys.CwM2$level cl,
     olapsys.CwM2$HierLevelRel hlr,
     olapsys.CwM2$Hierarchy h
where hlr.dimension_irid = d.irid and
      hlr.hierarchy_IRID = h.irid and
      hlr.parentlevel_irid = pl.irid(+) and
      hlr.childlevel_irid = cl.irid
with read only
/

