create view EXPORTOLAP1_CUBES as
SELECT DISTINCT
   sch.physicalname owner
   , cub.physicalname cube_name
   , cwm$util.cube_invalid(cub.irid) invalid
   , cub.displayname display_name
   , cub.description short_description
   , cub.description description
   , nvl(cub.mvsummarycode, 'RU') mv_summarycode
   , cub.irid irid   -- add for export
   , 'CWM1' model    -- add for export
FROM
   dba_users u
  , cwm$model sch
  , cwm$cube  cub
  , cwm$cubedimensionuse cdu
  , cwm$dimension cd
  , dba_users du
  , sys.obj$ do
WHERE u.username = sch.physicalname
    AND sch.irid = cub.datamodel_irid
    AND cdu.cube_irid = cub.irid
    AND cdu.dimension_owner = du.username
    AND cdu.dimension_name = do.name
    AND du.user_id = do.owner#
    AND do.obj# = cd.irid
    AND do.type# = 43
    AND cd.irid = cdu.abstractdimension_irid
WITH READ ONLY
/

