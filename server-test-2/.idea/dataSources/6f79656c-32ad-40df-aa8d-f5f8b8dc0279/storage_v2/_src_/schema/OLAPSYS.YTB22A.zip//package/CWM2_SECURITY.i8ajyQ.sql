create package CWM2$SECURITY as

function dimension_tables_visible(dim_irid number) return varchar2;

function fact_table_visible(p_cube_irid number) return varchar2;

end;
/

