create view ALL$OLAP2_CATALOG_ENTITY_USES as
select
 ce.classification_irid catalog_id,
 cub.owner entity_owner,
 cub.name entity_name,
 meas.name child_entity_name
from /* MEASURES */
 cwm$classification c,
 cwm$classificationentry ce,
 cwm$classificationtype cty,
 cwm2$measure meas,
 cwm2$cube cub
where cty.irid = c.classificationtype_irid and
      cty.name = 'ORACLE_OLAP2_CATALOG' and
      c.irid = ce.classification_irid and
      ce.name = 'MEASURE2' and
      ce.element_irid = meas.irid and
      meas.cube_irid = cub.irid and
      (cub.invalid = 'N' or cub.invalid = 'O') and
      (cwm2$security.fact_table_visible(cub.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47)))
with read only
/

