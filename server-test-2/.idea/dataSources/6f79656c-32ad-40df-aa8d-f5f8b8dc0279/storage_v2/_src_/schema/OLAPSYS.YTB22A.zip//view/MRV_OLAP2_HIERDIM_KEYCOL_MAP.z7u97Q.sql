create view MRV$OLAP2_HIERDIM_KEYCOL_MAP as
select
  hkm.owner owner,
  hkm.dimension_name dimension_name,
  hkm.hierarchy_name hierarchy_name,
  hkm.level_name level_name,
  hkm.display_name display_name,
  hkm.shortdescription short_description,
  hkm.description description,
  hkm.hierarchy_position hierarchy_position,
  hkm.table_owner table_owner,
  hkm.table_name table_name,
  hkm.column_name column_name,
  hkm.column_position column_position,
  hkm.data_type data_type,
  hkm.data_length data_length,
  hkm.data_precision data_precision
 from olapsys.cwm2$mrall_hierdim_keycol_map hkm,
      olapsys.olap_session_objects oso
 where oso.version_id = hkm.version_id and
       oso.id = hkm.id
/

