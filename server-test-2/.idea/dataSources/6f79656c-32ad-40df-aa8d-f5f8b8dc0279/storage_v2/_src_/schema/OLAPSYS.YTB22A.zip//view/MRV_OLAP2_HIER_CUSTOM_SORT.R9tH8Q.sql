create view MRV$OLAP2_HIER_CUSTOM_SORT as
select
  hcs.owner owner,
  hcs.dimension_name dimension_name,
  hcs.hierarchy_name hierarchy_name,
  hcs.table_owner table_owner,
  hcs.table_name table_name,
  hcs.column_name column_name,
  hcs.position position,
  hcs.sort_pos sort_pos,
  hcs.sort_order sort_order,
  hcs.null_order null_order,
  hcs.data_type data_type,
  hcs.data_length data_length,
  hcs.data_precision data_precision
 from olapsys.cwm2$mrall_hier_custom_sort hcs,
      olapsys.olap_session_objects oso
 where oso.version_id = hcs.version_id and
       oso.id = hcs.id
/

