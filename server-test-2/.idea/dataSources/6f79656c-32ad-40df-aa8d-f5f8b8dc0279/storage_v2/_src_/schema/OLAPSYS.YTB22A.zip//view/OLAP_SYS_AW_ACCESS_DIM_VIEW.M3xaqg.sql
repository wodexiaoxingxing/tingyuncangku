create view OLAP_SYS_AW_ACCESS_DIM_VIEW as
SELECT AW_DIM_ACCESS_INFO FROM
    TABLE(CAST(OLAP_TABLE('SYS.AWCREATE duration session',
                          'OLAPSYS.OLAP_SYS_AW_ACCESS_TBL',
                          '',
                          'DIMENSION AW_DIM_ACCESS_INFO FROM OLAP_SYS_RETURN_INFO')
                      AS OLAP_SYS_AW_ACCESS_TBL))
/

