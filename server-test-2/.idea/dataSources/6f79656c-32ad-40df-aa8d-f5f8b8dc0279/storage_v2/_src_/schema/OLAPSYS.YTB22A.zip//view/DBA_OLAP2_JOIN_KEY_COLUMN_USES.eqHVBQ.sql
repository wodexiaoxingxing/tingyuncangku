create view DBA$OLAP2_JOIN_KEY_COLUMN_USES as
select
  d.owner owner,
  d.name dimension_name,
  (case when h.hidden = 'N'
        then h.name else null end) hierarchy_name,
  l.name child_level_name,
  u.username table_owner,
  o.name table_name,
  c.name column_name,
  dhlm.position position,
  'KEY' join_key_type /* join key type */
from olapsys.CwM2$dimension d,
     olapsys.CwM2$hierarchy h,
     olapsys.CwM2$level l,
     olapsys.CwM2$HierLevelRel hlr,
     olapsys.CwM2$DimHierLvlMap dhlm,
     dba_users u,
     sys.obj$ o,
     sys.col$ c
where h.dimension_irid = d.irid and
      h.irid = hlr.hierarchy_irid and
      l.irid = hlr.childlevel_irid and
      dhlm.DimHierLvl_IRID = hlr.irid and
      dhlm.object_ID = o.obj# and
      dhlm.column_id = c.col# and
      o.obj# = c.obj# and
      o.owner# = u.user_id and
      dhlm.style = 'STAR'
UNION ALL
select d.owner owner,
  d.name dimension_name,
  (case when h.hidden = 'N'
        then h.name else null end) hierarchy_name,
  l.name child_level_name,
  u.username table_owner,
  o.name table_name,
  c.name column_name,
  dhlm.position position,
  'FOREIGN KEY' join_key_type /* join key type */
from olapsys.CwM2$dimension d,
     olapsys.CwM2$hierarchy h,
     olapsys.CwM2$level l,
     olapsys.CwM2$HierLevelRel hlr,
     olapsys.CwM2$DimHierLvlMap dhlm,
     dba_users u,
     sys.obj$ o,
     sys.col$ c
where h.dimension_irid = d.irid and
      h.irid = hlr.hierarchy_irid and
      l.irid = hlr.parentlevel_irid and
      dhlm.DimHierLvl_IRID = hlr.irid and
      dhlm.object_ID = o.obj# and
      dhlm.parentcolumn_id = c.col# and
      o.obj# = c.obj# and
      o.owner# = u.user_id and
      dhlm.style = 'SNOWFLAKE'
with read only
/

