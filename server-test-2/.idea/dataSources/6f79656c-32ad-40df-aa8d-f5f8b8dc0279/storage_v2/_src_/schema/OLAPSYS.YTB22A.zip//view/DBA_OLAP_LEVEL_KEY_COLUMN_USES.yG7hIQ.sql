create view DBA$OLAP_LEVEL_KEY_COLUMN_USES as
SELECT
/*+ ORDERED */
  du.username owner
, d.name dimension_name
, l.levelname level_name
, c.name column_name
, k.keypos# position
FROM
  dba_users du
, sys.obj$ d
, sys.dimlevel$ l
, sys.dimlevelkey$ k
, sys.col$ c
WHERE du.user_id = d.owner#
AND d.type# = 43
AND d.obj# = l.dimobj#
AND l.dimobj# = k.dimobj#
AND l.levelid# = k.levelid#
AND k.detailobj# = c.obj#
AND k.col# = c.col#
WITH READ ONLY
/

