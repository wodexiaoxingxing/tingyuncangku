create view ALL$OLAP2_CUBE_MEASURES as
select
  c.owner owner,
  c.name cube_name,
  m.name measure_name,
  m.displayname display_name,
  m.shortdescription short_description,
  m.description description
from olapsys.CwM2$Cube c,
     olapsys.CwM2$Measure m
where c.irid = m.cube_irid and
      (c.invalid = 'N' or c.invalid = 'O') and
  (cwm2$security.fact_table_visible(c.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47)))
with read only
/

