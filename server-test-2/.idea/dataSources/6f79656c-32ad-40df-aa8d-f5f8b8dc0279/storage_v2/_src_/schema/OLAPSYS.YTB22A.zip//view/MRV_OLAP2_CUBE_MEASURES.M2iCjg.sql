create view MRV$OLAP2_CUBE_MEASURES as
select
  cm.owner owner,
  cm.cube_name cube_name,
  cm.measure_name measure_name,
  cm.display_name display_name,
  cm.shortdescription short_description,
  cm.description description,
  cm.cube_description cube_description
 from olapsys.cwm2$mrall_cube_measures cm,
      olapsys.olap_session_objects oso
 where oso.version_id = cm.version_id and
       oso.id = cm.id
/

