create view MRV$OLAP2_HIERDIMS_CC as
select
  hd.owner owner,
  hd.dimension_name dimension_name,
  hd.plural_name plural_name,
  hd.display_name display_name,
  hd.shortdescription short_description,
  hd.description description,
  hd.default_display_hierarchy default_display_hierarchy,
  hd.descriptor_value descriptor_value
 from olapsys.cwm2$mrall_hierdims hd
/

