create view ALL$AW_LOAD_DIM_PARM as
select
    ldm.owner owner,
    ldm.dimension_name dimension_name,
    ldm.load_name load_name,
    dlp.name parm_name,
    dlpv.value parm_value
 from olapsys.all$aw_load_dim_map ldm,
      olapsys.cwm2$awdimloadparm dlp,
      olapsys.cwm2$awdimloadparmvalue dlpv
 where ldm.load_irid = dlpv.dimload_irid
   and dlpv.parmname_irid = dlp.irid
with read only
/

