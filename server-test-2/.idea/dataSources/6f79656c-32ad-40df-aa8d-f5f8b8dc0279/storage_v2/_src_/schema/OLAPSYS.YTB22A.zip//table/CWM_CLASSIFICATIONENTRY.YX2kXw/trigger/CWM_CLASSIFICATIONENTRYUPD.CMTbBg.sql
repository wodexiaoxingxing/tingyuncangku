create trigger CWM$CLASSIFICATIONENTRYUPD
    before insert or update
    on CWM$CLASSIFICATIONENTRY
    for each row
declare
    v_User_Name varchar2(30);
  begin
    select USER into v_User_Name from dual;
    if inserting then
      :new.CreatedOn := SYSDATE;
      :new.CreatedBy := v_User_Name;
    else
      :new.LastModifiedOn := SYSDATE;
      :new.LastModifiedBy := v_User_Name;
    end if;
  end;
/

