create view ALL$OLAP2UCUBES as
select owner, cube_name, invalid, display_name, short_description, description,
       mv_summarycode
from olapsys.all$olap1_cubes
union all
select owner, cube_name, invalid, display_name, short_description, description,
       mv_summarycode
from olapsys.all$olap2_cubes
with read only
/

