create view ALL$AW_LOAD_CUBE_MAP as
select
   c.owner owner,
   c.name cube_name,
   c.irid cube_irid,
   l.name load_name,
   l.irid load_irid,
   l.version_id version_id
  from olapsys.CwM2$Cube c,
       olapsys.cwm2$awcubeload l
    where (c.invalid = 'N' OR c.invalid = 'O') and
    l.version_id = 'CWM2' and
    (cwm2$security.fact_table_visible(c.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47)))
    and
      c.irid = l.cube_irid
union all
SELECT
   sch.physicalname owner
   , cub.physicalname cube_name
   , cub.irid cube_irid,
   l.name load_name,
   l.irid load_irid,
   l.version_id version_id
FROM
   dba_users u
  , cwm$model sch
  , cwm$cube  cub
  , olapsys.cwm2$awcubeload l
WHERE u.username = sch.physicalname
    AND sch.irid = cub.datamodel_irid
    AND (cwm$util.fact_table_visible(cub.irid) = 'Y'
         OR EXISTS /* SELECT ANY TABLE */
          (SELECT null FROM v$enabledprivs
            WHERE priv_number = -47))
   and cub.irid = l.cube_irid and
       l.version_id = 'CWM'
with read only
/

