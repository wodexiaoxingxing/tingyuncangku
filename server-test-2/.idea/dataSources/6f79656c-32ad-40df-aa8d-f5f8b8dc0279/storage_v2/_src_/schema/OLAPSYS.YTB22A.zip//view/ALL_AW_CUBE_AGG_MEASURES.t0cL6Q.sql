create view ALL$AW_CUBE_AGG_MEASURES as
select c.owner cube_owner,
          c.name cube_name,
          cagg.name aggregation_name,
          m.name measure_name
   from
     cwm2$cube c,
     cwm2$awcubeagg cagg,
     cwm2$awcubeaggmeasure caggm,
     cwm2$measure m
   where
     cagg.cube_irid = c.irid and
     cagg.version_id = 'CWM2' and
     (c.invalid = 'N' or c.invalid = 'O') and
     caggm.cubeagg_irid = cagg.irid and
     m.irid = caggm.measure_irid and
     (cwm2$security.fact_table_visible(c.irid) = 'Y'
        OR EXISTS (select null from v$enabledprivs
                   where priv_number in (-47)))
  union all
   select sch.physicalname cube_owner,
          c.physicalname cube_name,
          cagg.name aggregation_name,
          m.physicalname measure_name
   from
      cwm$cube c,
      cwm$model sch,
      cwm2$awcubeagg cagg,
      cwm2$awcubeaggmeasure caggm,
      cwm$measure m
   where
     sch.irid = c.datamodel_irid and
     cagg.cube_irid = c.irid and
     cagg.version_id = 'CWM' and
     caggm.cubeagg_irid = cagg.irid and
     caggm.measure_irid = m.irid and
     (cwm$util.fact_table_visible(c.irid) = 'Y'
        OR EXISTS (select null from v$enabledprivs
                   where priv_number in (-47)))
with read only
/

