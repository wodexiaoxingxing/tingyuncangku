create view ALL$OLAP2UHIERDIMS as
select owner, dimension_name, plural_name, display_name, short_description,
       description, default_display_hierarchy, descriptor_value
from olapsys.all$olap9i1_hier_dimensions
union all
select owner, dimension_name, plural_name, display_name, short_description,
       description, default_display_hierarchy, descriptor_value
from olapsys.all$olap9i2_hier_dimensions
with read only
/

