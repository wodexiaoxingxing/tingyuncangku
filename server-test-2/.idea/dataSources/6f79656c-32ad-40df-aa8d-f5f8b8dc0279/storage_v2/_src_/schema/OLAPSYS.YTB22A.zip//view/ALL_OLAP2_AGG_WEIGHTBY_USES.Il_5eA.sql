create view ALL$OLAP2_AGG_WEIGHTBY_USES as
select
  c.owner owner,
  c.name cube_name,
  d.owner dimension_owner,
  d.name dimension_name,
  (case when h.hidden = 'N'
        then h.name else null end) hierarchy_name,
  fdhm.irid dim_hier_combo_id,
  f.name aggregation_name,
  fkdhm.aggorder aggregation_order,
  u.username table_owner,
  o.name table_name,
  col.name column_name
from olapsys.CwM2$Cube c,
     olapsys.CwM2$Dimension d,
     olapsys.CwM2$CubeDimensionUse cdu,
     olapsys.CwM2$FactDimHierMap fdhm,
     olapsys.CwM2$FactDimHierTplsDtl fdhtd,
     olapsys.CwM2$FactKeyDimHierMap fkdhm,
     olapsys.CwM2$Hierarchy h,
     olapsys.cwm$Function f,
     sys.obj$ o,
     dba_users u,
     sys.col$ col
where c.irid = cdu.cube_irid and
      d.irid = cdu.dimension_irid and
      h.dimension_irid = d.irid and
      fdhm.cube_irid = c.irid and
      fkdhm.factDimHier_IRID = fdhm.irid and
      fkdhm.dimension_irid = d.irid and
      fdhm.irid = fdhtd.factdimhier_irid and
      h.irid = fdhtd.hier_irid and
      fkdhm.aggoperator_irid = f.irid and
      u.user_id = o.owner# and
      o.obj# = col.obj# and
      col.col# = fkdhm.AggWeightCol_ID and
      col.obj# = fkdhm.AggWeightTbl_ID and
       (c.invalid = 'N' or c.invalid = 'O') and
       (cwm2$security.fact_table_visible(c.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47)))
with read only
/

