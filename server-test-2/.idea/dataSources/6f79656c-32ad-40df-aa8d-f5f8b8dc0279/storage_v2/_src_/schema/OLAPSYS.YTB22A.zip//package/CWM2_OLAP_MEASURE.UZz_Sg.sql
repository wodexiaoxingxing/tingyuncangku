create package cwm2_olap_measure as

procedure create_measure(p_Cube_Owner varchar2
                        ,p_Cube_Name varchar2
                        ,p_Measure_Name varchar2
                        ,p_Display_Name varchar2
                        ,p_Short_Description varchar2
                        ,p_Description varchar2);


procedure set_measure_name(p_Cube_Owner varchar2
                          ,p_Cube_Name varchar2
                          ,p_Measure_Name varchar2
                          ,p_Set_Measure_Name varchar2);

procedure set_display_name(p_Cube_Owner varchar2
                          ,p_Cube_Name varchar2
                          ,p_Measure_Name varchar2
                          ,p_Display_Name varchar2);

procedure set_short_description(p_Cube_Owner varchar2
                               ,p_Cube_Name varchar2
                               ,p_Measure_Name varchar2
                               ,p_Short_Description varchar2);

procedure set_description(p_Cube_Owner varchar2
                         ,p_Cube_Name varchar2
                         ,p_Measure_Name varchar2
                         ,p_Description varchar2);

procedure drop_measure(p_Cube_Owner varchar2
                      ,p_Cube_Name varchar2
                      ,p_Measure_Name varchar2);

procedure lock_measure(p_Cube_Owner varchar2
                      ,p_Cube_Name varchar2
                      ,p_Measure_Name varchar2
                      ,p_Wait_For_Lock boolean default false);

end cwm2_olap_measure;
/

