create view DBA$OLAP9I2_HIER_DIMENSIONS as
SELECT distinct
  dim.owner               owner,
  dim.name                dimension_name,
  dim.pluralname          plural_name,
  dim.displayname         display_name,
  dim.shortdescription    short_description,
  dim.description         description,
  h.name                 default_display_hierarchy,
  (case when ce.classification_irid = 28 then 'Time'
       else 'Other'
       end)    descriptor_value
FROM
  olapsys.cwm2$dimension           dim,
  olapsys.cwm2$hierarchy h,
  olapsys.cwm$classificationentry ce
WHERE
      (dim.defaulthier_irid = h.irid  or
       dim.irid in (select irid from olapsys.cwm2$hierarchy))
and
      h.hidden = 'N'
AND dim.irid = ce.element_irid (+) and
    ce.name (+) = 'DIMENSION2'
WITH READ ONLY
/

