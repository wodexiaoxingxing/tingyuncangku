create view CWM2$MRTMPCWM1AGGORD as
select x.owner owner,
          x.cube_name cube_name,
          x.dimension_owner dimension_owner,
         x.dimension_name dimension_name,
         x.position position,
         'CWM1' version_id,
         x.id id
       from
       (
        select  rownum position,
                cdu2.cube_dimension_use_id cube_dimension_use_id,
                cdu2.dependent_on_dim_use_id dependent_on_dim_use_id,
                cdu2.owner owner,
                cdu2.cube_name cube_name,
                cdu2.dimension_owner dimension_owner,
                cdu2.dimension_name dimension_name,
                cdu2.id id
          from (
SELECT
  cdu.irid cube_dimension_use_id
, sch.physicalname owner
, cub.physicalname cube_name
, cdu.dimension_owner dimension_owner
, cdu.dimension_name dimension_name
, cdu.name dimension_alias
, cdu.cubedimensionuse_irid dependent_on_dim_use_id
, cdu.calc_hierarchy_name default_calc_hierarchy_name
, cub.irid id
FROM
  dba_users u
, cwm$model sch
, cwm$cube cub
, cwm$cubedimensionuse cdu
, cwm$dimension cd
, dba_users du
, sys.obj$ do
WHERE u.username = sch.physicalname
AND sch.irid = cub.datamodel_irid
AND cub.irid = cdu.cube_irid
AND cdu.dimension_owner = du.username
AND cdu.dimension_name = do.name
AND du.user_id = do.owner#
AND cd.irid = do.obj#
AND do.type# = 43
AND cd.irid = cdu.abstractdimension_irid
) cdu2
    start with cdu2.dependent_on_dim_use_id is null
    connect by prior cdu2.cube_dimension_use_id = cdu2.dependent_on_dim_use_id
     order
      siblings by cdu2.owner, cdu2.cube_name
        ) x
       group by x.owner, x.cube_name, x.dimension_owner, x.dimension_name,
               x.position, x.id
       having count(x.dependent_on_dim_use_id) > 0
order by x.owner, x.cube_name, x.position
/

