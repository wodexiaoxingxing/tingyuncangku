create view DBA$OLAP2_CUBE_DIM_USES as
select
  cdu.irid cube_dimension_use_id,
  c.owner owner,
  c.name cube_name,
  d.owner dimension_owner,
  d.name dimension_name,
  null dimension_alias,
  (case when h.hidden = 'N' then h.name
        else null end) default_calc_hierarchy_name,
  null dependent_on_dim_use_id
from olapsys.CwM2$CubeDimensionUse cdu,
     olapsys.CwM2$Cube c,
     olapsys.CwM2$Dimension d,
     olapsys.CwM2$hierarchy h
where c.irid = cdu.cube_irid and
      d.irid = cdu.dimension_irid and
      cdu.DefaultCalcHier_IRID = h.irid (+)
with read only
/

