create view DBA$OLAP2_RUFCTTBLKYMAPS as
select flu.owner owner,
           flu.cube_name cube_name,
           flu.dim_hier_combo_id dim_hier_combo_id,
           flu.dimension_owner dimension_owner,
           flu.dimension_name dimension_name,
           flu.hierarchy_name hierarchy_name,
           flu.fact_table_owner fact_table_owner,
           flu.fact_table_name fact_table_name,
          flu.column_name column_name,
          ftg.column_name gid_column_name
   from olapsys.dba$olap2_fact_level_uses flu,
        olapsys.dba$olap2_dim_levels_keymaps lkm,
        olapsys.dba$olap2_fact_table_gid ftg
   where
     flu.dimension_keymap_type = 'RU' and
     flu.dimension_owner = lkm.owner and
     flu.dimension_name = lkm.dimension_name and
     flu.hierarchy_name = lkm.hierarchy_name and
     flu.level_name = lkm.level_name and
     flu.owner = ftg.owner
     and flu.cube_name = ftg.cube_name
     and flu.dimension_owner = ftg.dimension_owner
     and flu.dimension_name = ftg.dimension_name
     and flu.hierarchy_name = ftg.hierarchy_name
     and flu.dim_hier_combo_id = ftg.dim_hier_combo_id
     and flu.fact_table_owner = ftg.fact_table_owner
     and flu.fact_table_name = ftg.fact_table_name
  order by flu.owner asc, flu.cube_name asc, flu.dim_hier_combo_id asc,
    flu.dimension_owner asc, flu.dimension_name asc, flu.hierarchy_name asc,
    lkm.pos desc
/

