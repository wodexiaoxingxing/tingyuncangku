create view MRV$OLAP2_ENTITY_DESC_USES as
select
  edu.descriptor_id descriptor_id,
  edu.entity_owner entity_owner,
  edu.entity_name entity_name,
  edu.child_entity_name child_entity_name,
  edu.secondary_child_entity_name secondary_child_entity_name
 from olapsys.cwm2$mrall_entity_desc_uses edu,
      olapsys.olap_session_objects oso
 where oso.version_id = edu.version_id and
       oso.id = edu.id
/

