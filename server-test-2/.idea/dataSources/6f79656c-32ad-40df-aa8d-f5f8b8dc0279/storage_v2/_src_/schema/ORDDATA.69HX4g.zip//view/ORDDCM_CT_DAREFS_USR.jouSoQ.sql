create view ORDDCM_CT_DAREFS_USR as
select DA_ID, DOC_ID
from ORDDATA.ORDDCM_CT_DAREFS_TMP
with read only
/

