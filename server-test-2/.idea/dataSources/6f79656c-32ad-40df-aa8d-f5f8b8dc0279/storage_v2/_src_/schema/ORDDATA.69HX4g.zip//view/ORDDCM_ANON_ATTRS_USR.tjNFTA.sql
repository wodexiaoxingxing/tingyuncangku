create view ORDDCM_ANON_ATTRS_USR as
select
    AAID
   ,DOC_ID
   ,TAG
   ,ANON_ACTION_TYPE_ID
   ,ANON_VALUE
   ,TAG_DESC
from  ORDDATA.ORDDCM_ANON_ATTRS_TMP
with read only
/

