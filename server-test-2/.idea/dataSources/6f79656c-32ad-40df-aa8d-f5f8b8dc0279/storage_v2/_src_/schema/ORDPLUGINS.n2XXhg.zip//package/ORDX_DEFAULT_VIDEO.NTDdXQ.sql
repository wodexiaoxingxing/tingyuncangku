create PACKAGE ORDX_DEFAULT_VIDEO
authid current_user
AS


  --VIDEO ATTRIBUTES ACCESSORS
  FUNCTION  getAttribute(ctx IN OUT RAW,
                         obj IN ORDSYS.ORDVideo,
                         name IN VARCHAR2) RETURN VARCHAR2;

  PROCEDURE setProperties(ctx IN OUT RAW,
                          obj IN OUT NOCOPY ORDSYS.ORDVideo,
                          setComments IN NUMBER := 0);
  FUNCTION checkProperties(ctx IN OUT RAW,obj IN OUT NOCOPY ORDSYS.ORDVideo)
  RETURN NUMBER;

  -- must return name=value; name=value; ...  pairs
  PROCEDURE getAllAttributes(ctx IN OUT RAW,
                             obj IN ORDSYS.ORDVideo,
                             attributes IN OUT NOCOPY CLOB);

  -- VIDEO PROCESSING METHODS
  FUNCTION  processCommand(
                                 ctx       IN OUT RAW,
                                 obj       IN OUT NOCOPY ORDSYS.ORDVideo,
                                 cmd       IN VARCHAR2,
                                 arguments IN VARCHAR2,
				 result OUT RAW)
             RETURN RAW;
  PRAGMA RESTRICT_REFERENCES(getAttribute, WNDS, WNPS, RNDS, RNPS);

END;
/

