create type        rlm$collpreds as object
 (rlm$grpbyrep  NUMBER,
  rlm$wndiwspc  NUMBER,
  rlm$hvgpred   VARCHAR2(4000),
  rlm$prdslhs   EXFSYS.RLM$APNUMBLST,
  rlm$prdsrhs   EXFSYS.RLM$APVARCLST,
  constructor function rlm$collpreds return self as result);
/

