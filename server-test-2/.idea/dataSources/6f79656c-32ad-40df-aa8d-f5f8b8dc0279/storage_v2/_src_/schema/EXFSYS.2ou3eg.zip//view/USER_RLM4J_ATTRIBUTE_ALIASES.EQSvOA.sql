create view USER_RLM4J_ATTRIBUTE_ALIASES (EVENT_STRUCT, ATTRIBUTE_ALIAS, ATTRIBUTE_EXPRESSION, ALIAS_TYPE) as
SELECT esname, esattals, esattexp,
          decode(bitand(aliastype, 1), 1, 'PREDICATE', 'LHS')
  FROM  rlm4j$attraliases
  WHERE esowner =  SYS_CONTEXT('USERENV', 'CURRENT_USER')
/

