create view USER_EXPFIL_PRIVILEGES as
select esowner, esexptab, esexpcol, esgrantee, escrtpriv, esupdpriv from
   exf$expsetprivs where esgrantee = 'PUBLIC' or
    esgrantee = (select user from dual) or
    esowner = (select user from dual)
/

comment on table USER_EXPFIL_PRIVILEGES is 'Privileges for Expression set modifications'
/

comment on column USER_EXPFIL_PRIVILEGES.EXPSET_OWNER is 'Owner of the table storing the expression set. Also the grantor'
/

comment on column USER_EXPFIL_PRIVILEGES.EXPSET_TABLE is 'The table storing the expression set in the owner''s schema'
/

comment on column USER_EXPFIL_PRIVILEGES.EXPSET_COLUMN is 'The column storing the expression set'
/

comment on column USER_EXPFIL_PRIVILEGES.GRANTEE is 'Grantee of the privilege. PUBLIC or the current user'
/

comment on column USER_EXPFIL_PRIVILEGES.INSERT_PRIV is 'Grantee''s privilege to create new expressions in the set'
/

comment on column USER_EXPFIL_PRIVILEGES.UPDATE_PRIV is 'Grantee''s privilege to modify existing expressions in the set'
/

