create view USER_RLMGR_RULE_CLASSES
            (RULE_CLASS_NAME, ACTION_CALLBACK, EVENT_STRUCTURE, RULE_CLASS_PACK, RCLS_RSLT_VIEW, IS_COMPOSITE,
             SEQUENCE_ENB, AUTOCOMMIT, CONSUMPTION, DURATION, ORDERING, EQUAL, DML_EVENTS, CNF_EVENTS)
as
select rset_name, action_cbk, rset_eventst, rset_pack,
      rset_rsltvw,
      decode(bitand(rset_prop, 4),4, 'YES', 'NO'),
      decode(bitand(rset_prop, 4),4,
        decode(bitand(rset_prop, 8),8, 'YES', 'NO'), 'N/A'),
      decode(bitand(rset_prop, 16),16, 'YES', 'NO'),
      decode(bitand(rset_prop, 32),32, 'EXCLUSIVE',
             decode(bitand(rset_prop, 64),64, 'RULE','SHARED')),
      rset_durtcl, rset_ordrcl, rset_eqcls,
      decode(bitand(rset_prop, 128), 128, 'INS',
             decode(bitand(rset_prop, 256), 256, 'INS/UPD',
             decode(bitand(rset_prop, 512), 512, 'INS/UPD/DEL', 'N/A'))),
      decode(bitand(rset_prop, 1024), 1024, 'INS',
             decode(bitand(rset_prop, 2048), 2048, 'INS/UPD',
             decode(bitand(rset_prop, 4096), 4096, 'INS/UPD/DEL', 'N/A')))
    from rlm$ruleset where
    rset_owner = sys_context('USERENV', 'CURRENT_USER')
/

comment on table USER_RLMGR_RULE_CLASSES is 'List of all the rule classes in the current schema'
/

comment on column USER_RLMGR_RULE_CLASSES.RULE_CLASS_NAME is 'Name of the rule class'
/

comment on column USER_RLMGR_RULE_CLASSES.ACTION_CALLBACK is 'The procedure configured as action callback for the rule class'
/

comment on column USER_RLMGR_RULE_CLASSES.EVENT_STRUCTURE is 'The event structure used for the rule class'
/

comment on column USER_RLMGR_RULE_CLASSES.RULE_CLASS_PACK is 'Name of the package implementing the rule class cursors (internal)'
/

comment on column USER_RLMGR_RULE_CLASSES.RCLS_RSLT_VIEW is 'View to display the matching events and rules for the current session'
/

comment on column USER_RLMGR_RULE_CLASSES.IS_COMPOSITE is 'YES if the rules class is configured for composite events'
/

comment on column USER_RLMGR_RULE_CLASSES.SEQUENCE_ENB is 'YES if the rules class is enabled for rule conditions with sequencing'
/

comment on column USER_RLMGR_RULE_CLASSES.AUTOCOMMIT is 'YES if the rules class is configured for auto-commiting events and rules'
/

comment on column USER_RLMGR_RULE_CLASSES.CONSUMPTION is 'Default Consumption policy for the events in the rule class: EXCLUSIVE/SHARED'
/

comment on column USER_RLMGR_RULE_CLASSES.DURATION is 'Default Duration policy of the primitive events'
/

comment on column USER_RLMGR_RULE_CLASSES.ORDERING is 'Ordering clause used for conflict resolution among matching rules and
events'
/

comment on column USER_RLMGR_RULE_CLASSES.DML_EVENTS is 'Types of DML operations enabled for event management'
/

comment on column USER_RLMGR_RULE_CLASSES.CNF_EVENTS is 'Types of Change Notifications enabled for event management'
/

