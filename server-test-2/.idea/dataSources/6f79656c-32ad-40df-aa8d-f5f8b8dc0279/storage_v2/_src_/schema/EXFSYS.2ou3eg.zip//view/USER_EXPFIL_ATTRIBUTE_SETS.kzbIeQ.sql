create view USER_EXPFIL_ATTRIBUTE_SETS as
select atsname from exf$attrset
  where atsowner = (select user from dual)
/

comment on table USER_EXPFIL_ATTRIBUTE_SETS is 'List of all the attribute sets in the current schema'
/

comment on column USER_EXPFIL_ATTRIBUTE_SETS.ATTRIBUTE_SET_NAME is 'Name of the attribute set'
/

