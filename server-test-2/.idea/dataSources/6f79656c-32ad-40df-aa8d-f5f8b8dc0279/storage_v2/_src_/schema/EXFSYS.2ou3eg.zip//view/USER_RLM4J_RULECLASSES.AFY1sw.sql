create view USER_RLM4J_RULECLASSES as
SELECT rle.dbowner, rle.dbrsname, rle.dbevsnm, rle.javapck,
    rle.javacls
  FROM rlm4j$ruleset rle
  where rle.dbowner = SYS_CONTEXT('USERENV', 'CURRENT_USER')
/

