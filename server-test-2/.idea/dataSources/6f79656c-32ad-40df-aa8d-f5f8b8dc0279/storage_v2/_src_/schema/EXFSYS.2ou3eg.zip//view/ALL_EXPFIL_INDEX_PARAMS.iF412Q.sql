create view ALL_EXPFIL_INDEX_PARAMS
            (OWNER, EXPSET_TABLE, EXPSET_COLUMN, ATTRIBUTE, DATA_TYPE, ELEMENTARY, INDEXED, OPERATOR_LIST,
             XMLTYPE_ATTR) as
select esetowner, esettabn, esetcoln, attrsexp, attrtype,
         decode (bitand(attrprop, 1), 1, 'YES','NO'),
         decode (bitand(attrprop, 8), 8, 'YES','NO'),
         varray2str(attroper), xmltattr
  from exf$esetidxparam, all_tables ao
  where  esetowner = ao.owner and esettabn = ao.table_name
/

comment on table ALL_EXPFIL_INDEX_PARAMS is 'List of all the stored attributes for index instances accessible to the user'
/

comment on column ALL_EXPFIL_INDEX_PARAMS.OWNER is 'Owner of the Expression Set'
/

comment on column ALL_EXPFIL_INDEX_PARAMS.EXPSET_TABLE is 'Name of the table storing the expressions'
/

comment on column ALL_EXPFIL_INDEX_PARAMS.EXPSET_COLUMN is 'Name of the column storing the expressions'
/

comment on column ALL_EXPFIL_INDEX_PARAMS.ATTRIBUTE is 'Name of the attribute'
/

comment on column ALL_EXPFIL_INDEX_PARAMS.DATA_TYPE is 'Datatype of the attribute'
/

comment on column ALL_EXPFIL_INDEX_PARAMS.ELEMENTARY is 'Field to indicate if the attribute is elementary'
/

comment on column ALL_EXPFIL_INDEX_PARAMS.INDEXED is 'Field to indicate if the attribute is indexed in the predicate table'
/

comment on column ALL_EXPFIL_INDEX_PARAMS.OPERATOR_LIST is 'List of common operators for the attribute'
/

comment on column ALL_EXPFIL_INDEX_PARAMS.XMLTYPE_ATTR is 'The XMLType attribute for which the current XPath attribute is defined'
/

