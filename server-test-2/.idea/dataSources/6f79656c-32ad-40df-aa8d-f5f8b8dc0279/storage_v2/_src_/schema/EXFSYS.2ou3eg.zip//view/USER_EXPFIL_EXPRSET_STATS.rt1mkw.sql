create view USER_EXPFIL_EXPRSET_STATS
            (EXPR_TABLE, EXPR_COLUMN, ATTRIBUTE_EXP, PCT_OCCURRENCE, PCT_EQ_OPER, PCT_LT_OPER, PCT_GT_OPER,
             PCT_LTEQ_OPER, PCT_GTEQ_OPER, PCT_NEQ_OPER, PCT_NUL_OPER, PCT_NNUL_OPER, PCT_BETW_OPER, PCT_NVL_OPER,
             PCT_LIKE_OPER)
as
select e.ESETTABLE, e.ESETCOLUMN, e.PREDLHS, (((NOEQPREDS+NOLTPREDS+NOGTPREDS
  +NOLTEQPRS+NOGTEQPRS+NONEQPRS+NOISNLPRS+NOISNNLPRS+NOBETPREDS+NONVLPREDS
  +NOLIKEPRS)*100)/EXSETNEXP),
   NOEQPREDS*100/EXSETNEXP, NOLTPREDS*100/EXSETNEXP, NOGTPREDS*100/EXSETNEXP,
   NOLTEQPRS*100/EXSETNEXP, NOGTEQPRS*100/EXSETNEXP, NONEQPRS*100/EXSETNEXP,
   NOISNLPRS*100/EXSETNEXP, NOISNNLPRS*100/EXSETNEXP, NOBETPREDS*
    100/EXSETNEXP, NONVLPREDS*100/EXSETNEXP, NOLIKEPRS*100/EXSETNEXP
 from exf$expsetstats e, exf$exprset es
 where e.esetowner = es.exsowner and e.esettable = es.exstabnm and
       e.esetcolumn = es.exscolnm and e.esetowner = (select user from dual)
/

comment on table USER_EXPFIL_EXPRSET_STATS is 'Predicate statistics for the expression sets in the current schema'
/

comment on column USER_EXPFIL_EXPRSET_STATS.EXPR_TABLE is 'The table storing the expression set in the current schema'
/

comment on column USER_EXPFIL_EXPRSET_STATS.EXPR_COLUMN is 'The column storing the expression set'
/

comment on column USER_EXPFIL_EXPRSET_STATS.ATTRIBUTE_EXP is 'Sub-expression representing the complex or elementary attribute. Also
 the left-hand-side of predicates'
/

comment on column USER_EXPFIL_EXPRSET_STATS.PCT_OCCURRENCE is 'Percentage occurrence of the attribute in the expression set'
/

comment on column USER_EXPFIL_EXPRSET_STATS.PCT_EQ_OPER is 'Percentage of predicates (of the attribute) with ''='' operator'
/

comment on column USER_EXPFIL_EXPRSET_STATS.PCT_LT_OPER is 'Percentage of predicates (of the attribute) with ''<'' operator'
/

comment on column USER_EXPFIL_EXPRSET_STATS.PCT_GT_OPER is 'Percentage of predicates (of the attribute) with ''>'' operator'
/

comment on column USER_EXPFIL_EXPRSET_STATS.PCT_LTEQ_OPER is 'Percentage of predicates (of the attribute) with ''<='' operator'
/

comment on column USER_EXPFIL_EXPRSET_STATS.PCT_GTEQ_OPER is 'Percentage of predicates (of the attribute) with ''>='' operator'
/

comment on column USER_EXPFIL_EXPRSET_STATS.PCT_NEQ_OPER is 'Percentage of predicates (of the attribute) with ''!='' operator'
/

comment on column USER_EXPFIL_EXPRSET_STATS.PCT_NUL_OPER is 'Percentage of predicates (of the attribute) with ''IS NULL'' operator'
/

comment on column USER_EXPFIL_EXPRSET_STATS.PCT_NNUL_OPER is 'Percentage of predicates (of the attribute) with ''IS NOT NULL'' operator'
/

comment on column USER_EXPFIL_EXPRSET_STATS.PCT_BETW_OPER is 'Percentage of predicates (of the attribute) with ''BETWEEN'' operator'
/

comment on column USER_EXPFIL_EXPRSET_STATS.PCT_NVL_OPER is 'Percentage of predicates (of the attribute) with ''NVL'' operator'
/

comment on column USER_EXPFIL_EXPRSET_STATS.PCT_LIKE_OPER is 'Percentage of predicates (of the attribute) with ''LIKE'' operator'
/

