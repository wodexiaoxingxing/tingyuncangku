create view ALL_EXPFIL_ATTRIBUTE_SETS as
select atsowner, atsname from exf$attrset ast, all_types ao
   where ao.owner = ast.atsowner and ao.type_name = ast.atsname
/

comment on table ALL_EXPFIL_ATTRIBUTE_SETS is 'List of all the attribute sets accessible to the user'
/

comment on column ALL_EXPFIL_ATTRIBUTE_SETS.OWNER is 'Owner of the attribute set'
/

comment on column ALL_EXPFIL_ATTRIBUTE_SETS.ATTRIBUTE_SET_NAME is 'Name of the attribute set'
/

