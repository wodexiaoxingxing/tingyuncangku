create function varray2str (ioper exf$indexoper,
                                       wquote VARCHAR2 default 'FALSE')
    return varchar2 is
  ret  varchar2(300);
  CURSOR c1 (va exf$indexoper) IS
     SELECT column_value from TABLE (cast(va as exf$indexoper));
begin
  ret := null;

  IF (upper(wquote) = 'TRUE') THEN
    FOR cur IN c1(ioper) LOOP
      IF (ret is null) THEN
        ret := ''''||cur.column_value||'''';
      ELSE
        ret := ret ||','''||cur.column_value||'''';
      END IF;
    END LOOP;
  ELSE
    FOR cur IN c1(ioper) LOOP
      IF (ret is null) THEN
        ret := cur.column_value;
      ELSE
        ret := ret ||','||cur.column_value;
      END IF;
    END LOOP;
  END IF;

  return ret;
end;
/

