create function rlm$uniquetag(tag varchar2, pos int) return varchar2
  deterministic is
begin
  if (instr(tag, 'RLM$RCND_COLL') > 0) then
    return tag||pos;
  else
    return tag;
  end if;
end;
/

