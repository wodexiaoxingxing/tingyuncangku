create package dbms_rlmgr authid current_user as

  procedure create_rule_class (
              rule_class     IN   VARCHAR2,   -- rule class name --
              event_struct   IN   VARCHAR2,   -- event structure (object) --
              action_cbk     IN   VARCHAR2,   -- action cbk procedure --
              actprf_spec    IN   VARCHAR2 default null,
              rslt_viewnm    IN   VARCHAR2 default null,
              rlcls_prop     IN   VARCHAR2 default null);

  procedure process_rules (
              rule_class     IN   VARCHAR2,
              event_inst     IN   VARCHAR2,
              event_type     IN   VARCHAR2 default null);

  procedure process_rules (
              rule_class     IN   VARCHAR2,
              event_inst     IN   sys.AnyData);

  procedure add_rule (
              rule_class     IN   VARCHAR2,
              rule_id        IN   VARCHAR2,
              rule_cond      IN   VARCHAR2,
              actprf_nml     IN   VARCHAR2 default null,
              actprf_vall    IN   VARCHAR2 default null);

  procedure delete_rule (
              rule_class     IN   VARCHAR2,
              rule_id        IN   VARCHAR2);

  procedure drop_rule_class (
              rule_class    IN   VARCHAR2);

  procedure grant_privilege (
              rule_class     IN   VARCHAR2,
              priv_type      IN   VARCHAR2,
              to_user        IN   VARCHAR2);

  procedure revoke_privilege (
              rule_class     IN   VARCHAR2,
              priv_type      IN   VARCHAR2,
              from_user      IN   VARCHAR2);

  --- APIs for obtaining results as a set --
  procedure add_event (
              rule_class     IN   VARCHAR2,
              event_inst     IN   VARCHAR2,
              event_type     IN   VARCHAR2 default null);

  procedure add_event (
              rule_class     IN   VARCHAR2,
              event_inst     IN   sys.AnyData);

  function consume_event (
              rule_class     IN   VARCHAR2,
              event_ident    IN   VARCHAR2) return number;

  function consume_prim_events (
              rule_class     IN   VARCHAR2,
              event_idents   IN   RLM$EVENTIDS) return number;


  procedure reset_session (
              rule_class     IN   VARCHAR2);

  --- event structure designing APIs ---
  procedure create_event_struct (
              event_struct   IN   VARCHAR2);

  procedure add_elementary_attribute (
              event_struct   IN   VARCHAR2,    --- event structure name
              attr_name      IN   VARCHAR2,    --- attr name
              attr_type      IN   VARCHAR2,    --- attr type
              attr_defvl     IN   VARCHAR2     --- default value for attr
                         default NULL);

  procedure add_elementary_attribute (
              event_struct   IN   VARCHAR2,    --- attr set name
              attr_name      IN   VARCHAR2,    --- table alias (name)
              tab_alias      IN   rlm$table_alias);  -- table alias for

  procedure add_elementary_attribute (
              event_struct   IN   VARCHAR2,    --- attr set name
              attr_name      IN   VARCHAR2,    --- attr name
              attr_type      IN   VARCHAR2,    --- attr type
              text_pref      IN   exf$text);   --- text data type pref

  procedure add_functions (
              event_struct   IN   VARCHAR2,    --- attr set name
              funcs_name     IN   VARCHAR2);   --- function/package/type name

  procedure drop_event_struct (
              event_struct   IN   VARCHAR2);

  procedure sync_text_indexes (
              rule_class     IN   VARCHAR2);

  procedure purge_events (
              rule_class     IN   VARCHAR2);

  procedure create_conditions_table (
              cond_table     IN   VARCHAR2,
              pevent_struct  IN   VARCHAR2,
              stg_clause     IN   VARCHAR2 default null);

  procedure create_conditions_table (
              cond_table     IN   VARCHAR2,
              tab_alias      IN   rlm$table_alias,
              stg_clause     IN   VARCHAR2 default null);

  procedure drop_conditions_table (
              cond_table     IN   VARCHAR2);

  procedure create_expfil_indexes (
              rule_class     IN   VARCHAR2,
              coll_stats     IN   VARCHAR2 default 'NO');

  procedure drop_expfil_indexes (
              rule_class     IN   VARCHAR2);

  procedure create_interface (
              rule_class     IN   VARCHAR2,
              interface_nm   IN   VARCHAR2);

  procedure drop_interface (
              interface_nm   IN   VARCHAR2);

  procedure extend_event_struct (
              event_struct   IN   VARCHAR2,
              attr_name      IN   VARCHAR2,
              attr_type      IN   VARCHAR2,
              attr_defvl     IN   VARCHAR2 default null);

  function condition_ref (
              rulecond       IN   VARCHAR2,
              eventnm        IN   VARCHAR2) return VARCHAR2 deterministic;

  function get_aggregate_value (
              rule_class     IN   VARCHAR2,
              event_ident    IN   VARCHAR2,
              aggr_func      IN   VARCHAR2) return VARCHAR2;

end dbms_rlmgr;
/

