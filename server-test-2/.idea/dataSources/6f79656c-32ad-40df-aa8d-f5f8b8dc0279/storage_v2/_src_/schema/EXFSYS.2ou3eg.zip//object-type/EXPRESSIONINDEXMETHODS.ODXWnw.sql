create type ExpressionIndexMethods AUTHID CURRENT_USER AS object
(
  -- cursor set by IndexStart and used in IndexFetch
  scanctx RAW(4),

  static function ODCIGetInterfaces(ifcList OUT sys.ODCIObjectList)
    return NUMBER,

  --- DDL ---
  static function ODCIIndexCreate (idxinfo   sys.ODCIIndexInfo,
                                   idxparms  VARCHAR2,
                                   idxenv    sys.ODCIEnv)
    return NUMBER,
  static function ODCIIndexDrop (idxinfo  sys.ODCIIndexInfo,
                                 idxenv   sys.ODCIEnv)
    return NUMBER,
  static function ODCIIndexAlter (idxinfo          sys.ODCIIndexInfo,
                                  idxparms  IN OUT VARCHAR2,
                                  altopt           NUMBER,
                                  idxenv           sys.ODCIEnv)
    return NUMBER,
  static function ODCIIndexTruncate (idxinfo  sys.ODCIIndexInfo,
                                     idxenv   sys.ODCIEnv)
    return NUMBER,

  --- DML ---
  static function ODCIIndexInsert (idxinfo  sys.ODCIIndexInfo,
                                   rid      VARCHAR2,
                                   newval   VARCHAR2,
                                   idxenv   sys.ODCIEnv)
    return NUMBER,
  static function ODCIIndexDelete (idxinfo  sys.ODCIIndexInfo,
                                   rid      VARCHAR2,
                                   oldval   VARCHAR2,
                                   idxenv   sys.ODCIEnv)
    return NUMBER,
  static function ODCIIndexUpdate (idxinfo  sys.ODCIIndexInfo,
                                   rid      VARCHAR2,
                                   oldval   VARCHAR2,
                                   newval   VARCHAR2,
                                   idxenv   sys.ODCIEnv)
    return NUMBER,

  --- Query ---
  static function ODCIIndexStart (ictx    IN OUT ExpressionIndexMethods,
                                  idxinfo        sys.ODCIIndexInfo,
                                  opi            sys.ODCIPredInfo,
                                  oqi            sys.ODCIQueryInfo,
                                  strt           NUMBER,
                                  stop           NUMBER,
                                  ditem          VARCHAR2,
                                  idxenv         sys.ODCIEnv)
   return NUMBER,

  static function ODCIIndexStart (ictx    IN OUT ExpressionIndexMethods,
                                  idxinfo        sys.ODCIIndexInfo,
                                  opi            sys.ODCIPredInfo,
                                  oqi            sys.ODCIQueryInfo,
                                  strt           NUMBER,
                                  stop           NUMBER,
                                  ditem          sys.AnyData,
                                  idxenv         sys.ODCIEnv)
   return NUMBER,

  member function ODCIIndexFetch (nrows          NUMBER,
                                  rids     OUT   sys.ODCIRidList,
                                  idxenv         sys.ODCIEnv)
    return  NUMBER IS LANGUAGE C
     name "EXF_IFETCH"
     library EXFTLIB
    with context
    parameters (
     context,
     self,
     self INDICATOR STRUCT,
     nrows,
     nrows INDICATOR,
     rids,
     rids INDICATOR,
     idxenv,
     idxenv INDICATOR STRUCT,
     return OCINumber
   ),

  member function ODCIIndexClose (idxenv        sys.ODCIEnv)
    return NUMBER IS LANGUAGE C
     name "EXF_ICLOSE"
     library EXFTLIB
   with context
   parameters (
     context,
     self,
     self INDICATOR STRUCT,
     idxenv,
     idxenv INDICATOR STRUCT,
     return OCINumber
   ),

  static function ODCIIndexGetMetadata (
                                  idxinfo  IN    sys.ODCIIndexInfo,
                                  expver   IN    VARCHAR2,
                                  newblock OUT   PLS_INTEGER,
                                  idxenv   IN    sys.ODCIEnv)
     return VARCHAR2,

  static function ODCIIndexUtilGetTableNames (
                                  idxinfo  IN    sys.ODCIIndexInfo,
                                  readonly IN    PLS_INTEGER,
                                  version  IN    VARCHAR2,
                                  context  OUT   PLS_INTEGER)
     return BOOLEAN,

  static procedure ODCIIndexUtilCleanup (
                                  context  IN    PLS_INTEGER),

  static function pvtcreate_expfil_instance (
                                  idxinfo        sys.ODCIIndexInfo,
                                  idxparms       VARCHAR2,
                                  asname         VARCHAR2,
                                  esetcol        VARCHAR2)
     return NUMBER
);
/

