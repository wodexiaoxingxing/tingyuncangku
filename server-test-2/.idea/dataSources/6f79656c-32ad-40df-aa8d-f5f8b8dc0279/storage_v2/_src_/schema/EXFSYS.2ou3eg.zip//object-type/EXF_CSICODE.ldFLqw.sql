create type exf$csicode as object (code int, arg varchar2(1000));
/

