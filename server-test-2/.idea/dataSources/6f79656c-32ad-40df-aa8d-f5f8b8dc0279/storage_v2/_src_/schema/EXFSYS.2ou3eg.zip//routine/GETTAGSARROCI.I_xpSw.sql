create procedure getTagsArrOCI wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
fd 10f
c9A+2zqAsllp4PRqwdLj7GqnpNYwg+lKLcsVfC+EWE6Ub+AOCRsr6PbsYfclGkWHqFnj+y0f
+Q8UYtMTQwMQIF0RfoIDlR4698YeLtnT8GqzKj6id9EvmrnR481W9hamFBU43QK00ttJ8CHO
G6sELPaya0p17uEGVksmABp/EreZedhnt5dBVMtdjcX2NzltEP9VmGJTluK/KsHGY5aT1XGQ
0nx/xxTMBPTHYnJZV6fOuw5th6+BLPWN/QbFeGcC/DT44flaIus=
/

