create type exf$xptaginfo as object (
  tag_name  VARCHAR2(70),
  type      NUMBER,
  poslst    exf$xpposlst,
  varclst   exf$xpvarclst,
  numblst   exf$xpnumblst,
  datelst   exf$xpdatelst)
/

