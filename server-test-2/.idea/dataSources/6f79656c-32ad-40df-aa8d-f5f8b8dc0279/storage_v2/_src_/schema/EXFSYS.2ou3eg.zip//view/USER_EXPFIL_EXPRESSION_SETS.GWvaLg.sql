create view USER_EXPFIL_EXPRESSION_SETS as
select exstabnm, exscolnm, exsatsnm, exsetlanl, exsetnexp,
            avgprpexp, exsetsprp from exf$exprset
  where exsowner = (select user from dual)
/

comment on table USER_EXPFIL_EXPRESSION_SETS is 'List of expression sets in the current schema'
/

comment on column USER_EXPFIL_EXPRESSION_SETS.EXPR_TABLE is 'The table storing the expression set in the current schema'
/

comment on column USER_EXPFIL_EXPRESSION_SETS.EXPR_COLUMN is 'The column storing the expression set'
/

comment on column USER_EXPFIL_EXPRESSION_SETS.ATTRIBUTE_SET is 'Attribute set used for the expression set'
/

comment on column USER_EXPFIL_EXPRESSION_SETS.LAST_ANALYZED is 'The date of the most recent time the expression set is analyzed'
/

comment on column USER_EXPFIL_EXPRESSION_SETS.NUM_EXPRESSIONS is 'Number of expressions (disjunctions) in the expression set'
/

comment on column USER_EXPFIL_EXPRESSION_SETS.PREDS_PER_EXPR is 'Average number of conjunctive predicates per expressions'
/

comment on column USER_EXPFIL_EXPRESSION_SETS.NUM_SPARSE_PREDS is 'Number of sparse predicates in the expression set'
/

