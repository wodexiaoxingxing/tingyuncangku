create view USER_RLM4J_EVTST (DB_OWNER, EVTST_NAME, JAVA_PACKAGE, JAVA_CLASS, IS_COMPOSITE) as
SELECT evt.dbowner, evt.dbesname, evt.javapck, evt.javacls,
         decode(evt.estflags, 1, 'YES','NO')
  FROM rlm4j$evtstructs evt
  where evt.dbowner = SYS_CONTEXT('USERENV', 'CURRENT_USER')
/

