create view ALL_RLMGR_RULE_CLASSES
            (RULE_CLASS_OWNER, RULE_CLASS_NAME, EVENT_STRUCTURE, ACTION_CALLBACK, RULE_CLASS_PACK, RCLS_RSLT_TABLE,
             RCLS_RSLT_VIEW, IS_COMPOSITE, SEQUENCE_ENB, AUTOCOMMIT, CONSUMPTION, DURATION, ORDERING, EQUAL, DML_EVENTS,
             CNF_EVENTS, PRIM_EXPR_TABLE, PRIM_EVENTS_TABLE, PRIM_RESULTS_TABLE)
as
select rset_owner, rset_name, rset_eventst, action_cbk, rset_pack,
     rset_rslttab, rset_rsltvw,
     decode(bitand(rset_prop, 4),4, 'YES', 'NO'),
     decode(bitand(rset_prop, 4),4,
        decode(bitand(rset_prop, 8),8, 'YES', 'NO'), 'N/A'),
     decode(bitand(rset_prop, 16),16, 'YES', 'NO'),
     decode(bitand(rset_prop, 32),32, 'EXCLUSIVE',
             decode(bitand(rset_prop, 64),64, 'RULE','SHARED')),
     rset_durtcl, rset_ordrcl, rset_eqcls,
     decode(bitand(rset_prop, 128), 128, 'INS',
             decode(bitand(rset_prop, 256), 256, 'INS/UPD',
             decode(bitand(rset_prop, 512), 512, 'INS/UPD/DEL', 'N/A'))),
      decode(bitand(rset_prop, 1024), 1024, 'INS',
             decode(bitand(rset_prop, 2048), 2048, 'INS/UPD',
             decode(bitand(rset_prop, 4096), 4096, 'INS/UPD/DEL', 'N/A'))),
     rset_prmexpt, rset_prmobjt, rset_prmrslt
  from rlm$ruleset rs where rs.rset_owner =
                           sys_context('USERENV', 'CURRENT_USER') or
    ((rs.rset_owner, rs.rset_name) IN
     (select rsp.rset_owner, rsp.rset_name from rlm$rulesetprivs rsp
         where prv_grantee = sys_context('USERENV', 'CURRENT_USER'))) or
     exists (select 1 from user_role_privs where granted_role = 'DBA')
/

comment on table ALL_RLMGR_RULE_CLASSES is 'List of all the rule classes accessible to the user'
/

comment on column ALL_RLMGR_RULE_CLASSES.RULE_CLASS_OWNER is 'Owner of the rule class'
/

comment on column ALL_RLMGR_RULE_CLASSES.RULE_CLASS_NAME is 'Name of the rule class'
/

comment on column ALL_RLMGR_RULE_CLASSES.EVENT_STRUCTURE is 'The event structure used for the rule class'
/

comment on column ALL_RLMGR_RULE_CLASSES.ACTION_CALLBACK is 'The procedure configured as action callback for the rule class'
/

comment on column ALL_RLMGR_RULE_CLASSES.RULE_CLASS_PACK is 'Name of the package implementing the rule class cursors (internal)'
/

comment on column ALL_RLMGR_RULE_CLASSES.RCLS_RSLT_TABLE is 'Temporary table storing the results from the current session'
/

comment on column ALL_RLMGR_RULE_CLASSES.RCLS_RSLT_VIEW is 'View to display the matching events and rules for the current session'
/

comment on column ALL_RLMGR_RULE_CLASSES.IS_COMPOSITE is 'YES if the rules class is configured for composite events'
/

comment on column ALL_RLMGR_RULE_CLASSES.SEQUENCE_ENB is 'YES if the rules class is enabled for rule conditions with sequencing'
/

comment on column ALL_RLMGR_RULE_CLASSES.AUTOCOMMIT is 'YES if the rules class is configured for auto-commiting events and rules'
/

comment on column ALL_RLMGR_RULE_CLASSES.CONSUMPTION is 'Default Consumption policy for the events in the rule class: EXCLUSIVE/SHARED'
/

comment on column ALL_RLMGR_RULE_CLASSES.DURATION is 'Default Duration policy of the primitive events'
/

comment on column ALL_RLMGR_RULE_CLASSES.ORDERING is 'Ordering clause used for conflict resolution among matching rules and
events'
/

comment on column ALL_RLMGR_RULE_CLASSES.DML_EVENTS is 'Types of DML operations enabled for event management'
/

comment on column ALL_RLMGR_RULE_CLASSES.CNF_EVENTS is 'Types of Change Notifications enabled for event management'
/

comment on column ALL_RLMGR_RULE_CLASSES.PRIM_EXPR_TABLE is 'Name of the table storing conditional expressions for primitive events'
/

comment on column ALL_RLMGR_RULE_CLASSES.PRIM_EVENTS_TABLE is 'Name of the table storing primitive events'
/

comment on column ALL_RLMGR_RULE_CLASSES.PRIM_RESULTS_TABLE is 'Name of the table storing incremental results'
/

