create procedure rlm$proccllgrpby wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
12c ff
cRsVNkBenUb6+LXaCICi1kmux84wg43/LcusfI4COBdBBssbZ+B7U3tMLTWyjl42wfIn1iZQ
oHBdzZQbMoZHSQ/5tnJmRdVXRAosDAsF5SWjk8ekyo+tABcfYK12BGf0eoPvD2Td1q39lEA+
Aixsbo5HqDVvHwReV+D0fKQApbrVxWL0z1i6O/pJLpMVt46Nwgn03JuHDIDUcSlxfgUZflsf
aJVeL2Kr6Zv/PPDsE5INqsXSeG14XtvyWA==
/

