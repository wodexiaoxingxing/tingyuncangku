create type body exf$attribute as
  constructor function exf$attribute(attr_name varchar2)
    return self as result is
  begin
    self.attr_name := attr_name;
    self.attr_oper := exf$indexoper('all');
    self.attr_indexed := 'FALSE';
    return;
  end;

  constructor function exf$attribute(attr_name varchar2,
                                     attr_indexed varchar2)
    return self as result is
  begin
    self.attr_name := attr_name;
    self.attr_oper := exf$indexoper('all');
    self.attr_indexed := attr_indexed;
    return;
  end;

  constructor function exf$attribute(attr_name varchar2,
                                     attr_oper exf$indexoper,
                                     attr_indexed varchar2 default 'FALSE')
    return self as result is
  begin
    self.attr_name := attr_name;
    self.attr_oper := attr_oper;
    self.attr_indexed := attr_indexed;
    return;
  end;
end;
/

