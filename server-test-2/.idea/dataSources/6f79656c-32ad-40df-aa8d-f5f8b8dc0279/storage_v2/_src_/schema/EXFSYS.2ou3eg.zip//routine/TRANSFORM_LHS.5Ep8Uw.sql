create function transform_lhs wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
b0 df
thgcP/wGKg4ASKF47DA3+pBgkGEwg0zwAJkVfI6mkPjVGTxFkbgyI4lU1asMkjcTehQ7jXU8
nBZzOvJbRCB6y0heCqCX0J7ht07N3f4D7ZKiQZ6FlCFN62L8PWXhpmIKo7V2cL0Sw5PwWEak
3wQ+elrjW+htKhVZCwW67iwrhd5W4+04CJCPxmx4I/dLXXvMOblMeA/JtEZJ2s4oBoEGsgNJ
eLo=
/

