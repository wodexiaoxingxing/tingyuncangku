create view ADM_RLMGR_COMPRCLS_PROPERTIES
            (RULE_CLASS_OWNER, RULE_CLASS_NAME, PRIM_EVENT, PRIM_EVENT_STRUCT, HAS_CRTTIME_ATTR, CONSUMPTION,
             TABLE_ALIAS_OF, DURATION, COLLECTION_ENB, COLLECTION_TAB_NAME, GROUPBY_ATTRIBUTES)
as
select crs.rset_owner, crs.rset_name, crs.prim_attr, crs.prim_asetnm,
      decode(bitand(pem.prim_evttflgs, 1), 1, 'YES', 'NO'),
      decode(bitand(pem.prim_evttflgs, 32),32, 'EXCLUSIVE','SHARED'),
      '"'||pem.talstabonr||'"."'||pem.talstabnm||'"',
      decode(pem.prim_durmin, -1, 'TRANSACTION', -2, 'SESSION', -3, 'CALL',
             pem.prim_evdurcls),
      decode(bitand(pem.prim_evttflgs, 128), 128, 'YES','NO'),
        pem.collcttab, pem.grpbyattrs
 from rlm$rsprimevents crs, rlm$primevttypemap pem
 where  crs.rset_owner = pem.rset_owner and crs.rset_name = pem.rset_name
       and crs.prim_asetnm = pem.prim_evntst
/

