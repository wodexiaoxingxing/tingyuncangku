create view ADM_RLMGR_RULE_CLASSES
            (RULE_CLASS_OWNER, RULE_CLASS_NAME, EVENT_STRUCTURE, ACTION_CALLBACK, RULE_CLASS_PACK, IS_INDEXED,
             RCLS_RSLT_TABLE, RCLS_RSLT_VIEW, IS_COMPOSITE, SEQUENCE_ENB, AUTOCOMMIT, CONSUMPTION, DURATION, ORDERING,
             EQUAL, DML_EVENTS, CNF_EVENTS, STORAGE, PRIM_EXPR_TABLE, PRIM_EVENTS_TABLE, PRIM_RESULTS_TABLE)
as
select rset_owner, rset_name, rset_eventst, action_cbk, rset_pack,
    decode(bitand(rset_prop, 1),1, 'YES', 'NO'),
    rset_rslttab, rset_rsltvw, decode(bitand(rset_prop, 4),4, 'YES', 'NO'),
    decode(bitand(rset_prop, 4),4,
        decode(bitand(rset_prop, 8),8, 'YES', 'NO'), 'N/A'),
    decode(bitand(rset_prop, 16),16, 'YES', 'NO'),
    decode(bitand(rset_prop, 32),32, 'EXCLUSIVE',
             decode(bitand(rset_prop, 64),64, 'RULE','SHARED')),
    rset_durtcl, rset_ordrcl, rset_eqcls,
    decode(bitand(rset_prop, 128), 128, 'INS',
             decode(bitand(rset_prop, 256), 256, 'INS/UPD',
             decode(bitand(rset_prop, 512), 512, 'INS/UPD/DEL', 'N/A'))),
      decode(bitand(rset_prop, 1024), 1024, 'INS',
             decode(bitand(rset_prop, 2048), 2048, 'INS/UPD',
             decode(bitand(rset_prop, 4096), 4096, 'INS/UPD/DEL', 'N/A'))),
    rset_stgcls, rset_prmexpt, rset_prmobjt, rset_prmrslt
 from  rlm$ruleset
/

