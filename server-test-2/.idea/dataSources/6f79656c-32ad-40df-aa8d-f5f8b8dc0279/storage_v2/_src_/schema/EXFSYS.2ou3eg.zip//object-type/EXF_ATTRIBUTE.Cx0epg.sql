create type exf$attribute as object (
  attr_name     VARCHAR2(350),
  attr_oper     EXF$INDEXOPER,
  attr_indexed  VARCHAR2(5),
  constructor function exf$attribute(attr_name varchar2)
    return self as result,
  constructor function exf$attribute(attr_name varchar2,
                                     attr_indexed varchar2)
    return self as result,
  constructor function exf$attribute(attr_name varchar2,
                                     attr_oper exf$indexoper,
                                     attr_indexed varchar2 default 'FALSE')
    return self as result
);
/

