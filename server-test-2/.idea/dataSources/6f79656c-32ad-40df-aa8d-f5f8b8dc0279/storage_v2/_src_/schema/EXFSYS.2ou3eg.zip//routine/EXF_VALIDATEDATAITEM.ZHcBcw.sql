create procedure exf$validatedataitem wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
ad e7
vH5dboF/zAsXYvejaL4H7CpvKuYwg2JKNZmsaS9G2vjVOSlwUCb2sNfEBh0Ql0VyihTmOeZV
FJI6O7M4cIi8MVgr7G5MjtTkQoqa68e+rh5+7KcyPwH/1bF9oZvxXfVn4Wl3JdpdzEbWSi0L
+zKPNZPhXGDKaddaQhbUvMD8d7ATujptyGhfVne5NupkbJsbTQG2oBRvA0mkZWq1+VIK5DtX
br8P7fHR5w==
/

