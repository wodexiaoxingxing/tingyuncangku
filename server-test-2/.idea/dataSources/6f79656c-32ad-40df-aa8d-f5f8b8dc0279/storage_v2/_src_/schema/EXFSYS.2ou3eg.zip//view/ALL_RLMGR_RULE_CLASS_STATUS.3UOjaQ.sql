create view ALL_RLMGR_RULE_CLASS_STATUS as
select rs.rset_owner, rs.rset_name, st.rset_stdesc, st.rset_stnext
 from rlm$ruleset rs, rlm$rulesetstcode st where
    rs.rset_status = st.rset_stcode and
    (rs.rset_owner = sys_context('USERENV', 'CURRENT_USER') or
    ((rs.rset_owner, rs.rset_name) IN
     (select rsp.rset_owner, rsp.rset_name from rlm$rulesetprivs rsp
         where prv_grantee = sys_context('USERENV', 'CURRENT_USER'))) or
     exists (select 1 from user_role_privs where granted_role = 'DBA'))
/

comment on table ALL_RLMGR_RULE_CLASS_STATUS is 'View used to track the progress of rule class creation'
/

comment on column ALL_RLMGR_RULE_CLASS_STATUS.RULE_CLASS_OWNER is 'Owner of the rule class'
/

comment on column ALL_RLMGR_RULE_CLASS_STATUS.RULE_CLASS_NAME is 'Name of the rule class'
/

comment on column ALL_RLMGR_RULE_CLASS_STATUS.STATUS is 'Current status of the rule class'
/

comment on column ALL_RLMGR_RULE_CLASS_STATUS.NEXT_OPERATION is 'Next operation performed on the rule class'
/

