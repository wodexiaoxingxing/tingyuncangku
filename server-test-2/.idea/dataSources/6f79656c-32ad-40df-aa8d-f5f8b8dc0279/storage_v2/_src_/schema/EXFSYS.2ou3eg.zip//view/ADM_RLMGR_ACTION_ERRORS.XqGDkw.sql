create view ADM_RLMGR_ACTION_ERRORS as
select rset_owner, rset_name, actschat, oraerrcde from rlm$schacterrs
/

