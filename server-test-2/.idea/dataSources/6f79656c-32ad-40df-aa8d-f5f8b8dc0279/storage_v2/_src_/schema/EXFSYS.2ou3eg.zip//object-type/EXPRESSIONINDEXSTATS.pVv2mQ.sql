create type ExpressionIndexStats AUTHID CURRENT_USER AS object
(
  dummy number(6),
  static function ODCIGetInterfaces(ifclist OUT sys.ODCIObjectList)
    return number,

  static function ODCIStatsCollect(col sys.ODCIColInfo,
    options sys.ODCIStatsOptions, stats OUT RAW, env sys.ODCIEnv)
    return number,

  static function ODCIStatsCollect(idx sys.ODCIIndexInfo,
    options sys.ODCIStatsOptions, stats OUT RAW, env sys.ODCIEnv)
    return number,

  static function ODCIStatsDelete(col sys.ODCIColInfo,
    stats OUT RAW, env sys.ODCIEnv) return number,

  static function ODCIStatsDelete(idx sys.ODCIIndexInfo,
    stats OUT RAW, env sys.ODCIEnv) return number,

  static function ODCIStatsSelectivity(pred sys.ODCIPredInfo,
    sel OUT number, args sys.ODCIArgDescList, strt number,
    stop number, expr VARCHAR2, datai VARCHAR2,
    env sys.ODCIEnv) return number,

  static function ODCIStatsFunctionCost(func sys.ODCIFuncInfo,
    cost OUT sys.ODCICost, args sys.ODCIArgDescList,
    expr VARCHAR2, datai VARCHAR2, env sys.ODCIEnv) return number,

  static function ODCIStatsIndexCost(idx sys.ODCIIndexInfo,
    sel number, cost OUT sys.ODCICost, qi sys.ODCIQueryInfo,
    pred sys.ODCIPredInfo, args sys.ODCIArgDescList,
    strt number, stop number, datai varchar2, env sys.ODCIEnv)
    return number

  /*** AnyData : Ext-Optimizer Arg overloading problem ***
  static function ODCIStatsSelectivity(pred sys.ODCIPredInfo,
    sel OUT number, args sys.ODCIArgDescList, strt number,
    stop number, expr VARCHAR2, datai sys.AnyData,
    env sys.ODCIEnv) return number,

  static function ODCIStatsFunctionCost(func sys.ODCIFuncInfo,
    cost OUT sys.ODCICost, args sys.ODCIArgDescList,
    expr VARCHAR2, datai sys.AnyData, env sys.ODCIEnv) return number,

  static function ODCIStatsIndexCost(idx sys.ODCIIndexInfo,
    sel number, cost OUT sys.ODCICost, qi sys.ODCIQueryInfo,
    pred sys.ODCIPredInfo, args sys.ODCIArgDescList,
    strt number, stop number, datai sys.AnyData, env sys.ODCIEnv)
    return number
  */
);
/

