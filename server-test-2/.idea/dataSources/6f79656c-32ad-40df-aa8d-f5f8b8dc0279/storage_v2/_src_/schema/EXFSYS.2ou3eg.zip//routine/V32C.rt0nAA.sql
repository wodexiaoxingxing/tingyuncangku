create function v32c wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
17a 144
xVCEq9GqK+j4crR44NIiSZUV6s8wgzLImEjhfy/pXrvqaGbThz4Y5/UtFl+IWwzJNJsL6Zxm
tcgnJCILhC81GBNCOv++YQp+bdBfu82LmZfG9NN9ikFy66+Onr5fWsMn4EcbMYyh/c56DipS
9ibNIwAnKYPswFlLIGkDQmjrMsBlRMJE30AjBnIxRvK4PkFpRyIviSq+Ib76KP02LbAocurk
+MtxhFDWd+LM9qwXNw9Bf2bbVzIav2ku7sfqXxaABm1Ymi5mP+2/GvhUS9L+h5nZwiOTYtkk
0yLnZENi9m9Frx5J8lDWdNLrKJq1un8=
/

