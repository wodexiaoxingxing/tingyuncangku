create procedure rlm$create_scheduler_jobs is
begin
  begin
    dbms_scheduler.create_job(
                 job_name   =>'EXFSYS.RLM$EVTCLEANUP',
                 job_action =>
                      'begin dbms_rlmgr_dr.cleanup_events; end;',
                 job_type   => 'plsql_block',
                 number_of_arguments => 0,
                 start_date => systimestamp+0.0001,
                 repeat_interval => 'FREQ = HOURLY; INTERVAL = 1',
                 auto_drop => FALSE,
                 enabled    => true);
  exception
    when others then
      if (SQLCODE = -27477) then
        dbms_scheduler.set_attribute ('EXFSYS.RLM$EVTCLEANUP',
                                      'start_date', systimestamp);
        dbms_scheduler.enable('EXFSYS.RLM$EVTCLEANUP');
      else
        raise;
      end if;
  end;

  begin
    dbms_scheduler.create_job(
                 job_name   =>'EXFSYS.RLM$SCHDNEGACTION',
                 job_action =>
          'begin dbms_rlmgr_dr.execschdactions(''RLM$SCHDNEGACTION''); end;',
                 job_type   => 'plsql_block',
                 number_of_arguments => 0,
                 start_date => systimestamp+0.0001,
                 repeat_interval => 'FREQ=MINUTELY;INTERVAL=60',
                 auto_drop => FALSE,
                 enabled    => true);
  exception
    when others then
      if (SQLCODE = -27477) then
        dbms_scheduler.set_attribute ('EXFSYS.RLM$SCHDNEGACTION',
                                      'start_date', systimestamp);
        dbms_scheduler.enable('EXFSYS.RLM$SCHDNEGACTION');
      else
        raise;
      end if;
  end;
end rlm$create_scheduler_jobs;
/

