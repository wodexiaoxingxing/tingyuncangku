create view USER_RLMGR_COMPRCLS_PROPERTIES
            (RULE_CLASS_NAME, PRIM_EVENT, PRIM_EVENT_STRUCT, HAS_CRTTIME_ATTR, CONSUMPTION, TABLE_ALIAS_OF, DURATION,
             COLLECTION_ENB, GROUPBY_ATTRIBUTES)
as
select crs.rset_name, crs.prim_attr, crs.prim_asetnm,
      decode(bitand(pem.prim_evttflgs, 1), 1, 'YES', 'NO'),
      decode(bitand(pem.prim_evttflgs, 32),32, 'EXCLUSIVE','SHARED'),
      decode(pem.talstabonr, null, null,
              '"'||pem.talstabonr||'"."'||pem.talstabnm||'"'),
      pem.prim_evdurcls,
      decode(bitand(pem.prim_evttflgs, 128), 128, 'YES','NO'), pem.grpbyattrs
 from rlm$rsprimevents crs, rlm$primevttypemap pem
 where crs.rset_owner = sys_context('USERENV', 'CURRENT_USER') and
       crs.rset_owner = pem.rset_owner and crs.rset_name = pem.rset_name
       and crs.prim_asetnm = pem.prim_evntst
/

comment on table USER_RLMGR_COMPRCLS_PROPERTIES is 'List of primitive events configured for a rule class and their properties'
/

comment on column USER_RLMGR_COMPRCLS_PROPERTIES.RULE_CLASS_NAME is 'Name of the rule class configured for composite rules'
/

comment on column USER_RLMGR_COMPRCLS_PROPERTIES.PRIM_EVENT is 'Name of the primitive event in the composite event'
/

comment on column USER_RLMGR_COMPRCLS_PROPERTIES.PRIM_EVENT_STRUCT is 'Name of the primitive event structure (object type)'
/

comment on column USER_RLMGR_COMPRCLS_PROPERTIES.HAS_CRTTIME_ATTR is 'YES if the primitive event structure has the RLM$CRTTIME attribute'
/

comment on column USER_RLMGR_COMPRCLS_PROPERTIES.CONSUMPTION is 'Consumption policy for the primitive event: EXCLUSIVE/SHARED'
/

comment on column USER_RLMGR_COMPRCLS_PROPERTIES.TABLE_ALIAS_OF is 'Table name for a table alias primitive event'
/

comment on column USER_RLMGR_COMPRCLS_PROPERTIES.DURATION is 'Duration policy for the primitive event'
/

comment on column USER_RLMGR_COMPRCLS_PROPERTIES.COLLECTION_ENB is 'Is the primitive event enabled for collections?'
/

comment on column USER_RLMGR_COMPRCLS_PROPERTIES.GROUPBY_ATTRIBUTES is 'Event attributes that may be used for GROUPBY clauses'
/

