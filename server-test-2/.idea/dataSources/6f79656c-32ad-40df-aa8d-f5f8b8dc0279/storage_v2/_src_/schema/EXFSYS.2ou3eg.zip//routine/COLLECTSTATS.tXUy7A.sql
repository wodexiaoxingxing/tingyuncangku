create function collectStats wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
11d 10b
Uq9bgvlygo3EW8nkdwZWlSqOCpswg/D/LcusfC85cBdBBt/Kf6RxkNwJzB0CZzWxGI1wq8pj
BBwPUKJZVDQImJgktSILHCRgdBhgPpN1d+frN2pSH5CIXXUwW1nf9pmp7wsEJTGph+CWnj+m
XpeTzkSxrEabVljH1JnnyDqIko7cdYyBSqD9Yp5s9HaDEmNaaKDt02DUoxlfU/EJq3ugkOSJ
xxwGPuPTMqEJjApFbpfwA48k25CHDSHt4h/aEpgj+0iok54=
/

