create view USER_EXPFIL_XPATH_TAGS
            (ATTRIBUTE_SET_NAME, XMLTYPE_ATTRIBUTE, XPATH_TAG, DATA_TYPE, TAG_TYPE, FILTER_TYPE) as
select atsname, xmltattr, attrsexp, attrtype,
     decode(bitand(attrprop, 32), 32, 'XML ELEMENT',
            decode(bitand(attrprop, 64), 64, 'XML ATTRIBUTE', null)),
     decode(bitand(attrprop, 128), 128, 'POSITIONAL',
            decode(bitand(attrprop, 256), 256, 'VALUE BASED', null))
   from exf$defidxparam where xmltattr is not null and
        atsowner = (select user from dual)
/

comment on table USER_EXPFIL_XPATH_TAGS is 'List of all the XPath Tags in the attribute sets'
/

comment on column USER_EXPFIL_XPATH_TAGS.ATTRIBUTE_SET_NAME is 'Name of the attribute set a XPath Tag belongs'
/

comment on column USER_EXPFIL_XPATH_TAGS.XMLTYPE_ATTRIBUTE is 'Name of the XMLType attribute for which this XPath Tag is defined'
/

comment on column USER_EXPFIL_XPATH_TAGS.XPATH_TAG is 'Name of the XPath Tag'
/

comment on column USER_EXPFIL_XPATH_TAGS.DATA_TYPE is 'Datatype of the values for the XPath tag'
/

comment on column USER_EXPFIL_XPATH_TAGS.TAG_TYPE is 'Type of the Tag - XML ELEMENT or XML ATTRIBUTE'
/

comment on column USER_EXPFIL_XPATH_TAGS.FILTER_TYPE is 'Type of filter for the XPath tag - POSITIONAL/ VALUE BASED'
/

