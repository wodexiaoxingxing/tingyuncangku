create PACKAGE dbms_rlm4j_dictmaint AUTHID current_user AS

  -- Return the case-preserved names ---
  FUNCTION dict_name(rawname IN VARCHAR2)
    RETURN VARCHAR2;

  -- Record the event-structure and java package/class mapping
  PROCEDURE add_event_struct (esowner     VARCHAR2,
                              esname      VARCHAR2,
                              javapkg     VARCHAR2,
                              javacls     VARCHAR2,
                              iscomposite NUMBER);

  -- Record the rule class, event-structure and java package/class
  -- mapping
  PROCEDURE add_rule_class( rleowner VARCHAR2,
                            rlename  VARCHAR2,
                            evsname  VARCHAR2,
                            javapkg  VARCHAR2,
                            javacls  VARCHAR2);

  PROCEDURE add_attribute_alias (esname   VARCHAR2,
                                 alsname  VARCHAR2,
                                 alsexpr  VARCHAR2,
                                 alstype  NUMBER default 0);

  PROCEDURE validate_rulecls_properties(propdoc VARCHAR2);

  PROCEDURE validate_rule_condition(conddoc VARCHAR2);

END dbms_rlm4j_dictmaint;
/

