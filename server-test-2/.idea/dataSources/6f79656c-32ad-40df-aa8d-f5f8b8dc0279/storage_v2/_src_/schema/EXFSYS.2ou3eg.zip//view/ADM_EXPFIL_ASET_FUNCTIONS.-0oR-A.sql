create view ADM_EXPFIL_ASET_FUNCTIONS as
select udfasoner, udfasname, udfname, udfobjown, udfobjnm, udftype from
   exf$asudflist
/

comment on table ADM_EXPFIL_ASET_FUNCTIONS is 'List of approved user-defined functions for the attribute sets'
/

comment on column ADM_EXPFIL_ASET_FUNCTIONS.OWNER is 'Owner of the attribute set'
/

comment on column ADM_EXPFIL_ASET_FUNCTIONS.ATTRIBUTE_SET_NAME is 'Name of the attribute set'
/

comment on column ADM_EXPFIL_ASET_FUNCTIONS.UDF_NAME is 'Name of the user-defined FUNCTION/PACKAGE/TYPE'
/

comment on column ADM_EXPFIL_ASET_FUNCTIONS.OBJECT_OWNER is 'Owner of the object'
/

comment on column ADM_EXPFIL_ASET_FUNCTIONS.OBJECT_NAME is 'Name of the object'
/

comment on column ADM_EXPFIL_ASET_FUNCTIONS.OBJECT_TYPE is 'Type of the object - FUNCTION/PACKAGE/TYPE'
/

