create view ADM_RLMGR_RULE_CLASS_STATUS as
select rs.rset_name, st.rset_stdesc, st.rset_stcode, st.rset_stnext
 from rlm$ruleset rs, rlm$rulesetstcode st
 where rs.rset_status = st.rset_stcode
/

