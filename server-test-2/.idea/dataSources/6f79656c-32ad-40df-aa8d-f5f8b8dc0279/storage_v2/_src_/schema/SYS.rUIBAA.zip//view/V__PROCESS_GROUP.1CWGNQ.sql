create view V_$PROCESS_GROUP (INDX, NAME, PID) as
select "INDX","NAME","PID" from v$process_group
/

