create view GV_$SQLFN_ARG_METADATA (INST_ID, FUNC_ID, ARGNUM, DATATYPE, DESCR) as
select "INST_ID","FUNC_ID","ARGNUM","DATATYPE","DESCR" from gv$sqlfn_arg_metadata
/

