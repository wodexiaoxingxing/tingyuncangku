create view GV_$LATCHHOLDER (INST_ID, PID, SID, LADDR, NAME, GETS) as
select "INST_ID","PID","SID","LADDR","NAME","GETS" from gv$latchholder
/

