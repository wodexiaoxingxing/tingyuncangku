create view V_$STATNAME (STATISTIC#, NAME, CLASS, STAT_ID) as
select "STATISTIC#","NAME","CLASS","STAT_ID" from v$statname
/

