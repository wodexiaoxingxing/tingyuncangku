create view V_$TIMEZONE_FILE (FILENAME, VERSION) as
select "FILENAME","VERSION" from v$timezone_file
/

