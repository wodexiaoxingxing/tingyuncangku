create view V_$DETACHED_SESSION (INDX, PG_NAME, SID, SERIAL#, PID) as
select "INDX","PG_NAME","SID","SERIAL#","PID" from v$detached_session
/

