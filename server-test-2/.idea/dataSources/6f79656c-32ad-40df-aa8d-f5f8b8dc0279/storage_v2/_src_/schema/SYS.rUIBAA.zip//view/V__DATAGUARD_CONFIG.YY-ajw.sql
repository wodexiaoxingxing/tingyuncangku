create view V_$DATAGUARD_CONFIG (DB_UNIQUE_NAME) as
select "DB_UNIQUE_NAME" from v$dataguard_config
/

