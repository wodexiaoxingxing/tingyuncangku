create view V_$SGASTAT (POOL, NAME, BYTES) as
select "POOL","NAME","BYTES" from v$sgastat
/

