create view V_$FIXED_TABLE (NAME, OBJECT_ID, TYPE, TABLE_NUM) as
select "NAME","OBJECT_ID","TYPE","TABLE_NUM" from v$fixed_table
/

