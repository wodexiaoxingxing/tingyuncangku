create view GV_$VERSION (INST_ID, BANNER) as
select "INST_ID","BANNER" from gv$version
/

