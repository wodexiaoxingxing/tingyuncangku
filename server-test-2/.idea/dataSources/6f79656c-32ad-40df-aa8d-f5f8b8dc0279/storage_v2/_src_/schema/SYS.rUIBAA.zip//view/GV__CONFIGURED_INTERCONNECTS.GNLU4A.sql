create view GV_$CONFIGURED_INTERCONNECTS (INST_ID, NAME, IP_ADDRESS, IS_PUBLIC, SOURCE) as
select "INST_ID","NAME","IP_ADDRESS","IS_PUBLIC","SOURCE" from gv$configured_interconnects
/

