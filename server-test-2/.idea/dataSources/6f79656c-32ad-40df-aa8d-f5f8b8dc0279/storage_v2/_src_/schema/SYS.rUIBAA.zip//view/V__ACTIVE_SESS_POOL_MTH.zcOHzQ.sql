create view V_$ACTIVE_SESS_POOL_MTH (NAME) as
select "NAME" from v$active_sess_pool_mth
/

