create view GV_$STATNAME (INST_ID, STATISTIC#, NAME, CLASS, STAT_ID) as
select "INST_ID","STATISTIC#","NAME","CLASS","STAT_ID" from gv$statname
/

