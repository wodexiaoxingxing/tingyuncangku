create view V_$PX_PROCESS_SYSSTAT (STATISTIC, VALUE) as
select "STATISTIC","VALUE" from v$px_process_sysstat
/

