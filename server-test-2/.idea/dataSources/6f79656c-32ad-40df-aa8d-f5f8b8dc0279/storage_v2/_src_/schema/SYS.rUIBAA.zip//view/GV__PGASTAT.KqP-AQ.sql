create view GV_$PGASTAT (INST_ID, NAME, VALUE, UNIT) as
select "INST_ID","NAME","VALUE","UNIT" from gv$pgastat
/

