create view V_$PWFILE_USERS (USERNAME, SYSDBA, SYSOPER, SYSASM) as
select "USERNAME","SYSDBA","SYSOPER","SYSASM" from v$pwfile_users
/

