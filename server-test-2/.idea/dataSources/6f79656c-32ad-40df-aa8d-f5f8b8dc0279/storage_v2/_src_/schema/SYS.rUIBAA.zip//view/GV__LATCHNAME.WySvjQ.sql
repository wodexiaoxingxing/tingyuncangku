create view GV_$LATCHNAME (INST_ID, LATCH#, NAME, HASH) as
select "INST_ID","LATCH#","NAME","HASH" from gv$latchname
/

