create view V_$OPTION (PARAMETER, VALUE) as
select "PARAMETER","VALUE" from v$option
/

