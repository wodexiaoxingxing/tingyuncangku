create view V_$DB_PIPES (OWNERID, NAME, TYPE, PIPE_SIZE) as
select "OWNERID","NAME","TYPE","PIPE_SIZE" from v$db_pipes
/

