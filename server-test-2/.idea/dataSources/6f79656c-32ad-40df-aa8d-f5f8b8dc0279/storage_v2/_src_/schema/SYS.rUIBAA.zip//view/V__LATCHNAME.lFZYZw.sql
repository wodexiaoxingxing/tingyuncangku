create view V_$LATCHNAME (LATCH#, NAME, HASH) as
select "LATCH#","NAME","HASH" from v$latchname
/

