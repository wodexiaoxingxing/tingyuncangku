create view GV_$DLM_MISC (INST_ID, STATISTIC#, NAME, VALUE) as
select "INST_ID","STATISTIC#","NAME","VALUE" from gv$dlm_misc
/

