create view GV_$SYSSTAT (INST_ID, STATISTIC#, NAME, CLASS, VALUE, STAT_ID) as
select "INST_ID","STATISTIC#","NAME","CLASS","VALUE","STAT_ID" from gv$sysstat
/

