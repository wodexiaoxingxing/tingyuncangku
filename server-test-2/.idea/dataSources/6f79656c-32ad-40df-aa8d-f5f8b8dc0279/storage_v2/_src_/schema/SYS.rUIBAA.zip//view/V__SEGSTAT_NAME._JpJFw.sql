create view V_$SEGSTAT_NAME (STATISTIC#, NAME, SAMPLED) as
select "STATISTIC#","NAME","SAMPLED" from v$segstat_name
/

