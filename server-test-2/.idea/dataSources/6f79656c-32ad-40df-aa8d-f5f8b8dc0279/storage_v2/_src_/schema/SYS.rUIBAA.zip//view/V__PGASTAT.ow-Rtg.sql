create view V_$PGASTAT (NAME, VALUE, UNIT) as
select "NAME","VALUE","UNIT" from v$pgastat
/

