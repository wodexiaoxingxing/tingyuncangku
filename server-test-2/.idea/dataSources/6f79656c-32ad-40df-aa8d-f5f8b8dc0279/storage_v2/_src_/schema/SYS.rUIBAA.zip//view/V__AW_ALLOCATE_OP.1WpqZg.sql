create view V_$AW_ALLOCATE_OP (NAME, LONGNAME) as
select "NAME","LONGNAME" from v$aw_allocate_op
/

