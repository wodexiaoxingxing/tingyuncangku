create view V_$LOCKS_WITH_COLLISIONS (LOCK_ELEMENT_ADDR) as
select "LOCK_ELEMENT_ADDR" from v$locks_with_collisions
/

