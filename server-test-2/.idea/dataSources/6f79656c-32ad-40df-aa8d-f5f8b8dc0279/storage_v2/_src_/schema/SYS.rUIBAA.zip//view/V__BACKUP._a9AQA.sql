create view V_$BACKUP (FILE#, STATUS, CHANGE#, TIME) as
select "FILE#","STATUS","CHANGE#","TIME" from v$backup
/

