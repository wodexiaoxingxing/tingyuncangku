create view V_$GLOBAL_BLOCKED_LOCKS (ADDR, KADDR, SID, TYPE, ID1, ID2, LMODE, REQUEST, CTIME) as
select "ADDR","KADDR","SID","TYPE","ID1","ID2","LMODE","REQUEST","CTIME" from v$global_blocked_locks
/

