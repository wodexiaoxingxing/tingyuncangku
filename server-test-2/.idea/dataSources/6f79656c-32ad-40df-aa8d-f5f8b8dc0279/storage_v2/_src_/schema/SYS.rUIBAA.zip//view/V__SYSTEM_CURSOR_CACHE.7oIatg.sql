create view V_$SYSTEM_CURSOR_CACHE (OPENS, HITS, HIT_RATIO) as
select "OPENS","HITS","HIT_RATIO" from v$system_cursor_cache
/

