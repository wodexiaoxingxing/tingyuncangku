create view GV_$AW_AGGREGATE_OP (INST_ID, NAME, LONGNAME, DEFAULT_WEIGHT) as
select "INST_ID","NAME","LONGNAME","DEFAULT_WEIGHT" from gv$aw_aggregate_op
/

