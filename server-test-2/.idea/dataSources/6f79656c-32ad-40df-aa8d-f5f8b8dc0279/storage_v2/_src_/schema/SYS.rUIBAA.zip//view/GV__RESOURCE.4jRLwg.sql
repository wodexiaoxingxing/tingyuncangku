create view GV_$RESOURCE (INST_ID, ADDR, TYPE, ID1, ID2) as
select "INST_ID","ADDR","TYPE","ID1","ID2" from gv$resource
/

