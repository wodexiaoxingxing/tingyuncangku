create view V_$TIMER (HSECS) as
select "HSECS" from v$timer
/

