create view GV_$LOCKS_WITH_COLLISIONS (INST_ID, LOCK_ELEMENT_ADDR) as
select "INST_ID","LOCK_ELEMENT_ADDR" from gv$locks_with_collisions
/

