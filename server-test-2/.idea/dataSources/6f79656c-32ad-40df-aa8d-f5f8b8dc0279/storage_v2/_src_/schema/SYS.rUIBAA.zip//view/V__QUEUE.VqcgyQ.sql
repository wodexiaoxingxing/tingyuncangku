create view V_$QUEUE (PADDR, TYPE, QUEUED, WAIT, TOTALQ) as
select "PADDR","TYPE","QUEUED","WAIT","TOTALQ" from v$queue
/

