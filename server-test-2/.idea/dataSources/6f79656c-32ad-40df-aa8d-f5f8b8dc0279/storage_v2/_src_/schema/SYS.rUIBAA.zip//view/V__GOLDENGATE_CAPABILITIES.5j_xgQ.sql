create view V_$GOLDENGATE_CAPABILITIES (NAME, COUNT, LAST_USED) as
select "NAME","COUNT","LAST_USED" from v$goldengate_capabilities
/

