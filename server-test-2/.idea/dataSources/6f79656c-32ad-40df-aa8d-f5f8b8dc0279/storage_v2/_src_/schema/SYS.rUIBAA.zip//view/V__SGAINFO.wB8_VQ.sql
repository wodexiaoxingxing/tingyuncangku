create view V_$SGAINFO (NAME, BYTES, RESIZEABLE) as
select "NAME","BYTES","RESIZEABLE" from v$sgainfo
/

