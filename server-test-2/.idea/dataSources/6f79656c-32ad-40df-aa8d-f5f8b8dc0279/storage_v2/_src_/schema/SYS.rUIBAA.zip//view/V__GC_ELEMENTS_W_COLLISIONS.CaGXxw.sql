create view V_$GC_ELEMENTS_W_COLLISIONS (GC_ELEMENT_ADDR) as
select "GC_ELEMENT_ADDR" from v$gc_elements_with_collisions
/

