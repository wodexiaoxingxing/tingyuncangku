create view V_$DLM_MISC (STATISTIC#, NAME, VALUE) as
select "STATISTIC#","NAME","VALUE" from v$dlm_misc
/

