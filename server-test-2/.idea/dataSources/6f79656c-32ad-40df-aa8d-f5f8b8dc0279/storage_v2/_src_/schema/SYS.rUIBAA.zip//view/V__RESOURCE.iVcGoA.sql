create view V_$RESOURCE (ADDR, TYPE, ID1, ID2) as
select "ADDR","TYPE","ID1","ID2" from v$resource
/

