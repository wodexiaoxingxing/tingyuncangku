create view V_$ENABLEDPRIVS (PRIV_NUMBER) as
select "PRIV_NUMBER" from v$enabledprivs
/

