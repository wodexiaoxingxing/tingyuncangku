create view GV_$SESSTAT (INST_ID, SID, STATISTIC#, VALUE) as
select "INST_ID","SID","STATISTIC#","VALUE" from gv$sesstat
/

