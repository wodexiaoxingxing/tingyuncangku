create view GV_$GC_ELEMENTS_W_COLLISIONS (INST_ID, GC_ELEMENT_ADDR) as
select "INST_ID","GC_ELEMENT_ADDR" from gv$gc_elements_with_collisions
/

