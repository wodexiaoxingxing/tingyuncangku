create view V_$LATCHHOLDER (PID, SID, LADDR, NAME, GETS) as
select "PID","SID","LADDR","NAME","GETS" from v$latchholder
/

