create view V_$ACCESS (SID, OWNER, OBJECT, TYPE) as
select "SID","OWNER","OBJECT","TYPE" from v$access
/

