create view V_$WAITSTAT (CLASS, COUNT, TIME) as
select "CLASS","COUNT","TIME" from v$waitstat
/

