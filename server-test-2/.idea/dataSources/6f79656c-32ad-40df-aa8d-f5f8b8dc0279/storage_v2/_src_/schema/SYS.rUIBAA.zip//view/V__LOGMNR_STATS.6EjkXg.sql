create view V_$LOGMNR_STATS (SESSION_ID, NAME, VALUE) as
select "SESSION_ID","NAME","VALUE" from v$logmnr_stats
/

