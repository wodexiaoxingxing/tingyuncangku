create view V_$MYSTAT (SID, STATISTIC#, VALUE) as
select "SID","STATISTIC#","VALUE" from v$mystat
/

