create view V_$REQDIST (BUCKET, COUNT) as
select "BUCKET","COUNT" from v$reqdist
/

