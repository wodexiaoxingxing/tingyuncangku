create view V_$MUTEX_SLEEP (MUTEX_TYPE, LOCATION, SLEEPS, WAIT_TIME) as
select "MUTEX_TYPE","LOCATION","SLEEPS","WAIT_TIME" from v$mutex_sleep
/

