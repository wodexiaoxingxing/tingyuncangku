create view V_$PX_PROCESS (SERVER_NAME, STATUS, PID, SPID, SID, SERIAL#) as
select "SERVER_NAME","STATUS","PID","SPID","SID","SERIAL#" from v$px_process
/

