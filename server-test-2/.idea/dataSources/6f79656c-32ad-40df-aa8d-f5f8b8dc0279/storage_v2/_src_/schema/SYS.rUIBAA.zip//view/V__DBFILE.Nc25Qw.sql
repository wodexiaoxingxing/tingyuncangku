create view V_$DBFILE (FILE#, NAME) as
select "FILE#","NAME" from v$dbfile
/

