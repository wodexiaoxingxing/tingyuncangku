create view GV_$FAST_START_SERVERS (INST_ID, STATE, UNDOBLOCKSDONE, PID, XID) as
select "INST_ID","STATE","UNDOBLOCKSDONE","PID","XID" from gv$fast_start_servers
/

