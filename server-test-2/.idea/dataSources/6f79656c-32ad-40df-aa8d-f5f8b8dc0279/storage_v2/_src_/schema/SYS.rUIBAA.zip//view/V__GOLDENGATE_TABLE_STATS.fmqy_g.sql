create view V_$GOLDENGATE_TABLE_STATS
            (SERVER_NAME, SERVER_ID, SOURCE_TABLE_OWNER, SOURCE_TABLE_NAME, DESTINATION_TABLE_OWNER,
             DESTINATION_TABLE_NAME, LAST_UPDATE, TOTAL_INSERTS, TOTAL_UPDATES, TOTAL_DELETES, INSERT_COLLISIONS,
             UPDATE_COLLISIONS, DELETE_COLLISIONS, REPERROR_RECORDS, REPERROR_IGNORES, WAIT_DEPENDENCIES,
             CDR_INSERT_ROW_EXISTS, CDR_UPDATE_ROW_EXISTS, CDR_UPDATE_ROW_MISSING, CDR_DELETE_ROW_EXISTS,
             CDR_DELETE_ROW_MISSING, CDR_SUCCESSFUL_RESOLUTIONS, CDR_FAILED_RESOLUTIONS)
as
select server_name, server_id, source_table_owner,
         source_table_name, destination_table_owner, destination_table_name,
         last_update, total_inserts, total_updates, total_deletes,
         insert_collisions, update_collisions, delete_collisions,
         reperror_records, reperror_ignores, wait_dependencies,
         cdr_insert_row_exists, cdr_update_row_exists,
         cdr_update_row_missing, cdr_delete_row_exists,
         cdr_delete_row_missing,
         cdr_successful_resolutions, cdr_failed_resolutions
         from gv$goldengate_table_stats where INST_ID = USERENV('Instance')
/

