create view GV_$OBSOLETE_PARAMETER (INST_ID, NAME, ISSPECIFIED) as
select "INST_ID","NAME","ISSPECIFIED" from gv$obsolete_parameter
/

