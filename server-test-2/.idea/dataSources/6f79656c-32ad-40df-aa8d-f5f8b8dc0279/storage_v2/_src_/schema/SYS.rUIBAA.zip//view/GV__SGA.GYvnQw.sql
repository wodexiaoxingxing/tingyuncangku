create view GV_$SGA (INST_ID, NAME, VALUE) as
select "INST_ID","NAME","VALUE" from gv$sga
/

