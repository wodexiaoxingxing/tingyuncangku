create view GV_$CLUSTER_INTERCONNECTS (INST_ID, NAME, IP_ADDRESS, IS_PUBLIC, SOURCE) as
select "INST_ID","NAME","IP_ADDRESS","IS_PUBLIC","SOURCE" from gv$cluster_interconnects
/

