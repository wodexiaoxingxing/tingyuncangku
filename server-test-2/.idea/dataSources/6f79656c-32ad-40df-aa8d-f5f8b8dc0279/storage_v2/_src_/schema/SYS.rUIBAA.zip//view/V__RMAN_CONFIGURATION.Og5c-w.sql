create view V_$RMAN_CONFIGURATION (CONF#, NAME, VALUE) as
select "CONF#","NAME","VALUE" from v$rman_configuration
/

