create view GV_$ENABLEDPRIVS (INST_ID, PRIV_NUMBER) as
select "INST_ID","PRIV_NUMBER" from gv$enabledprivs
/

