create view V_$RECOVER_FILE (FILE#, ONLINE, ONLINE_STATUS, ERROR, CHANGE#, TIME) as
select "FILE#","ONLINE","ONLINE_STATUS","ERROR","CHANGE#","TIME" from v$recover_file
/

