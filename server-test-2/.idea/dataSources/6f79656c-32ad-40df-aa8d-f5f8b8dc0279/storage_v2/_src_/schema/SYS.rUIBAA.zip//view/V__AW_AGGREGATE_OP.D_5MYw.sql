create view V_$AW_AGGREGATE_OP (NAME, LONGNAME, DEFAULT_WEIGHT) as
select "NAME","LONGNAME","DEFAULT_WEIGHT" from v$aw_aggregate_op
/

