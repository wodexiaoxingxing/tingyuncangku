create view GV_$ACCESS (INST_ID, SID, OWNER, OBJECT, TYPE) as
select "INST_ID","SID","OWNER","OBJECT","TYPE" from gv$access
/

