create view V_$PQ_SYSSTAT (STATISTIC, VALUE) as
select "STATISTIC","VALUE" from v$pq_sysstat
/

