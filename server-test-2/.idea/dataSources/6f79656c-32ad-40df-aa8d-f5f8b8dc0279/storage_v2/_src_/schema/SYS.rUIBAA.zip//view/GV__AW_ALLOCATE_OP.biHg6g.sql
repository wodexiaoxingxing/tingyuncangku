create view GV_$AW_ALLOCATE_OP (INST_ID, NAME, LONGNAME) as
select "INST_ID","NAME","LONGNAME" from gv$aw_allocate_op
/

