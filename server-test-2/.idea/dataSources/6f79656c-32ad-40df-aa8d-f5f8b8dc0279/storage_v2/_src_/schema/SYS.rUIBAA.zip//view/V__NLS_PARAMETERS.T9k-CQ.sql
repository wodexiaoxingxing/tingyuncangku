create view V_$NLS_PARAMETERS (PARAMETER, VALUE) as
select "PARAMETER","VALUE" from v$nls_parameters
/

