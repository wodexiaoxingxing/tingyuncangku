create view V_$QUEUEING_MTH (NAME) as
select "NAME" from v$queueing_mth
/

