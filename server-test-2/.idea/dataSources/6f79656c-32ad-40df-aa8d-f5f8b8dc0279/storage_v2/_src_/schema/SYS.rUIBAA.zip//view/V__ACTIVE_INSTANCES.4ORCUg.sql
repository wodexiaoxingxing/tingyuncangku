create view V_$ACTIVE_INSTANCES (INST_NUMBER, INST_NAME) as
select "INST_NUMBER","INST_NAME" from v$active_instances
/

