create view V_$RECOVERY_LOG (THREAD#, SEQUENCE#, TIME, ARCHIVE_NAME) as
select "THREAD#","SEQUENCE#","TIME","ARCHIVE_NAME" from v$recovery_log
/

