create view V_$LOCK_ACTIVITY (FROM_VAL, TO_VAL, ACTION_VAL, COUNTER) as
select "FROM_VAL","TO_VAL","ACTION_VAL","COUNTER" from v$lock_activity
/

