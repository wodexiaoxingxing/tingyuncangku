create view V_$SESSTAT (SID, STATISTIC#, VALUE) as
select "SID","STATISTIC#","VALUE" from v$sesstat
/

