create view V_$SES_OPTIMIZER_ENV (SID, ID, NAME, SQL_FEATURE, ISDEFAULT, VALUE) as
select "SID","ID","NAME","SQL_FEATURE","ISDEFAULT","VALUE" from v$ses_optimizer_env
/

