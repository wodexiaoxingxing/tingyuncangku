create view GV_$DBFILE (INST_ID, FILE#, NAME) as
select "INST_ID","FILE#","NAME" from gv$dbfile
/

