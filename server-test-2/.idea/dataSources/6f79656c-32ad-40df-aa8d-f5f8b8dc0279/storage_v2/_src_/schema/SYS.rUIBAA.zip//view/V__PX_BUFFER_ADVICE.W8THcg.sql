create view V_$PX_BUFFER_ADVICE (STATISTIC, VALUE) as
select "STATISTIC","VALUE" from v$px_buffer_advice
/

