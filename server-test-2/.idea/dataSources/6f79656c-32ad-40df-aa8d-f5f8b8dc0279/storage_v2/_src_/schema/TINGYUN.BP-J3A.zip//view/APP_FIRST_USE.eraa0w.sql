create view APP_FIRST_USE as
SELECT t.id,T.AGREEMENT_ID,
                                MIN(T.ACTIVE_TIME) AS ACTIVE_TIME
                           FROM NL_U_MOBILE_APP T
                          GROUP BY T.AGREEMENT_ID,t.id


/

