create view SS_V_ORDERS as
select
       b.id,
       a.id as order_id,
       u.code as login_code,
       u.company,
       a.type,
       a.user_id,
       a.status,
       a.ctime,
       a.ORDER_NO,
       b.service_type,
       st.type as product_type,
       st.name as product_name,
       b.cash_sum,
       b.cash_actually_paid,
       (b.cash_sum - b.cash_actually_paid) dk,
       a.bill_time pay_time,
       p.PROVIDER_TYPE,
       CASE st.free
         when 1 then b.ctime
         else add_months(b.service_disable_time,-(b.expiration+b.affixation))
       END as begin_time,
       b.service_disable_time as end_time
  from ss_orders a right join  ss_orders_detail b on a.id = b.order_id
       left join nb_m_user u on a.user_id = u.id
       left join SS_PAYMENTS p on a.id = p.order_id
       left join ss_m_service_type st on b.service_type  = st.id


/

