create view SS_V_BOSS_US as
SELECT T.ID,
       T.USER_ID,
       T.CODE,
       LOWER(T.CODE) AS CTR,
       T.ORDER_TYPE,
       T.COMPANY,
       T.SERVICE_TYPE,
       T.PRODUCT_TYPE,
       T.ENABLE_TIME,
       T.DISABLE_TIME,
       T.NSTR,
       T.TSTR,
       T.DSTR,
       T.STATUS,
       T.CUSER,
       T.CTIME,
       T.MUSER,
       T.MTIME,
       T.AREA
  FROM (SELECT S.ID,
               S.USER_ID,
               S.CODE,
               S.ORDER_TYPE,
               S.COMPANY,
               S.SERVICE_TYPE,
               S.PRODUCT_TYPE,
               S.ENABLE_TIME,
               S.DISABLE_TIME,
               S.NSTR,
               S.TSTR,
               S.DSTR,
               S.STATUS,
               S.CUSER,
               S.CTIME,
               S.MUSER,
               S.MTIME,
               S.AREA,
               ROW_NUMBER() OVER(PARTITION BY S.USER_ID, S.PRODUCT_TYPE ORDER BY S.ORDER_TYPE DESC) RN
          FROM (SELECT S.ID,
                       S.USER_ID,
                       U.CODE,
                       S.TYPE AS ORDER_TYPE,
                       U.COMPANY,
                       S.SERVICE_TYPE,
                       T.TYPE AS PRODUCT_TYPE,
                       S.ENABLE_TIME,
                       S.SERVICE_DISABLE_TIME AS DISABLE_TIME,
                       DECODE(T.TYPE,
                              '1',
                              '听云App' || T.NAME ||
                              DECODE(S.TYPE, '2', '试用', ''),
                              '2',
                              '听云Server' || T.NAME ||
                              DECODE(S.TYPE, '2', '试用', ''),
                              '3',
                              '听云Network' || T.NAME ||
                              DECODE(S.TYPE, '2', '试用', ''),
                              '4',
                              '听云sys' || T.NAME ||
                              DECODE(S.TYPE, '2', '试用', ''),
                              '5',
                              '听云Browser' || T.NAME ||
                              DECODE(S.TYPE, '2', '试用', ''),
                              '6',
                              '听云Idaas' || T.NAME ||
                              DECODE(S.TYPE, '2', '试用', ''),
                              '7',
                              '听云Alarm' || T.NAME ||
                              DECODE(S.TYPE, '2', '试用', ''),
                              '301',
                              '听云network点次包' || T.NAME ||
                              DECODE(S.TYPE, '2', '试用', ''),
                              '12',
                              '听云小程序' || T.NAME ||
                              DECODE(S.TYPE, '2', '试用', ''),
                              '10',
                              '听云大屏' || T.NAME ||
                              DECODE(S.TYPE, '2', '试用', '')) AS NSTR,
                       DECODE(S.TYPE,
                              '1',
                              '免费  ',
                              '2',
                              '试用',
                              '3',
                              '升级',
                              '') AS TSTR,
                       TO_CHAR(S.ENABLE_TIME, 'YYYY.MM.DD') || '-' ||
                       TO_CHAR(S.SERVICE_DISABLE_TIME, 'YYYY.MM.DD') AS DSTR,
                       S.STATUS,
                       T.CUSER,
                       T.CTIME,
                       T.MUSER,
                       T.MTIME,
                       SU.AREA
                  FROM SS_USER_SERVICE_TYPE S,
                       NB_M_USER            U,
                       SS_M_SERVICE_TYPE    T,
                       SS_ACCOUNT           SU
                 WHERE S.USER_ID = U.ID
                   AND S.SERVICE_TYPE = T.ID
                   AND S.SERVICE_STATUS > 0
                   AND T.TYPE IN (1, 2, 3, 5,12)
                   AND S.ENABLE_TIME <= SYSDATE
                   AND S.SERVICE_DISABLE_TIME >= SYSDATE
                   AND U.ID = SU.ID(+)
                 ORDER BY S.CTIME DESC) S) T
 WHERE T.RN = 1
 ORDER BY T.MTIME DESC
/

