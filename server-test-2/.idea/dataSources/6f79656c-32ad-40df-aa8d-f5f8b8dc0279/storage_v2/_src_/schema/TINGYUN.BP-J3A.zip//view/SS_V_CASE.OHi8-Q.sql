create view SS_V_CASE as
select
c."ID",c."CASE_NO",c."TITLE",c."CASE_LEVEL",c."STATUS",c."CASE_TYPE",c."PRODUCT_TYPE",c."CURRENTER",c."CUSER",c."COMPANY",c."MUSER",c."CASE_FROM",
c."COMPANY_SAAS",c."REMARKS",c."TASK_NAME",c."DEPARTMENT",c."EXPIRE",c."CONTACTNAME",c."CONTACTWAY",c."EMAIL",c."DELAY",c."EXPECT",c."ACCOUNT",c."ACCOUNT_PSW",c."SUPPORT_MAIL",
c.support,c.cperson,c.company_smb,c.gdoc,c.tag,c.PROJECT_TYPE,c.attachment,c.COMPANY_TYPE,c.AREA,c.CMAIL,c.BACK_SUPPORT,c.REASON,c.issue_type,c.estimate_solve_time,c.stars,
to_date(to_char(c.ctime,'yyyy-mm-dd HH24:MI:SS'),'yyyy-mm-dd HH24:MI:SS') as ctime,
to_date(to_char(c.ctime,'yyyy-mm-dd HH24:MI:SS'),'yyyy-mm-dd HH24:MI:SS') as lctime,
to_date(to_char(c.mtime,'yyyy-mm-dd HH24:MI:SS'),'yyyy-mm-dd HH24:MI:SS') as mtime,
to_date(to_char(c.mtime,'yyyy-mm-dd HH24:MI:SS'),'yyyy-mm-dd HH24:MI:SS') as lmtime,
to_date(to_char(c.OTIME,'yyyy-mm-dd HH24:MI:SS'),'yyyy-mm-dd HH24:MI:SS') as OTIME,
to_date(to_char(c.OTIME,'yyyy-mm-dd HH24:MI:SS'),'yyyy-mm-dd HH24:MI:SS') as lOTIME,
to_date(to_char(c.STIME,'yyyy-mm-dd HH24:MI:SS'),'yyyy-mm-dd HH24:MI:SS') as STIME,
to_date(to_char(c.STIME,'yyyy-mm-dd HH24:MI:SS'),'yyyy-mm-dd HH24:MI:SS') as lSTIME,
u1.name as cname, u2.name as mname,u3.name as dname,u4.name as sname,u5.name AS tname ,cl.relatedperson,c."SUSER",
TRUNC(ceil(((case when c.status in(1,0) then c.stime else sysdate end)  - c.mtime) * 24 * 60 ) / 24 / 60, 0) || '天' ||
trunc((ceil(((case when c.status in(1,0) then c.stime else sysdate end)- c.mtime) * 24 * 60 ) - 60 * 24 * TRUNC(ceil(((case when c.status in(1,0) then c.stime else sysdate end)- c.mtime) * 24 * 60 ) / 24 / 60, 0)) / 60, 0) || '小时' ||
trunc(ceil(((case when c.status in(1,0) then c.stime else sysdate end)- c.mtime) * 24 * 60 ) - 60 * 24 * TRUNC(ceil(((case when c.status in(1,0) then c.stime else sysdate end)- c.mtime) * 24 * 60 ) / 24 / 60, 0) - 60 *
trunc((ceil(((case when c.status in(1,0) then c.stime else sysdate end)- c.mtime) * 24 * 60 ) - 60 * 24 * TRUNC(ceil(((case when c.status in(1,0) then c.stime else sysdate end)- c.mtime) * 24 * 60 ) / 24 / 60, 0)) / 60, 0)) || '分' satustime ,
TRUNC(ceil(((case when c.status in(1,0) then c.stime else sysdate end)- c.ctime) * 24 * 60 ) / 24 / 60, 0) || '天' ||
trunc((ceil(((case when c.status in(1,0) then c.stime else sysdate end)- c.ctime) * 24 * 60 ) - 60 * 24 * TRUNC(ceil(((case when c.status in(1,0) then c.stime else sysdate end)- c.ctime) * 24 * 60 ) / 24 / 60, 0)) / 60, 0) || '小时' ||
trunc(ceil(((case when c.status in(1,0) then c.stime else sysdate end)- c.ctime) * 24 * 60 ) - 60 * 24 * TRUNC(ceil(((case when c.status in(1,0) then c.stime else sysdate end)- c.ctime) * 24 * 60 ) / 24 / 60, 0) - 60 *
trunc((ceil(((case when c.status in(1,0) then c.stime else sysdate end)- c.ctime) * 24 * 60 ) - 60 * 24 * TRUNC(ceil(((case when c.status in(1,0) then c.stime else sysdate end)- c.ctime) * 24 * 60 ) / 24 / 60, 0)) / 60, 0)) || '分' sumtime,
r1.total AS response_time,r2.total AS repeat_time,r3.total AS repeat_suc_time,r4.total AS repeat_fail_time ,DECODE(c.CASE_TYPE, '12', r5.TOTAL) AS FIRST_RESPONSE_TIME from ss_case c,nb_m_user u1,nb_m_user u2,nb_m_user u3,nb_m_user u4,nb_m_user u5,ss_v_caselog cl,
(SELECT R.CASE_ID,
       R.CASE_STATUS,
       trunc(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) / 24 / 60, 0) || '天' ||
trunc((ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) - 60 * 24 * TRUNC(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) / 24 / 60, 0)) / 60, 0) || '小时' ||
trunc(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) - 60 * 24 * TRUNC(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) / 24 / 60, 0) - 60 *
trunc((ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) - 60 * 24 * TRUNC(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) / 24 / 60, 0)) / 60, 0)) || '分' as total
  FROM (SELECT R.ID,
               R.CASE_ID,
               R.CASE_STATUS,
               R.STIME,
               NVL(R.ETIME, SYSDATE) AS ETIME,
               R.CTIME
          FROM SS_CASE_REPORT R) R WHERE R.CASE_STATUS = 111
 GROUP BY R.CASE_ID, R.CASE_STATUS
 ORDER BY R.CASE_ID DESC, R.CASE_STATUS DESC) r1,
(SELECT R.CASE_ID,
       R.CASE_STATUS,
       trunc(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) / 24 / 60, 0) || '天' ||
trunc((ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) - 60 * 24 * TRUNC(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) / 24 / 60, 0)) / 60, 0) || '小时' ||
trunc(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) - 60 * 24 * TRUNC(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) / 24 / 60, 0) - 60 *
trunc((ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) - 60 * 24 * TRUNC(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) / 24 / 60, 0)) / 60, 0)) || '分' as total
  FROM (SELECT R.ID,
               R.CASE_ID,
               R.CASE_STATUS,
               R.STIME,
               NVL(R.ETIME, SYSDATE) AS ETIME,
               R.CTIME
          FROM SS_CASE_REPORT R) R WHERE R.CASE_STATUS = 112
 GROUP BY R.CASE_ID, R.CASE_STATUS
 ORDER BY R.CASE_ID DESC, R.CASE_STATUS DESC) r2,
 (SELECT R.CASE_ID,
       R.CASE_STATUS,
       trunc(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) / 24 / 60, 0) || '天' ||
trunc((ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) - 60 * 24 * TRUNC(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) / 24 / 60, 0)) / 60, 0) || '小时' ||
trunc(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) - 60 * 24 * TRUNC(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) / 24 / 60, 0) - 60 *
trunc((ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) - 60 * 24 * TRUNC(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) / 24 / 60, 0)) / 60, 0)) || '分' as total
  FROM (SELECT R.ID,
               R.CASE_ID,
               R.CASE_STATUS,
               R.STIME,
               NVL(R.ETIME, SYSDATE) AS ETIME,
               R.CTIME
          FROM SS_CASE_REPORT R) R WHERE R.CASE_STATUS = 114
 GROUP BY R.CASE_ID, R.CASE_STATUS
 ORDER BY R.CASE_ID DESC, R.CASE_STATUS DESC) r3,
 (SELECT R.CASE_ID,
       R.CASE_STATUS,
       trunc(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) / 24 / 60, 0) || '天' ||
trunc((ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) - 60 * 24 * TRUNC(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) / 24 / 60, 0)) / 60, 0) || '小时' ||
trunc(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) - 60 * 24 * TRUNC(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) / 24 / 60, 0) - 60 *
trunc((ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) - 60 * 24 * TRUNC(ceil((sum(R.ETIME - R.STIME)) * 24 * 60 ) / 24 / 60, 0)) / 60, 0)) || '分' as total
  FROM (SELECT R.ID,
               R.CASE_ID,
               R.CASE_STATUS,
               R.STIME,
               NVL(R.ETIME, SYSDATE) AS ETIME,
               R.CTIME
          FROM SS_CASE_REPORT R) R WHERE R.CASE_STATUS = 115
 GROUP BY R.CASE_ID, R.CASE_STATUS
 ORDER BY R.CASE_ID DESC, R.CASE_STATUS DESC) r4,
 (SELECT R1.CASE_ID,  trunc(ceil((nvl(R1.ETIME,SYSDATE) - R1.STIME) * 24 * 60 ) / 24 / 60, 0) || '天' ||
trunc((ceil((nvl(R1.ETIME,SYSDATE) - R1.STIME) * 24 * 60 ) - 60 * 24 * TRUNC(ceil((nvl(R1.ETIME,SYSDATE) - R1.STIME) * 24 * 60 ) / 24 / 60, 0)) / 60, 0) || '小时' ||
trunc(ceil((nvl(R1.ETIME,SYSDATE) - R1.STIME) * 24 * 60 ) - 60 * 24 * TRUNC(ceil((nvl(R1.ETIME,SYSDATE) - R1.STIME) * 24 * 60 ) / 24 / 60, 0) - 60 *
trunc((ceil((nvl(R1.ETIME,SYSDATE) - R1.STIME) * 24 * 60 ) - 60 * 24 * TRUNC(ceil((nvl(R1.ETIME,SYSDATE) - R1.STIME) * 24 * 60 ) / 24 / 60, 0)) / 60, 0)) || '分' as total
  FROM SS_CASE_REPORT R1,
       (SELECT R.CASE_ID, R.CASE_STATUS, MAX(NVL(R.STIME, R.STIME)) AS STIME
          FROM SS_CASE_REPORT R
         WHERE R.CASE_STATUS = 4
         GROUP BY R.CASE_ID, R.CASE_STATUS) R2
 WHERE R1.CASE_ID = R2.CASE_ID
   AND R1.STIME = R2.STIME) r5
where c.cuser = u1.id(+)
and c.muser = u2.id(+)
and c.currenter = u3.id(+)
and c.support =u4.id(+)
AND c.tam_manager =u5.id(+)
and c.id = cl.caseno(+)
AND c.id = r1.CASE_ID(+)
AND c.id = r2.CASE_ID(+)
AND c.id = r3.CASE_ID(+)
AND c.id = r4.CASE_ID(+)
AND c.id = r5.CASE_ID(+)
/

