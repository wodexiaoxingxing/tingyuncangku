create view SS_V_TRANSFER as
select v_t.order_id as id,v_t.user_id,v_t.ctime,v_t.ptime,v_t.payments,v_t.order_no,v_t.status,v_t.mtime,v_t.open_status,v_t.trade_no,v_t.bank,v_t.total_fee
,v_a.link_name,v_a.link_phone
,v_u.code,v_u.name,v_u.mobile,v_u.company
from
(select p.ORDER_ID,p.USER_ID,p.CTIME ptime,p.PAYMENTS,p.trade_no,p.bank,p.total_fee
,o.ORDER_NO,o.STATUS,o.MTIME,o.ctime,o.open_status
from SS_PAYMENTS p,SS_ORDERS o
where p.ORDER_ID = o.ID
and PROVIDER_TYPE=1
and o.status<>-1 and o.type in (0,3,4)) v_t,
(select ID,LINK_NAME,LINK_PHONE from SS_ACCOUNT ) v_a,
(select ID,CODE,NAME,MOBILE,COMPANY from NB_M_USER) v_u
where v_t.user_id = v_a.id(+)
and v_t.user_id = v_u.id(+)
order by v_t.order_no desc


/

