create view SS_V_CASELOG as
select v.caseno,to_char(WM_CONCAT(v.name)) as relatedperson  from (
select distinct c.caseno,u.name from  ss_caselog c,nb_m_user u where c.ouser=u.id
) v group by v.caseno


/

