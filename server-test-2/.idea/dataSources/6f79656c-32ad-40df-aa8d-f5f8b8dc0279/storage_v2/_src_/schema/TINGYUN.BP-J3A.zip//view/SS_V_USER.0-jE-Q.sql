create view SS_V_USER as
SELECT u.id,
       k.area_id,
       a.province_id,
       u.code,
       u.name,
       u.mobile,
       u.type,
       u.passwd,
       u.email,
       u.msn,
       u.phone,
       u.status,
       u.agree_id,
       u.sales_id,
       u.ctime,
       u.mtime,
       u.company,
       u.user_from,
       a.phone_province,
       t1.aTime AS mapp_Active_Time,
       t2.aTime AS app_Active_Time,
       t3.aTime AS task_Active_Time,
       t4.aTime AS sys_Active_Time,
       t5.aTime as browser_Active_Time,
       a.operator_id as smb_sales_id,
       trade.cn_name as company_trade,
       trade.id as company_trade_id,
       area.cn_name as company_area,
       area.id as company_area_id
  FROM NB_M_USER u
  left join (select id, cn_name from SS_M_CATEGORY_DETAIL where status > 0) area
    on u.area = area.id

  left join (select id, cn_name from SS_M_CATEGORY_DETAIL where status > 0) trade
    on u.trade = trade.id

  LEFT JOIN ss_account a
    ON u.id = a.id
  LEFT JOIN (SELECT p.area_id, ac.id
               FROM ss_account ac, ss_province_org p
              WHERE ac.province_id = p.province_id) k
    ON k.id = u.id
  LEFT JOIN (SELECT ma.AGREEMENT_ID ai,
                    MIN(ma.active_Time) aTime,
                    COUNT(ma.id) c
               FROM nl_u_mobile_app ma
              GROUP BY ma.AGREEMENT_ID) t1
    ON u.agree_id = t1.ai
  LEFT JOIN (SELECT app.agreement_id ai, MIN(app.ctime) aTime, COUNT(app.id)
               FROM NL_U_APPLICATION app
              GROUP BY app.agreement_id) t2
    ON u.agree_id = t2.ai
  LEFT JOIN (SELECT task.AGREEMENT_ID ai,
                    MIN(task.active_Time) aTime,
                    COUNT(task.id) c
               FROM NL_U_TASK task
              GROUP BY task.AGREEMENT_ID) t3
    ON u.agree_id = t3.ai
  LEFT JOIN (SELECT server.AGREEMENT_ID ai,
                    MIN(server.active_Time) aTime,
                    COUNT(server.id) c
               FROM NL_U_SERVER server
              GROUP BY server.AGREEMENT_ID) t4
    ON u.agree_id = t4.ai
  LEFT JOIN (SELECT server.AGREEMENT_ID ai,
                    MIN(server.active_Time) aTime,
                    COUNT(server.id) c
               FROM Nl_u_Browser_Application server
              GROUP BY server.AGREEMENT_ID) t5
    ON u.agree_id = t5.ai
 WHERE u.status >= 0
   AND u.type IN (3, 70, 71)
 order by ctime desc
/

