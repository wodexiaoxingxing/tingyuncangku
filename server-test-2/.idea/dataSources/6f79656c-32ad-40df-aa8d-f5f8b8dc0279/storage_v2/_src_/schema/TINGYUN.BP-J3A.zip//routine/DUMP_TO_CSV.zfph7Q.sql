create procedure  dump_to_csv(
p_query in varchar2, --sql query statement
p_dir in varchar2, --the directory of file
p_filename in varchar2, --the export filename
p_max_linesize in number default 32000 --max linesize,must less than 32787
)
is
l_output utl_file.file_type;
l_theCursor integer default dbms_sql.open_cursor;
l_columnValue varchar2(4000);
l_status integer;
l_colCnt number := 0;
l_separator varchar2(1);
l_descTbl dbms_sql.desc_tab;
begin
--open file
l_output := utl_file.fopen( p_dir, p_filename, 'w', p_max_linesize);
--define date format
execute immediate 'alter session set nls_date_format=''yyyy-mm-dd hh24:mi:ss''';
--open cursor
dbms_sql.parse( l_theCursor, p_query, dbms_sql.native );
dbms_sql.describe_columns( l_theCursor, l_colCnt, l_descTbl );
--dump table column name
for i in 1 .. l_colCnt loop
utl_file.put( l_output, l_separator || '"' || l_descTbl(i).col_name || '"' );
dbms_sql.define_column( l_theCursor, i, l_columnValue, 4000 );
l_separator := ',';
end loop;
utl_file.new_line( l_output );
--execute the query statement
l_status := dbms_sql.execute(l_theCursor);
--dump table column value
while ( dbms_sql.fetch_rows(l_theCursor) > 0 ) loop
l_separator := '';
for i in 1 .. l_colCnt loop
dbms_sql.column_value( l_theCursor, i, l_columnValue );
utl_file.put( l_output, l_separator || '"' ||
trim(both ' ' from replace(l_columnValue,'"','""')) || '"');
l_separator := ',';
end loop;
utl_file.new_line( l_output );
end loop;
--close cursor
dbms_sql.close_cursor(l_theCursor);
--close file
utl_file.fclose( l_output );
exception
when others then
raise;
end;


/

