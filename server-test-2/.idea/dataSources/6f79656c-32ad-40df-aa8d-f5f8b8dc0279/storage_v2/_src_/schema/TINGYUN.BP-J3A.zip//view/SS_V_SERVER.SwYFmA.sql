create view SS_V_SERVER as
select a.id,a.service_type,a.user_id,a.enable_time,a.disable_time,a.ctime ,
b.name,b.type,
c.code userName,c.MOBILE,c.EMAIL
from SS_SERVICE a,SS_M_SERVICE_TYPE b,NB_M_USER c
where  a.service_type = b.id
and a.user_id = c.id


/

