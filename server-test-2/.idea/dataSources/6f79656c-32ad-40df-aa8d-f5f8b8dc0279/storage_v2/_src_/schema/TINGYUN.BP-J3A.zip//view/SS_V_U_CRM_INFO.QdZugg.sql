create view SS_V_U_CRM_INFO as
SELECT P.ID,
       P.USER_ID,
       P.AGREE_ID,
       P.CODE,
       P.NAME,
       P.COMPANY,
       P.APP_RELATED,
       P.SERVER_RELATED,
       P.BROWSER_RELATED,
       P.NETWORK_RELATED,
       NVL(U1.NAME, '') AS SALES,
       NVL(U2.NAME, '') AS SUPPORT,
       P.CTIME
  FROM (SELECT U.ID,
               U.CODE,
               U.NAME,
               U.COMPANY,
               U.AGREE_ID,
               NVL(C.APP_RELATED, 0) AS APP_RELATED,
               NVL(C.SERVER_RELATED, 0) AS SERVER_RELATED,
               NVL(C.BROWSER_RELATED, 0) AS BROWSER_RELATED,
               NVL(C.NETWORK_RELATED, 0) AS NETWORK_RELATED,
               A.SALES_USER_ID,
               A.SUPPORT_USER_ID,
               U.CTIME,
               U.ID AS USER_ID
          FROM NB_M_USER U, SS_U_CRM_INFO C, SS_ACCOUNT A
         WHERE U.TYPE = 3
           AND U.STATUS > 0
           AND U.ID = C.USER_ID(+)
           AND U.ID = A.ID(+)
         ORDER BY U.CTIME DESC, U.ID DESC) P,
       NB_M_USER U1,
       NB_M_USER U2
 WHERE P.SALES_USER_ID = U1.ID(+)
   AND P.SUPPORT_USER_ID = U2.ID(+)
/

