create view NL_V_USER_TAG as
SELECT user_id, type, LTRIM(text, '、') as name, LTRIM(ids, '、') as ids
  FROM (SELECT ROW_NUMBER() OVER(PARTITION BY user_id,type ORDER BY user_id,type, lvl DESC) rn,
               user_id,
               type,
               text,
               ids
          FROM (SELECT user_id,
                       type,
                       LEVEL lvl,
                       SYS_CONNECT_BY_PATH(name, '、') text,
                       SYS_CONNECT_BY_PATH(id, '、') ids
                  FROM (SELECT u.user_id,
                               u.type,
                               t.name,
                               t.id,
                               ROW_NUMBER() OVER(PARTITION BY u.user_id,u.type ORDER BY u.user_id,u.type, t.id) x
                          FROM nl_u_alarm_tag_user u,nl_m_alarm_tag t where u.tag_id = t.id
                         ORDER BY u.user_id,u.type, t.id) a
                CONNECT BY user_id = PRIOR user_id AND type = PRIOR type
                       AND x - 1 = PRIOR x))
WHERE rn = 1 ORDER BY user_id,type
/

