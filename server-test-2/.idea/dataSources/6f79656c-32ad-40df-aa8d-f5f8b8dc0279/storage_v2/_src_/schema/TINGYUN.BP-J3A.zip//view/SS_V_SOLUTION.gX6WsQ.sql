create view SS_V_SOLUTION as
select s.id,s.title,s.content,s.mtime,s.muser,s.case_id,s.cuser,s.ctime,u.name
from ss_solution s,nb_m_user u
where s.muser = u.id(+)


/

