create view XSY_V_CUSTOMER_REAL_STATUS as
(

SELECT cu.id,cu.customer_name,
       CASE WHEN cu.status = -1 THEN -1 --待修改
            WHEN cu.status = 1 THEN 1 --未跟
            WHEN cu.status = 2 THEN 2 --交流
            WHEN cu.status = 3 AND cu.customer_type = 1 AND cu.disable_time IS NULL THEN 3 --开通
            WHEN cu.status = 3 AND cu.customer_type = 1 AND cu.disable_time >=  to_date(to_char(SYSDATE,'yyyy-mm-dd'),'yyyy-mm-dd') THEN 4 --试用
            WHEN cu.status = 3 AND cu.customer_type = 1 AND cu.disable_time < to_date(to_char(SYSDATE,'yyyy-mm-dd'),'yyyy-mm-dd')THEN 6 --过期
            WHEN cu.status = 3 AND cu.customer_type = 2 AND (cu.disable_time IS NULL OR cu.disable_time >= to_date(to_char(SYSDATE,'yyyy-mm-dd'),'yyyy-mm-dd')) THEN 6 --签约
            WHEN cu.status = 3 AND cu.customer_type = 2 AND cu.disable_time < to_date(to_char(SYSDATE,'yyyy-mm-dd'),'yyyy-mm-dd') THEN 7 --曾签
            END AS real_status
FROM xsy_customer cu

)


/

