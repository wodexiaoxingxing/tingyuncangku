create procedure edm authid current_user is
sqlStr varchar2(4000);
sql_query  varchar2(4000);
   file_name varchar2(100);
     -- 压测注意事项
     -- 1 检查task_id是否配置正确，主要看有效期及频率
      -- 2 检查sql数量，分三条，最初一条，循环一条，最后恢复一条;检查每条语句后要跟着commit;
     -- 3 每条sql三个字段，sla_probes,status,mtime,检查sla_probes初始值及循环时是否按指定数量增加,
--   检查最后一条sql的status=0,且sla_probes等于初始值
     -- 4 检查循环次数是否与需求相符，这个要重点检查，容易多或少循环
     -- 5 dbms_lock.sleep()是以秒为单位，5分钟=300

  -- 初始500，每10分钟增加100节点,到17000后不再加执行完两小时
begin
  for i in 1..50 loop
    sql_query:='select * from edmtab_tmp where rownum <85';
     file_name:=concat(i,'edmtab.csv');
 --dump到‘DUMP’文件夹下的file_name文件中
 dump_to_csv(sql_query, 'DMPDIR', file_name);
 sqlStr:='delete edmtab_tmp where rownum <85';
   execute immediate sqlStr;
 commit; 
 end loop;
end edm;
/

