create view SS_V_API as
select nl1.id, nl1.TIMESTAMP,nl1.host_id,nl1.response_time_total,nl1.dns_time_total,nl1.connect_time_total,nl1.first_packet_time_total,nl1.bytes_total,
nl1.count,nl1.dns_count,nl1.connect_count,nl1.first_packet_count,nl1.success_count,nl1.error_count,nl1.http_error_count,nl1.network_error_count,
round((nl1.success_count/nl1.count)*100,2) success,round((nl1.network_error_count/nl1.count)*100,2) network_error,
decode(nl1.success_count,0,0,round(nl1.response_time_total/(1000*nl1.success_count),3)) response_time,
decode(nl1.first_packet_count,0,0,round(nl1.first_packet_time_total/(1000*nl1.first_packet_count),3)) first_packet_time,
nl2.category,
nl3.category_id,nl3.host,nl3.host_alias,nl3.api_img,nl3.api_url, 0 as apiindex ,'' as apidate
from NL_BIZ_MOB_APP_3RD_STAT_DAY nl1,
NL_API_CATEGORY nl2,
NL_API_INDEX nl3
where nl1.host_id = nl3.host_id(+)
and nl3.category_id = nl2.id(+)


/

