create view SS_V_APPLY as
select a.id,
       u.id as userid,
       u.code,
       u.mobile,
       u.email,
       u.agree_id,
       u.server_apply,
       a.name,
       a.apply_ser_os_ver,
       a.apply_ser_lang,
       a.apply_ser_db,
       a.apply_ser_nosqldb,
       a.apply_ser_address,
       a.apply_ser_qq,
       a.ctime,
       a.mtime
  from SS_APPLY a
  left join nb_m_user u
    on a.user_id = u.id where u.type = 70 and u.server_apply in(1,2)


/

