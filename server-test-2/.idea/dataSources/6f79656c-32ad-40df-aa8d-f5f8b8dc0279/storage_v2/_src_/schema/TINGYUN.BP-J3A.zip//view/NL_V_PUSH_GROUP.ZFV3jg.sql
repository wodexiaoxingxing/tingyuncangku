create view NL_V_PUSH_GROUP as
SELECT recipient_group_id, LTRIM(text, '、') as name, LTRIM(ids, '、') as ids
  FROM (SELECT ROW_NUMBER() OVER(PARTITION BY recipient_group_id ORDER BY recipient_group_id, lvl DESC) rn,
               recipient_group_id,
               text,
               ids
          FROM (SELECT recipient_group_id,
                       LEVEL lvl,
                       SYS_CONNECT_BY_PATH(name, '、') text,
                       SYS_CONNECT_BY_PATH(settings_id, '、') ids
                  FROM (SELECT p.recipient_group_id,
                               p.settings_id,
                               s.name,
                               ROW_NUMBER() OVER(PARTITION BY p.recipient_group_id ORDER BY p.recipient_group_id, s.id) x
                          FROM nl_u_alarm_push_settings_group p,NL_U_ALARM_PUSH_SETTINGS s where p.settings_id = s.id
                         ORDER BY p.recipient_group_id, s.id) a
                CONNECT BY recipient_group_id = PRIOR recipient_group_id
                       AND x - 1 = PRIOR x))
WHERE rn = 1 ORDER BY recipient_group_id
/

