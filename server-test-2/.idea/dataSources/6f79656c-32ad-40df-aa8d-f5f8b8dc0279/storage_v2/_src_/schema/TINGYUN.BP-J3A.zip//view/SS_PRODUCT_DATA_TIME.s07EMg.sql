create view SS_PRODUCT_DATA_TIME as
(
SELECT app.agreement_id AS agree_id, 1 AS TYPE,ma.timestamp
FROM
NL_U_MOB_APP_USAGE_STAT_DAY  ma,
nl_u_mobile_app app
WHERE app.id = ma.mobile_app_id
AND ma.active_devices > 0
UNION ALL
SELECT ser.agree_id, 2 AS TYPE,ser.timestamp
FROM NL_U_SAPP_USAGE_STAT_DAY  ser
WHERE ser.server_count > 0
UNION ALL
SELECT app.agreement_id AS agree_id, 3 AS TYPE,net.timestamp
FROM
NL_U_NET_USAGE_STAT_DAY   net,
NL_U_TASK app
WHERE app.id = net.task_id
AND net.hit_count > 0
UNION ALL
SELECT SYS.agree_id, 4 AS TYPE,SYS.timestamp
FROM NL_U_SYS_USAGE_STAT_DAY  SYS
WHERE SYS.SERVER_COUNT > 0
UNION ALL
SELECT app.agreement_id AS agree_id, 5 AS TYPE,bro.timestamp
FROM
NL_U_BW_USAGE_STAT_DAY   bro,
NL_U_BROWSER_APPLICATION app
WHERE app.id = bro.browser_application_id
AND bro.hit_count > 0)


/

