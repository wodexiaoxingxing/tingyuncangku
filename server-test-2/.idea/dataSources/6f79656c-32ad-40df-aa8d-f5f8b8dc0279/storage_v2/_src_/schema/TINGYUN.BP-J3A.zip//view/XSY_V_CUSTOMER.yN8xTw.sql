create view XSY_V_CUSTOMER as
SELECT
c.id,c.customer_name,c.trade_main,c.trade_primary,c.trade_secondary,
nvl(c.source,0) AS SOURCE,c.region,u.name AS sales_name,c.remark,c.status_mtime,c.customer_type,c.customer_grade,
c.status,c.mtime,c.muser,c.disable_time,NVL2(wf.ctime,1,2) AS top_flag,NVL(wf.ctime,to_date('1970-01-01','yyyy-mm-dd')) AS ordertime,c.ctime,c.sales_id,
NVL(c.money,0) AS money,NVL(c.expected_money,0) AS expected_money
FROM XSY_CUSTOMER c
LEFT JOIN XSY_WORK_FOCUS wf ON c.id = wf.table_id AND wf.type=1
LEFT JOIN xsy_user u ON u.id = c.sales_id
/

