create view SS_PRODUCT_USAGE_DETAILS as
(

SELECT u.id,u.code,cus.customer_name,cus.trade_primary,cus.trade_secondary,ser.service_type,decode(ser.type,2,-1,ser.type)AS TYPE, cus.sales_id,
sac.support_user_id,ser.enable_time,ser.disable_time,
limi,
decode(ser.service_type,40,-1,NVL2(coalesce(n1.agreement_id,n2.agreement_id,n3.agreement_id),1,0)) AS notify,
decode(ser.service_type,22,-1,40,-1,NVL2(COALESCE(k1.account_id,k2.account_id),1,0)) AS key_factor,
nvl(us.usage_stat,0) AS usage_stat,
round(DECODE(limi,0,0,nvl(us.usage_stat,0) / limi),2) * 100 AS usage_rate,
ser.ctime
FROM xsy_account_relation acc
LEFT JOIN xsy_customer cus ON acc.customer_id = cus.id --获取公司名称和销售id
LEFT JOIN nb_m_user u ON acc.account_id=u.id --获取帐号 id 和帐号
INNER JOIN
      (SELECT ser1.id,ser1.user_id,ser1.service_type,ser1.type,ser1.agree_id,
      ser1.enable_time,ser1.disable_time ,
      GREATEST(ser1.active_devices_limit,ser1.server_number_limit,ser1.browser_number_limit,ser1.network_point_limit) AS limi,
      ser1.ctime AS ctime
      FROM ss_user_service_type ser1
      WHERE ser1.service_type IN (4,7,22,40) AND ser1.type <> 1) ser --开通的服务
ON u.id = ser.user_id
LEFT JOIN ss_account sac ON u.id = sac.id --获取技术支持

LEFT JOIN (SELECT as1.agreement_id FROM NL_U_ALARM_SETTINGS as1 WHERE as1.target_type IN (1,2,3,4) GROUP BY as1.agreement_id)  n1
ON n1.agreement_id=ser.agree_id AND ser.service_type =4  --App警报
LEFT JOIN (SELECT as1.agreement_id FROM NL_U_ALARM_SETTINGS as1 WHERE as1.target_type IN (21,22) GROUP BY as1.agreement_id)  n2
ON n2.agreement_id=ser.agree_id AND ser.service_type =7  --Server警报
LEFT JOIN (SELECT as1.agreement_id FROM NL_U_ALARM_SETTINGS as1 WHERE as1.target_type IN (11,12) GROUP BY as1.agreement_id)  n3
ON n3.agreement_id=ser.agree_id AND ser.service_type =22 --Network警报
LEFT JOIN (
  SELECT mk.owner_id AS account_id FROM NL_U_MOBILE_KEY_URL mk GROUP BY mk.owner_id
)k1 ON acc.account_id=k1.account_id --App关键元素
LEFT JOIN(
  SELECT app.account_id FROM NL_U_KEY_ACTION sk INNER JOIN NL_U_APPLICATION app ON sk.application_id=app.id GROUP BY  app.account_id
)k2 ON acc.account_id=k2.account_id ---Server关键元素
LEFT JOIN SS_USER_SERVICE_USAGE_STAT us ON ser.id = us.id --各产品的实际使用


)


/

