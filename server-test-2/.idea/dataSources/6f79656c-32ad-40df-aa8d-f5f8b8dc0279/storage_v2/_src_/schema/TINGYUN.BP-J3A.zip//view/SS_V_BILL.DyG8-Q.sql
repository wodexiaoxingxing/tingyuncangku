create view SS_V_BILL as
select rownum as id,
       nvl(d.order_id,0) as order_id,
       d.order_no,
       d.user_name,
       d.company,
       nvl(d.payments,0) as payments,
       nvl(d.ctime, a.ctime) as ctime,
       d.paytime,
       nvl(d.status,4) as status ,
       a.merchant_out_order_no,
       a.trade_no,
       nvl(a.total_fee, 0) total_fee,
       a.trans_date,
       case
         when d.status = 1 and d.payments = a.total_fee then
          1
         when d.status <> 1 and a.total_fee is null then
          1
         else
          0
       end result_status
  from (select p.order_id,
               o.order_no,
               p.payments,
               o.ctime,
               p.paytime,
               o.status,
               u.name as user_name,
               u.company
          from ss_payments p
          left join ss_orders o
            on p.order_id = o.id
          left join nb_m_user u on o.user_id = u.id
         where p.provider_type=0 and o.type not in (1,2) and o.status<>-1) d
  full outer join (select * from SS_ALIPAY_FLOW where income>0) a
    on d.order_no = a.merchant_out_order_no
    order by d.order_no desc Nulls last


/

