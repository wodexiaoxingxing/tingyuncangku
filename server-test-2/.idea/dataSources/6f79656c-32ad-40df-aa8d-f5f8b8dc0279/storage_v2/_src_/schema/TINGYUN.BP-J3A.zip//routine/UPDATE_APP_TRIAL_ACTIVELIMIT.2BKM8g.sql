create PROCEDURE UPDATE_APP_TRIAL_ACTIVELIMIT AS 

active number := 200000;
mtime DATE := sysdate;
muser number := 91262;

-- ss_service
Cursor services is select * from ss_service where service_type = 4 AND TYPE = 2 and ACTIVE_DEVICES_LIMIT = 0 AND status = 1 and disable_time > sysdate-1;
-- SS_SERVICE_DETAIL
Cursor s_details(s_id number) is select distinct(ORDER_DETAIL_ID) ORDER_DETAIL_ID from SS_SERVICE_DETAIL where SERVICE_ID = s_id; 
-- 订单id
order_id number;
BEGIN
  -- 修改字典表 app 试用月活数为200000
  update SS_M_SERVICE_TYPE set ACTIVE_DEVICES_LIMIT = active, mtime = mtime, muser = muser where id = 4;
  
  for ser in services Loop
    begin
        -- 修改 ss_service
        update ss_service set ACTIVE_DEVICES_LIMIT = active , mtime = mtime, muser = muser where id = ser.id;
        -- 修改服务详情表       
        update SS_SERVICE_DETAIL set ACTIVE_DEVICES_LIMIT = active where SERVICE_ID = ser.id;
        -- 修改SS_USER_SERVICE_TYPE        
        update SS_USER_SERVICE_TYPE set ACTIVE_DEVICES_LIMIT = active, mtime = mtime, muser = muser where USER_SERVICE_ID = ser.id;
        
        for s_detail in s_details(ser.id) loop
          begin
            -- 修改订单时间
            select order_id into order_id from SS_ORDERS_DETAIL where id = s_detail.ORDER_DETAIL_ID;
            update SS_ORDERS set mtime = mtime, muser = muser where id = order_id;
            -- 修改订单详情表
            update SS_ORDERS_DETAIL set ACTIVE_DEVICES_LIMIT = active, mtime = mtime, muser = muser where id = s_detail.ORDER_DETAIL_ID;
          end;
        end Loop;
    end;
  end Loop;
  
  commit;
END UPDATE_APP_TRIAL_ACTIVELIMIT;
/

