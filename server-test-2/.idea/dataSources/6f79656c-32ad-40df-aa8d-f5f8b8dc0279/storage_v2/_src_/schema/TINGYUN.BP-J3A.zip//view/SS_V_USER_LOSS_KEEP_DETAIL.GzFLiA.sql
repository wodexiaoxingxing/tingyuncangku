create view SS_V_USER_LOSS_KEEP_DETAIL as
SELECT  u.agree_id AS agreeid ,u.code,u.email,u.mobile,u.user_from AS userfrom,u.type AS usertype,mst.type AS producttype,dt.timestamp
,ua.app_active_time,ua.mapp_active_time,ua.task_active_time,ua.sys_active_time,ua.browser_active_time,ua.user_active_time
,ua.is_saas_core AS saascore
FROM NB_M_USER U
INNER JOIN NL_U_USER_ACTIVE UA ON u.agree_id = ua.agree_id
INNER JOIN SS_USER_SERVICE_TYPE UST ON  u.agree_id = ust.agree_id
INNER JOIN SS_M_SERVICE_TYPE MST ON ust.service_type = mst.id
LEFT JOIN SS_PRODUCT_DATA_TIME DT  ON  u.agree_id= dt.agree_id AND mst.type = dt.type


/

