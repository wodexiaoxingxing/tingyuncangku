create type          SYS_PLSQL_68889_30_1 as table of "CTXSYS"."SYS_PLSQL_68889_12_1";
/

