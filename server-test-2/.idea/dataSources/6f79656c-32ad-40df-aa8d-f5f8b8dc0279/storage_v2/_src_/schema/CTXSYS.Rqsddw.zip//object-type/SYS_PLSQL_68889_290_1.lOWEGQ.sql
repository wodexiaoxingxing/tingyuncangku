create type          SYS_PLSQL_68889_290_1 as object (ID NUMBER,
VALUE VARCHAR2(128 BYTE));
/

