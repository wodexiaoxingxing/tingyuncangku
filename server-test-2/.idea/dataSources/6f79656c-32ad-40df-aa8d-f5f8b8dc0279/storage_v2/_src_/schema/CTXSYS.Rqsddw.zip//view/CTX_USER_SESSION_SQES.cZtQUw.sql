create view CTX_USER_SESSION_SQES as
select u.name sqe_owner,
       s.sqe_name sqe_name,
       s.sqe_query sqe_query
  from sys.user$ u, table(drvxmd.ctx_sqe_tbl_func) s
  where u.user# = s.sqe_owner# and
        u.user# = userenv('SCHEMAID')
/

