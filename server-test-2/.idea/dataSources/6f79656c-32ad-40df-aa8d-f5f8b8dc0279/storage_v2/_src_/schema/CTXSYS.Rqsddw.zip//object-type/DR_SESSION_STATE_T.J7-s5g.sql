create type dr$session_state_t as object(
  logfile   varchar2(2000),
  logfile_overwrite number,
  dumpederrors dr$numtable,
  events    number,
  traces    number
);
/

