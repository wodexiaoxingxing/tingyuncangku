create type dr$substring2 as object
(
  part_1 varchar2(64),
  part_2 varchar2(64)
);
/

