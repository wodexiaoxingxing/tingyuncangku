create view CTX_INDEX_SETS as
select
   u.name      ixs_owner,
   ixs_name
from dr$index_set, sys.user$ u
where ixs_owner# = u.user#
/

