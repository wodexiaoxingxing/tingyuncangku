create package drispl as

/*-------------------- create_stoplist --------------------------*/

PROCEDURE create_stoplist(
  stoplist_name  in   varchar2,
  stoplist_type  in   varchar2 default 'BASIC_STOPLIST'
);

/*-------------------- drop_stoplist --------------------------*/

PROCEDURE drop_stoplist(
  stoplist_name  in   varchar2
);

/*-------------------- drop_user_stoplists ---------------------*/

PROCEDURE drop_user_stoplists(
  user_name in varchar2 := null
);

/*-------------------- add_stopobj --------------------------*/

PROCEDURE add_stopobj(
  stoplist_name  in   varchar2,
  obj_type       in   varchar2,
  stopword       in   varchar2,
  stoppattern    in   varchar2 default NULL,
  language       in   varchar2 default NULL,
  language_dependent in boolean default TRUE
);

/*-------------------- remove_stopobj --------------------------*/

PROCEDURE remove_stopobj(
  stoplist_name  in   varchar2,
  obj_type       in   varchar2,
  stopword       in   varchar2,
  language       in   varchar2 default NULL
);

/*------------------------ copy_stoplist -----------------------------------*/

function copy_stoplist(
  p_idx_id     in  number,
  p_stoplist   in  varchar2,
  p_rcount     out number
)
return dr_def.pref_rec;

/*----------------------- IndexAddStopword  -------------------------*/
/* add a stopword to an already-existing index */

PROCEDURE IndexAddStopword(
  ia          in  sys.ODCIIndexInfo,
  idx         in  dr_def.idx_rec,
  stopword    in  varchar2,
  language    in  varchar2,
  language_dependent in boolean default TRUE,
  add_ML_tokens     out boolean
);

/*----------------------- IndexRemStopword  -------------------------*/
/* remove a stopword from an already-existing index */

PROCEDURE IndexRemStopword(
  ia          in  sys.ODCIIndexInfo,
  idx         in  dr_def.idx_rec,
  stopword    in  varchar2,
  language    in  varchar2,
  for_all     in boolean default FALSE,
  rem_ML_tokens out boolean
);

/*----------------------- GetIndexStopwords  -------------------------*/
/* get stopwords from already-existing index */

PROCEDURE GetIndexStopwords(
  p_idx_id    in  number,
  p_obj_id    in  binary_integer,
  o_spw       in out nocopy dr_def.spw_tab
);

/*---------------------- MigrateToMultiStoplist ---------------------*/
/* Migrate from basic stoplist to multi stoplist */

PROCEDURE MigrateToMultiStoplist(
  ia      in sys.ODCIIndexInfo,
  idx     in dr_def.idx_rec,
  langcol in varchar2
);

PROCEDURE GetSPLLang(
  idx         in  dr_def.idx_rec,
  language    in  varchar2,
  language_dependent in boolean,
  out_lang    in out varchar2
);

end drispl;
/

