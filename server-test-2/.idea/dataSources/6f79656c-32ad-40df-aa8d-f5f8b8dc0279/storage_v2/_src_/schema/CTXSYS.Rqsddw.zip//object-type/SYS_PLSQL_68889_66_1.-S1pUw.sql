create type          SYS_PLSQL_68889_66_1 as table of "CTXSYS"."SYS_PLSQL_68889_38_1";
/

