create type dr$createindex_state_t as object(
  session_state   dr$session_state_t,
  index_memory    number,
  populate        varchar2(1),
  import          varchar2(1),
  params          varchar2(1000)
);
/

