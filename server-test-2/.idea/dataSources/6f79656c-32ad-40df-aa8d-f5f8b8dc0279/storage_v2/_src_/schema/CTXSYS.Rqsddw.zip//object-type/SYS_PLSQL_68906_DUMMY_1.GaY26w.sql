create type          SYS_PLSQL_68906_DUMMY_1 as table of number;
/

