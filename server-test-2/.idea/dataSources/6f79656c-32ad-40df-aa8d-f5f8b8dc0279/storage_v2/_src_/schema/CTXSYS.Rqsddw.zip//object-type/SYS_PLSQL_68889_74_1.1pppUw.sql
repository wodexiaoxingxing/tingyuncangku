create type          SYS_PLSQL_68889_74_1 as object (DOCID NUMBER,
CATID NUMBER,
SCR NUMBER);
/

