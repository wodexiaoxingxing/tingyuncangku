create type          SYS_PLSQL_68889_DUMMY_1 as table of number;
/

