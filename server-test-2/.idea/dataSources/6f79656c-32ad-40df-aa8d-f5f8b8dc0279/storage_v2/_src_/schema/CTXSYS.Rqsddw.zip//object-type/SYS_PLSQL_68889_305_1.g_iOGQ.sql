create type          SYS_PLSQL_68889_305_1 as table of "CTXSYS"."SYS_PLSQL_68889_290_1";
/

