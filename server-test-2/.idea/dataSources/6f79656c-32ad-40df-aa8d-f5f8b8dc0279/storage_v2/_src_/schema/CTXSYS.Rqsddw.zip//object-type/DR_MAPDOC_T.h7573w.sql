create type dr$mapdoc_t as object(
  map_docid number,
  map_data  varchar2(4000)
);
/

