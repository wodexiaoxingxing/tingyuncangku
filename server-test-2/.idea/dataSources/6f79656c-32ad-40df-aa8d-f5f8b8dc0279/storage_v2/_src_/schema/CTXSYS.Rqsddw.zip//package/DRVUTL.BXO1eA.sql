create package drvutl authid current_user as

/*--------------------------- CurrentUserid ------------------------------*/
/* this basically does a select userenv('SCHEMAID') from dual and returns */
/* the result.  This is needed because SQL and PL/SQL don't always agree  */
/* on what userenv('SCHEMAID') should be */
function CurrentUserid return binary_integer;

/*------------------------------ SetInvoker ------------------------------*/
/* set invoking user -- used by invoker's rights packages calling */
/* definer's rights packages which need to know the invoker       */

/* note: pass 0 to use current user -- this has to be done by select */
/* from dual, NOT calling userenv directly                           */

procedure SetInvoker(p_userid in binary_integer default 0);

/*------------------------------ ClearInvoker ----------------------------*/
/* clear invoking user -- if you call SetInvoker, make sure to call this */

procedure ClearInvoker;

/*------------------------------ GetInvoker ------------------------------*/
/* get the last invoking username */

function GetInvoker return varchar2;

/*------------------------------ GetInvokerId ----------------------------*/
/* get the last invoking userid */

function GetInvokerId return number;

/*-------------------------- get_ora_event_level ----------------------------*/
/* Set an Oracle Event's level */

function set_ora_event_level (
  event   in number,
  level   in number
) return number;

/*-------------------------- get_ora_event_level ----------------------------*/
/* Get an Oracle Event's Level */

function get_ora_event_level (
  event   in number
) return number;

/*------------------------------ write_to_log -------------------------------*/
/* Write a message to the ctx log file.
 * msg     - the message to dump
 * newline - should the message be terminated with a new line ?
 *
 * The reason this function is here instead of in dr0out (where the
 * rest of the log-file functionality changes are, is because we don't
 * want to expose this yet to end users
 */
procedure write_to_log(msg in varchar2,
                       newline in binary_integer default 1);

/*--------------------------- check_base_table ------------------------*/
/* Returns the no. of base table rows which have lang OR abbr OR alt
 *  as their language column value.
 */
function check_base_table(idx in dr_def.idx_rec,
                          language in varchar2,
                          abbr in varchar2 default NULL,
                          alt  in varchar2 default NULL)
return number;


/*--------------------------- validate_ixs_columns -------------------------*/
/* validate ixs columns returned by driixs.GetIndexIXSColumns */
procedure validate_ixs_columns
(
  l_idx   in dr_def.idx_rec,
  collist in dr_def.ixc_tab
);

/*--------------------------- validate_ixs_collist -------------------------*/
/* validate ixs_collist returned by driixs.GetIndexIndexSet */
procedure validate_ixs_collist
(
  l_idx   in dr_def.idx_rec,
  collist in varchar2,
  out_collist out varchar2
);

end drvutl;
/

