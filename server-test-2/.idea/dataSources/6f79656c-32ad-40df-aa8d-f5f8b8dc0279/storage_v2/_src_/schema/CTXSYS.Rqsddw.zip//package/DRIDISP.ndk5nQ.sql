create package dridisp is

  /*
   * NAME
   *   EXECTRUST - synchronous trust callout command
   *
   * RETURN
   *
   */
  procedure EXECTRUST(
                     idx_owner  in     varchar2,
                     idx_name   in     varchar2,
                     part_name  in     varchar2,
                     func_code  in     number,
  		     arg1       in     varchar2 default NULL,
  		     arg2       in     varchar2 default NULL,
  		     arg3       in     varchar2 default NULL,
  		     arg4       in     varchar2 default NULL,
  		     arg5       in     varchar2 default NULL,
  		     arg6       in     varchar2 default NULL,
  		     arg7       in     varchar2 default NULL,
  		     arg8       in     varchar2 default NULL,
  		     arg9       in     varchar2 default NULL,
  		     arg10      in     varchar2 default NULL
                    );

  /*
   * NAME
   *   EXECTRUST_RET - synchronous trust callout command with return
   *
   * RETURN
   *
   */
  procedure EXECTRUST_RET(
                     idx_owner  in     varchar2,
                     idx_name   in     varchar2,
                     part_name  in     varchar2,
                     func_code  in     number,
                     ret1       out    varchar2,
                     ret2       out    varchar2,
  		     arg1       in     varchar2 default NULL,
  		     arg2       in     varchar2 default NULL,
  		     arg3       in     varchar2 default NULL,
  		     arg4       in     varchar2 default NULL,
  		     arg5       in     varchar2 default NULL,
  		     arg6       in     varchar2 default NULL,
  		     arg7       in     varchar2 default NULL,
  		     arg8       in     varchar2 default NULL,
  		     arg9       in     varchar2 default NULL,
  		     arg10      in     varchar2 default NULL
                    );

  /*
   * NAME
   *   EXECTRUST_RET1 - synchronous trust callout command with 1 return
   *
   * RETURN
   *
   */
  function EXECTRUST_RET1(
                     idx_owner  in     varchar2,
                     idx_name   in     varchar2,
                     part_name  in     varchar2,
                     func_code  in     number,
  		     arg1       in     varchar2 default NULL,
  		     arg2       in     varchar2 default NULL,
  		     arg3       in     varchar2 default NULL,
  		     arg4       in     varchar2 default NULL,
  		     arg5       in     varchar2 default NULL,
  		     arg6       in     varchar2 default NULL,
  		     arg7       in     varchar2 default NULL,
  		     arg8       in     varchar2 default NULL,
  		     arg9       in     varchar2 default NULL,
  		     arg10      in     varchar2 default NULL
                    )
   return varchar2;

end dridisp;
/

