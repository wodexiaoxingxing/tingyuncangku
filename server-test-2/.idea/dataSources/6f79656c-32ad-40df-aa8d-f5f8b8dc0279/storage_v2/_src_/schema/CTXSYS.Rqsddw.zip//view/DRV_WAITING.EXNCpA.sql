create view DRV$WAITING as
select "WTG_CID","WTG_ROWID","WTG_PID" from dr$waiting
 where wtg_cid = SYS_CONTEXT('DR$APPCTX','IDXID')
with check option
/

