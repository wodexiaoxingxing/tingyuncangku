create TYPE          "yCbCrCoefficientsType218_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","tag" NUMBER(38),"Coefficient_1" NUMBER,"Coefficient_2" NUMBER,"Coefficient_3" NUMBER)NOT FINAL INSTANTIABLE
/

