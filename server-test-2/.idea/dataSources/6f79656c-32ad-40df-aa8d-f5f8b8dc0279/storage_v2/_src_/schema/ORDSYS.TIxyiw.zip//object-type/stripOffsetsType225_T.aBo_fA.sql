create TYPE          "stripOffsetsType225_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","tag" NUMBER(38),"StripOffset" "StripOffset227_COLL")NOT FINAL INSTANTIABLE
/

