create TYPE          "UID_DEF553_T" UNDER "UID_ENTRY_T551_T"("classification" "XDB"."XDB$ENUM_T","isLE" RAW(1),"isEVR" RAW(1),"isCompressed" RAW(1),"retired" RAW(1),"contentType" "XDB"."XDB$ENUM_T")FINAL INSTANTIABLE
/

