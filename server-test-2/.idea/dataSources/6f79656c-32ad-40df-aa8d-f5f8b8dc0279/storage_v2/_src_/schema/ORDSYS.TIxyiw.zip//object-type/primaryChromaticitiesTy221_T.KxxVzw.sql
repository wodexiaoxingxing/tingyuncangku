create TYPE          "primaryChromaticitiesTy221_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","tag" NUMBER(38),"Color_1" "chromaticity219_T","Color_2" "chromaticity219_T","Color_3" "chromaticity219_T")NOT FINAL INSTANTIABLE
/

