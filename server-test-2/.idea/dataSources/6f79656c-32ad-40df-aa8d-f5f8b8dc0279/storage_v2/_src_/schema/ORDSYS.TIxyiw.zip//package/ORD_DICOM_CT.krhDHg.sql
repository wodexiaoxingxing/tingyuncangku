create PACKAGE        ORD_DICOM_CT wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
206 f7
LoWvE3+E1n8TT3RwsSrTXJk4dW8wg9f3LcsVfHSiWPiUHDXlBFTaiAVj83nTrcsnsPm1DyHz
4A7g5nRuNM71IgD68ylKeDcONMKMfDuRUKZwYa9/S9L/bd915ZPockFHRCj/Sczv2v/rhRHn
lTegGscxefQlPNKHdk2JK41LcutcoHMvtj0OGwP7Rn6lZ2P7gcAjK+VUPLFCsYpTVGB/OiTi
dpnXH3Eeu6/bTgWdmGo5r87AkQ==
/

