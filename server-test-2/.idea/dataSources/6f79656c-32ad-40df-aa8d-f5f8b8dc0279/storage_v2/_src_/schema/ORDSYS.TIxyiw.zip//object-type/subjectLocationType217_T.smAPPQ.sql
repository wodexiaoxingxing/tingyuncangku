create TYPE          "subjectLocationType217_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","tag" NUMBER(38),"CenterX" NUMBER(38),"CenterY" NUMBER(38))NOT FINAL INSTANTIABLE
/

