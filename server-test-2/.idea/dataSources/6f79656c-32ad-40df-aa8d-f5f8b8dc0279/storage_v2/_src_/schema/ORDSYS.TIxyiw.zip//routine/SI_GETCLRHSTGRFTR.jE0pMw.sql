create FUNCTION
  SI_getClrHstgrFtr wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
10c f7
IZ0P2EDug2UR+kJ9lnoc7zmuFuowg1xKf8vWfHTp2see0AEpRHURuNMMr/d2F8nlVHvMuZZZ
QJ7ohbsQwQXqn/JYa1DCP5/+VQYgD3idIK7QjCuvouk3o4/mkstnUOgbcdyTUe52kW4u8Fzv
Lo/l58LRDQ4EkGnMyeCZ8R3FVf0dLb3KKP684XFe/DXvYabkHtwiIUYmj1VMvDCQF2z06dYw
jWE3epPrUJBkKakjLnrLJS9gaA==
/

