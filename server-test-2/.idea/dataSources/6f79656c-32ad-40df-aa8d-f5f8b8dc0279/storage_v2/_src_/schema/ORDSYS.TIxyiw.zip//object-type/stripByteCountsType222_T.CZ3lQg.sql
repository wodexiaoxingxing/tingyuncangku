create TYPE          "stripByteCountsType222_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","tag" NUMBER(38),"StripByteCount" "StripByteCount224_COLL")NOT FINAL INSTANTIABLE
/

