create TYPE SI_AverageColor
                                                                          
  AUTHID CURRENT_USER
  AS OBJECT
    (
     --attributes
     SI_AverageColorSpec SI_Color,
     --
     --Methods
     CONSTRUCTOR FUNCTION SI_AverageColor
     (sourceImage IN SI_StillImage)
     return SELF AS RESULT DETERMINISTIC,

     --NOTE This constructor function OVERRIDE and HIDES the system DEFAULT
     --constructor.
     --The functions arguments names MUST match the attribute names
     CONSTRUCTOR FUNCTION SI_AverageColor
     (SI_AverageColorSpec IN SI_Color)
     return SELF AS RESULT DETERMINISTIC,
     --
     MEMBER FUNCTION SI_Score
     (SELF IN SI_AverageColor, image in SI_StillImage)
     RETURN DOUBLE PRECISION DETERMINISTIC
) INSTANTIABLE
  NOT FINAL;
/

