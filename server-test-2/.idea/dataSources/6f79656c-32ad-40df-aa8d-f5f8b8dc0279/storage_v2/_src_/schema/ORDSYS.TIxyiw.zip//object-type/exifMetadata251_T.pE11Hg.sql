create TYPE          "exifMetadata251_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","TiffIfd" "TiffIfd252_T","ExifIfd" "ExifIfd253_T","GpsIfd" "GpsIfd254_T","InteroperabilityIfd" "InteroperabilityIfd255_T")FINAL INSTANTIABLE
/

