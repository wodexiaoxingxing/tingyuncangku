create TYPE          "photometricInterpretati232_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","SYS_XDBBODY$" "XDB"."XDB$ENUM_T","tag" NUMBER(38))NOT FINAL INSTANTIABLE
/

