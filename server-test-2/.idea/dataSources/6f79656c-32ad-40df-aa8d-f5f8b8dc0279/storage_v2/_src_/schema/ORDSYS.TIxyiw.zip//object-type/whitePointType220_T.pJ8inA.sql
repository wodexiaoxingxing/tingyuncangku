create TYPE          "whitePointType220_T" UNDER "chromaticity219_T"("tag" NUMBER(38))NOT FINAL INSTANTIABLE
/

