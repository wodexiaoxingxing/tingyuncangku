create TYPE          "ordImageAttributesType496_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","height" NUMBER(38),"width" NUMBER(38),"contentLength" NUMBER(38),"fileFormat" VARCHAR2(4000 CHAR),"contentFormat" VARCHAR2(4000 CHAR),"compressionFormat" VARCHAR2(4000 CHAR),"mimeType" VARCHAR2(4000 CHAR))NOT FINAL INSTANTIABLE
/

