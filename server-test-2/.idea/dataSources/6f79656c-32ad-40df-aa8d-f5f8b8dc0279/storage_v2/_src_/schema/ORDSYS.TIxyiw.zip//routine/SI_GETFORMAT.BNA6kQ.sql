create FUNCTION
  SI_getFormat wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
e6 ef
vveTtZ23zDK78hU+xCsaJq+gwNUwg1xKLZ4VZ3RAkPiOiM0Gj4MpNNkNN5iOwK2xBsrcCci8
JOgHnsm9zw/xJC3C6uyInmLQ+G+xsU5hpD6Y8zerYvI+KlC/pqyjAu78267c/2BxPfThzsWs
2AxiFmAdxfIbG7r+Z0Qz/NFX0xNEGKWyPt0qYxz1FeiPH8JOa6hZRLVMuiIxElKniqDwqFva
evUSeIJRP13usqsxrRA=
/

