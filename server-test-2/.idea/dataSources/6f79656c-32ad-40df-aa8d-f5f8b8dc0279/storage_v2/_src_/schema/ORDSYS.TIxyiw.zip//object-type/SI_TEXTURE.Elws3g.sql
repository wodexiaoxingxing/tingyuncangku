create TYPE SI_Texture
                                                                          
  AUTHID CURRENT_USER
  AS OBJECT
  (
     --attributes
     SI_TextureEncoding  textureEncoding,

     --Methods
     CONSTRUCTOR FUNCTION SI_Texture
     (sourceImage IN SI_StillImage)
     return SELF AS RESULT DETERMINISTIC,
     --
     MEMBER FUNCTION SI_Score
     (SELF  IN SI_Texture,
      image IN SI_StillImage)
     RETURN DOUBLE PRECISION DETERMINISTIC
) INSTANTIABLE
  NOT FINAL;
/

