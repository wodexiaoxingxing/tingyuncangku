create TYPE          "singleFieldType190_T" UNDER "singleField_t189_T"("tag" NUMBER(38))NOT FINAL INSTANTIABLE
/

