create type        LOGMNR$KEY_GG_REC wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
1c0 10f
jTpMgyLdopxFfjftKC6tkDxgnL4wgzKu7cusfC+fuV5xUR0Uy6kRWW7yrZmeYq1nkfz4nQKU
Zi9WVby1h+vq5wKnY1FqthLvY6iO3fZQ+h3panrf5ejXXml5WMqkWDK5qqb5mup4/qzZg3mr
9ZUMRh9J91IYNHxFkrdtQ8WVxLOQ5uyfpxrv2UbRcY3fPFTe4inCcZHZDF/ojt73mc/GqnnG
i6HY4lc4514eqYyUIju4dE7JdjafMl1y/eQB14K1YfimaMMXyQ==
/

