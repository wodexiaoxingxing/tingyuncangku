create type        LOGMNR$SEQ_GG_REC wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
13e ef
J88CgRBqXl/LFy4+YxS8COL8AaYwgzJKNcusfC/pTP6Ot33h0x9ps3VT7KctcBGv3rNL/HMg
qMwd94+b7bVvJHSkNeurHjDBKRzw9FmrUIQKSBod46LPi7SxbFMZxQbtBMbNNstirx2T6oVl
+kOtpNaw70G3eOIysTnwT2W61KnFSoAh/Bgrz80ht2wfd3w7vITodj+T0c5Lj+GL1emnASmx
LLXO6yVt0sJC++g93OQ=
/

