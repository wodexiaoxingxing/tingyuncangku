create view WM$REPLICATION_INFO as
select groupName, masterdefsite writerSite
         from wmsys.wm$replication_table
WITH READ ONLY
/

