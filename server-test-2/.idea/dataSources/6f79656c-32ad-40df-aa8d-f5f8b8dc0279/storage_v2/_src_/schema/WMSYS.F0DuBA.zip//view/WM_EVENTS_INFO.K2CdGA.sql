create view WM_EVENTS_INFO as
select "EVENT_NAME","CAPTURE" from wmsys.wm$events_info
WITH READ ONLY
/

