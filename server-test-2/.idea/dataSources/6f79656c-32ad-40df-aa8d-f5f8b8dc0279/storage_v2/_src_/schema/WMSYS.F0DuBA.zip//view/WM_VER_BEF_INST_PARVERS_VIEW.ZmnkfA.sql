create view WM$VER_BEF_INST_PARVERS_VIEW as
(select parent_vers
      from wmsys.wm$version_view
      where version = sys_context('lt_ctx','ver_before_instant'))
    WITH READ ONLY
/

