create type       WM$NV_PAIR_TYPE                                                                       
         as object (name varchar2(100), value clob)
/

