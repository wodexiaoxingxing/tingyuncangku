create view WM$TABLE_WS_PARVERS_VIEW as
(select table_name,version
   from wmsys.wm$modified_tables
   where workspace = nvl(sys_context('lt_ctx','state'),'LIVE'))
   union all
      (select vht.table_name,vht.version
       from wmsys.wm$modified_tables vht, wmsys.wm$version_table vt
       where vt.workspace  = nvl(sys_context('lt_ctx','state'),'LIVE') and
                    vht.workspace = vt.anc_workspace and
                    vht.version  <= vt.anc_version)
WITH READ ONLY
/

