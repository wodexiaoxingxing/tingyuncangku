create view USER_WORKSPACE_PRIVS as
select spt.grantee,
       spt.workspace,
       decode(spt.priv,'A','ACCESS_WORKSPACE',
                   'C','MERGE_WORKSPACE',
                   'R','ROLLBACK_WORKSPACE',
                   'D','REMOVE_WORKSPACE',
                   'M','CREATE_WORKSPACE',
                   'F','FREEZE_WORKSPACE',
                   'AA','ACCESS_ANY_WORKSPACE',
                   'CA','MERGE_ANY_WORKSPACE',
                   'RA','ROLLBACK_ANY_WORKSPACE',
                   'DA','REMOVE_ANY_WORKSPACE',
                   'MA','CREATE_ANY_WORKSPACE',
                   'FA','FREEZE_ANY_WORKSPACE',
                        'UNKNOWN_PRIV') privilege,
       spt.grantor,
       decode(spt.admin, 0, 'NO',
                         1, 'YES') grantable
from  user_workspaces ult, wmsys.wm$workspace_priv_table spt
where ult.workspace = spt.workspace
/

