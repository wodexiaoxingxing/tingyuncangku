create view WM$CURRENT_VER_VIEW as
(select current_version
         from wmsys.wm$workspaces_table
         where workspace = nvl(SYS_CONTEXT('lt_ctx','state'),'LIVE')
               and ( sys_context('lt_ctx', 'version') is null or
                     sys_context('lt_ctx', 'version') = -1))
        union all
        (select to_number(sys_context('lt_ctx', 'version')) from dual where
          sys_context('lt_ctx', 'version') is not null and
          sys_context('lt_ctx', 'version') != -1) WITH READ ONLY
/

