create view USER_WM_LOCKED_TABLES as
select t.table_owner, t.table_name, t.Lock_mode, t.Lock_owner, t.Locking_state
from wmsys.wm$all_locks_view t
where t.table_owner = (select username from all_users where user_id=userenv('schemaid'))
with READ ONLY
/

