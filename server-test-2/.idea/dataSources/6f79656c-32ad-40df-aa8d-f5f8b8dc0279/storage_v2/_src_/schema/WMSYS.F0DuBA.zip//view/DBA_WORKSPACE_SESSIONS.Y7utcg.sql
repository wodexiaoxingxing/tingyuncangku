create view DBA_WORKSPACE_SESSIONS as
select sut.username,
       sut.workspace,
       sut.sid,
       decode(t.ses_addr, null, 'INACTIVE','ACTIVE') status
from   wmsys.wm$workspace_sessions_view sut,
       v$transaction t
where  sut.saddr = t.ses_addr (+)
WITH READ ONLY
/

