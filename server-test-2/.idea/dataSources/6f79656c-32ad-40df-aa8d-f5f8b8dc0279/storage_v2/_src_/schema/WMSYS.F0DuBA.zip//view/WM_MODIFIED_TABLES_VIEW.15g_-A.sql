create view WM$MODIFIED_TABLES_VIEW as
select table_name, version, workspace from wmsys.wm$modified_tables
WITH READ ONLY
/

