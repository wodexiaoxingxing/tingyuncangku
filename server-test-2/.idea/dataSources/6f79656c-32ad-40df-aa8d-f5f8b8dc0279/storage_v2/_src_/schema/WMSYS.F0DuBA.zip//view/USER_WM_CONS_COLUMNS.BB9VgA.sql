create view USER_WM_CONS_COLUMNS as
select /*+ ORDERED */ t1."OWNER",t1."CONSTRAINT_NAME",t1."TABLE_NAME",t1."COLUMN_NAME",t1."POSITION" from
wmsys.wm$cons_columns t1, user_views t2
where t1.owner = (select username from all_users where user_id=userenv('schemaid'))
and t1.table_name = t2.view_name
/

