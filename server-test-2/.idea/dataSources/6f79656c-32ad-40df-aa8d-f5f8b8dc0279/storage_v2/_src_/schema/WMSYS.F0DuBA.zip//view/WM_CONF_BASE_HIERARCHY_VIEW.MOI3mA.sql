create view WM$CONF_BASE_HIERARCHY_VIEW as
select version from wmsys.wm$version_hierarchy_table
  start with version = sys_context('lt_ctx', 'confbasever')
  connect by prior parent_version  = version
WITH READ ONLY
/

