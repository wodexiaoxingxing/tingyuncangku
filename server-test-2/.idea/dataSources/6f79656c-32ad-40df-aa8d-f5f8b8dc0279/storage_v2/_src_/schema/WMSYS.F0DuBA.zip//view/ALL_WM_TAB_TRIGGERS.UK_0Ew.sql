create view ALL_WM_TAB_TRIGGERS as
(select trig_owner_name,
        trig_name,
        table_owner_name,
        table_name,
        wmsys.ltUtil.getTrigTypes(trig_flag),
        status,
        when_clause,
        description,
        trig_code,
        decode(bitand(event_flag, 1), 0, 'OFF', 'ON'),
        decode(bitand(event_flag, 2), 0, 'OFF', 'ON'),
        decode(bitand(event_flag, 4), 0, 'OFF', 'ON'),
        decode(bitand(event_flag, 8), 0, 'OFF', 'ON'),
        decode(bitand(event_flag, 16), 0, 'OFF', 'ON'),
        decode(bitand(event_flag, 1024), 0, 'OFF', 'ON')
 from   wmsys.wm$udtrig_info
 where  (trig_owner_name   = (select username from all_users where user_id=userenv('schemaid'))    OR
         table_owner_name  = (select username from all_users where user_id=userenv('schemaid'))    OR
         EXISTS (
           SELECT 1
           FROM   user_sys_privs
           WHERE  privilege = 'CREATE ANY TRIGGER'
         )
         OR
         EXISTS
         ( SELECT 1
           FROM   session_roles sr, role_sys_privs rsp
           WHERE  sr.role       = rsp.role     AND
                  rsp.privilege = 'CREATE ANY TRIGGER' ))  AND
         internal_type   = 'USER_DEFINED')
with READ ONLY
/

