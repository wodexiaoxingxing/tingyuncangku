create view WM$TABLE_VERSIONS_IN_LIVE_VIEW as
(select table_name,version
              from wmsys.wm$modified_tables
              where workspace = 'LIVE')
WITH READ ONLY
/

