create package body       owm_9ip_pkg wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
9b c2
1AQzMdlYgDYZpX9RWxhElMlyS8kwg0xf2ssVfC+iJscYPu7nL8x+imzY3SwxmeernOfp8ylT
IlKi6YIgYKvtWouiAIyZM0r+F1YFscPo7r2Xsi9efH6W9PeT+k1xk5UIqBQe/x6jbTDDyWwf
UrYA0bbQj0IdJvFKEgiCN2z5KrTNCIINTjfteROrCpb4zBZ8
/

