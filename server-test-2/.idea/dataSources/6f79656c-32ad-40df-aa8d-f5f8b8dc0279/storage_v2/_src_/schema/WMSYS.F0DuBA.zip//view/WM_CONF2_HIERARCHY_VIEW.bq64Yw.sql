create view WM$CONF2_HIERARCHY_VIEW as
select "VERSION","PARENT_VERSION","WORKSPACE" from wmsys.wm$version_hierarchy_table
  start with version = (select current_version from wmsys.wm$workspaces_table
                        where workspace = sys_context('lt_ctx', 'parent_conflict_state'))
  connect by prior parent_version = version
WITH READ ONLY
/

