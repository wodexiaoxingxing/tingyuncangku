create view WM$CURCONFLICT_PARVERS_VIEW as
select version, vtid
  from wmsys.wm$modified_tables
  where workspace = SYS_CONTEXT('lt_ctx','conflict_state')
WITH READ ONLY
/

