create view ALL_VERSION_HVIEW as
select version, parent_version, workspace
   from wmsys.wm$version_hierarchy_table
WITH READ ONLY
/

