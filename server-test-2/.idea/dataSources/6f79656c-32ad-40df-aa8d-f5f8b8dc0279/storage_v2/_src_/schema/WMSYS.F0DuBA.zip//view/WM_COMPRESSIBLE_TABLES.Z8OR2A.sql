create view WM_COMPRESSIBLE_TABLES as
select vt.owner, vt.table_name, sys_context('lt_ctx','compress_workspace') workspace,
sys_context('lt_ctx','compress_beginsp') BEGIN_SAVEPOINT,
sys_context('lt_ctx','compress_endsp') END_SAVEPOINT
from wmsys.wm$versioned_tables vt
where exists
(select 1 from wmsys.wm$modified_tables mt
 where mt.table_name = vt.owner || '.' || vt.table_name
 and   mt.workspace = sys_context('lt_ctx','compress_workspace')
 and   mt.version > sys_context('lt_ctx','compress_beginver')
 and   mt.version <= sys_context('lt_ctx','compress_endver')
 and   substr(vt.hist,1,17) != 'VIEW_WO_OVERWRITE'
 and   mt.version in
     (
       select v.version
       from wmsys.wm$version_hierarchy_table v,
       (
        select w1.beginver, w2.endver
        from
         (select rownum rn,beginver from
           (select distinct beginver from
              (select to_number(sys_context('lt_ctx','compress_beginver')) beginver from dual
               where not exists
                 (select parent_version from wmsys.wm$workspaces_table
                  where parent_workspace = sys_context('lt_ctx','compress_workspace')
                  and to_number(sys_context('lt_ctx','compress_beginver')) = parent_version
                 )
               union all
               select min(version) beginver from wmsys.wm$version_hierarchy_table,
                 (select distinct parent_version
                  from wmsys.wm$workspaces_table
                  where parent_workspace = sys_context('lt_ctx','compress_workspace')
                  and   parent_version >= sys_context('lt_ctx','compress_beginver')
                  and   parent_version < sys_context('lt_ctx','compress_endver')) pv
               where workspace = sys_context('lt_ctx','compress_workspace')
               and version > pv.parent_version
               group by (pv.parent_version)
             )
            order by beginver
           )
         ) w1,
         (select rownum rn,endver from
            (select distinct endver from
              (select parent_version endver
               from wmsys.wm$workspaces_table
               where parent_workspace = sys_context('lt_ctx','compress_workspace')
               and   parent_version > sys_context('lt_ctx','compress_beginver')
               and   parent_version <= sys_context('lt_ctx','compress_endver')
               union all
               select to_number(sys_context('lt_ctx','compress_endver')) endver  from dual
              )
             order by endver
            )
         ) w2
         where w1.rn = w2.rn
         and w2.endver > w1.beginver
       ) p
       where v.workspace = sys_context('lt_ctx','compress_workspace')
       and v.version > p.beginver
       and v.version <= p.endver
     )
 union all
 select 1 from wmsys.wm$modified_tables mt
 where mt.table_name = vt.owner || '.' || vt.table_name
 and   mt.workspace = sys_context('lt_ctx','compress_workspace')
 and   mt.version >= sys_context('lt_ctx','compress_beginver')
 and   mt.version <= sys_context('lt_ctx','compress_endver')
 and   substr(vt.hist,1,17) = 'VIEW_WO_OVERWRITE'
)
/

