create view ROLE_WM_PRIVS as
select grantee role,
       workspace,
       decode(priv,'A','ACCESS_WORKSPACE',
                   'C','MERGE_WORKSPACE',
                   'R','ROLLBACK_WORKSPACE',
                   'D','REMOVE_WORKSPACE',
                   'M','CREATE_WORKSPACE',
                   'F','FREEZE_WORKSPACE',
                   'AA','ACCESS_ANY_WORKSPACE',
                   'CA','MERGE_ANY_WORKSPACE',
                   'RA','ROLLBACK_ANY_WORKSPACE',
                   'DA','REMOVE_ANY_WORKSPACE',
                   'MA','CREATE_ANY_WORKSPACE',
                   'FA','FREEZE_ANY_WORKSPACE',
                        'UNKNOWN_PRIV') privilege,
       decode(admin, 0, 'NO',
                     1, 'YES') grantable
from wmsys.wm$workspace_priv_table where grantee in
   (select role from session_roles
    union all
    select 'WM_ADMIN_ROLE' from dual where (select username from all_users where user_id=userenv('schemaid')) = 'SYS')
WITH READ ONLY
/

