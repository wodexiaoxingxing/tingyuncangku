create view WM$MW_VERSIONS_VIEW as
select distinct version, modified_by from
(
select vht.version, vht.workspace modified_by from
wmsys.wm$mw_table mw, wmsys.wm$version_table vt, wmsys.wm$version_hierarchy_table vht
where mw.workspace = vt.workspace
and vt.anc_workspace = vht.workspace
and vht.version <= vt.anc_version
union all
select vht.version, vht.workspace modified_by from
wmsys.wm$mw_table mw, wmsys.wm$version_hierarchy_table vht
where mw.workspace = vht.workspace
)
/

