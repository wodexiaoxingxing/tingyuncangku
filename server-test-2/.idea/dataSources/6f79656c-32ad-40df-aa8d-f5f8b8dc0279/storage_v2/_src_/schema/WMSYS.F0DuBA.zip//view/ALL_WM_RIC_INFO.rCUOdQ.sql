create view ALL_WM_RIC_INFO
            (CT_OWNER, CT_NAME, PT_OWNER, PT_NAME, RIC_NAME, CT_COLS, PT_COLS, R_CONSTRAINT_NAME, DELETE_RULE,
             STATUS) as
select /*+ ORDERED */ ct_owner, ct_name, pt_owner, pt_name, ric_name,
         rtrim(ct_cols,','), rtrim(pt_cols,','),
         pt_unique_const_name, my_mode, status
  from   wmsys.wm$ric_table rt, all_views uv
  where  uv.view_name = rt.ct_name and
         uv.owner = rt.ct_owner
/

