create view WM$MW_PARVERS_VIEW as
select unique parent_vers from wmsys.wm$version_view where
  version in ( select current_version from wmsys.wm$workspaces_table
		where workspace in (select workspace from wmsys.wm$mw_table) )
/

