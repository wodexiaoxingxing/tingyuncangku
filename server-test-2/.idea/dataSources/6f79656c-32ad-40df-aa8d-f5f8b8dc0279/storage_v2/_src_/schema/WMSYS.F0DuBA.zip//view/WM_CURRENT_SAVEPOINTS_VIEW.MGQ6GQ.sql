create view WM$CURRENT_SAVEPOINTS_VIEW as
select "WORKSPACE","SAVEPOINT","VERSION","POSITION","IS_IMPLICIT","OWNER","CREATETIME","DESCRIPTION" from wmsys.wm$workspace_savepoints_table
   where workspace = nvl(sys_context('lt_ctx','state'),'LIVE')
WITH READ ONLY
/

