create view USER_WM_TAB_TRIGGERS
            (TRIGGER_NAME, TABLE_OWNER, TABLE_NAME, TRIGGER_TYPE, STATUS, WHEN_CLAUSE, DESCRIPTION, TRIGGER_BODY,
             TAB_MERGE_WO_REMOVE, TAB_MERGE_W_REMOVE, WSPC_MERGE_WO_REMOVE, WSPC_MERGE_W_REMOVE, DML, TABLE_IMPORT)
as
select trig_name,
       table_owner_name,
       table_name,
       wmsys.ltUtil.getTrigTypes(trig_flag),
       status,
       when_clause,
       description,
       trig_code,
       decode(bitand(event_flag, 1), 0, 'OFF', 'ON'),
       decode(bitand(event_flag, 2), 0, 'OFF', 'ON'),
       decode(bitand(event_flag, 4), 0, 'OFF', 'ON'),
       decode(bitand(event_flag, 8), 0, 'OFF', 'ON'),
       decode(bitand(event_flag, 16), 0, 'OFF', 'ON'),
       decode(bitand(event_flag, 1024), 0, 'OFF', 'ON')
from   wmsys.wm$udtrig_info
where  trig_owner_name = (select username from all_users where user_id=userenv('schemaid'))  and
       internal_type   = 'USER_DEFINED'
with READ ONLY
/

