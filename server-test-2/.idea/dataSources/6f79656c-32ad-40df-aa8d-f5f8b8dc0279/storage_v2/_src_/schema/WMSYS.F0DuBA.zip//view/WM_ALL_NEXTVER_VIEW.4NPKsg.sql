create view WM$ALL_NEXTVER_VIEW as
select version, next_vers, workspace, split
  from wmsys.wm$nextver_table
WITH READ ONLY
/

