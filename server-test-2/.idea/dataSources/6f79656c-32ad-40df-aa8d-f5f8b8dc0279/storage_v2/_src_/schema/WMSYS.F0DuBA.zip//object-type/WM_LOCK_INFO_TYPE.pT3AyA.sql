create type       wm$lock_info_type
                                                                         wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
9c a2
xByvrbM+14dgykYpNRIWwI7LR5owg5n0dLhcFnJc+vqu/0pyRwzZ0JYmVlpDCbh0K6W/m8Ay
y7OPCanWL4BJLLEwtbgkscoCfMbKFyjGyu+yth0upHQqP0q84p5XPTCSvjpqtLgqQDk57HFn
ppSxoMmmps7fZnE=
/

