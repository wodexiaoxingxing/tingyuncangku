create view WM$MP_GRAPH_REMOVED_VERSIONS as
select vht.version, vht.workspace
from wmsys.wm$version_hierarchy_table vht, wmsys.wm$version_table vt
where vt.workspace = sys_context('lt_ctx','mp_workspace')
and vht.workspace = vt.anc_workspace
and vht.version <= vt.anc_version
and (vt.refCount = 0 or ( vht.workspace = sys_context('lt_ctx','mp_root')
                          and vht.version > sys_context('lt_ctx','new_root_anc_version') )
    )
WITH READ ONLY
/

