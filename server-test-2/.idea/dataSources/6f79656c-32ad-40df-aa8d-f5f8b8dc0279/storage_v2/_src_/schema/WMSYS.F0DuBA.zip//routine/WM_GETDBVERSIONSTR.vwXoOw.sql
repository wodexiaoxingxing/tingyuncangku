create function       wm$getDbVersionStr wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
117 ff
YRW+MRCq396JIrQuiRNngZ7cNm8wg3lyLpmsZy85j//5GK0waectSqFb/oyjEbG0iJSurMqz
a+G2kvh5LEA4EpAXGb+ft/3cxYK4JPjGYR8us5/E64GsEFsrCUiyjiZDmHfRNWtbaVpt/7Fa
b7wgyq9mSoYv08Ew6Cg+PugzGOU1rna3ugFuOa8hPK3t9RRUcya9YDJOoZHOVpK+EQ1ACQsC
zCYQQYh4Zq/5ke14ByhK4dOuq/dHHBZc8uw=
/

