create view WM$CURRENT_PARVERS_VIEW as
select vht.version parent_vers
from wmsys.wm$version_hierarchy_table  vht
where
(
 (
   vht.workspace = nvl(sys_context('lt_ctx','state'),'LIVE') and
    vht.version   <=   decode(sys_context('lt_ctx','version'),
                       null,(SELECT current_version
                               FROM wmsys.wm$workspaces_table
                               WHERE workspace = 'LIVE'),
                       -1,(select current_version
                           from wmsys.wm$workspaces_table
                           where workspace = sys_context('lt_ctx','state')),
                           sys_context('lt_ctx','version')
                          )
 )
 or
 ( exists ( select 1 from wmsys.wm$version_table vt
                    where vt.workspace  = nvl(sys_context('lt_ctx','state'),'LIVE')   and
                          vht.workspace = vt.anc_workspace and
                          vht.version  <= vt.anc_version )
 )
)
/

