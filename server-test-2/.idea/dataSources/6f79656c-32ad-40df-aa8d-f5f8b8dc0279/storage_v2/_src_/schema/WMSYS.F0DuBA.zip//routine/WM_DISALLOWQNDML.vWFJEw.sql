create function       wm$disallowQnDML wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
ad eb
lLYpp/7sM6/tehIOk7WYDBD8c/EwgwDwAJkVfI6mkPjVGcrDNZ6QdnsmEKdn+Bih8lLF92B0
26ITJ7W8D4+faLLEIBFJky58TMHtvZejJKRxh43dzN9uqffb4a1883ktcI77oI1XGBo7e100
i72afDcPceTyPrUtDLHegIGe4EJ/+2AywqsZj+Tn/CZfcxgDLI/5UNaz+4ke7gP+eABNszAf
BgE58wlB14cGfipw
/

