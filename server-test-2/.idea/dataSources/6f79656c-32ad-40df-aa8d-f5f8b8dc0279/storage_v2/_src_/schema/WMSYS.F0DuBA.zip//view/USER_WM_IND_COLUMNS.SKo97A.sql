create view USER_WM_IND_COLUMNS as
select /*+ ORDERED */ t2.index_name, t1.table_name, t2.column_name, t2.column_position,
t2.column_length, t2.descend
from wmsys.wm$constraints_table t1, user_ind_columns t2
where t1.index_owner = (select username from all_users where user_id=userenv('schemaid'))
and t1.index_name = t2.index_name
and t1.constraint_type != 'P'
union
select /*+ ORDERED */ t2.index_name, t1.table_name, t2.column_name, t2.column_position-1,
t2.column_length, t2.descend
from wmsys.wm$constraints_table t1, user_ind_columns t2
where t1.index_owner = (select username from all_users where user_id=userenv('schemaid'))
and t1.index_name = t2.index_name
and t1.constraint_type = 'P'
and t2.column_name not in ('VERSION','DELSTATUS')
/

