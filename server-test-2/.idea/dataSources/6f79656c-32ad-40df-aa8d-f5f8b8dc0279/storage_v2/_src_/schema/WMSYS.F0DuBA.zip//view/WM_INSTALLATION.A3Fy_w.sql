create view WM_INSTALLATION as
select name, value from WMSYS.WM$ENV_VARS where hidden=0 union
       select name, value from wmsys.wm$sysparam_all_values sv where isdefault = 'YES' and
         not exists (select 1 from wmsys.wm$env_vars ev where ev.name = sv.name)  WITH READ ONLY
/

