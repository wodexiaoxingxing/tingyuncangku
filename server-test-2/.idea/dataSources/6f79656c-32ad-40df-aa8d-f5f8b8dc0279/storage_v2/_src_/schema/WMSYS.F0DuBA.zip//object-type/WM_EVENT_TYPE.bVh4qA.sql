create type       WM$EVENT_TYPE                                                                       
         as object (event_name             varchar2(100),
                    workspace_name         varchar2(30),
                    parent_workspace_name  varchar2(30),
                    user_name              varchar2(30),
                    table_name             varchar2(60),
                    aux_params             WMSYS.WM$NV_PAIR_NT_TYPE)
/

