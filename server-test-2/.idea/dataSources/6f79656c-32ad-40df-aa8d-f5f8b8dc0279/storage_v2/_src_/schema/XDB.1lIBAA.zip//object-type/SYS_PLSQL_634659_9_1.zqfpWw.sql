create type       SYS_PLSQL_634659_9_1 as table of VARCHAR2(4000 BYTE);
/

