create procedure     xdb$InitXDBSchema
 is language C name "INIT_XDBSCHEMA"
 library XMLSCHEMA_LIB;
/

