create view RESOURCE_VIEW as
select value(p) res, abspath(8888) any_path, sys_nc_oid$ resid
  from xdb.xdb$resource p
  where under_path(value(p), '/', 8888) = 1
/

create trigger XDB_RV_TRIG
    instead of insert or update or delete
    on RESOURCE_VIEW
    for each row
begin
    -- missing source code
end
/

