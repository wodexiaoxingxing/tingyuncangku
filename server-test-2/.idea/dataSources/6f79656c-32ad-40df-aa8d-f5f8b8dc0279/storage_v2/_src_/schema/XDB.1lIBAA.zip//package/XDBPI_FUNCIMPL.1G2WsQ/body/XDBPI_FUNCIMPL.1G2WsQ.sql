create package body     xdbpi_funcimpl as
  function noop_func(res sys.xmltype) return number is
  begin
   return 0;
  end;
end;
/

