create package     dbms_xdb_print wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
21f 150
06MzMQ13qNBWcasUBbFw7YjSNNEwg/BQr/Idfy85cHL4jsfDpQmU99EARxvrq0UTRvo2/N4O
0gY184GPhhNAUQd+lXZq/hebrqIDlbKvOLWbaw8H7bztJJ0/4clC9W9ZyRuW7LZ/U3cypvdM
vkug1HoYYMv3VEHdNk827aly62mlwERt+QeAG1jpeJ3UB0INcVWkzINFTVk+kd8aEdQ8AKDi
BD5Eo5lt+Css9jzyJrJoPGSnGfw0kKrCGL2/F6JVoX+BiT5AfsmsogkffEQMnFIABjluJOni
krWX9leyALcq76i1rbDvIK/LXiWQpKAl+Qb9WTv3CQ==
/

