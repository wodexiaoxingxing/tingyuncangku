create package body     XDB_DLTRIG_PKG wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
12e 124
J2oYzmy0uqYMz3C+p3q2D7c09XYwg0zIr0oVfHSi/mhkBFLhJvz7zfC3E1SVUdv3t0gFXrW1
lnxN4aAioqcAgpah6LiMN7P2cS3bP20LKohhz/1nY/vC3o9XiB34J5cIBCc3FH3D9yERh8w8
JWL+LeJYulOibBURIjVBPjTDYaKMxPS5X2pJbcUsz3oM7WYR5dEQ4PpxweishiJ57nex7n0W
N+Wr8rUFReSYn1M5Uvn40ZqnTvpijNJgMyP1F3H1wt0FT6U0OoslIW4GnSi+5HqmREJZmg==

/

