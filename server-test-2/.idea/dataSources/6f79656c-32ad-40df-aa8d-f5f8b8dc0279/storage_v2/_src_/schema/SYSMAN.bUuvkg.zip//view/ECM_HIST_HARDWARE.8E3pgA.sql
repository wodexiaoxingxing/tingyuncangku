create view ECM$HIST_HARDWARE as
SELECT
  s.snapshot_guid AS ecm_snapshot_id,
  s.hostname,
  s.domain,
  m.vendor_name,
  m.system_config,
  m.machine_architecture,
  m.clock_freq_in_mhz,
  m.memory_size_in_mb,
  m.local_disk_space_in_gb,
  m.cpu_count,
  m.cpu_board_count,
  m.iocard_count,
  m.fan_count,
  m.power_supply_count
FROM
  mgmt_hc_system_summary s,
  mgmt_hc_hardware_master m
WHERE s.snapshot_guid = m.snapshot_guid
WITH READ ONLY
/

