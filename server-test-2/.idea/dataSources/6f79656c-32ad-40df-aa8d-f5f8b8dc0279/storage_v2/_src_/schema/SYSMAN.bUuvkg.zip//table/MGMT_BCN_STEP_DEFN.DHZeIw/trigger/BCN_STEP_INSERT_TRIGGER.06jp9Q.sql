create trigger BCN_STEP_INSERT_TRIGGER
    before insert
    on MGMT_BCN_STEP_DEFN
    for each row
DECLARE
  v_step_guid    RAW(16);
BEGIN

    IF (:new.txn_guid IS NOT NULL) AND
       (:new.name IS NOT NULL) THEN

      IF :new.step_type IS NULL THEN
        :new.step_type := 'HTTP';
      END IF;

      IF :new.step_guid IS NULL THEN
        v_step_guid :=
            dbms_obfuscation_toolkit.md5(
                   input => utl_raw.cast_to_raw(
                                   RAWTOHEX(:new.txn_guid) ||
                                   ';' || :new.step_type ||
                                   ';' || :new.name));
        :new.step_guid := v_step_guid;
      END IF;

    END IF;

END;
/

