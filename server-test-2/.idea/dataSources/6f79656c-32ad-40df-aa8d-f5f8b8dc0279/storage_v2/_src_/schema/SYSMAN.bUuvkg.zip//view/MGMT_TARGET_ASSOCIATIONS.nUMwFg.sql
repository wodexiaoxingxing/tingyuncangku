create view MGMT$TARGET_ASSOCIATIONS as
SELECT d.assoc_def_name assoc_def_name ,
           t1.target_name source_target_name,
           t1.target_type source_target_type,
           t2.target_name assoc_target_name,
           t2.target_type assoc_target_type,
           t3.target_name scope_target_name,
           t3.target_type scope_target_type,
           d.association_type association_type
      FROM mgmt_targets t1,
           mgmt_targets t2,
           mgmt_targets t3,
           mgmt_target_assocs a,
           mgmt_target_assoc_defs d
     WHERE t1.target_guid = a.source_target_guid
       AND t2.target_guid = a.assoc_target_guid
       AND t3.target_guid = a.scope_target_guid
       AND d.assoc_guid = a.assoc_guid
    UNION ALL
       SELECT d.assoc_def_name assoc_def_name,
              t1.target_name source_target_name,
              t1.target_type source_target_type,
              t2.target_name assoc_target_name,
              t2.target_type assoc_target_type,
              ' ' scope_target_name,
              ' ' scope_target_type,
              d.association_type association_type
       FROM   mgmt_targets t1,
              mgmt_targets t2,
              mgmt_target_assocs a,
              mgmt_target_assoc_defs d
       WHERE  t1.target_guid = a.source_target_guid
         AND  t2.target_guid = a.assoc_target_guid
         AND  a.scope_target_guid = '0000000000000000'
         AND  d.assoc_guid = a.assoc_guid
/

