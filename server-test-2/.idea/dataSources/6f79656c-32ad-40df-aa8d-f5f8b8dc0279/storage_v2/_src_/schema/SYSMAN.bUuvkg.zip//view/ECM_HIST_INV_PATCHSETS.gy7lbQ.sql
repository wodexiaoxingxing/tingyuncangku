create view ECM$HIST_INV_PATCHSETS as
SELECT
  h.snapshot_guid AS ecm_snapshot_id,
  p.name,
  p.version,
  h.container_location,
  p.description,
  NVL(p.external_name,p.name) AS external_name,
  p.installer_version,
  p.min_deinstaller_version,
  p.timestamp
FROM
  mgmt_inv_patchset p,
  mgmt_inv_container h
WHERE p.container_guid = h.container_guid
WITH READ ONLY
/

