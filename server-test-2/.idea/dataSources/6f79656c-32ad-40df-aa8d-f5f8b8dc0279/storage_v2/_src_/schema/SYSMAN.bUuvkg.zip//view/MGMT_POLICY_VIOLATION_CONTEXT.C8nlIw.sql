create view MGMT$POLICY_VIOLATION_CONTEXT as
SELECT t.target_name, t.target_type, t.target_guid, p.policy_name,
           p.policy_guid, func_cats.category_name, v.key_value, null, null, null, null,
           v.collection_timestamp, vc.column_name,
           DECODE(vc.column_type,
                    2, DECODE(vc.column_value,
                                NULL, NULL,
                                to_number(vc.column_value)),
                    column_str_value)
      FROM mgmt_violations v,
           mgmt_violation_context vc,
           mgmt_targets t,
           mgmt_policies p,
           (SELECT target_type, object_guid, category_name
              FROM mgmt_category_map catm
             WHERE class_name = 'Functional'
               AND object_type = 2) func_cats
     WHERE v.target_guid = t.target_guid
       AND v.policy_guid = p.policy_guid
       AND v.target_guid = vc.target_guid
       AND v.policy_guid = vc.policy_guid
       AND v.policy_guid = func_cats.object_guid (+)
       AND v.key_value = vc.key_value
       AND v.collection_timestamp = vc.collection_timestamp
       AND p.policy_type = 2
       AND v.violation_type = 3
  UNION ALL
    SELECT t.target_name, t.target_type, t.target_guid, p.policy_name,
           p.policy_guid, func_cats.category_name, k.key_part1_value, k.key_part2_value,
           k.key_part3_value, k.key_part4_value, k.key_part5_value,
           v.collection_timestamp, vc.column_name,
           DECODE(vc.column_type,
                    2, DECODE(vc.column_value, NULL, NULL,
                                to_number(vc.column_value)),
                    column_str_value)
      FROM mgmt_violations v,
           mgmt_violation_context vc,
           mgmt_targets t,
           mgmt_policies p,
           (SELECT target_type, object_guid, category_name
              FROM mgmt_category_map catm
             WHERE class_name = 'Functional'
               AND object_type = 2) func_cats,
           mgmt_metrics_composite_keys k
     WHERE v.target_guid = t.target_guid
       AND v.policy_guid = p.policy_guid
       AND v.target_guid = vc.target_guid
       AND v.policy_guid = vc.policy_guid
       AND v.policy_guid = func_cats.object_guid (+)
       AND v.key_value = vc.key_value
       AND v.collection_timestamp = vc.collection_timestamp
       AND k.target_guid = t.target_guid
       AND v.key_value = k.composite_key
       AND p.policy_type = 2
       AND v.violation_type = 3
WITH READ ONLY
/

