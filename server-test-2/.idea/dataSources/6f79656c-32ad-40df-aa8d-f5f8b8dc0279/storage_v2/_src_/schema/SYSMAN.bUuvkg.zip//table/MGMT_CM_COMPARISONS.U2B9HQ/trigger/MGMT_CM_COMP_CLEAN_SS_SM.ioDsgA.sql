create trigger MGMT_CM_COMP_CLEAN_SS_SM
    after delete
    on MGMT_CM_COMPARISONS
    for each row
BEGIN
    DELETE FROM mgmt_CM_SCOPESPECS
           WHERE ss_guid = :old.comparison_ss;
    DELETE FROM mgmt_cm_schema_maps
           WHERE owner_id = :old.comparison_ss;
  END;
/

