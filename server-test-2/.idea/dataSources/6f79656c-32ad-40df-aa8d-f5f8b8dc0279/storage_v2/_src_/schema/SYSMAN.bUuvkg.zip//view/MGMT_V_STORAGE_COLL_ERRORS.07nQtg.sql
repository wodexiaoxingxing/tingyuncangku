create view MGMT_V_STORAGE_COLL_ERRORS as
SELECT tgt.host_name,
         tgt.target_name,
         met.target_type,
         met.metric_label,
         err.collection_timestamp,
         metric_error_message as
         metric_collection_error_msg
  FROM mgmt_current_metric_errors err,
       mgmt_targets tgt,
       mgmt_metrics met
  WHERE tgt.target_guid = err.target_guid
    AND met.metric_guid = err.metric_guid
    AND met.type_meta_ver = tgt.type_meta_ver
    AND (met.category_prop_1 = ' ' OR
         met.category_prop_1 =  tgt.category_prop_1)
    AND (met.category_prop_2 = ' ' OR
         met.category_prop_2 =  tgt.category_prop_2)
    AND (met.category_prop_3 = ' ' OR
         met.category_prop_3 =  tgt.category_prop_3)
    AND (met.category_prop_4 = ' ' OR
         met.category_prop_4 =  tgt.category_prop_4)
    AND (met.category_prop_5 = ' ' OR
         met.category_prop_5 =  tgt.category_prop_5)
    AND ((tgt.target_type = 'host' AND
          err.coll_name = 'host_storage' AND
          EXISTS
          (select uit.target_guid
             from mgmt_storage_report_ui_targets uit
            where uit.target_guid = tgt.target_guid)) OR
          (((tgt.target_type = 'oracle_database' AND
             err.coll_name = 'oracle_dbconfig') OR
             (tgt.target_type = 'rac_database' AND
              err.coll_name = 'oracle_racconfig') OR
             (tgt.target_type = 'osm_instance' AND
              err.coll_name IN ('Database_DiskGroup_Usage',
                                'DiskGroup_Usage_10_2'))) AND
             EXISTS
             (
               select uit.ecm_snapshot_id
                 from mgmt_storage_report_ui_targets uit,
                      mgmt_targets t
                where uit.ecm_snapshot_id is not null
                  and uit.target_name = t.host_name
                  and t.target_guid = err.target_guid
             )
          )
        )
/

