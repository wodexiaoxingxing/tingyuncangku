create view MGMT$METRIC_CATEGORIES as
SELECT DISTINCT c.target_type, c.type_meta_ver,
             m.metric_name, m.metric_column, m.metric_guid,c.class_name,
             c.category_name,cg.category_name_nlsid
        FROM mgmt_metrics m,
             mgmt_category_map c,
             mgmt_categories cg,
			 mgmt_targets t
       WHERE c.object_type = 1
         AND c.object_guid = m.metric_guid
         AND c.type_meta_ver = m.type_meta_ver
         AND c.category_name = cg.category_name
         AND c.class_name = cg.class_name
         AND t.target_type = c.target_type
         AND t.target_type = m.target_type
         AND t.type_meta_ver = m.type_meta_ver
         AND (t.category_prop_1 = m.category_prop_1
			  or m.category_prop_1 = ' ')
         AND (t.category_prop_2 = m.category_prop_2
		      or m.category_prop_2 = ' ')
         AND (t.category_prop_3 = m.category_prop_3
		      or m.category_prop_3 = ' ')
         AND (t.category_prop_4 = m.category_prop_4
		      or m.category_prop_4 = ' ')
         AND (t.category_prop_5 = m.category_prop_5
		      or m.category_prop_5 = ' ')
    WITH READ ONLY
/

