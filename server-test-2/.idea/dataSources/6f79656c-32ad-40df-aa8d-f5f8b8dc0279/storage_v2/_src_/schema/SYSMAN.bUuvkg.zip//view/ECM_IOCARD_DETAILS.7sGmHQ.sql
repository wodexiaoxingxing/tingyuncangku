create view ECM$IOCARD_DETAILS as
select
  snapshot_guid as ecm_snapshot_id,
  vendor_name,
  name,
  freq_in_mhz,
  bus,
  revision,
  count(*) as count
from
  MGMT_HC_IOCARD_DETAILS
group by snapshot_guid, vendor_name, name,freq_in_mhz,bus, revision
/

