create view MGMT$HOSTPATCH_HOST_COMPL as
SELECT t.target_name as host_name,
       h.pkg_name,
       h.pkg_verspec as version,
       h.is_out_of_date,
       h.is_rogue
FROM   mgmt_ecm_hostpatch_host_compl h,
       mgmt_targets t
WHERE  t.target_guid = h.host_guid
/

