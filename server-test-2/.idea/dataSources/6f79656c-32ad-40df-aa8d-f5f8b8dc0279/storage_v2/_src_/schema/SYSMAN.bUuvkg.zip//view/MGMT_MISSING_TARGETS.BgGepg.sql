create view MGMT$MISSING_TARGETS as
SELECT
  t.target_name,
  t.target_type,
  t.target_guid,
  t.host_name,
  t.type_display_name,
  home_property.property_value as home,
  NVL2(home_property.property_value, 'no_oui_information_diagnostic', 'target_oracle_home_not_found_diagnostic') as diagnostic
FROM
  mgmt_targets t,
  mgmt_target_properties home_property,
  mgmt$target_components c
WHERE
  t.target_type in ('oracle_database', 'oracle_ias')
  and c.target_name(+) = t.target_name
  and c.target_type(+) = t.target_type
  and c.target_name is null
  and c.target_type is null
  and t.target_guid = home_property.target_guid (+)
  and home_property.property_name (+) = 'OracleHome'
/

