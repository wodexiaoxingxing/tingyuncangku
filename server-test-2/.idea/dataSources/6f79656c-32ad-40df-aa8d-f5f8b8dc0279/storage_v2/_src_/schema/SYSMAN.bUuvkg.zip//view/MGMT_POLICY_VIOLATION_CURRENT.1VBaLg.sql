create view MGMT$POLICY_VIOLATION_CURRENT as
SELECT t.target_name, t.target_type, tt.type_display_name, t.target_guid,
       p.policy_name, p.policy_guid, func_cats.category_name,
       v.key_value, null, null, null, null,
       v.collection_timestamp, v.violation_level, v.message,v.message_nlsid,
       v.message_params,v.exempt_code, v.exempt_until, v.exempt_by
     FROM
       mgmt_targets t,
       mgmt_metrics m,
       mgmt_policies p,
       mgmt_target_types tt,
       mgmt_current_violation v,
       (SELECT target_type, object_guid, category_name
          FROM mgmt_category_map catm
         WHERE class_name = 'Functional'
           AND object_type = 2) func_cats
     WHERE v.target_guid = t.target_guid
       AND v.policy_guid = p.policy_guid
       AND tt.target_type = t.target_type
       AND m.metric_guid = p.metric_guid
       AND m.num_keys < 2
       AND m.target_type = t.target_type
       AND t.type_meta_ver = m.type_meta_ver
       AND (t.category_prop_1 = m.category_prop_1 OR m.category_prop_1 = ' ')
       AND (t.category_prop_2 = m.category_prop_2 OR m.category_prop_2 = ' ')
       AND (t.category_prop_3 = m.category_prop_3 OR m.category_prop_3 = ' ')
       AND (t.category_prop_4 = m.category_prop_4 OR m.category_prop_4 = ' ')
       AND (t.category_prop_5 = m.category_prop_5 OR m.category_prop_5 = ' ')
       AND p.policy_type = 2
       AND v.violation_type = 3
       AND v.policy_guid = func_cats.object_guid (+)
   UNION ALL
   SELECT t.target_name, t.target_type, tt.type_display_name, t.target_guid,
       p.policy_name, p.policy_guid, func_cats.category_name,
       k.key_part1_value, k.key_part2_value, k.key_part3_value,
       k.key_part4_value, k.key_part5_value, v.collection_timestamp,
       v.violation_level, v.message,v.message_nlsid, v.message_params,
       v.exempt_code, v.exempt_until, v.exempt_by
   FROM
       mgmt_targets t,
       mgmt_metrics m,
       mgmt_policies p,
       mgmt_target_types tt,
       mgmt_current_violation v,
       (SELECT target_type, object_guid, category_name
          FROM mgmt_category_map catm
         WHERE class_name = 'Functional'
           AND object_type = 2) func_cats,
       mgmt_metrics_composite_keys k
   WHERE v.target_guid = t.target_guid
     AND v.policy_guid = p.policy_guid
     AND tt.target_type = t.target_type
     AND m.metric_guid = p.metric_guid
     AND m.num_keys > 1
     AND m.target_type = t.target_type
     AND t.type_meta_ver = m.type_meta_ver
     AND (t.category_prop_1 = m.category_prop_1 OR m.category_prop_1 = ' ')
     AND (t.category_prop_2 = m.category_prop_2 OR m.category_prop_2 = ' ')
     AND (t.category_prop_3 = m.category_prop_3 OR m.category_prop_3 = ' ')
     AND (t.category_prop_4 = m.category_prop_4 OR m.category_prop_4 = ' ')
     AND (t.category_prop_5 = m.category_prop_5 OR m.category_prop_5 = ' ')
     AND k.target_guid = t.target_guid
     AND v.key_value = k.composite_key
     AND p.policy_type = 2
     AND violation_type = 3
     AND v.policy_guid = func_cats.object_guid (+)
 WITH READ ONLY
/

