create view MGMT$SOFTWARE_ONEOFF_PATCHES as
SELECT
  s.target_name as HOST_NAME,
  c.container_name as HOME_NAME,
  c.container_location as HOME_LOCATION,
  p.id as PATCH_ID,
  p.timestamp as INSTALL_TIMESTAMP,
  p.description, p.is_rollbackable,
  s.snapshot_guid
FROM
  mgmt_inv_container c,
  mgmt_ecm_snapshot s,
  mgmt_inv_patch p,
  mgmt_targets t
WHERE c.snapshot_guid = s.snapshot_guid
  AND s.is_current = 'Y'
  AND s.snapshot_type = 'host_configuration'
  AND c.container_guid = p.container_guid
  AND t.target_name = s.target_name
  AND t.target_type = 'host'
/

