create view MGMT_V_DAILY_HISTORY as
SELECT tgt.target_type,
         tgt.target_name,
         met.metric_name,
         met.metric_guid,
         met.metric_column,
         rollup_timestamp,
         value_average as value
  FROM mgmt_metrics met,
       mgmt_metrics_1day day,
       mgmt_targets tgt
  WHERE tgt.target_guid = day.target_guid
    AND tgt.target_name in
        ( SELECT target_name
          FROM mgmt_storage_report_ui_targets
        )
    AND met.metric_guid = day.metric_guid
    AND met.metric_name in( 'host_storage_history',
                            'group_storage_history' )
    AND met.type_meta_ver = tgt.type_meta_ver
    AND (met.category_prop_1 = ' ' OR
         met.category_prop_1 =  tgt.category_prop_1)
    AND (met.category_prop_2 = ' ' OR
         met.category_prop_2 =  tgt.category_prop_2)
    AND (met.category_prop_3 = ' ' OR
         met.category_prop_3 =  tgt.category_prop_3)
    AND (met.category_prop_4 = ' ' OR
         met.category_prop_4 =  tgt.category_prop_4)
    AND (met.category_prop_5 = ' ' OR
         met.category_prop_5 =  tgt.category_prop_5)
    AND rollup_timestamp >= sysdate -
          to_number(sys_context('storage_context',
                    'history_period_in_days' ))
/

