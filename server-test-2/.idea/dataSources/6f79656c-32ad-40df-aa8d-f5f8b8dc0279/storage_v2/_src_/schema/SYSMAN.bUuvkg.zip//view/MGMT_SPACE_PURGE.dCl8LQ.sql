create view MGMT_SPACE_PURGE as
SELECT target_guid, metric_name
  FROM mgmt_space_metrics WITH CHECK OPTION
/

create trigger SPACE_METRICS_PURGE_TRIGGER
    instead of insert or update or delete
    on MGMT_SPACE_PURGE
    for each row
begin
    -- missing source code
end
/

