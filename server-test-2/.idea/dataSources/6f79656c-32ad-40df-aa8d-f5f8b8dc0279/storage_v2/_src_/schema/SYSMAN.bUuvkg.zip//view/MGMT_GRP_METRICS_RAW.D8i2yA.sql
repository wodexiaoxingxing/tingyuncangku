create view MGMT$GRP_METRICS_RAW as
(
	select grp_name, value,	metric_column,column_label,
	column_label_nlsid,met.target_type target_type,
	txn_name ,bcn_name,txn_guid,stp_groups.target_guid,collection_timestamp
	from mgmt$step_groups stp_groups, (
      select met.value_average value,met.target_guid target_guid,
				mtm.target_type target_type,
				metric_column,column_label,column_label_nlsid,
				ck.key_part1_value,ck.key_part2_value,ck.key_part3_value,rollup_timestamp as collection_timestamp
			from
				mgmt_metrics_1hour met,
				mgmt_metrics_composite_keys ck,
				(
					SELECT metric_column,target_guid,metric_guid ,column_label,column_label_nlsid,mt.target_type
					FROM
						mgmt_metrics mm,mgmt_targets mt
					WHERE
					 mt.type_meta_ver = mm.type_meta_ver
					 and mm.target_type = mt.target_type
					 and (mt.category_prop_1 = mm.category_prop_1 or mm.category_prop_1 = ' ')
					 and (mt.category_prop_2 = mm.category_prop_2 or mm.category_prop_2 = ' ')
					 and (mt.category_prop_3 = mm.category_prop_3 or mm.category_prop_3 = ' ')
					 and (mt.category_prop_4 = mm.category_prop_4 or mm.category_prop_4 = ' ')
					 and (mt.category_prop_5 = mm.category_prop_5 or mm.category_prop_5 = ' ')
					 and metric_name = 'http_uagroup'
					 ) mtm
		where
		ck.target_guid = mtm.target_guid
		and met.key_value=ck.composite_key
		and mtm.metric_guid=met.metric_guid
      ) met
	where stp_groups.target_guid = met.target_guid(+)
	and met.key_part1_value(+) = stp_groups.txn_name
	and met.key_part2_value(+) = stp_groups.bcn_name
	and stp_groups.grp_name = met.key_part3_value(+)
)
/

