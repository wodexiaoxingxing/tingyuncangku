create view EM$INV_COMPONENT as
select
  c.name as name,
  c.version as base_version,
  decode( p.version, null, c.version, p.version ) as version,
  c.container_guid,
  c.component_guid,
  c.description,
  c.external_name,
  c.languages,
  c.installed_location,
  c.installer_version,
  c.min_deinstaller_version,
  c.is_top_level,
  c.timestamp
from
  mgmt_inv_component c,
  mgmt_inv_versioned_patch p
where
  c.component_guid = p.component_guid(+)
WITH READ ONLY
/

