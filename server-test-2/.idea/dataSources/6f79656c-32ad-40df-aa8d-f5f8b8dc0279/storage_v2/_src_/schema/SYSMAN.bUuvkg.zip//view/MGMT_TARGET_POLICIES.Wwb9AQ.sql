create view MGMT$TARGET_POLICIES as
SELECT t.target_name, t.target_type, t.target_guid, p.policy_name,
           p.policy_guid, func_cats.category_name, pa.is_enabled
      FROM mgmt_policy_assoc pa,
           mgmt_targets t,
           mgmt_policies p,
           (SELECT target_type, object_guid, category_name
              FROM mgmt_category_map catm
             WHERE class_name = 'Functional'
               AND object_type = 2) func_cats
     WHERE pa.object_guid = t.target_guid
       AND pa.object_type = 2
       AND pa.policy_guid = p.policy_guid
       AND p.policy_type = 2
       AND pa.policy_guid = func_cats.object_guid (+)
WITH READ ONLY
/

