create view MGMT$STORAGE_REPORT_LOCALFS as
SELECT
  b.target_name,
  b.target_type,
  a1,
  a2,
  a3,
  sizeb,
  usedb,
  freeb
FROM mgmt_storage_report_data a,
     mgmt$ecm_current_snapshots b
WHERE  storage_layer = 'LOCAL_FILESYSTEM'
AND  entity_type = 'Mountpoint'
AND  a.ecm_snapshot_id = b.ecm_snapshot_id
AND  b.snapshot_type = 'host_storage'
/

