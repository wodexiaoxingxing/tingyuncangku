create view MGMT_V_SL_SRC as
SELECT a.parent_storage_layer AS parent_storage_layer,
       SUM( DECODE( a.child_storage_layer,'OS_DISK',
           a.parent_sizeb, 0) ) AS on_local_disks,
       SUM( DECODE( a.child_storage_layer,'VOLUME_MANAGER',
           a.parent_sizeb, 0) ) on_volumes,
       SUM( DECODE( a.child_storage_layer,'NFS',
           a.parent_sizeb, 0) ) AS on_nfs_read,
       SUM( DECODE( a.child_storage_layer,'LOCAL_FILESYSTEM',
           a.parent_sizeb, 0) ) AS on_local_fs
FROM
(
   SELECT p.storage_layer AS parent_storage_layer,
          c.storage_layer AS child_storage_layer,
          p.global_unique_id,
          p.sizeb AS parent_sizeb,
          p.usedb AS parent_usedb,
          c.sizeb AS child_sizeb,
          c.freeb AS child_usedb,
          ROW_NUMBER() OVER ( PARTITION BY p.storage_layer, p.global_unique_id ORDER BY p.sizeb, c.sizeb ) AS global_unique_id_rownumber
   FROM   mgmt_v_storage_report_data p,
          mgmt_storage_report_keys k,
          mgmt_v_storage_report_data c,
          mgmt$ecm_current_snapshots s
   WHERE  s.ecm_snapshot_id = k.ecm_snapshot_id
   AND    s.snapshot_type = 'host_storage'
   AND    s.target_name = p.target_name
   AND    s.target_type = p.target_type
   AND    s.target_name = c.target_name
   AND    s.target_type = c.target_type
   AND    s.target_type = 'host'
   AND    s.target_name = SYS_CONTEXT('storage_context', 'host_name' )
   AND    k.key_value = c.key_value
   AND    k.parent_key_value = p.key_value
) a
WHERE  a.parent_storage_layer != a.child_storage_layer
AND    a.global_unique_id_rownumber = 1
GROUP BY
      a.parent_storage_layer,
      a.child_storage_layer
/

