create view MGMT_TARGET_MEMBERSHIPS as
SELECT t1.target_name composite_target_name,
           t1.target_type composite_target_type,
           i.source_target_guid composite_target_guid,
           t2.target_name member_target_name,
           t2.target_type member_target_type,
           i.assoc_target_guid member_target_guid,
           ' ' association
      FROM MGMT_TARGET_ASSOCS i,
           MGMT_TARGET_ASSOC_DEFS a,
           MGMT_TARGETS t1,
           MGMT_TARGETS t2
     WHERE t1.target_guid = i.source_target_guid
       AND t2.target_guid = i.assoc_target_guid
       AND i.assoc_guid = a.assoc_guid
       AND a.assoc_def_name = 'contains'
       AND a.scope_target_type = ' '
/

create trigger MEMBERSHIPS_INSERT_TRIGGER
    instead of insert
    on MGMT_TARGET_MEMBERSHIPS
    for each row
begin
    -- missing source code
end
/

