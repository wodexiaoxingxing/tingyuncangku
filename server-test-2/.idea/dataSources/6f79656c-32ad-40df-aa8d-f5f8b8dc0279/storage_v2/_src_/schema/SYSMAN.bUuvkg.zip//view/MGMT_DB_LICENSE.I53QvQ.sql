create view MGMT$DB_LICENSE as
select
  g.host_name,
  s.target_name,
  s.target_type,
  s.target_guid,
  s.start_timestamp as collection_timestamp,
  f.SESSIONS_MAX,
  f.SESSIONS_WARNING,
  f.SESSIONS_CURRENT,
  f.SESSIONS_HIGHWATER,
  f.USERS_MAX
from
  mgmt_targets g,
  mgmt_db_license_ecm f,
  mgmt_ecm_gen_snapshot s
where
  s.snapshot_guid = f.ecm_snapshot_id and
  s.target_guid = g.target_guid and
  s.is_current = 'Y'
/

