create view ECM$HIST_FS_MOUNT_DETAILS as
SELECT
  snapshot_guid AS ecm_snapshot_id,
  resource_name,
  mount_location,
  type,
  mount_options
FROM mgmt_hc_fs_mount_details
WITH READ ONLY
/

