create view ECM$OS_COMPONENTS as
select
    snapshot_guid as ecm_snapshot_id,
    name,
    type,
    version,
    description
from MGMT_HC_OS_COMPONENTS
where type <> 'Patch'
/

