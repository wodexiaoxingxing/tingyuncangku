create view MGMT_V_STORAGE_STATS as
SELECT target_name,
       target_type,
       metric_name,
       metric_column,
       round(sum_value/sum_sample_count, 2) as average,
       maximum,
       minimum,
       last_known_value
FROM
(
  -- we get the sum of all values, sample count,
  -- max, minimum AND last known value here.
  SELECT target_name,
         target_type,
         metric_name,
         metric_column,
         sum( value) sum_value,
         sum( sample_count) sum_sample_count,
         max( maximum) maximum,
         min( minimum ) minimum,
         max( last_known_value ) as last_known_value
  FROM
  (
    -- since we want to include the current value
    -- alongwith the daily rollup values, we take
    -- a union of SELECT FROM current value AND
    -- daily rollup values. The SELECT immediately
    -- below selects values FROM the mgmt_current_metrics,
    -- treating the current value as maximum, minimum etc.
    -- note that we need to get the sample count as well
    -- AND in this case, it would be always 1 since there
    -- is only one record for a metric in the
    -- mgmt_current_metrics.
    SELECT tgt.target_name,
           tgt.target_type,
           met.metric_name,
           met.metric_column,
           curr.value as maximum,
           curr.value as minimum,
           curr.value as last_known_value,
           1 as sample_count,
           curr.value as value
    FROM mgmt_metrics met,
         mgmt_targets tgt,
         mgmt_current_metrics curr
    WHERE tgt.target_guid = curr.target_guid
      AND ((tgt.target_type = 'host' AND
            met.metric_name = 'host_storage_history') OR
           (tgt.target_type = 'composite' AND
            met.metric_name = 'group_storage_history'))
      AND met.type_meta_ver = tgt.type_meta_ver
      AND (met.category_prop_1 = ' ' OR
           met.category_prop_1 =  tgt.category_prop_1)
      AND (met.category_prop_2 = ' ' OR
           met.category_prop_2 =  tgt.category_prop_2)
      AND (met.category_prop_3 = ' ' OR
           met.category_prop_3 =  tgt.category_prop_3)
      AND (met.category_prop_4 = ' ' OR
           met.category_prop_4 =  tgt.category_prop_4)
      AND (met.category_prop_5 = ' ' OR
           met.category_prop_5 =  tgt.category_prop_5)
      AND met.metric_guid = curr.metric_guid
      AND collection_timestamp >= sysdate -
            to_number(sys_context('storage_context',
                      'history_period_in_days' ))
    UNION ALL
    -- the SELECT below gets maximum, minimum,
    -- sum of all values, last known value
    -- AND sum of sample counts
    -- FROM the daily rollup table. Note that
    -- last known value always comes FROM the
    -- SELECT above (the one FROM mgmt_current_metrics)
    -- so we just use a max(0) in the query below - the
    -- max existing for the GROUP BY to work.
    SELECT tgt.target_name,
           tgt.target_type,
           met.metric_name,
           met.metric_column,
           max(daily.value_maximum) as maximum,
           min(daily.value_minimum) as minimum,
           max( 0 ) as last_known_value,
           sum(daily.sample_count ) as sample_count,
           sum(daily.value_average*sample_count) as value
    FROM mgmt_metrics met,
         mgmt_targets tgt,
         mgmt_metrics_1day daily
    WHERE tgt.target_guid = daily.target_guid
      AND ((tgt.target_type = 'host' AND
            met.metric_name = 'host_storage_history') OR
           (tgt.target_type = 'composite' AND
            met.metric_name = 'group_storage_history'))
      AND met.type_meta_ver = tgt.type_meta_ver
      AND (met.category_prop_1 = ' ' OR
           met.category_prop_1 =  tgt.category_prop_1)
      AND (met.category_prop_2 = ' ' OR
           met.category_prop_2 =  tgt.category_prop_2)
      AND (met.category_prop_3 = ' ' OR
           met.category_prop_3 =  tgt.category_prop_3)
      AND (met.category_prop_4 = ' ' OR
           met.category_prop_4 =  tgt.category_prop_4)
      AND (met.category_prop_5 = ' ' OR
           met.category_prop_5 =  tgt.category_prop_5)
      AND met.metric_guid = daily.metric_guid
      AND rollup_timestamp >= sysdate -
            to_number(sys_context('storage_context',
                      'history_period_in_days' ))
    GROUP BY tgt.target_name, tgt.target_type, met.metric_name, met.metric_column
  )
  GROUP BY target_name, target_type, metric_name, metric_column
)
/

