create view EM$ECM_TARGETS_BY_ARUID as
select
       db.target_name as target_name,
       db.target_type as target_type,
       db.target_guid as target_guid,
       plat.em_os_name as platform,
       iv.property_value as version,
       htg.target_name as host,
       dbp.property_value as oracle_home,
       plat.em_os_bitlength as address_size,
       'ARU' as id_type,
       home.container_guid as container_guid,
       prop.property_value as target_aru_id
from
     mgmt_targets db,
     mgmt_targets htg,
     mgmt_target_properties iv,
     mgmt_target_properties dbp,
     mgmt_ecm_snapshot snap,
     mgmt_inv_container home,
     mgmt_aru_platforms plat,
     mgmt_inv_container_property prop
where
  htg.target_type =  'host' and
  db.host_name = htg.target_name and
  db.target_guid = iv.target_guid and
  iv.property_name = 'Version' and
  db.target_guid = dbp.target_guid and
  dbp.property_name = 'OracleHome' and
  snap.target_name = htg.target_name and
  snap.target_type = htg.target_type and
  snap.snapshot_type = 'host_configuration' and
  snap.is_current = 'Y' and
  home.snapshot_guid = snap.snapshot_guid and
  home.container_location = dbp.property_value and
  home.container_type = 'O' and
  prop.container_guid = home.container_guid and
  plat.platform_id = to_number(prop.property_value) and
  prop.property_name = 'ARU_PLATFORM_ID'
union
select db.target_name as target_name,
       db.target_type as target_type,
       db.target_guid as target_guid,
       hos.property_value as platform,
       iv.property_value as version,
       htg.target_name as host,
       dbp.property_value as oracle_home,
       replace(os.address_length_in_bits, '-bit','') as address_size,
       'NOT_ARU' as id_type,
       home.container_guid as container_guid,
       to_char(oui.aru_id) as target_aru_id
from mgmt_targets db,
     mgmt_targets htg,
     mgmt_target_properties hos,
     mgmt_target_properties iv,
     mgmt_target_properties dbp,
     mgmt_ecm_snapshot snap,
     mgmt_hc_os_summary os,
     mgmt_inv_container home,
     mgmt_oui_aru_map oui
where
  htg.target_type =  'host' and
  db.host_name = htg.target_name and
  hos.target_guid = htg.target_guid and
  hos.property_name = 'OS' and
  db.target_guid = iv.target_guid and
  iv.property_name = 'Version' and
  dbp.target_guid = db.target_guid and
  dbp.property_name = 'OracleHome' and
  snap.target_name = htg.target_name and
  snap.target_type = htg.target_type and
  snap.snapshot_type = 'host_configuration' and
  snap.is_current = 'Y' and
  os.snapshot_guid = snap.snapshot_guid and
  home.snapshot_guid = snap.snapshot_guid and
  home.container_location = dbp.property_value and
  home.container_type = 'O' and
  oui.oui_id = home.oui_platform and
  not exists (
   select
    property_value
   from
    mgmt_inv_container_property p
   where
   container_guid = home.container_guid  and
   p.property_name = 'ARU_PLATFORM_ID'
  )
WITH READ ONLY
/

