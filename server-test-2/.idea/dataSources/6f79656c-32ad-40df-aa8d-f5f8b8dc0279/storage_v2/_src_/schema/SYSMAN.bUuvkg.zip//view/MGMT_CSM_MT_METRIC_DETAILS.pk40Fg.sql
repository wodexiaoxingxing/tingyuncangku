create view MGMT$CSM_MT_METRIC_DETAILS
            (MEMBER_TARGET_NAME, MEMBER_TARGET_TYPE, COMPOSITE_TARGET_NAME, COMPOSITE_TARGET_TYPE, COLLECTION_TIMESTAMP,
             METRIC_NAME, METRIC_VALUE, URL, VISITOR_IP, VISITOR_NODE, VISITOR_DOMAIN, VISITOR_SUBNET)
as
SELECT
  tg.target_name, tg.target_type,
  st.target_name, st.target_type,
  rw.collection_timestamp, rw.metric_name, rw.elapsed_time,
  rw.url_filename, rw.visitor_ip, rw.visitor_node,
  rw.visitor_domain,
  SUBSTR(rw.visitor_ip, 1, INSTR(rw.visitor_ip, '.', 1, 3)-1)
FROM
  MGMT_RT_METRICS_RAW rw,
  MGMT_TARGETS tg,
  MGMT_TARGET_ASSOCS tm,
  MGMT_TARGETS st,
  MGMT_TARGET_ASSOC_DEFS d
WHERE
  tg.target_guid = rw.target_guid
  AND rw.target_guid = tm.assoc_target_guid (+)
  AND st.target_guid = tm.source_target_guid
  AND tm.assoc_guid = d.assoc_guid
  AND d.assoc_def_name = 'supports_eum_on'
  AND d.scope_target_type = ' '
WITH READ ONLY
/

