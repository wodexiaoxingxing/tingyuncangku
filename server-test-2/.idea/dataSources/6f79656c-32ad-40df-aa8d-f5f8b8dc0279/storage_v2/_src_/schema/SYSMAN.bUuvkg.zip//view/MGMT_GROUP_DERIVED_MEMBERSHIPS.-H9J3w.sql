create view MGMT$GROUP_DERIVED_MEMBERSHIPS as
SELECT ct.target_name composite_target_name,
         ct.target_type composite_target_type,
         ct.target_guid composite_target_guid,
         mt.target_name member_target_name,
         mt.target_type member_target_type,
         mt.target_guid member_target_guid
   FROM  mgmt_flat_target_assoc assoc,
         mgmt_targets ct,
         mgmt_targets mt
  WHERE  assoc.is_membership = 1
    AND  ct.target_guid = assoc.source_target_guid
    AND  mt.target_guid = assoc.assoc_target_guid
     AND  EXISTS
         ( SELECT 1
             FROM mgmt_flat_target_assoc f2,
                  mgmt_target_assocs m,
                  mgmt_targets ct,
                  mgmt_type_properties p,
                  mgmt_target_assoc_defs def
            WHERE p.property_name = 'is_group'
              AND m.assoc_guid = def.assoc_guid
              AND def.assoc_def_name = 'contains'
              AND def.scope_target_type = ' '
              AND f2.is_membership = 1
              AND p.target_type   = ct.target_type
              AND ct.target_guid = m.source_target_guid
              AND (m.source_target_guid = f2.assoc_target_guid OR
                   m.source_target_guid = f2.source_target_guid)
              AND assoc.source_target_guid = f2.source_target_guid
              AND assoc.assoc_target_guid = m.assoc_target_guid)
  WITH READ ONLY
/

comment on table MGMT$GROUP_DERIVED_MEMBERSHIPS is 'The MGMT$GROUP_DERIVED_MEMBERSHIPS view has been deprecated. Please consult
the documentation for the MGMT$TARGET_MEMBERS and MGMT$TARGET_FLAT_MEMBERS
views for alternatives.'
/

