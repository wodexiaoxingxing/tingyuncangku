create trigger COMPUTE_AGENT_SIDE_STATUS
    before update
    on MGMT_BLACKOUTS
    for each row
BEGIN
    IF :new.created_thru IS NOT NULL THEN
        :new.blackout_status :=
            MGMT_BLACKOUT_ENGINE.compute_blackout_status(:new.blackout_guid,
                                    MGMT_BLACKOUT_ENGINE.BLK_MODE_NONE,
                                    :new.last_start_time,
                                    :new.last_end_time);
    END IF;
END;
/

