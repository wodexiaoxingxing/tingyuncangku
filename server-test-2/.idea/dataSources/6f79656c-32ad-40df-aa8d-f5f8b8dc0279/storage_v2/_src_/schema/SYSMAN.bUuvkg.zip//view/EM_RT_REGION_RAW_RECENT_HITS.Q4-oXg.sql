create view EM$RT_REGION_RAW_RECENT_HITS as
SELECT COMPOSITE_TARGET_GUID,
        COMPOSITE_TARGET_NAME, COMPOSITE_TARGET_TYPE,
        TARGET_GUID,
        METRIC_NAME,
        DISPLAY_NAME,
        URL_FILENAME,
        URL_LINK,
        VISITOR_NODE,
        VISITOR_DOMAIN,
        (select REGION_NAME from mgmt_rt_regions r
          where r.target_guid = d.composite_target_guid
            and r.region_guid IN (select mp.region_guid /*+ INDEX(mgmt_rt_region_entries IDX_REGION_MIN_IP) */ FROM mgmt_rt_region_entries e, mgmt_rt_region_mapping mp WHERE e.id = mp.id AND ((e.min_ip >= 0 AND visitor_ip_num between e.min_ip AND e.max_ip) OR (e.min_ip < 0 AND UPPER(substr('.'||visitor_domain, -LENGTH(e.domain)-1)) = UPPER('.'||e.domain))))
        ) VISITOR_REGION,
        COLLECTION_TIMESTAMP,
        ELAPSED_TIME,
        SUBMIT_ACTION_TIMESTAMP,
        OS_NAME,
        OS_VERSION,
        BROWSER_NAME,
        BROWSER_VERSION
    FROM em$rt_url_raw_recent_hits D
    ORDER BY collection_timestamp DESC
/

