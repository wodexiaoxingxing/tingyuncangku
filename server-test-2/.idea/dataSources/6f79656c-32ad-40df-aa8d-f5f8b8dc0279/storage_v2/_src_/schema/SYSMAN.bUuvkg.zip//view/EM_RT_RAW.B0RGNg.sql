create view EM$RT_RAW
            (TARGET_GUID, METRIC_NAME, COLLECTION_TIMESTAMP, STATUS, STATUS_DESCRIPTION, SUBMIT_ACTION_TIMESTAMP,
             LOAD_ACTION_TIMESTAMP, ELAPSED_TIME, URL_BASE, URL_LINK, URL_FILENAME, VISITOR_NODE, VISITOR_DOMAIN,
             VISITOR_IP, VISITOR_IP_NUM, SERVER_IN_TIMESTAMP, SERVER_OUT_TIMESTAMP, SERVER_LATENCY_TIME, DATABASE_TIME,
             BROWSER_NAME, BROWSER_VERSION, OS_NAME, OS_VERSION, USERNAME, COOKIE_INDEX, CACHE_RENDERED)
as
SELECT target_guid, metric_name, collection_timestamp,
      status, status_description, submit_action_timestamp, load_action_timestamp,
      elapsed_time,
      url_base, url_base || url_filename, url_filename,
      visitor_node, visitor_domain, visitor_ip, visitor_ip_num,
      server_in_timestamp, server_out_timestamp, server_latency_time, database_time,
      browser_name, browser_version, os_name, os_version,
      username, cookie_index, cache_rendered
    FROM MGMT_RT_METRICS_RAW
/

