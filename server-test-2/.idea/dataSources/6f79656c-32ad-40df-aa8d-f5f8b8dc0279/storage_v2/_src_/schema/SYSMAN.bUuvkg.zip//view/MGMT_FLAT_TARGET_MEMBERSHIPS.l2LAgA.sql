create view MGMT_FLAT_TARGET_MEMBERSHIPS as
SELECT ct.target_name composite_target_name,
         ct.target_type composite_target_type,
         ct.target_guid composite_target_guid,
         mt.target_name member_target_name,
         mt.target_type member_target_type,
         mt.target_guid member_target_guid,
         (
          SELECT CASE
                   WHEN (count(*) = 0)
                     THEN 0
                   ELSE 1
                 END
             FROM mgmt_flat_target_assoc f2,
                  mgmt_target_assocs m,
                  mgmt_targets ct,
                  mgmt_type_properties p,
                  mgmt_target_assoc_defs def
            WHERE p.property_name = 'is_group'
              AND m.assoc_guid = def.assoc_guid
              AND def.assoc_def_name = 'contains'
              AND def.scope_target_type = ' '
              AND f2.is_membership = 1
              AND p.target_type   = ct.target_type
              AND ct.target_guid = m.source_target_guid
              AND (m.source_target_guid = f2.assoc_target_guid OR
                   m.source_target_guid = f2.source_target_guid)
              AND a.source_target_guid = f2.source_target_guid
              AND a.assoc_target_guid = m.assoc_target_guid
         )is_group_memb
    FROM mgmt_flat_target_assoc a,
         mgmt_targets ct,
         mgmt_targets mt
   WHERE a.is_membership = 1
     AND ct.target_guid = a.source_target_guid
     AND mt.target_guid = a.assoc_target_guid
/

