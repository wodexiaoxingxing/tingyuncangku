create view MGMT$DB_TABLESPACES_ALL as
select
  g.host_name,
  s.ecm_snapshot_id as snapshot_guid,
  s.target_name,
  s.target_type,
  s.target_guid,
  s.start_timestamp as collection_timestamp,
  s.is_current,
  t.tablespace_name,
  t.contents,
  t.status,
  t.extent_management,
  t.allocation_type,
  t.logging,
  t.tablespace_size,
  t.initial_ext_size,
  t.next_extent,
  t.increment_by,
  t.max_extents,
  t.tablespace_used_size,
  t.segment_space_management,
  t.block_size,
  t.min_extents,
  t.min_extlen,
  t.bigfile
from
  mgmt_targets g,
  mgmt_db_tablespaces_ecm t,
  mgmt$ecm_visible_snapshots s
where
  s.ecm_snapshot_id = t.ecm_snapshot_id and
  s.target_guid = g.target_guid (+)
/

