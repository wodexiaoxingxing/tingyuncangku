create view MGMT$CS_CONFIG_STANDARDS as
SELECT NVL(nem.message, cs.cs_dname) as cs_name,
	  cs.cs_dname,
          cs.author,
          cs.version,
          cs.cs_guid,
          cs.target_type,
          NVL(dem.message, cs.description) as description,
	  cs.description,
          ecm_util.config_std_keyword_list(cs.cs_guid) keywords
     FROM mgmt_cs_config_standard cs,
            (select message, message_id from mgmt_messages
            where subsystem = 'CONFIG_STD' and language_code = 'en' and country_code = ' ') nem,
            (select message, message_id from mgmt_messages
            where subsystem = 'CONFIG_STD' and language_code = 'en' and country_code = ' ') dem
     WHERE cs.cs_dname  = nem.message_id(+)
       AND cs.description = dem.message_id(+)
WITH READ ONLY
/

