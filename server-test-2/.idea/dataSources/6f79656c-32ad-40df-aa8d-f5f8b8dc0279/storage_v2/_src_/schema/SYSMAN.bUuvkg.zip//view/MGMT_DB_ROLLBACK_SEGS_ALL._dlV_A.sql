create view MGMT$DB_ROLLBACK_SEGS_ALL as
select
  g.host_name,
  s.ecm_snapshot_id as snapshot_guid,
  s.target_name,
  s.target_type,
  s.target_guid,
  s.start_timestamp as collection_timestamp,
  s.is_current,
  r.rollname,
  r.status,
  r.tablespace_name,
  r.extents,
  r.rollsize,
  r.initial_size,
  r.next_size,
  r.maximum_extents,
  r.minimum_extents,
  r.pct_increase,
  r.optsize,
  r.aveactive,
  r.wraps,
  r.shrinks,
  r.aveshrink,
  r.hwmsize
from
  mgmt_targets g,
  mgmt_db_rollback_segs_ecm r,
  mgmt$ecm_visible_snapshots s
where
  s.ecm_snapshot_id = r.ecm_snapshot_id and
  s.target_guid = g.target_guid (+)
/

