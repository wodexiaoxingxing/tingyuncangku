create view MGMT$ESA_TRC_AUD_PERM_REP_NT as
SELECT  targets.target_guid AS "TARGET_GUID",
        targets.target_name AS "TARGET_NAME",
        collection.value2 as PRINCIPAL,
        decode(property,'nt_audit_file_dest','Audit file destination',
                        'nt_user_dump_dest','User dump destination',
                        'nt_background_dump_dest','Background dump destination',
                        'nt_core_dump_dest','Core dump destination') as OBJECT_NAME,
        collection.value AS permission
FROM esm_collection_latest collection, mgmt_targets targets
WHERE collection.target_guid = targets.target_guid and
      property in ('nt_audit_file_dest',
                   'nt_user_dump_dest',
                   'nt_background_dump_dest',
                   'nt_core_dump_dest')
/

