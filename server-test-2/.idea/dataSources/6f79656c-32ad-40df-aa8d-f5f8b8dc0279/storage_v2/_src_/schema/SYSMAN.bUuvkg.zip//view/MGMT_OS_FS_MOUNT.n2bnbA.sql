create view MGMT$OS_FS_MOUNT as
select
  s.target_name as host_name,
  f.resource_name as resource_name,
  f.type as type,
  f.mount_location as mount_location,
  f.mount_options as mount_options,
  s.snapshot_guid
from
  mgmt_targets t,
  mgmt_ecm_snapshot s,
  mgmt_hc_fs_mount_details f
where
  t.target_type = 'host' and
  t.target_name = s.target_name and
  s.snapshot_type = 'host_configuration' and
  s.target_type = 'host' and
  s.is_current = 'Y' and
  s.snapshot_guid = f.snapshot_guid
/

