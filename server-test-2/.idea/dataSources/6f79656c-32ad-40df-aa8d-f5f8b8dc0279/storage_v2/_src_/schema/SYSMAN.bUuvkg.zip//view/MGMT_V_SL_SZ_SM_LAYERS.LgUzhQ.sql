create view MGMT_V_SL_SZ_SM_LAYERS as
SELECT  SUM(DECODE( a.storage_layer, 'OS_DISK',
          a.bottom_sizeb, 0)) total_disks_sizeb,
        SUM(DECODE( a.storage_layer, 'VOLUME_MANAGER',
          a.bottom_sizeb, 0)) total_volumes_sizeb,
        SUM(DECODE( a.storage_layer, 'NFS-WRITE',
          a.bottom_sizeb, 0)) total_writeable_nfs_sizeb,
        SUM(DECODE( a.storage_layer, 'LOCAL_FILESYSTEM',
          a.bottom_sizeb, 0)) total_fs_sizeb,
        SUM(DECODE( a.storage_layer, 'OS_DISK',
           a.total_freeb, 0)) disks_total_freeb,
        SUM(DECODE( a.storage_layer, 'VOLUME_MANAGER',
           a.total_freeb, 0)) volumes_total_freeb,
        SUM(DECODE( a.storage_layer, 'NFS-WRITE',
           a.total_freeb, 0)) nfswriteable_total_freeb,
        SUM(DECODE( a.storage_layer, 'LOCAL_FILESYSTEM',
           a.total_freeb, 0)) fs_total_freeb,
        SUM(DECODE( a.storage_layer, 'VOLUME_MANAGER',
           a.top_allocatedb, 0)) volumes_total_allocated,
        SUM(DECODE( a.storage_layer, 'OS_DISKS',
           a.top_allocatedb, 0)) disks_total_allocated,
        SUM(DECODE( a.storage_layer, 'VOLUME_MANAGER',
           a.top_unallocatedb, 0)) volumes_total_unallocated,
        SUM(DECODE( a.storage_layer, 'OS_DISKS',
           a.top_unallocatedb, 0)) disks_total_unallocated
FROM   mgmt_v_sl_size_summary a
/

