create trigger EM_DELETE_COLL_ITEM_PROPERTY
    instead of delete
    on MGMT_COLLECTION_PROPERTIES
    for each row
BEGIN
  IF EMDW_LOG.P_IS_DEBUG_SET THEN
    EMDW_LOG.INFO('em_delete_coll_item_property.. Deleting ' ||
       ' Target_guid = ' || :new.target_guid ||
       ' Metric guid = ' || :new.metric_guid ||
       ' Coll_name = ' || :new.coll_name ||
       ' property_name = ' || :new.property_name, 'EM_DELETE_COLL_ITEM_PROPERTY');
  END IF ;
  -- Delete coll_item property
  EM_COLL_UTIL.delete_coll_item_property(
      p_object_guid => :old.target_guid,
      p_metric_guid => :old.metric_guid,
      p_coll_name   => :old.coll_name,
      p_property_name => :old.property_name);
END;
/

