create view MGMT$DB_DATAFILES as
select
  g.host_name,
  s.target_name,
  s.target_type,
  s.target_guid,
  s.start_timestamp as collection_timestamp,
  f.file_name,
  f.tablespace_name,
  f.status,
  f.file_size,
  f.autoextensible,
  f.increment_by,
  f.max_file_size,
  f.os_storage_entity
from
  mgmt_targets g,
  mgmt_db_datafiles_ecm f,
  mgmt_ecm_gen_snapshot s
where
  s.snapshot_guid = f.ecm_snapshot_id and
  s.target_guid = g.target_guid and
  s.is_current = 'Y'
/

