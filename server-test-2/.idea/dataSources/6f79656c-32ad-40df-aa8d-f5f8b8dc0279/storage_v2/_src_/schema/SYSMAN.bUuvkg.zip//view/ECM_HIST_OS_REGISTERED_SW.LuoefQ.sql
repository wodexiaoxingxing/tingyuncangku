create view ECM$HIST_OS_REGISTERED_SW as
SELECT
  snapshot_guid AS ecm_snapshot_id,
  name,
  vendor_name,
  version,
  installation_date,
  installed_location,
  description,
  vendor_software_specific_info
FROM mgmt_hc_vendor_sw_summary
WITH READ ONLY
/

