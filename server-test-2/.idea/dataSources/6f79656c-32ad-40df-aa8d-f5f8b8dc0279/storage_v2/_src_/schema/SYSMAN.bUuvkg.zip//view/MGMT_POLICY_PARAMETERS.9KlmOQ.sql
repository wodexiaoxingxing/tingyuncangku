create view MGMT$POLICY_PARAMETERS
            (TARGET_TYPE, METRIC_NAME, POLICY_NAME, POLICY_GUID, PARAMETER_NAME, PARAMETER_NAME_NLSID,
             PARAMETER_TYPE) as
SELECT p.target_type, m.metric_name, p.policy_name, p.policy_guid,
           pp.param_name,pp.param_name_nlsid,
           DECODE(pp.param_type,
	            1, 'NUMERIC',
                    2, 'STRING',
                    'UNKNOWN')
      FROM mgmt_policies p,
           mgmt_policy_parameters pp,
           (SELECT distinct metric_guid, metric_name
              FROM mgmt_metrics) m
     WHERE p.metric_guid = m.metric_guid
       AND p.policy_guid = pp.policy_guid
       AND p.policy_type = 2
WITH READ ONLY
/

