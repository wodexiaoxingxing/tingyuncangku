create view MGMT$HA_INIT_PARAMS_ALL as
select
  g.host_name,
  s.ecm_snapshot_id as snapshot_guid,
  s.target_name,
  s.target_type,
  s.target_guid,
  s.start_timestamp as collection_timestamp,
  s.is_current,
  p.name,
  p.value
from
  mgmt_targets g,
  mgmt_ha_init_params_ecm p,
  mgmt$ecm_visible_snapshots s
where
  s.ecm_snapshot_id = p.ecm_snapshot_id and
  s.target_guid = g.target_guid (+)
/

