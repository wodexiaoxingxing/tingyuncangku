create view MGMT$HA_RMAN_CONFIG as
select
  g.host_name,
  s.target_name,
  s.target_type,
  s.target_guid,
  s.start_timestamp as collection_timestamp,
  a.name,
  a.value
from
  mgmt_targets g,
  mgmt_ha_rman_config_ecm a,
  mgmt_ecm_gen_snapshot s
where
  s.snapshot_guid = a.ecm_snapshot_id and
  s.target_guid = g.target_guid and
  s.is_current = 'Y'
/

