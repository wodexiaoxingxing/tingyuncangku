create view MGMT$ALERT_HISTORY as
SELECT
            t.target_name, t.target_type, t.target_guid, s.violation_guid,
            s.violation_level,s.cycle_guid,
            m.metric_name, m.metric_column,s.policy_guid,
            m.metric_label,
            CASE
              WHEN m.is_transposed = 0 THEN
                 m.column_label
              ELSE
                 s.key_value
              END,
            s.key_value, null, null, null, null,
            s.collection_timestamp,
            DECODE (s.violation_level, 15, 'Clear', 20, 'Warning', 25, 'Critical', 'Unknown'),
            s.violation_duration, s.message,s.message_nlsid,s.message_params,
            s.action_message,s.action_message_nlsid,s.action_message_params,
            DECODE (s.violation_type, 0, 'Threshold Violation',
                                      1, 'Availability',
                                      2, 'Resource',
                                      3, 'Policy Violation',
                                         'Unknown'),
            tt.type_display_name,
            s.acknowledged,
            s.acknowledged_by
          FROM
            mgmt_targets t,
            mgmt_metrics m,
            mgmt_violations s,
            mgmt_target_types tt
          WHERE t.target_guid = s.target_guid
            and m.metric_guid = s.policy_guid
            and t.target_type = m.target_type
            and tt.target_type = t.target_type
            and t.type_meta_ver = m.type_meta_ver
            and m.num_keys < 2
            and s.violation_type IN (0,1,2)
            and (t.category_prop_1 = m.category_prop_1
                 or m.category_prop_1 = ' ')
            and (t.category_prop_2 = m.category_prop_2
                 or m.category_prop_2 = ' ')
            and (t.category_prop_3 = m.category_prop_3
                 or m.category_prop_3 = ' ')
            and (t.category_prop_4 = m.category_prop_4
                 or m.category_prop_4 = ' ')
            and (t.category_prop_5 = m.category_prop_5
                 or m.category_prop_5 = ' ')
     UNION ALL
        SELECT
            t.target_name, t.target_type, t.target_guid, s.violation_guid,s.violation_level,s.cycle_guid,
            m.metric_name, m.metric_column,s.policy_guid,
            m.metric_label,
            CASE
              WHEN m.is_transposed = 0 THEN
                 m.column_label
              ELSE
                 k.key_part1_value
              END,
            k.key_part1_value,  k.key_part2_value,  k.key_part3_value,
            k.key_part4_value,  k.key_part5_value,
            s.collection_timestamp,
            DECODE (s.violation_level, 15, 'Clear', 20, 'Warning', 25, 'Critical', 'Unknown'),
            s.violation_duration, s.message,s.message_nlsid,s.message_params,
            s.action_message,s.action_message_nlsid,s.action_message_params,
            DECODE (s.violation_type, 0, 'Threshold Violation',
                                      1, 'Availability',
                                      2, 'Resource',
                                      3, 'Policy Violation',
                                          'Unknown'),
            tt.type_display_name,
            s.acknowledged,
            s.acknowledged_by
          FROM
            mgmt_targets t,
            mgmt_metrics m,
                        mgmt_target_types tt,
            mgmt_violations s,
                        mgmt_metrics_composite_keys k
          WHERE t.target_guid = s.target_guid
            and m.metric_guid = s.policy_guid
            and t.target_type = m.target_type
            and tt.target_type = t.target_type
            and t.type_meta_ver = m.type_meta_ver
            and m.num_keys > 1
            and s.violation_type IN (0,1,2)
            and (t.category_prop_1 = m.category_prop_1
                 or m.category_prop_1 = ' ')
            and (t.category_prop_2 = m.category_prop_2
                 or m.category_prop_2 = ' ')
            and (t.category_prop_3 = m.category_prop_3
                 or m.category_prop_3 = ' ')
            and (t.category_prop_4 = m.category_prop_4
                 or m.category_prop_4 = ' ')
            and (t.category_prop_5 = m.category_prop_5
                 or m.category_prop_5 = ' ')
            and s.target_guid = k.target_guid
            and s.key_value = k.composite_key
    WITH READ ONLY
/

