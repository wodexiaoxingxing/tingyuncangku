create view MGMT$CSM_MT_DSR_DIST_DAILY as
SELECT
  tg.target_name, tg.target_type,
  st.target_name, st.target_type,
  ru.visitor_domain, ru.visitor_subnet, rg.region_name,
  ru.rollup_timestamp, ru.metric_name,
  ru.num_seconds, ru.hits
FROM
  MGMT_RT_DOMAIN_DIST_1DAY ru,
  MGMT_TARGET_ASSOCS tm,
  MGMT_TARGETS tg,
  MGMT_RT_REGIONS rg,
  MGMT_TARGETS st,
  MGMT_TARGET_ASSOC_DEFS d
WHERE
  tg.target_guid = ru.target_guid
  AND ru.target_guid = tm.assoc_target_guid (+)
  AND tm.source_target_guid = rg.target_guid (+)
  AND tm.assoc_guid = d.assoc_guid
  AND d.assoc_def_name = 'supports_eum_on'
  AND d.scope_target_type = ' '
  AND st.target_guid = tm.source_target_guid
  AND rg.region_guid IN (
   SELECT mp.region_guid /*+ INDEX(mgmt_rt_region_entries IDX_REGION_MIN_IP) */
     FROM mgmt_rt_region_entries e, mgmt_rt_region_mapping mp
     WHERE e.id = mp.id
       AND ((e.min_ip >= 0 AND
             ru.visitor_subnet_num BETWEEN e.min_ip AND e.max_ip)
         OR (e.min_ip < 0 AND UPPER(substr('.'||ru.visitor_domain,
             -LENGTH(e.domain)-1)) = UPPER('.'||e.domain))))
  AND ru.dist_value_type = 0
WITH READ ONLY
/

