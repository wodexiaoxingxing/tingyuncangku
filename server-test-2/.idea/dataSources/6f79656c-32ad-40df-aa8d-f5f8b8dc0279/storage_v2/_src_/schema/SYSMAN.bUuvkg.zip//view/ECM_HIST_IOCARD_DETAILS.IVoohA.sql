create view ECM$HIST_IOCARD_DETAILS as
SELECT
  snapshot_guid AS ecm_snapshot_id,
  vendor_name,
  name,
  freq_in_mhz,
  bus,
  revision,
  count(*) AS count
FROM
  mgmt_hc_iocard_details
GROUP BY snapshot_guid,vendor_name,name,freq_in_mhz,bus,revision
WITH READ ONLY
/

