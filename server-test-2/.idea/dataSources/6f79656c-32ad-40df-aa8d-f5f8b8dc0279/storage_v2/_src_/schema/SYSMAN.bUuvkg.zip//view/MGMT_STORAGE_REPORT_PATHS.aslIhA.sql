create view MGMT$STORAGE_REPORT_PATHS as
SELECT  b.target_name,
  b.target_type,
  a.key_value,
  c.name,
  a.value,
  a.file_type,
  c.storage_layer,
  c.entity_type
FROM mgmt_storage_report_alias a,
     mgmt$ecm_current_snapshots b,
     mgmt_storage_report_data c
WHERE a.ecm_snapshot_id = b.ecm_snapshot_id
AND   c.ecm_snapshot_id = b.ecm_snapshot_id
AND   c.key_value = a.key_value
AND   b.snapshot_type = 'host_storage'
/

