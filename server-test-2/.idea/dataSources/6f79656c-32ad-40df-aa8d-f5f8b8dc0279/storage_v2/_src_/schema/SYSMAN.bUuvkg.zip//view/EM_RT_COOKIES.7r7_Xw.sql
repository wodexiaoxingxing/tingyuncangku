create view EM$RT_COOKIES as
SELECT
      target_guid, metric_name, collection_timestamp,
      status, status_description,
      submit_action_timestamp, load_action_timestamp,
      elapsed_time, url_filename, url_base,
      visitor_node, visitor_domain, visitor_ip,
      server_in_timestamp, server_out_timestamp,
      server_latency_time, database_time,
      browser_name, browser_version,
      os_name, os_version, username, t.name, t.value
   FROM
      MGMT_RT_METRICS_RAW s, MGMT_RT_COOKIE_DATA t
   WHERE s.cookie_index=t.raw_index
/

