create trigger MGMT_CREDS_UPD
    after insert or update
    on MGMT_CREDENTIALS2
DECLARE
  l_updating BOOLEAN := false;
BEGIN
    IF UPDATING THEN
        l_updating := true;
    END IF;
    MGMT_CREDENTIAL.post_process(l_updating);
END;
/

