create view MGMT$CS_EVAL_SUMMARY_STANDARD as
SELECT t.target_name,
      t.target_type,
      t.target_guid,
      NVL(nem.message, cs.cs_dname) as cs_name,
      cs.cs_dname as cs_name_nlsid,
      cs.cs_guid as cs_guid,
      cs.author as cs_author,
      cs.version as cs_version,
      e.last_evaluation_date as last_evaln_timestamp,
      ROUND(e.compliance_score) as compliance_score,
      (e.crit_violations + e.warn_violations + e.info_violations) as total_violations,
      e.non_compliant_rules as total_non_compliant_rules,
      e.compliant_rules as total_compliant_rules,
      e.error_rules as total_error_rules,
      e.unknown_rules as total_unknown_rules
   FROM mgmt_targets t,
        mgmt_cs_config_standard cs,
        mgmt_cs_eval_summ_rqs e,
       (select message, message_id from mgmt_messages
        where subsystem = 'CONFIG_STD' and language_code = 'en' and country_code = ' ') nem
  WHERE t.target_guid = e.target_guid
    AND cs.cs_guid = e.rqs_guid
    AND cs.cs_dname = nem.message_id(+)
WITH READ ONLY
/

