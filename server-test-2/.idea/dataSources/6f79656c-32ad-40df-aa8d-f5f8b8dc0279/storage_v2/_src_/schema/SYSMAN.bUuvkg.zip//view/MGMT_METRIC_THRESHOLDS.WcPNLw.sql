create view MGMT_METRIC_THRESHOLDS
            (TARGET_GUID, METRIC_GUID, COLL_NAME, KEY_VALUE, KEY_OPERATOR, IS_PUSH, WARNING_OPERATOR, WARNING_THRESHOLD,
             CRITICAL_OPERATOR, CRITICAL_THRESHOLD, NUM_OCCURENCES, NUM_WARNINGS, NUM_CRITICALS, EVAL_ORDER, FIXIT_JOB,
             MESSAGE, MESSAGE_NLSID)
as
SELECT pa.object_guid, pa.policy_guid, pa.coll_name, pac.key_value, pac.key_operator,
         pac.is_push, pac.condition_operator, pacp.warn_threshold,
         pac.condition_operator, pacp.crit_threshold,
         pac.num_occurrences, 0, 0,
         pac.eval_order, pac.fixit_job, pac.message, pac.message_nlsid
    FROM mgmt_policy_assoc pa,
         mgmt_policy_assoc_cfg pac,
         mgmt_policy_assoc_cfg_params pacp
   WHERE pa.policy_guid = pac.policy_guid
     AND pa.object_guid = pac.object_guid
     AND pa.coll_name = pac.coll_name
     AND pac.policy_guid = pacp.policy_guid
     AND pac.object_guid = pacp.object_guid
     AND pac.coll_name = pacp.coll_name
     AND pac.key_value = pacp.key_value
     AND pac.key_operator = pacp.key_operator
     AND pa.object_type = 2
     AND pa.policy_type = 1
     AND pacp.param_name = ' '
/

create trigger EM_INSERT_POLICY_INFO
    instead of insert
    on MGMT_METRIC_THRESHOLDS
    for each row
begin
    -- missing source code
end
/

create trigger EM_DELETE_POLICY_CFG
    instead of delete
    on MGMT_METRIC_THRESHOLDS
    for each row
begin
    -- missing source code
end
/

create trigger EM_UPDATE_POLICY_CFG
    instead of update
    on MGMT_METRIC_THRESHOLDS
    for each row
begin
    -- missing source code
end
/

