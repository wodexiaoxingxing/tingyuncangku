create view MGMT$JOB_ANNOTATIONS
            (JOB_NAME, JOB_OWNER, JOB_STATUS, OCCURRENCE_TIMESTAMP, ANNOTATION_MESSAGE, ANNOTATION_TIMESTAMP,
             ANNOTATED_BY) as
SELECT
	     j.job_name, j.job_owner,
             decode(sc.newstate, 1, 'SCHEDULED', 2, 'EXECUTING',
				 3, 'ABORTED', 4, 'FAILED',
				 5, 'COMPLETED', 6, 'SUSPENDED',
				 7, 'AGENT DOWN', 8, 'STOPPED',
				 9, 'SUSPENDED/LOCK', 10, 'SUSPENDED/EVENT',
				 11, 'SUSPENDED/BLACKOUT', 12, 'STOP PENDING',
				 13, 'SUSPEND PENDING', 14, 'INACTIVE',
				 15, 'QUEUED', 16, 'FAILED',
				 17, 'WAITING', 18, 'SKIPPED',
				 newstate),
             sc.occurred, a.message, a.timestamp, a.user_name
           FROM mgmt_annotation a,
                mgmt_job_state_changes sc,
                mgmt_job j
           WHERE a.source_obj_type = 3
             AND sc.state_change_guid = a.source_obj_guid
             AND j.job_id = sc.job_id
	WITH READ ONLY
/

