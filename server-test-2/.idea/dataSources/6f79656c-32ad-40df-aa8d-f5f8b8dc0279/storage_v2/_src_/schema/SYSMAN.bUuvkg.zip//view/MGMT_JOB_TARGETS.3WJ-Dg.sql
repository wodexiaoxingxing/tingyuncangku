create view MGMT$JOB_TARGETS as
SELECT
           j.job_name, j.job_owner, j.job_id, j.job_type,
           t.target_name, t.target_type, t.target_guid
        FROM
            mgmt_job j,
            mgmt_job_target jt,
            mgmt_targets t
        WHERE
            j.job_id = jt.job_id (+) AND
            HEXTORAW('0000000000000000')=jt.execution_id (+) AND
            jt.target_guid=t.target_guid (+) AND
            j.system_job = 0 AND
            j.nested=0 AND
            j.is_corrective_action=0
    WITH READ ONLY
/

