create view MGMT$OS_COMPONENTS as
select
  t.target_name as host,
  c.name,
  c.type,
  c.version,
  c.description,
  c.installation_date,
  s.snapshot_guid
from
  mgmt_targets t,
  mgmt_ecm_snapshot s,
  mgmt_hc_os_components c
where
  t.target_type = 'host' and
  t.target_name = s.target_name and
  s.snapshot_type = 'host_configuration' and
  s.target_type = 'host' and
  s.is_current = 'Y' and
  s.snapshot_guid = c.snapshot_guid
/

