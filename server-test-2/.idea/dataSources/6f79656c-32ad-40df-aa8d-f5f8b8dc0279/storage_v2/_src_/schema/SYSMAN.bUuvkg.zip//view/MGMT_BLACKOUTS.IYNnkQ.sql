create view MGMT$BLACKOUTS
            (BLACKOUT_NAME, BLACKOUT_GUID, REASON, DESCRIPTION, STATUS, CREATED_BY, LAST_START_TIME, LAST_END_TIME,
             SCHEDULED_TIME, SCHEDULE_TYPE, SCHEDULE_START_TIME, SCHEDULE_END_TIME, DURATION)
as
SELECT b.blackout_name, b.blackout_guid, br.reason, b.blackout_desc,
               DECODE(b.blackout_status,
                      0, 'Scheduled',
                      1, 'Start Processing',
                      2, 'Start Partial',
                      4, 'Started',
                      5, 'Stop Pending',
                      6, 'Stop Failed',
                      7, 'Stop Partial',
                      8, 'Edit Failed',
                      9, 'Edit Partial',
                     10, 'Stopped',
                     11, 'Ended',
                     12, 'Partial Blackout',
                     13, 'Modify Pending', b.blackout_status),
                b.created_by, b.last_start_time, b.last_end_time,
                b.scheduled_time,
                DECODE (s.frequency_code, 1, 'One Time',
                                     2, 'Interval',
                                     3, 'Daily',
                                     4, 'Weekly',
                                     5, 'Monthy',
                                     6, 'Yearly'),
                s.start_time, s.end_time, s.duration
        FROM    MGMT_BLACKOUTS b, MGMT_BLACKOUT_SCHEDULE s,
                MGMT_BLACKOUT_REASON br
        WHERE   b.blackout_guid=s.blackout_guid
        AND     b.reason_id=br.reason_id (+)
        WITH READ ONLY
/

