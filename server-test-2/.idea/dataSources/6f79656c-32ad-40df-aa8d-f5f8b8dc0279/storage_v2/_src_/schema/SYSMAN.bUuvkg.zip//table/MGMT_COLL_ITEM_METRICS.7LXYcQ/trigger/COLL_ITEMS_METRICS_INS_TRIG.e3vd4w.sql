create trigger COLL_ITEMS_METRICS_INS_TRIG
    before insert
    on MGMT_COLL_ITEM_METRICS
    for each row
DECLARE
  l_coll_cnt NUMBER := 0;
BEGIN

  -- Check to see if the metric has duplicate default collections

  -- Get all cat prop combinations for the given coll_name
  FOR cp_rec IN (SELECT target_type, type_meta_ver, coll_name,
                        category_prop_1, category_prop_2, category_prop_3,
                        category_prop_4, category_prop_5
                   FROM mgmt_coll_items
                  WHERE target_type = :new.target_type
                    AND type_meta_ver = :new.type_meta_ver
                    AND coll_name = :new.coll_name)
  LOOP
    -- Check to see if there are any overlaps with the cat prop list

    -- For the same target_type, type_meta_ver, metric, check to see
    -- if there is any other default collection
    SELECT COUNT(*) INTO l_coll_cnt
      FROM mgmt_coll_items ci, mgmt_coll_item_metrics cim
     WHERE ci.target_type = cim.target_type
       AND ci.type_meta_ver = cim.type_meta_ver
       AND ci.coll_name = cim.coll_name
       AND ci.target_type = cp_rec.target_type
       AND ci.type_meta_ver = cp_rec.type_meta_ver
       AND cim.metric_guid = :new.metric_guid
       AND (   (ci.category_prop_1 = cp_rec.category_prop_1)
            OR (ci.category_prop_1 = ' ')
            OR (cp_rec.category_prop_1 = ' ') )
       AND (   (ci.category_prop_2 = cp_rec.category_prop_2)
            OR (ci.category_prop_2 = ' ')
            OR (cp_rec.category_prop_2 = ' ') )
       AND (   (ci.category_prop_3 = cp_rec.category_prop_3)
            OR (ci.category_prop_3 = ' ')
            OR (cp_rec.category_prop_3 = ' ') )
       AND (   (ci.category_prop_4 = cp_rec.category_prop_4)
            OR (ci.category_prop_4 = ' ')
            OR (cp_rec.category_prop_4 = ' ') )
       AND (   (ci.category_prop_5 = cp_rec.category_prop_5)
            OR (ci.category_prop_5 = ' ')
            OR (cp_rec.category_prop_5 = ' ') )
       AND ci.coll_name <> cp_rec.coll_name;

    IF (EMDW_LOG.P_IS_DEBUG_SET)THEN
       EMDW_LOG.DEBUG('coll_item_metrics_insert_trigger: Colls overlapping cnt = ' || l_coll_cnt,
         MGMT_COLLECTION.G_MODULE_NAME);
    END IF;

    IF (l_coll_cnt > 0) THEN
       raise_application_error(MGMT_GLOBAL.OVERLAPPING_CATPROP_DEF_ERR,
         MGMT_GLOBAL.OVERLAPPING_CATPROP_DEF_ERR_M ||
         ' target type = [' || :new.target_type || ']' ||
         ' type ver = [' || :new.type_meta_ver || ']' ||
         ' coll name = [' || :new.coll_name || ']' ||
         ' metric_guid = [' || :new.metric_guid || ']' ||
         ' cat prop1 = [' || cp_rec.category_prop_1 || ']' ||
         ' cat prop2 = [' || cp_rec.category_prop_2 || ']' ||
         ' cat prop3 = [' || cp_rec.category_prop_3 || ']' ||
         ' cat prop4 = [' || cp_rec.category_prop_4 || ']' ||
         ' cat prop5 = [' || cp_rec.category_prop_5 || ']' );
    END IF;

  END LOOP;

END;
/

