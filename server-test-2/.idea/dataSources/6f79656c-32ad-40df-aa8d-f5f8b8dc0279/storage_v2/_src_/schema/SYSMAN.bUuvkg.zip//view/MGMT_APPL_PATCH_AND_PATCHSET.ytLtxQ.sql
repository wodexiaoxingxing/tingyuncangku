create view MGMT$APPL_PATCH_AND_PATCHSET as
SELECT
  ap.patch_id,
  ap.patch_type as  type,
  prod.product_name as product,
  rel.release_name as patch_release,
  plat.platform_name as platform,
  ecm_util.patch_advisory_list(pp.patch_guid) as advisory,
  patch.host_name,
  patch.home_location,
  patch.patch_guid,
  patch.target_guid
FROM
  mgmt_bug_available_patch ap,
  mgmt_bug_patch_platform  pp,
  mgmt_aru_products  prod,
  mgmt_aru_releases        rel,
  mgmt_aru_platforms        plat,
  mgmt_bug_adv_home_patch patch,
  mgmt_targets targets
WHERE
  ap.ap_guid = pp.ap_guid  and
  ap.product_id = prod.product_id  and
  ap.release_id = rel.release_id  and
  pp.PLATFORM_ID = plat.PLATFORM_ID  and
  pp.patch_guid = patch.patch_guid and
  patch.target_guid = targets.target_guid
WITH READ ONLY
/

