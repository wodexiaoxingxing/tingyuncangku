create view EM$RT_WATCH_LIST_31DAY
            (COMPOSITE_TARGET_GUID, COMPOSITE_TARGET_NAME, COMPOSITE_TARGET_TYPE, METRIC_NAME, DISPLAY_NAME,
             URL_FILENAME, URL_LINK, RESPONSE_TIME_AVERAGE, RESPONSE_TIME_MINIMUM, RESPONSE_TIME_MAXIMUM,
             RESPONSE_TIME_STDDEV, HITS, CRITICAL_THRESHOLD, WARNING_THRESHOLD, RESPONSE_TIME_CURRENT_AVG)
as
SELECT f.composite_target_guid,
        f.composite_target_name, f.composite_target_type,
        nvl(d.metric_name, 'latency'),
        f.display_name "DISPLAY_NAME",
        f.url_filename,
        max(d.url_link),
        sum(response_time_average*hits)/sum(hits), min(response_time_minimum),
        max(response_time_maximum), sum(RESPONSE_TIME_SDEV*hits)/sum(hits),
        sum(hits),
        to_number(0),
        to_number(0),
        max((select response_time_current_avg from EM$RT_CURRENT_URL_AVG_1DAY curr
          where curr.COMPOSITE_TARGET_GUID = f.composite_target_guid
          and curr.METRIC_NAME = d.metric_name
          and curr.URL_FILENAME = f.url_filename))
    FROM MGMT_RT_URL_1DAY d, em$rt_member_target_urls f
    WHERE f.member_target_guid = d.target_guid(+)
          AND f.url_filename = d.url_filename(+)
    GROUP BY f.composite_target_guid,
        f.composite_target_name, f.composite_target_type,
        f.display_name, f.url_filename, nvl(d.metric_name, 'latency')
/

