create view MGMT_SEVERITY as
SELECT target_guid, policy_guid, key_value, collection_timestamp,
         violation_level, violation_type, violation_duration, violation_guid,
	 annotated_flag, notification_status,
	 message, message_nlsid, message_params,
	 action_message, action_message_nlsid, action_message_params, advisory_id,
	 load_timestamp, user_name
    FROM mgmt_violations
   WHERE violation_type IN (0, 1, 2)
/

comment on table MGMT_SEVERITY is 'The MGMT_SEVERITY view contains the severity information.
    Severities are alerts that inform the user when a metric threshold
    Test or a policy violation has failed.'
/

comment on column MGMT_SEVERITY.TARGET_GUID is ' The target guid of the severity'
/

comment on column MGMT_SEVERITY.METRIC_GUID is ' The metric guid of the severity'
/

comment on column MGMT_SEVERITY.KEY_VALUE is ' The key value of the severity'
/

comment on column MGMT_SEVERITY.COLLECTION_TIMESTAMP is ' The timestamp at which the severity occurred'
/

comment on column MGMT_SEVERITY.SEVERITY_CODE is 'The severity codes for error, warnin, critical etc.
    These codes are backwards compatible with EM 9i and EM 10gR1.
      15 - CLEAR
      18 - INFO
      20 - WARNING
      25 - CRITICAL
     115 - AGENT UNREACHABLE CLEART
     125 - AGENT UNREACHABLE START
     215 - BLACKOUT END
     225 - BLACKOUT START
     315 - METRIC ERROR END
     325 - METRIC ERROR START
    Codes 115 and above are applicable only for response/status metric'
/

comment on column MGMT_SEVERITY.SEVERITY_TYPE is ' The severity type allows an application that is selecting
      from this table to filter the rows returned by the type of
      severity.  Values in this column are:
           0 - METRIC THRESHOLD ALERT
           1 - AVAILABILITY'
/

comment on column MGMT_SEVERITY.SEVERITY_DURATION is 'The delta time, in hours, from when the severity was logged
    until it was cleared.'
/

comment on column MGMT_SEVERITY.SEVERITY_GUID is ' The unique id of the severity. Defaults to SYS_GUID()'
/

comment on column MGMT_SEVERITY.ANNOTATED_FLAG is 'A flag to indicate whether the severity is annotated or not.'
/

comment on column MGMT_SEVERITY.NOTIFICATION_STATUS is 'The column used by the notification sub system to determine
    notification status of the severity.'
/

comment on column MGMT_SEVERITY.MESSAGE is 'The message of the severity.  The messages usually contain
    details about what triggered this severity.'
/

comment on column MGMT_SEVERITY.MESSAGE_NLSID is 'The NLS ID of the severity message.'
/

comment on column MGMT_SEVERITY.MESSAGE_PARAMS is 'URL encoded parameters separated by "&" to be used to
    format the severity message.'
/

comment on column MGMT_SEVERITY.ACTION_MESSAGE is 'Suggested action message in english for this severity'
/

comment on column MGMT_SEVERITY.ACTION_NLSID is 'The NLS ID of the action message.'
/

comment on column MGMT_SEVERITY.ACTION_MESSAGE_PARAMS is 'URL encoded parameters for translating action message'
/

comment on column MGMT_SEVERITY.ADVISORY_ID is 'Advisory ID of the severity'
/

comment on column MGMT_SEVERITY.LOAD_TIMESTAMP is 'Date and time when the severity was loaded'
/

comment on column MGMT_SEVERITY.USER_NAME is 'Name of the user to load the severity'
/

create trigger EM_INSERT_VIOLATIONS
    instead of insert
    on MGMT_SEVERITY
    for each row
begin
    -- missing source code
end
/

create trigger EM_UPDATE_VIOLATIONS
    instead of update
    on MGMT_SEVERITY
    for each row
begin
    -- missing source code
end
/

create trigger EM_DELETE_VIOLATIONS
    instead of delete
    on MGMT_SEVERITY
    for each row
begin
    -- missing source code
end
/

