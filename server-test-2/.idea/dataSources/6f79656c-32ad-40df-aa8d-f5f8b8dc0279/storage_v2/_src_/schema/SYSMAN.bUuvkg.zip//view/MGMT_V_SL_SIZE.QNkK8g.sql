create view MGMT_V_SL_SIZE
            (STORAGE_LAYER, ENTITY_TYPE, NAME, TOP_ALLOCATEDB, TOP_UNALLOCATEDB, TOTAL_FREEB, BOTTOM_SIZEB) as
SELECT  DECODE(a.storage_layer,'NFS',
         DECODE(a.nfs_mount_privilege,'WRITE',
          'NFS-WRITE','NFS-READ'),
         a.storage_layer),
        a.entity_type,
        a.name,
        DECODE(a.is_top_layer||'-'||a.is_allocated,'Y-Y',
          a.sizeb,0),
        DECODE(a.is_top_layer||'-'||a.is_allocated,'Y-N',
          a.sizeb,0),
        a.freeb,
        DECODE(a.is_bottom_layer,'Y',
          a.sizeb,0)
FROM    mgmt_v_storage_report_unique a
/

