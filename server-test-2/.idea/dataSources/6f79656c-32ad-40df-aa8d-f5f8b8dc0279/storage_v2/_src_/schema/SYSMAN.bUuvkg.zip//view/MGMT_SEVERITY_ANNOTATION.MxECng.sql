create view MGMT_SEVERITY_ANNOTATION as
SELECT source_obj_guid, timestamp, annotation_type, user_name, message
    FROM mgmt_annotation
   WHERE source_obj_type = 1
/

create trigger SEV_ANNOTATION_INSERT_TR
    instead of insert
    on MGMT_SEVERITY_ANNOTATION
    for each row
begin
    -- missing source code
end
/

create trigger SEV_ANNOTATION_DELETE_TR
    instead of delete
    on MGMT_SEVERITY_ANNOTATION
    for each row
begin
    -- missing source code
end
/

