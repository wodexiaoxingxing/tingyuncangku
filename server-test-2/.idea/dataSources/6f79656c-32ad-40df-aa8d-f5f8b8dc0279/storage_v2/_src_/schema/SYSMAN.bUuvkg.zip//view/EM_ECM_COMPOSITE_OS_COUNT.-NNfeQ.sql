create view EM$ECM_COMPOSITE_OS_COUNT as
select
  composite_target_name,
  composite_target_type,
  name,
  base_version,
  update_level,
  count( * ) as num_hosts,
  case sum( num_patched ) when 0 then 'No' else 'Yes' end as patched
from
  ( select unique
      ct.target_name composite_target_name,
      ct.target_type composite_target_type,
      name,
      base_version,
      update_level,
      ss.snapshot_guid,
      case when exists (select * from mgmt_hc_os_components c where ss.snapshot_guid = c.snapshot_guid and c.type = 'Patch') then 1 else 0 end as num_patched
    from
      mgmt_target_assocs composite,
      mgmt_targets ct,
      mgmt_target_assoc_defs def,
      mgmt_targets target,
      mgmt_targets host,
      mgmt_hc_os_summary os,
      mgmt_ecm_snapshot ss
    where composite.assoc_target_guid = target.target_guid
      and target.host_name = host.target_name
      and host.target_type = 'host'
      and host.target_name = ss.target_name
      and host.target_type = ss.target_type
      and ss.snapshot_type = 'host_configuration'
      and ss.is_current = 'Y'
      and ss.snapshot_guid = os.snapshot_guid
      and ct.target_guid = composite.source_target_guid
      and def.assoc_guid = composite.assoc_guid
      and def.assoc_def_name = 'contains'
      and def.scope_target_type = ' '
  )
group by composite_target_name, composite_target_type, name, base_version, update_level
WITH READ ONLY
/

