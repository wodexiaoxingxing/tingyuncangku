create view MGMT$ORACLE_SW_GRP_TARGETS as
SELECT
      c.external_name as external_name,
      c.version as version,
      h.container_guid as inst_container_guid,
      t.target_guid as target_guid,
      t.target_type as target_type,
      map.target_type as mtype,
      host_t.target_guid as hguid,
      t.target_name as target_name,
      t_home.property_value as container_location,
      t.host_name as host_name
    FROM
      mgmt_targets t,
      mgmt_targets host_t,
      mgmt_ecm_snapshot s,
      mgmt_inv_container h,
      em$inv_component c,
      mgmt_target_type_component_map map,
      mgmt_target_properties t_home
  WHERE
      host_t.target_name = t.host_name and
      s.target_name = host_t.target_name and
      s.target_type = host_t.target_type and
      s.is_current = 'Y' and
      s.snapshot_type = 'host_configuration' and
      s.snapshot_guid = h.snapshot_guid and
      h.container_guid = c.container_guid and
      c.name = map.component_name and
      (map.property_name IS NULL and map.property_value IS NULL) and
      t.target_guid = t_home.target_guid and
      t_home.property_name = 'OracleHome' and
      (exists (select * from mgmt_target_properties sub_type
          where
      t.target_guid = sub_type.target_guid
                ) ) and
      h.container_location = t_home.property_value(+)
/

