create view ECM$HIST_ORACLE_SOFTWARE as
SELECT
  snapshot_guid AS ecm_snapshot_id,
  container_location,
  container_name
FROM mgmt_inv_container
WITH READ ONLY
/

