create view MGMT$TEMPLATE_POLICY_SETTINGS as
SELECT tt.template_name, tt.target_type, tt.template_guid,
           p.policy_name, p.policy_guid, func_cats.category_name,
           pac.key_value, null, null, null, null,
           pac.key_operator, pacp.param_name, pac.prevent_override,
           DECODE(p.violation_level,
                    18, pacp.info_threshold,
                    20, pacp.warn_threshold,
                    25, pacp.crit_threshold,
                    NULL),
           DECODE(TRIM(pac.fixit_job),
	          NULL,  DECODE( DECODE(p.violation_level,
                                         18, tgt_info_cas.job_id,
                                         20, tgt_warn_cas.job_id,
                                         25, tgt_crit_cas.job_id),
				  NULL, 'No-action',
                                  'Corrective-Action'),
                  'Agent-Fixit job'),
           DECODE(p.violation_level, 18, tgt_info_cas.job_type,
                                     20, tgt_warn_cas.job_type,
                                     25, tgt_crit_cas.job_type),
           DECODE(p.violation_level, 18, tgt_info_cas.job_name,
                                     20, tgt_warn_cas.job_name,
                                     25, tgt_crit_cas.job_name),
           DECODE(p.violation_level, 18, tgt_info_cas.job_owner,
                                     20, tgt_warn_cas.job_owner,
                                     25, tgt_crit_cas.job_owner)
      FROM mgmt_policy_assoc pa,
           mgmt_templates tt,
           mgmt_policies p,
          (SELECT target_type, object_guid, category_name
             FROM mgmt_category_map catm
            WHERE class_name = 'Functional'
              AND object_type = 2) func_cats,
          mgmt_policy_assoc_cfg pac,
          mgmt_policy_assoc_cfg_params pacp,
           (SELECT ca.ca_template_guid, j.job_id, j.job_type,
                   j.job_owner, j.job_name
             FROM mgmt_job j, mgmt_corrective_action ca
            WHERE j.job_id = ca.job_id
              AND j.is_corrective_action = 1
              AND ca.ca_scope = 2) tgt_crit_cas,
           (SELECT ca.ca_template_guid, j.job_id, j.job_type,
                   j.job_owner, j.job_name
             FROM mgmt_job j, mgmt_corrective_action ca
            WHERE j.job_id = ca.job_id
              AND j.is_corrective_action = 1
              AND ca.ca_scope = 2) tgt_warn_cas,
           (SELECT ca.ca_template_guid, j.job_id, j.job_type,
                   j.job_owner, j.job_name
             FROM mgmt_job j, mgmt_corrective_action ca
            WHERE j.job_id = ca.job_id
              AND j.is_corrective_action = 1
              AND ca.ca_scope = 2) tgt_info_cas
      WHERE pa.object_guid = tt.template_guid
        AND pa.policy_guid = p.policy_guid
        AND pa.object_guid = pac.object_guid
        AND pa.policy_guid = pac.policy_guid
        AND pa.coll_name   = pac.coll_name
        AND pac.object_guid = pacp.object_guid (+)
        AND pac.policy_guid = pacp.policy_guid (+)
        AND pac.coll_name   = pacp.coll_name   (+)
        AND pac.key_value   = pacp.key_value   (+)
        AND pac.key_operator = pacp.key_operator (+)
        AND pa.policy_guid = func_cats.object_guid (+)
        AND pa.object_type = 3
        AND p.policy_type = 2
        AND pac.crit_action_job_id = tgt_crit_cas.job_id (+)
        AND pac.object_guid        = tgt_crit_cas.ca_template_guid (+)
        AND pac.warn_action_job_id = tgt_warn_cas.job_id (+)
        AND pac.object_guid        = tgt_warn_cas.ca_template_guid (+)
        AND pac.info_action_job_id = tgt_info_cas.job_id (+)
        AND pac.object_guid        = tgt_info_cas.ca_template_guid (+)
  UNION ALL
    SELECT tt.template_name, tt.target_type, tt.template_guid,
           p.policy_name, p.policy_guid, func_cats.category_name,
           k.key_part1_value, k.key_part2_value, k.key_part3_value,
           k.key_part4_value, k.key_part5_value,
           pac.key_operator, pacp.param_name, pac.prevent_override,
           DECODE(p.violation_level,
                    18, pacp.info_threshold,
                    20, pacp.warn_threshold,
                    25, pacp.crit_threshold,
                    NULL),
           DECODE(TRIM(pac.fixit_job),
	          NULL,  DECODE( DECODE(p.violation_level,
                                         18, tgt_info_cas.job_id,
                                         20, tgt_warn_cas.job_id,
                                         25, tgt_crit_cas.job_id),
				  NULL, 'No-action',
                                  'Corrective-Action'),
                  'Agent-Fixit job'),
           DECODE(p.violation_level, 18, tgt_info_cas.job_type,
                                     20, tgt_warn_cas.job_type,
                                     25, tgt_crit_cas.job_type),
           DECODE(p.violation_level, 18, tgt_info_cas.job_name,
                                     20, tgt_warn_cas.job_name,
                                     25, tgt_crit_cas.job_name),
           DECODE(p.violation_level, 18, tgt_info_cas.job_owner,
                                     20, tgt_warn_cas.job_owner,
                                     25, tgt_crit_cas.job_owner)
      FROM mgmt_policy_assoc pa,
           mgmt_templates tt,
           mgmt_policies p,
           mgmt_metrics_composite_keys k,
           (SELECT target_type, object_guid, category_name
              FROM mgmt_category_map catm
             WHERE class_name = 'Functional'
               AND object_type = 2) func_cats,
           mgmt_policy_assoc_cfg pac,
           mgmt_policy_assoc_cfg_params pacp,
           (SELECT ca.ca_template_guid, j.job_id, j.job_type,
                   j.job_owner, j.job_name
             FROM mgmt_job j, mgmt_corrective_action ca
            WHERE j.job_id = ca.job_id
              AND j.is_corrective_action = 1
              AND ca.ca_scope = 2) tgt_crit_cas,
           (SELECT ca.ca_template_guid, j.job_id, j.job_type,
                   j.job_owner, j.job_name
             FROM mgmt_job j, mgmt_corrective_action ca
            WHERE j.job_id = ca.job_id
              AND j.is_corrective_action = 1
              AND ca.ca_scope = 2) tgt_warn_cas,
           (SELECT ca.ca_template_guid, j.job_id, j.job_type,
                   j.job_owner, j.job_name
             FROM mgmt_job j, mgmt_corrective_action ca
            WHERE j.job_id = ca.job_id
              AND j.is_corrective_action = 1
              AND ca.ca_scope = 2) tgt_info_cas
      WHERE pa.object_guid = tt.template_guid
        AND pa.policy_guid = p.policy_guid
        AND pa.object_guid = pac.object_guid
        AND pa.policy_guid = pac.policy_guid
        AND pa.coll_name   = pac.coll_name
        AND pac.object_guid = pacp.object_guid (+)
        AND pac.policy_guid = pacp.policy_guid (+)
        AND pac.coll_name   = pacp.coll_name   (+)
        AND pac.key_value   = pacp.key_value   (+)
        AND pac.key_operator = pacp.key_operator (+)
        AND pa.policy_guid = func_cats.object_guid (+)
        AND pa.object_type = 3
        AND p.policy_type = 2
        AND pac.crit_action_job_id = tgt_crit_cas.job_id (+)
        AND pac.object_guid        = tgt_crit_cas.ca_template_guid (+)
        AND pac.warn_action_job_id = tgt_warn_cas.job_id (+)
        AND pac.object_guid        = tgt_warn_cas.ca_template_guid (+)
        AND pac.info_action_job_id = tgt_info_cas.job_id (+)
        AND pac.object_guid        = tgt_info_cas.ca_template_guid (+)
        AND k.target_guid = pac.object_guid
        AND pac.key_value = k.composite_key
WITH READ ONLY
/

