create trigger HANDLE_RELATED_TARGETS
    before insert
    on MGMT_BLACKOUT_STATE
    for each row
DECLARE
   l_created_thru MGMT_BLACKOUTS.created_thru%TYPE;
   l_include_members MGMT_BLACKOUT_TARGET_DETAILS.include_members%TYPE;
   l_target_type MGMT_TARGETS.target_type%TYPE;

l_targets_to_process MGMT_USER_GUID_ARRAY;

BEGIN
   -- For CLI blackouts, add entries to the blackout state table
   SELECT created_thru INTO l_created_thru
   FROM   MGMT_BLACKOUTS
   WHERE  blackout_guid=:new.blackout_guid;

   IF l_created_thru IS NOT NULL THEN
      BEGIN
          SELECT include_members INTO l_include_members
          FROM   MGMT_BLACKOUT_TARGET_DETAILS
	      WHERE  blackout_guid=:new.blackout_guid
	      AND    target_guid=:new.target_guid;

      EXCEPTION
          -- If we get a NO_DATA_FOUND, we are processing a
          -- node-level blackout, and a target that is on
          -- the node but is not the host.
          WHEN NO_DATA_FOUND THEN
              l_include_members := 0;
      END;

      --Find the target type to make sure that its of type host
      SELECT target_type INTO l_target_type
      FROM   MGMT_TARGETS
      WHERE  target_guid = :new.target_guid;

      --If include_members is true then insert all the dependent targets to the MGMT_BLACKOUT_STATE
      IF (l_include_members = 1 AND
          l_target_type = MGMT_GLOBAL.G_HOST_TARGET_TYPE) THEN
          --Find all the targets guid for this host url and insert in MGMT_BLACKOUT_FLAT_TARGETS
          SELECT t.target_guid
          BULK COLLECT INTO l_targets_to_process
          FROM   MGMT_TARGETS t, MGMT_BLACKOUT_FLAT_TARGETS ft
          WHERE  ft.blackout_guid=:new.blackout_guid
          AND    t.target_guid=ft.target_guid
          AND    t.target_guid != :new.target_guid
        ORDER BY DECODE(t.target_type, MGMT_GLOBAL.G_AGENT_TARGET_TYPE, 2, 1), 1;

          IF l_targets_to_process IS NOT NULL AND
             l_targets_to_process.COUNT > 0 THEN
              FOR i IN 1..l_targets_to_process.COUNT LOOP
                  INSERT INTO MGMT_BLACKOUT_STATE (
                    blackout_guid,
                    target_guid,
                    collection_timestamp,
                    load_timestamp,
                    blackout_code,
                    target_status
                  )
                  VALUES (
                    :new.blackout_guid,
                    l_targets_to_process(i),
                    :new.collection_timestamp,
                    :new.load_timestamp,
                    :new.blackout_code,
                    :new.target_status
                  );
              END LOOP;
          END IF;
      END IF;
   END IF;
END;
/

