create view ECM$ORACLE_TOPLEVEL as
select
    h.snapshot_guid as ecm_snapshot_id,
    c.name,
    c.external_name,
    case when p.version IS NULL THEN c.version ELSE p.version END as version,
    count(*) as count
from
  MGMT_INV_CONTAINER h,
  MGMT_INV_COMPONENT c,
  MGMT_INV_VERSIONED_PATCH p
where h.container_guid = c.container_guid
  and c.component_guid = p.component_guid(+)
  and c.IS_TOP_LEVEL = 'Y'
group by h.snapshot_guid, c.name, c.external_name, case when p.version IS NULL THEN c.version ELSE p.version END
/

