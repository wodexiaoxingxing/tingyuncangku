create view MGMT_V_HOST_FS_LIST as
SELECT global_unique_id,
         resource_name,
         resource_type,
         mount_point,
         storage_size,
         used,
         writeable,
         target_type,
         target_name,
         ecm_snapshot_id,
         count(DISTINCT target_name)
           OVER( PARTITION BY target_type, global_unique_id )
           AS shared_count
  FROM
  (
    SELECT global_unique_id,
           decode( storage_layer, 'LOCAL_FILESYSTEM', local_fs,
                   'NFS', nfs ) AS resource_name,
           decode( storage_layer, 'LOCAL_FILESYSTEM', local_fs_type,
                   'NFS', 'nfs' ) AS resource_type,
           decode( storage_layer, 'LOCAL_FILESYSTEM', local_fs_mountpoint,
                   'NFS', nfs_mountpoint ) AS mount_point,
           nvl(sizeb,0) AS storage_size,
           nvl(usedb,0) AS used,
           CASE
             WHEN storage_layer = 'LOCAL_FILESYSTEM' THEN
               'NOT_APPLICABLE'
             WHEN  storage_layer = 'NFS' THEN
               decode( instr(nfs_mount_privilege, 'WRITE'),
                  null, 'UNKNOWN', 0, 'NO', 'YES' )
           END AS writeable,
           data.target_type,
           data.target_name,
           data.ecm_snapshot_id as ecm_snapshot_id
    FROM mgmt_v_storage_report_data data,
         mgmt$ecm_current_snapshots snap
    WHERE snap.ecm_snapshot_id = data.ecm_snapshot_id
      AND storage_layer in( 'LOCAL_FILESYSTEM', 'NFS' )
      AND ( entity_type = 'Mountpoint'
            OR local_fs_type = 'swap' )
  )
/

