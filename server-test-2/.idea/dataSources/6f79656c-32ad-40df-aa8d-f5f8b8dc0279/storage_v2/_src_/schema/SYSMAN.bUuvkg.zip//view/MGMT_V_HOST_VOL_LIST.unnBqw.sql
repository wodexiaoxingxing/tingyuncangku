create view MGMT_V_HOST_VOL_LIST as
SELECT target_name,
         target_type,
         ecm_snapshot_id,
         global_unique_id,
         resource_name,
         resource_type,
         disk_group,
         os_path,
         vendor,
         product,
         storage_size,
         allocated,
         unallocated,
         configuration,
         count(DISTINCT target_name)  -- across all hosts in EM
           OVER( PARTITION BY target_type, global_unique_id )
           AS shared_count
  FROM
  (
    SELECT data.global_unique_id,
           data.name AS resource_name,
           data.entity_type AS resource_type,
           volume_manager_disk_group disk_group,
           data.volume_manager_vendor AS vendor,
           data.volume_manager_product AS product,
           data.volume_manager_used_path AS os_path,
           nvl(data.sizeb,0) AS storage_size,
           nvl(data.usedb,0) AS allocated,
           nvl(data.freeb,0) AS unallocated,
           nvl( data.volume_manager_configuration,
                'NOT_APPLICABLE' ) AS configuration,
           data.target_name,
           data.target_type,
           data.ecm_snapshot_id as ecm_snapshot_id
    FROM mgmt_v_storage_report_data data,
         mgmt$ecm_current_snapshots snap
    WHERE snap.ecm_snapshot_id = data.ecm_snapshot_id
      AND data.storage_layer = 'VOLUME_MANAGER'
  )
/

