create view EM$ECM_HOMES_BY_ARUID as
select  home.container_guid as home_id,
                plat.em_os_name as platform,
                snap.target_name as host,
                home.container_location as home_location,
                home.container_name as home_name,
                db.target_type as target_type,
                plat.em_os_bitlength as address_size,
                'ARU' as id_type,
                decode(patchset.version,null,comp.version,patchset.version) as version,
                plat.platform_id as platform_id
        from
            mgmt_inv_container home,
            mgmt_inv_container_property prop,
            mgmt_inv_component comp,
            mgmt_ecm_snapshot snap,
            mgmt_aru_platforms plat,
            mgmt_inv_versioned_patch patchset,
            mgmt_targets db,
            mgmt_target_properties dbp
        where
           home.container_type = 'O' and
           home.container_guid = prop.container_guid and
           prop.property_name = 'ARU_PLATFORM_ID' and
           plat.platform_id = to_number(prop.property_value) and
           comp.container_guid = home.container_guid and
           home.snapshot_guid = snap.snapshot_guid and
           snap.snapshot_type = 'host_configuration' and
           snap.is_current = 'Y' and
           comp.component_guid = patchset.component_guid(+) and
           dbp.property_name(+) ='OracleHome' and
           db.target_guid(+) = dbp.target_guid and
           dbp.property_value(+) = home.container_location
union
select     /*+ INDEX(patchset MGMT_ECM_IDX_PLAT_NAME)*/
           home.container_guid as home_id,
                hos.property_value as platform,
                snap.target_name as host,
                home.container_location as home_location,
                home.container_name as home_name,
                db.target_type as target_type,
                replace(os.address_length_in_bits, '-bit','') as address_size,
                'NO_ARU' as id_type,
                decode(patchset.version,null,comp.version,patchset.version) as version,
                oui.aru_id as platform_id
        from
            mgmt_inv_container home,
            mgmt_ecm_snapshot snap,
            mgmt_targets htg,
            mgmt_target_properties hos,
            mgmt_inv_component comp,
            mgmt_hc_os_summary os,
            mgmt_inv_versioned_patch patchset,
            mgmt_targets db,
            mgmt_target_properties dbp,
            mgmt_oui_aru_map oui
        where
           home.container_type = 'O' and
           home.snapshot_guid = snap.snapshot_guid and
           snap.snapshot_type = 'host_configuration' and
           snap.is_current = 'Y' and
           snap.target_name = htg.target_name and
           snap.target_type = 'host' and
           htg.target_guid  = hos.target_guid and
           hos.property_name = 'OS' and
           hos.property_value is not null and
           comp.container_guid = home.container_guid and
           os.snapshot_guid = snap.snapshot_guid and
           oui.oui_id = home.oui_platform and
           comp.component_guid = patchset.component_guid(+) and
           dbp.property_name(+) = 'OracleHome' and
           db.target_guid(+) = dbp.target_guid and
           dbp.property_value(+) = home.container_location and
        not exists (
           select
            property_value
           from
            mgmt_inv_container_property p
           where
               container_guid = home.container_guid  and
               p.property_name = 'ARU_PLATFORM_ID'
          )
WITH READ ONLY
/

