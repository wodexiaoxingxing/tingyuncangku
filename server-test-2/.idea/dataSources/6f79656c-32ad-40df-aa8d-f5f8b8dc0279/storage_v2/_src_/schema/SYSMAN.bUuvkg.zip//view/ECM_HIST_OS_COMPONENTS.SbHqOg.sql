create view ECM$HIST_OS_COMPONENTS as
SELECT
  snapshot_guid AS ecm_snapshot_id,
  name,
  type,
  version,
  description,
  installation_date
FROM mgmt_hc_os_components
WITH READ ONLY
/

