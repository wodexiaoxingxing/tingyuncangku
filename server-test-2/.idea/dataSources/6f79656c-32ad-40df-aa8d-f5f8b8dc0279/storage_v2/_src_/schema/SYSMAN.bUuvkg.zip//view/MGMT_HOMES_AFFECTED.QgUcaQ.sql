create view MGMT$HOMES_AFFECTED as
SELECT
  a.host_name as host,
  a.home_location as home_directory,
  a.target_guid,
  count (distinct advisory_name) as alerts
FROM
  mgmt_bug_adv_home_patch a, mgmt_targets t
WHERE
  a.target_guid = t.target_guid
group by a.host_name,a.home_location,a.target_guid
WITH READ ONLY
/

