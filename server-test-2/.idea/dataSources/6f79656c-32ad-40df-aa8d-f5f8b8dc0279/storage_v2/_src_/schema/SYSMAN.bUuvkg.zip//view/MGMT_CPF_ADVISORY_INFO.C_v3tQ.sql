create view MGMT$CPF_ADVISORY_INFO as
select
        a.advisory_name        as advisory_name,
        a.url                  as advisory_url,
        a.impact               as advisory_impact,
        a.abstract             as advisory_abstract,
        ab.bug_number          as advisory_bug
from
        mgmt_bug_advisory         a,
        mgmt_bug_advisory_bug     ab
where
        a.advisory_name = ab.advisory_name
/

