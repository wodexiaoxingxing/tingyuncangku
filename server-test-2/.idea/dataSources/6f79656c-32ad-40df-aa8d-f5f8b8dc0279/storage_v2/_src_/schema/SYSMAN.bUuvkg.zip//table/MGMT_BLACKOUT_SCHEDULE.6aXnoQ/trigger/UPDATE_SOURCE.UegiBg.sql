create trigger UPDATE_SOURCE
    before insert
    on MGMT_BLACKOUT_SCHEDULE
    for each row
DECLARE
    l_created_thru MGMT_BLACKOUTS.created_thru%TYPE;
BEGIN
    BEGIN
        SELECT created_thru INTO l_created_thru
        FROM   MGMT_BLACKOUTS
        WHERE  blackout_guid=:new.blackout_guid;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN;
    END;

    IF l_created_thru IS NOT NULL THEN
        IF :new.duration > 0 THEN
            :new.duration_source :=
                 MGMT_BLACKOUT_ENGINE.DURATION_SOURCE_DURATION;
        ELSIF :new.duration < 0 THEN
            :new.duration_source :=
                 MGMT_BLACKOUT_ENGINE.DURATION_SOURCE_INDEFINITE;
        ELSE
            :new.duration_source :=
                 MGMT_BLACKOUT_ENGINE.DURATION_SOURCE_ENDTIME;
        END IF;
    END IF;
END;
/

