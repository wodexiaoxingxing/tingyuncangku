create view MGMT_COLLECTION_PROPERTIES as
SELECT object_guid, metric_guid, coll_name,
         property_name, property_value
    FROM mgmt_coll_item_properties
   WHERE object_type = 2
/

create trigger EM_INSERT_COLL_ITEM_PROPERTY
    instead of insert
    on MGMT_COLLECTION_PROPERTIES
    for each row
begin
    -- missing source code
end
/

create trigger EM_UPDATE_COLL_ITEM_PROPERTY
    instead of update
    on MGMT_COLLECTION_PROPERTIES
    for each row
begin
    -- missing source code
end
/

create trigger EM_DELETE_COLL_ITEM_PROPERTY
    instead of delete
    on MGMT_COLLECTION_PROPERTIES
    for each row
begin
    -- missing source code
end
/

