create view MGMT$DELTA_ORACLE_HOME as
(select
  cd.host_name as host_name,
  cd.DELTA_TIME as delta_time,
  cd.HOME_PATH home_path,
  cd.operation as operation,
  'Product' as type,
  case cd.operation when 'UPDATE' then cd.COMPONENT_NAME || ' ' || cd.base_version || ': ' ||
       cd.delta_values else cd.COMPONENT_NAME || ' ' || cd.base_version end as description
 from mgmt$delta_components cd)
UNION ALL
(select
  p.host_name as host_name,
  p.DELTA_TIME as delta_time,
  p.HOME_name home_path,
  p.operation as operation,
  'Patch' as type,
  p.patch_id as description
 from mgmt$delta_oneoff_patches p)
UNION ALL
(select
  cd.host_name as host_name,
  cd.DELTA_TIME as delta_time,
  cd.HOME_name home_path,
  cd.operation as operation,
  'Patchset' as type,
  case cd.operation when 'UPDATE' then cd.patchset_NAME || ' ' || cd.version || ': ' ||
       cd.delta_values else cd.patchset_NAME || ' ' || cd.version end as description
 from mgmt$delta_patchsets cd)
/

comment on table MGMT$DELTA_ORACLE_HOME is 'The view MGMT$DELTA_ORACLE_HOME has been deprecated.'
/

