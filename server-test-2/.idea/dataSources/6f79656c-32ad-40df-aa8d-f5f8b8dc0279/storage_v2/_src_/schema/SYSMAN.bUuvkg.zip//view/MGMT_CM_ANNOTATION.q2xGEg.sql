create view MGMT_CM$ANNOTATION as
select
 source_obj_type,
 source_obj_guid,
 timestamp,
 annotation_type,
 user_name,
 message,
 ROW_NUMBER() over
(PARTITION BY source_obj_guid
 ORDER BY timestamp desc) as seq
from
 mgmt_annotation
where
 source_obj_type = 4
/

