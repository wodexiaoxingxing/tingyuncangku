create view MGMT$HA_INFO_ALL as
select
  g.host_name,
  s.ecm_snapshot_id as snapshot_guid,
  s.target_name,
  s.target_type,
  s.target_guid,
  s.start_timestamp as collection_timestamp,
  s.is_current,
  i.dbid,
  i.log_mode,
  i.force_logging,
  i.database_role,
  i.flashback_on
from
  mgmt_targets g,
  mgmt_ha_info_ecm i,
  mgmt$ecm_visible_snapshots s
where
  s.ecm_snapshot_id = i.ecm_snapshot_id and
  s.target_guid = g.target_guid (+)
/

