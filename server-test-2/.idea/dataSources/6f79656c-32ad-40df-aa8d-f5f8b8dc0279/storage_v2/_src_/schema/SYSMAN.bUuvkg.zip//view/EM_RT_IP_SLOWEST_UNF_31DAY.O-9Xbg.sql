create view EM$RT_IP_SLOWEST_UNF_31DAY
            (COMPOSITE_TARGET_GUID, COMPOSITE_TARGET_NAME, COMPOSITE_TARGET_TYPE, METRIC_NAME, VISITOR_NODE,
             RESPONSE_TIME_AVERAGE, RESPONSE_TIME_MINIMUM, RESPONSE_TIME_MAXIMUM, RESPONSE_TIME_STDDEV, HITS)
as
SELECT m.SOURCE_TARGET_GUID,
        ct.TARGET_NAME, ct.TARGET_TYPE,
        METRIC_NAME,
        VISITOR_NODE,
        sum(response_time_average*hits)/sum(hits), min(response_time_minimum),
        max(response_time_maximum), sum(RESPONSE_TIME_SDEV*hits)/sum(hits),
        sum(hits)
    FROM MGMT_RT_IP_1DAY d, MGMT_TARGET_ASSOCS m,
         MGMT_TARGETS ct, MGMT_TARGET_ASSOC_DEFS def
    WHERE
        d.target_guid = m.assoc_target_guid
        AND def.assoc_guid = m.assoc_guid
        AND def.assoc_def_name = 'supports_eum_on'
        AND def.scope_target_type = ' '
        AND ct.target_guid  = m.source_target_guid
    GROUP BY m.SOURCE_TARGET_GUID,
        ct.TARGET_NAME, ct.TARGET_TYPE,
        METRIC_NAME,
        VISITOR_NODE
    ORDER BY sum(response_time_average*hits)/sum(hits) DESC
/

