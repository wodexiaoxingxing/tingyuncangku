create view MGMT$OS_HW_SUMMARY as
select
  s.target_name as host_name,
  ss.domain as domain,
  os.name || ' ' || os.base_version || ' ' || os.update_level || '(' || os.address_length_in_bits || ')' as OS_SUMMARY,
  hm.system_config,
  hm.machine_architecture as ma,
  hm.clock_freq_in_mhz as freq,
  hm.memory_size_in_mb as mem,
  hm.local_disk_space_in_gb as disk,
  hm.cpu_count,
  hm.vendor_name,
  os.vendor_name as os_vendor,
  os.distributor_version,
  s.snapshot_guid
from
  mgmt_targets t,
  mgmt_ecm_snapshot s,
  mgmt_hc_system_summary ss,
  mgmt_hc_os_summary os,
  mgmt_hc_hardware_master hm
where
  t.target_type = 'host' and
  t.target_name = s.target_name and
  s.snapshot_type = 'host_configuration' and
  s.target_type = 'host' and
  s.is_current = 'Y' and
  s.snapshot_guid = ss.snapshot_guid and
  s.snapshot_guid = os.snapshot_guid and
  s.snapshot_guid = hm.snapshot_guid
/

