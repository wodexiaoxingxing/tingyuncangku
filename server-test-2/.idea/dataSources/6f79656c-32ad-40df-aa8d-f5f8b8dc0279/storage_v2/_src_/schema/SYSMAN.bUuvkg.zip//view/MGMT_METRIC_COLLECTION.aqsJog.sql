create view MGMT$METRIC_COLLECTION
            (TARGET_NAME, TARGET_TYPE, TARGET_GUID, METRIC_NAME, METRIC_COLUMN, KEY_VALUE, COLLECTION_FREQUENCY,
             UPLOAD_POLICY, WARNING_OPERATOR, WARNING_THRESHOLD, CRITICAL_OPERATOR, CRITICAL_THRESHOLD, OCCURENCE_COUNT,
             WARNING_COUNT, CRITICAL_COUNT)
as
SELECT
           t.target_name, t.target_type, t.target_guid,
           m.metric_name, m.metric_column, s.key_value,
           NULL, NULL,
           DECODE (s.warning_operator, 0, 'Greater Than', 1, 'Equal To', 2, 'Less Than',
                                     3, 'Less Than or Equal To', 4, 'Contains',
                                     5, 'Not Equal', 6, 'Match'),
           s.warning_threshold,
           DECODE (s.critical_operator, 0, 'Greater Than', 1, 'Equal To', 2, 'Less Than',
                                     3, 'Less Than or Equal To', 4, 'Contains',
                                     5, 'Not Equal', 6, 'Match'),
           s.critical_threshold, s.num_occurences, s.num_warnings, s.num_criticals
         FROM
             mgmt_targets t,
             mgmt_metrics m,
             mgmt_metric_thresholds s
          WHERE t.target_guid = s.target_guid
            and m.metric_guid = s.metric_guid
            and t.target_type = m.target_type
            and t.type_meta_ver = m.type_meta_ver
            and (t.category_prop_1 = m.category_prop_1
                 or m.category_prop_1 = ' ')
            and (t.category_prop_2 = m.category_prop_2
                 or m.category_prop_2 = ' ')
            and (t.category_prop_3 = m.category_prop_3
                 or m.category_prop_3 = ' ')
            and (t.category_prop_4 = m.category_prop_4
                 or m.category_prop_4 = ' ')
            and (t.category_prop_5 = m.category_prop_5
                 or m.category_prop_5 = ' ')
    WITH READ ONLY
/

comment on table MGMT$METRIC_COLLECTION is 'The MGMT$METRIC_COLLECTION view has been deprecated. Please consult
the documentation for the MGMT$TARGET_METRIC_COLLECTIONS and
MGMT$TARGET_METRIC_SETTINGS views for alternatives.'
/

