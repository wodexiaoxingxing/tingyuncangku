create view MGMT$TARGET
            (TARGET_NAME, TARGET_TYPE, TARGET_GUID, TYPE_VERSION, TYPE_QUALIFIER1, TYPE_QUALIFIER2, TYPE_QUALIFIER3,
             TYPE_QUALIFIER4, TYPE_QUALIFIER5, EMD_URL, TIMEZONE_REGION, DISPLAY_NAME, HOST_NAME, LAST_METRIC_LOAD_TIME,
             TYPE_DISPLAY_NAME)
as
SELECT
          t.target_name, t.target_type, t.target_guid, t.type_meta_ver,
          t.category_prop_1, t.category_prop_2, t.category_prop_3,
          t.category_prop_4, t.category_prop_5, t.emd_url, t.timezone_region,
          t.display_name, t.host_name, t.last_load_time,nvl(tt.type_display_name,
          t.type_display_name)
        FROM
            mgmt_targets t, mgmt_target_types tt
        WHERE
            t.target_type = tt.target_type(+)
    WITH READ ONLY
/

