create view EM_ADAPTIVE_THRESHOLDS as
SELECT DISTINCT
       pa.object_guid
      ,m.target_type
      ,m.metric_name
      ,m.metric_column
      ,pac.key_value
      ,pac.has_active_baseline
  FROM
       mgmt_metrics                 m
      ,mgmt_policies                p
      ,mgmt_policy_assoc            pa
      ,mgmt_policy_assoc_cfg        pac
 WHERE
       m.metric_guid = p.policy_guid
   AND p.policy_guid = pa.policy_guid
   AND pa.policy_guid = pac.policy_guid
   AND pa.object_guid = pac.object_guid
   AND pa.coll_name = pac.coll_name
   AND p.policy_type = 1
   AND pa.object_type = 2
   AND p.condition_type = 1
/

create trigger EM_ADAPTIVE_THRESHOLDS_INS
    instead of insert
    on EM_ADAPTIVE_THRESHOLDS
    for each row
begin
    -- missing source code
end
/

