create view MGMT$SOFTWARE_PATCHSETS as
SELECT
  s.target_name as host_name,
  c.container_name as home_name,
  c.container_location as home_location,
  p.name,
  p.version,
  p.description,
  p.external_name,
  p.installer_version,
  p.min_deinstaller_version,
  p.timestamp as install_timestamp,
  s.snapshot_guid
FROM
  mgmt_inv_container c,
  mgmt_ecm_snapshot s,
  mgmt_inv_patchset p,
  mgmt_targets t
WHERE c.snapshot_guid = s.snapshot_guid
  AND s.is_current = 'Y'
  AND s.snapshot_type = 'host_configuration'
  AND p.container_guid = c.container_guid
  AND t.target_name = s.target_name
  AND t.target_type = 'host'
/

