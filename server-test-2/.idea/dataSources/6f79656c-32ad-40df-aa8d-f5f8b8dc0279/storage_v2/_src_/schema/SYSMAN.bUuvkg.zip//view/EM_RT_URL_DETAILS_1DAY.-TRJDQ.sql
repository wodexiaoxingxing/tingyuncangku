create view EM$RT_URL_DETAILS_1DAY as
SELECT
        m.SOURCE_TARGET_GUID,
        ct.TARGET_NAME, ct.TARGET_TYPE,
        m.ASSOC_TARGET_GUID,
        d.METRIC_NAME,
        nvl((SELECT display_name FROM MGMT_RT_URLS u
          WHERE u.target_guid = m.source_target_guid
          AND u.url_filename = d.url_filename), d.url_filename) "DISPLAY_NAME",
        d.URL_FILENAME,
        d.URL_LINK,
        d.ROLLUP_TIMESTAMP, d.response_time_average,
        d.RESPONSE_TIME_MINIMUM, d.RESPONSE_TIME_MAXIMUM,
        d.RESPONSE_TIME_SDEV, d.HITS
  FROM
        MGMT_RT_URL_1HOUR d, MGMT_TARGET_ASSOCS m,
        MGMT_TARGETS ct,
        MGMT_TARGET_ASSOC_DEFS def
  WHERE
        d.target_guid = m.assoc_target_guid
        AND def.assoc_guid = m.assoc_guid
        AND def.assoc_def_name = 'supports_eum_on'
        AND def.scope_target_type = ' '
        AND ct.target_guid  = m.source_target_guid
/

