create view MGMT$HA_MTTR as
select
  d.host_name as host,
  d.target_name as database_name,
  d.target_type,
  m.target_guid,
  m.estimated_mttr
from
  mgmt_targets d,
  mgmt_ha_mttr m
where
  d.target_type = 'oracle_database' and
  d.target_guid = m.target_guid
/

