create materialized view MGMT_ECM_MD_ALL_TBL_COLUMNS
    refresh force on demand
as
SELECT c.METADATA_ID,
       m.TARGET_TYPE,
       m.SNAPSHOT_TYPE,
       t.name as TABLE_NAME,
       c.NAME,
       c.UI_NAME,
       c.TYPE, c.TYPE_FORMAT,
       c.UI_ON, c.COMPARE_ON, c.COMPARE_UI_ON, c.HISTORY_ON, c.HISTORY_UI_ON,
       c.IS_KEY, c.IS_CONTEXT, c.IS_SUMMARY,
       c.IS_CHILD_LINK, c.LINK_COLUMN_NAME,
       rank() over (partition by c.metadata_id, t.name
           order by anc.tbl_order asc, c.col_order asc) as COL_ORDER,
       c.table_name as SOURCE_TABLE_NAME
FROM
     mgmt_ecm_snapshot_metadata m,
     mgmt_ecm_snapshot_md_tables t,
     mgmt_ecm_snapshot_md_tables anc,
     mgmt_ecm_snapshot_md_columns c
WHERE
     (anc.name, anc.metadata_id) in
         (SELECT anc_t.name, anc_t.metadata_id
            FROM mgmt_ecm_snapshot_md_tables anc_t
          START WITH anc_t.name = t.name
                 AND anc_t.metadata_id = t.metadata_id
          CONNECT BY anc_t.name = PRIOR anc_t.parent_table_name
                 AND anc_t.metadata_id = PRIOR anc_t.metadata_id)
  AND c.metadata_id = anc.metadata_id
  AND c.table_name = anc.name
  AND c.metadata_id = m.metadata_id
  AND m.kind = 'P'
  AND ((c.is_key = 'Y') OR (anc.name = t.name))
/

