create view MGMT_PROVISION_CLUSTER_STATUS as
SELECT
    clus.cluster_guid, clus.name, clus.description, clus.purpose,
    tgt.current_asn_guid, tgt.component_urn, tgt.network_urn, tgt.status,
    sim.suite_inst_guid, si.name suite_inst_name, cnc.node_count
FROM
    mgmt_prov_cluster clus
INNER JOIN
   mgmt_prov_tgt_status tgt
ON
   clus.cluster_guid = tgt.prov_tgt_guid
AND
   tgt.prov_target_type = 'cluster'
LEFT OUTER JOIN
   mgmt_prov_suite_inst_members sim
ON
   sim.member_guid = clus.cluster_guid
LEFT OUTER JOIN
   mgmt_prov_suite_instance si
ON
   sim.suite_inst_guid = si.suite_inst_guid
LEFT OUTER JOIN
   mgmt_provision_clus_node_cnt cnc
ON
   cnc.cluster_guid = clus.cluster_guid
WITH READ ONLY
/

