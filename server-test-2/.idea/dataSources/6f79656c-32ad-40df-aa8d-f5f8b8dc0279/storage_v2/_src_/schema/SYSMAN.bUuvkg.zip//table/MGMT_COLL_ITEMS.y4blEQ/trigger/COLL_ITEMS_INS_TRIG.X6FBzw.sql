create trigger COLL_ITEMS_INS_TRIG
    before insert
    on MGMT_COLL_ITEMS
    for each row
DECLARE
  l_coll_cnt NUMBER := 0;
BEGIN
  -- Check to see if default collection is created with proper cat props
  -- Check to see if there are any valid-if overlaps
  SELECT COUNT(*) INTO l_coll_cnt FROM MGMT_COLL_ITEMS
   WHERE target_type = :new.target_type
     AND type_meta_ver = :new.type_meta_ver
     AND coll_name = :new.coll_name
     AND (    (category_prop_1 = :new.category_prop_1)
           OR (:new.category_prop_1 = ' ')
           OR (category_prop_1 = ' ') )
     AND (    (category_prop_2 = :new.category_prop_2)
           OR (:new.category_prop_2 = ' ')
           OR (category_prop_2 = ' ') )
     AND (    (category_prop_3 = :new.category_prop_3)
           OR (:new.category_prop_3 = ' ')
           OR (category_prop_3 = ' ') )
     AND (    (category_prop_4 = :new.category_prop_4)
           OR (:new.category_prop_4 = ' ')
           OR (category_prop_4 = ' ') )
     AND (    (category_prop_5 = :new.category_prop_5)
           OR (:new.category_prop_5 = ' ')
           OR (category_prop_5 = ' ') )
     AND (NOT ( (category_prop_1 = :new.category_prop_1) AND
                (category_prop_2 = :new.category_prop_2) AND
                (category_prop_3 = :new.category_prop_3) AND
                (category_prop_4 = :new.category_prop_4) AND
                (category_prop_5 = :new.category_prop_5) ) ) ;

  IF (EMDW_LOG.P_IS_DEBUG_SET)THEN
     EMDW_LOG.DEBUG('coll_items_insert_trigger: Colls overlapping cnt = ' || l_coll_cnt,
       MGMT_COLLECTION.G_MODULE_NAME);
  END IF;

  IF (l_coll_cnt > 0) THEN
     raise_application_error(MGMT_GLOBAL.OVERLAPPING_CATPROP_DEF_ERR,
         MGMT_GLOBAL.OVERLAPPING_CATPROP_DEF_ERR_M ||
         ' target type = [' || :new.target_type || ']' ||
         ' type ver = [' || :new.type_meta_ver || ']' ||
         ' coll name = [' || :new.coll_name || ']' ||
         ' cat prop1 = [' || :new.category_prop_1 || ']' ||
         ' cat prop2 = [' || :new.category_prop_2 || ']' ||
         ' cat prop3 = [' || :new.category_prop_3 || ']' ||
         ' cat prop4 = [' || :new.category_prop_4 || ']' ||
         ' cat prop5 = [' || :new.category_prop_5 || ']' );
  END IF;

END;
/

