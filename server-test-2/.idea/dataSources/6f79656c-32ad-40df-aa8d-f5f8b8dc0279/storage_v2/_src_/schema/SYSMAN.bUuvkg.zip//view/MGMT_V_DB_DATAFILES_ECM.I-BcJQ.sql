create view MGMT_V_DB_DATAFILES_ECM as
SELECT	ecm_snapshot_id,
        file_name,
        file_size,
        os_storage_entity
FROM mgmt_db_datafiles_ecm
/

