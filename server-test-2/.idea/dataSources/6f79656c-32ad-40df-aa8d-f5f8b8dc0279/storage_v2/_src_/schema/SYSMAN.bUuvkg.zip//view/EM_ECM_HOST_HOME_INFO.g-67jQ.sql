create view EM$ECM_HOST_HOME_INFO as
SELECT
  t.target_name as host_name,
  ecm_util.HOST_HOME_LIST( t.target_name, t.target_type ) as home_info,
  os.name as os_name,
  os.base_version os_base_version,
  os.update_level os_update_level,
  os.address_length_in_bits os_address_length_in_bits
FROM
  mgmt_targets t,
  mgmt_ecm_snapshot s,
  mgmt_hc_os_summary os
WHERE t.target_type = 'host' and
  t.target_name = s.target_name and
  s.snapshot_type = 'host_configuration' and
  s.target_type = 'host' and
  s.is_current = 'Y' and
  s.snapshot_guid = os.snapshot_guid
  WITH READ ONLY
/

