create view MGMT_PROVISION_HW_SEARCH as
SELECT
    hw.hw_guid, hw.hostname, hw.new_hostname, hw.purpose, hw.serial_number,
    hw.name, hw.description, tgt.current_asn_guid,
    tgt.component_urn, tgt.network_urn, tgt.status,
    summ.system_config, summ.mem, summ.freq, summ.cpu_count
FROM
    mgmt_prov_hardware hw, mgmt_prov_tgt_status tgt, mgmt$os_hw_summary summ
WHERE
    hw.hw_guid = tgt.prov_tgt_guid
AND
    summ.host_name = hw.hostname
AND
    tgt.prov_target_type = 'hw'
WITH READ ONLY
/

