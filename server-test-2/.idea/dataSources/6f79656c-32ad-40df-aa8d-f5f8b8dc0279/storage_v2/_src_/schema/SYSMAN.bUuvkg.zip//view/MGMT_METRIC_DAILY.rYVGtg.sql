create view MGMT$METRIC_DAILY as
SELECT
            t.target_name, t.target_type, t.target_guid, m.metric_name,
            m.metric_column, d.metric_guid,m.metric_label,
            CASE
              WHEN m.is_transposed = 0 THEN
                 m.column_label
              ELSE
                 key_value
              END,
            d.key_value, null, null, null, null,
            d.rollup_timestamp, d.sample_count, d.value_average,
            d.value_minimum, d.value_maximum, d.value_sdev
          FROM
            mgmt_targets t,
            mgmt_metrics m,
            mgmt_metrics_1day d
          WHERE t.target_guid = d.target_guid
            AND m.metric_guid = d.metric_guid
            and t.target_type = m.target_type
            and t.type_meta_ver = m.type_meta_ver
            and m.num_keys < 2
            and (t.category_prop_1 = m.category_prop_1
                 or m.category_prop_1 = ' ')
            and (t.category_prop_2 = m.category_prop_2
                 or m.category_prop_2 = ' ')
            and (t.category_prop_3 = m.category_prop_3
                 or m.category_prop_3 = ' ')
            and (t.category_prop_4 = m.category_prop_4
                 or m.category_prop_4 = ' ')
            and (t.category_prop_5 = m.category_prop_5
                 or m.category_prop_5 = ' ')
     UNION ALL
        SELECT
            t.target_name, t.target_type, t.target_guid, m.metric_name,
			m.metric_column, d.metric_guid,m.metric_label,
                        CASE
                            WHEN m.is_transposed = 0 THEN
                               m.column_label
                            ELSE
                               k.key_part1_value
                            END,
			k.key_part1_value, k.key_part2_value, k.key_part3_value,
			k.key_part4_value, k.key_part5_value, d.rollup_timestamp,
			d.sample_count, d.value_average, d.value_minimum,
			d.value_maximum, d.value_sdev
          FROM
            mgmt_targets t,
            mgmt_metrics m,
            mgmt_metrics_1day d,
			mgmt_metrics_composite_keys k
          WHERE t.target_guid = d.target_guid
            AND m.metric_guid = d.metric_guid
            and t.target_type = m.target_type
            and t.type_meta_ver = m.type_meta_ver
            and m.num_keys > 1
            and (t.category_prop_1 = m.category_prop_1
                 or m.category_prop_1 = ' ')
            and (t.category_prop_2 = m.category_prop_2
                 or m.category_prop_2 = ' ')
            and (t.category_prop_3 = m.category_prop_3
                 or m.category_prop_3 = ' ')
            and (t.category_prop_4 = m.category_prop_4
                 or m.category_prop_4 = ' ')
            and (t.category_prop_5 = m.category_prop_5
                 or m.category_prop_5 = ' ')
            and d.target_guid = k.target_guid
            and d.key_value = k.composite_key
    WITH READ ONLY
/

