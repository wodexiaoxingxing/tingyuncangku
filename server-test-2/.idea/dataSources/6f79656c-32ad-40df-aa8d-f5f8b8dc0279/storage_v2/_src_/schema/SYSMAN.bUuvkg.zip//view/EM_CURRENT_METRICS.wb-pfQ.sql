create view EM$CURRENT_METRICS
            (TARGET_NAME, TARGET_TYPE, TARGET_GUID, METRIC_NAME, METRIC_TYPE, METRIC_COLUMN, KEY_COLUMN, KEY_VALUE,
             COLLECTION_TIMESTAMP, COLLECTION_TIMESTAMP_STRING, DATA_VALUE, DATA_VALUE_INT, STRING_VALUE, DESCRIPTION,
             UNIT, WARNING_OPERATOR, WARNING_THRESHOLD, CRITICAL_OPERATOR, CRITICAL_THRESHOLD, METRIC_ERROR_MESSAGE)
as
SELECT
        t.target_name, t.target_type, t.target_guid, m.metric_name,
        DECODE (m.metric_type, 0, 'NUMBER', 1, 'STRING', 2, 'TABLE',
                             3, 'RAW', 4, 'COMPOSITE_EVENT'),
        m.metric_column, m.key_column, r.key_value, collection_timestamp,
        TO_CHAR (collection_timestamp),
        value, ROUND(value), string_value, description, unit,
        DECODE (warning_operator, 0, 'GT', 1, 'EQ', 2, 'LT', 3, 'LE', 4, 'GE',
                                  5, 'CONTAINS', 6, 'NE'),
        warning_threshold,
        DECODE (critical_operator, 0, 'GT', 1, 'EQ', 2, 'LT', 3, 'LE', 4, 'GE',
                                   5, 'CONTAINS', 6, 'NE'),
        critical_threshold,
        (select metric_error_message from MGMT_CURRENT_METRIC_ERRORS e
          WHERE m.metric_guid=e.metric_guid)
      FROM
         MGMT_METRICS m, MGMT_CURRENT_METRICS r,
         MGMT_TARGETS t, MGMT_METRIC_THRESHOLDS th
        WHERE t.target_guid=r.target_guid
          AND m.metric_guid=r.metric_guid
          AND t.target_guid = th.target_guid
          AND m.metric_guid = th.metric_guid
          AND r.key_value  = th.key_value
/

