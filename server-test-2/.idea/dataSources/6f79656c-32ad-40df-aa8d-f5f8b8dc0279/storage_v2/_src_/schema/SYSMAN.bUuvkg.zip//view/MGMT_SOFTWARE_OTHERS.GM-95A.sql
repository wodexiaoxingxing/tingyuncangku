create view MGMT$SOFTWARE_OTHERS as
select
  s.target_name as host_name,
  v.name as Software_Name,
  v.vendor_name as Software_vendor,
  v.version as Software_version,
  s.snapshot_guid,
	v.installation_date,
	v.installed_location
from
  mgmt_ecm_snapshot s,
  mgmt_hc_vendor_sw_summary v,
  mgmt_targets t
where
  t.target_type = 'host' and
  t.target_name = s.target_name and
  s.snapshot_type = 'host_configuration' and
  s.target_type = 'host' and
  s.is_current = 'Y' and
  s.snapshot_guid = v.snapshot_guid
/

