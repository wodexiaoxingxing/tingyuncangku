create view EM$ECM_HARDWARE_COUNT as
select
  system_config,
  machine_architecture,
  count( * ) as num_hosts
from
  mgmt_targets host,
  mgmt_hc_hardware_master hw,
  mgmt_ecm_snapshot ss,
  mgmt_ecm_snap_component_info cc
where host.target_type = 'host'
  and host.target_name = ss.target_name
  and host.target_type = ss.target_type
  and ss.snapshot_type = 'host_configuration'
  and ss.is_current = 'Y'
  and ss.snapshot_guid = hw.snapshot_guid
  and ss.snapshot_guid = cc.snapshot_guid
  and cc.component_name = 'oracle.hardware'
  and cc.collection_status = 'COLLECTED'
group by system_config, machine_architecture
WITH READ ONLY
/

