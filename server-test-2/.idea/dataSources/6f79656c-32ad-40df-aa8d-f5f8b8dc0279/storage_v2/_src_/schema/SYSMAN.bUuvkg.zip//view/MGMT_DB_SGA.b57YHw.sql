create view MGMT$DB_SGA as
select
  g.host_name,
  s.target_name,
  s.target_type,
  s.target_guid,
  s.start_timestamp as collection_timestamp,
  sg.sganame,
  sg.sgasize
from
  mgmt_targets g,
  mgmt_db_sga_ecm sg,
  mgmt_ecm_gen_snapshot s
where
  s.snapshot_guid = sg.ecm_snapshot_id and
  s.target_guid = g.target_guid and
  s.is_current = 'Y'
/

