create view MGMT_PAF_PROCS_LATEST as
select a."PROCEDURE_GUID",a."BASE_GUID",a."SOURCE_GUID",a."VERSION",a."APPLICATION_NAME",a."NAME",a."DESCRIPTION",a."LAST_UPDATED",a."CREATED_BY",a."DATA_GUID",a."IS_ORACLE",a."DELETED",a."HELPSET",a."CONTENT0",a."CONTENT1",a."CONTENT2",a."CONTENT3",a."CONTENT4",a."CONTENT5",a."CONTENT6",a."CONTENT7" from mgmt_paf_procedures a
   where (substr(a.version,0,instr(a.version,'.')-1)+1) * 10000 +  substr(a.version,instr(a.version,'.')+1) =
   (
     select max((substr(version,0,instr(version,'.')-1)+1) * 10000 +  substr(version,instr(version,'.')+1))
     from mgmt_paf_procedures
     where base_guid = a.base_guid
   )
/

