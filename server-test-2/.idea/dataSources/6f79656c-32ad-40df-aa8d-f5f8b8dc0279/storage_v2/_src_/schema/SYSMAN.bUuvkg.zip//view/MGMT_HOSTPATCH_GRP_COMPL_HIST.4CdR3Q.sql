create view MGMT$HOSTPATCH_GRP_COMPL_HIST as
SELECT t.target_name as group_name,
       h.total_hosts,
       h.compl_hosts as compliant_hosts,
       h.checked_on as last_checked_on
FROM   mgmt_ecm_hostpatch_compl_hist h,
       mgmt_targets t
WHERE  t.target_guid = h.group_guid
/

