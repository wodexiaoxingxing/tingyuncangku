create view MGMT$STORAGE_REPORT_NFS as
SELECT  b.target_name,
  b.target_type,
  a3,
  a4,
  sizeb,
  usedb,
  freeb,
  a2,
  a5,
  a1,
  a6
FROM mgmt_storage_report_data a,
     mgmt$ecm_current_snapshots b
WHERE storage_layer = 'NFS'
AND   entity_type = 'Mountpoint'
AND   a.ecm_snapshot_id = b.ecm_snapshot_id
AND   b.snapshot_type = 'host_storage'
/

