create view MGMT$POLICY_VIOL_ANNOTATIONS as
SELECT
	     t.target_name, t.target_type, t.target_guid,
             p.policy_name, v.policy_guid,p.description,
             v.key_value, null, null, null, null, v.message,
             DECODE(v.violation_level, 18, 'Informational',
                                       20, 'Warning',
                                       25, 'Critical', v.violation_level),
             v.collection_timestamp,
             a.message, a.timestamp , a.user_name
           FROM mgmt_annotation a,
                mgmt_targets t,
                mgmt_policies p,
                mgmt_violations v
          WHERE a.source_obj_type = 1
            AND v.violation_guid = a.source_obj_guid
            AND v.violation_type = 3
            AND p.policy_guid = v.policy_guid
            AND t.target_guid = v.target_guid
            AND p.target_type = t.target_type
         UNION ALL
         SELECT
	     t.target_name, t.target_type, t.target_guid,
             p.policy_name, v.policy_guid,p.description,
             k.key_part1_value, k.key_part2_value, k.key_part3_value,
	     k.key_part4_value, k.key_part5_value, v.message,
             DECODE(v.violation_level, 18, 'Informational',
                                       20, 'Warning',
                                       25, 'Critical', v.violation_level),
             v.collection_timestamp,
             a.message, a.timestamp, a.user_name
           FROM mgmt_annotation a,
                mgmt_targets t,
                mgmt_policies p,
                mgmt_violations v,
                mgmt_metrics_composite_keys k
          WHERE a.source_obj_type = 1
            AND v.violation_guid = a.source_obj_guid
            AND v.violation_type = 3
            AND p.policy_guid = v.policy_guid
            AND t.target_guid = v.target_guid
            AND p.target_type = t.target_type
            AND k.target_guid = v.target_guid
            AND v.key_value = k.composite_key
   WITH READ ONLY
/

