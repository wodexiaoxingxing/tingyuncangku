create view MGMT$TARGET_METRIC_COLLECTIONS
            (TARGET_NAME, TARGET_TYPE, TARGET_GUID, METRIC_NAME, METRIC_COLUMN, METRIC_GUID, COLLECTION_NAME,
             IS_ENABLED, IS_REPOSITORY, FREQUENCY_CODE, COLLECTION_FREQUENCY, UPLOAD_POLICY)
as
SELECT
	     t.target_name, t.target_type, t.target_guid, m.metric_name,
	     m.metric_column, m.metric_guid, c.coll_name, c.is_enabled,
	     m.is_repository,
             DECODE(c.frequency_code, 1, 'One Time',
                                   2, 'Interval',
                                   3, 'Daily',
                                   4, 'Weekly',
                                   5, 'Monthly',
                                   6, 'Yearly',
                                     'On-Demand'),
             DECODE(c.frequency_code, 1, to_char(c.start_time,'DD-MON-YY HH24:MI'),
                                   2, to_char(interval),
                                   3, to_char(execution_hours)||':'||to_char(execution_minutes),
                                   4, to_char(execution_hours)||':'||to_char(execution_minutes),
                                   5, to_char(execution_hours)||':'||to_char(execution_minutes),
                                   6, to_char(execution_hours)||':'||to_char(execution_minutes),
                                      'On-Demand'),
             c.upload_frequency
        FROM mgmt_targets t,
             mgmt_metrics m,
             mgmt_collections c,
             mgmt_collection_metric_tasks cmt
       WHERE t.target_type = m.target_type
         AND t.type_meta_ver = m.type_meta_ver
         AND (t.category_prop_1 = m.category_prop_1 OR m.category_prop_1 = ' ')
         AND (t.category_prop_2 = m.category_prop_2 OR m.category_prop_2 = ' ')
         AND (t.category_prop_3 = m.category_prop_3 OR m.category_prop_3 = ' ')
         AND (t.category_prop_4 = m.category_prop_4 OR m.category_prop_4 = ' ')
         AND (t.category_prop_5 = m.category_prop_5 OR m.category_prop_5 = ' ')
         AND c.object_guid = t.target_guid
         AND m.metric_guid = cmt.metric_guid
     AND c.object_guid = cmt.target_guid
     AND c.coll_name = cmt.coll_name
     AND c.object_type = 2
WITH READ ONLY
/

