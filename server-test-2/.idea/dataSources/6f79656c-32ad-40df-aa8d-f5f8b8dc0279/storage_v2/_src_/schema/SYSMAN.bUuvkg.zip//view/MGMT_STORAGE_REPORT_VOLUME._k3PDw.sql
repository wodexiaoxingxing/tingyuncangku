create view MGMT$STORAGE_REPORT_VOLUME as
SELECT
  b.target_name,
  b.target_type,
  a1,
  a2,
  entity_type,
  a4,
  name,
  a3,
  a4,
  rawsizeb,
  sizeb,
  usedb,
  freeb,
  a5
FROM mgmt_storage_report_data a,
     mgmt$ecm_current_snapshots b
WHERE storage_layer = 'VOLUME_MANAGER'
AND   a.ecm_snapshot_id = b.ecm_snapshot_id
AND   b.snapshot_type = 'host_storage'
/

