create view MGMT$CSM_MT_IP_HOURLY as
SELECT
  tg.target_name, tg.target_type,
  st.target_name, st.target_type,
  ru.visitor_node, ru.rollup_timestamp, ru.metric_name,
  ru.hits, ru.response_time_average,
  ru.response_time_minimum, ru.response_time_maximum,
  ru.response_time_sdev, ru.response_time_variance
FROM
  MGMT_RT_IP_1HOUR ru,
  MGMT_TARGET_ASSOCS tm,
  MGMT_TARGETS tg,
  MGMT_TARGETS st,
  MGMT_TARGET_ASSOC_DEFS d
WHERE tg.target_guid = ru.target_guid
  AND tm.assoc_guid = d.assoc_guid
  AND d.assoc_def_name = 'supports_eum_on'
  AND d.scope_target_type = ' '
  AND st.target_guid = tm.source_target_guid
  AND ru.target_guid = tm.assoc_target_guid (+)
WITH READ ONLY
/

