create view MGMT_V_VENDOR_DISTRIBUTION as
SELECT ecm_snapshot_id,
         DECODE( vendor, null, 'Unknown', vendor) vendor,
         DECODE( storage_layer, 'NFS',
                 'WRITEABLE_NFS', storage_layer ) storage_layer,
         sizeb,
         global_unique_id
  FROM
  (
    SELECT data.ecm_snapshot_id,
           DECODE( storage_layer||nfs_mount_privilege,
                   'NFSWRITE', nfs_vendor,
                   'OS_DISK', disk_vendor
                 ) as vendor,
           storage_layer,
           sizeb,
           global_unique_id
    FROM mgmt_v_storage_report_data data,
         mgmt_storage_report_ui_targets uit
    WHERE uit.ecm_snapshot_id = data.ecm_snapshot_id
      AND (storage_layer = 'OS_DISK' OR
           storage_layer||nfs_mount_privilege = 'NFSWRITE')
      AND em_query_flag LIKE '%_BOTTOM%'
  )
/

