create trigger EM_INSERT_COLL_ITEM_PROPERTY
    instead of insert
    on MGMT_COLLECTION_PROPERTIES
    for each row
BEGIN
  -- Add coll_item property
  EM_COLL_UTIL.add_coll_item_property(
      p_object_guid => :new.target_guid,
      p_metric_guid => :new.metric_guid,
      p_coll_name   => :new.coll_name,
      p_object_type => MGMT_GLOBAL.G_OBJECT_TYPE_TARGET,
      p_property_name => :new.property_name,
      p_property_value => :new.property_value);
END;
/

