create view MGMT_V_TIMESERIES_DAILY_HIST as
SELECT target_type,
         target_name,
         metric_name,
         metric_column,
         rollup_timestamp,
         value
  FROM mgmt_v_daily_history
  UNION ALL
  SELECT tgt.target_type,
         tgt.target_name,
         metric_name,
         met.metric_column,
         collection_timestamp,
         curr.value as value
  FROM mgmt_metrics met,
       mgmt_current_metrics curr,
       mgmt_targets tgt
  WHERE tgt.target_guid = curr.target_guid
    AND met.type_meta_ver = tgt.type_meta_ver
    AND met.metric_name in( 'host_storage_history',
                            'group_storage_history' )
    AND (met.category_prop_1 = ' ' OR
         met.category_prop_1 =  tgt.category_prop_1)
    AND (met.category_prop_2 = ' ' OR
         met.category_prop_2 =  tgt.category_prop_2)
    AND (met.category_prop_3 = ' ' OR
         met.category_prop_3 =  tgt.category_prop_3)
    AND (met.category_prop_4 = ' ' OR
         met.category_prop_4 =  tgt.category_prop_4)
    AND (met.category_prop_5 = ' ' OR
         met.category_prop_5 =  tgt.category_prop_5)
    AND met.metric_guid = curr.metric_guid
    AND collection_timestamp >
        (SELECT nvl(max(rollup_timestamp),
         to_date('01-01-0001', 'MM-DD-YYYY' ) )
         FROM mgmt_v_daily_history)
  ORDER BY 5 desc
/

