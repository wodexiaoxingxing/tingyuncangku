create view EM$ECM_INSTALLS_GROUPS as
SELECT UNIQUE
  source_target.target_name as composite_target_name,
  source_target.target_type as composite_target_type,
  t.target_name as software_target_name,
  t.target_type as software_target_type,
  t.target_guid as software_target_guid,
  s.display_target_name as display_host_name,
  s.target_name as host_name,
  h.container_name as container_name,
  h.container_location as container_location,
  h.container_guid as container_guid,
  c.external_name as external_name,
  decode(ivp.version, NULL, c.version, ivp.version) as version,
  c.name as component_name,
  map.property_name,
  map.property_value
FROM
  mgmt_ecm_snapshot s,
  mgmt_inv_container h,
  mgmt_flat_target_assoc tm,
  mgmt_targets source_target,
  mgmt_targets assoc_target,
  mgmt_targets t,
  mgmt_targets host,
  mgmt_inv_component c,
  mgmt_inv_versioned_patch ivp,
  mgmt_target_properties home_prop,
  mgmt_target_type_component_map map
WHERE tm.is_membership = 1
  and tm.assoc_target_guid = t.target_guid
  and source_target.target_guid = tm.source_target_guid
  and assoc_target.target_guid = tm.assoc_target_guid
  and t.host_name = s.target_name
  and s.is_current = 'Y'
  and s.target_type = 'host'
  and s.snapshot_type = 'host_configuration'
  and s.target_name = host.target_name
  and s.target_type = host.target_type
  and s.snapshot_guid = h.snapshot_guid
  and c.container_guid = h.container_guid
  and assoc_target.target_type = map.target_type
  and c.name = map.component_name
  and t.target_guid = home_prop.target_guid
  and home_prop.property_name = 'OracleHome'
  and home_prop.property_value = h.container_location
  and c.component_guid = ivp.component_guid(+)
WITH READ ONLY
/

