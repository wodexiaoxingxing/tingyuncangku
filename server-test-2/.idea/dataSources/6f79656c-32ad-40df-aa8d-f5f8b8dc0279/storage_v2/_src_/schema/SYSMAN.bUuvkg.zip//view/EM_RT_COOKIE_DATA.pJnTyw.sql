create view EM$RT_COOKIE_DATA (RAW_INDEX, NAME, VALUE) as
SELECT raw_index,name,value
    FROM
      MGMT_RT_COOKIE_DATA
/

