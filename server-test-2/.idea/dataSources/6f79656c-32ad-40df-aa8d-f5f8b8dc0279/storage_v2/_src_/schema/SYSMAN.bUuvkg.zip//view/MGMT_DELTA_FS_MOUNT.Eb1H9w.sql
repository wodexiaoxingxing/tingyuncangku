create view MGMT$DELTA_FS_MOUNT as
select
    e.delta_time as refresh_time,
    e.operation as operation,
    s.new_left_target_name as host_name,
    k2.value as resource_name,
    k3.value as type,
    k4.value as mount_location,
    case when e.operation = 'INSERT' then  v.value when e.operation = 'DELETE'
 then v.old_value else v.old_value || '=>' || v.value end as mount_options
 from
  mgmt_delta_ids i,
  mgmt_delta_id_values k2,
  mgmt_delta_id_values k3,
  mgmt_delta_id_values k4,
  mgmt_delta_entry e,
  mgmt_delta_entry_values v,
  mgmt_delta_snap s,
  mgmt_targets t
 where
  i.collection_type = 'ECM$HIST_FS_MOUNT_DETAILS' and
  i.row_guid = k2.delta_ids_guid and
  k2.name = 'RESOURCE_NAME' and
  i.row_guid = k3.delta_ids_guid and
  k3.name = 'TYPE' and
  i.row_guid = k4.delta_ids_guid and
  k4.name = 'MOUNT_LOCATION' and
  i.row_guid = e.row_guid and
  v.delta_entry_guid(+) = e.delta_entry_guid and
  t.target_name = s.new_left_target_name and
  t.target_type = 'host' and
  e.delta_guid = s.delta_guid and
  s.target_type = 'host' and
  s.snapshot_type = 'host_configuration'
/

comment on table MGMT$DELTA_FS_MOUNT is 'The view MGMT$DELTA_FS_MOUNT has been deprecated.'
/

