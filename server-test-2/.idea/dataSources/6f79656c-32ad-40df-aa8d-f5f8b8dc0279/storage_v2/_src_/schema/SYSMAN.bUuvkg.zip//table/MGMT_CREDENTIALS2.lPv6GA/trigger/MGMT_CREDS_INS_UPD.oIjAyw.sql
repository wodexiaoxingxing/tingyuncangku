create trigger MGMT_CREDS_INS_UPD
    before insert or update
    on MGMT_CREDENTIALS2
    for each row
DECLARE
  l_target_guid MGMT_TARGETS.target_guid%TYPE := null;
  l_set_name MGMT_CREDENTIAL_SETS.set_name%TYPE;
  l_cred_value MGMT_CREDENTIALS2.credential_value%TYPE;
BEGIN
    IF :new.credential_value IS NOT NULL THEN
        :new.credential_value := encrypt(:new.credential_value);
    END IF;

    -- For console inserts of credentials, all associated
    -- info is already computed
    -- If updating mgmt_credentials2 from MGMT_CREDS_UPD trigger, no need
    -- to do any further processing, is_no_recursion will be set
    IF MGMT_CREDENTIAL.is_console_insert OR MGMT_CREDENTIAL.is_no_recursion THEN
        RETURN;
    END IF;

    -- Compute associated info for target credentials
    BEGIN
        SELECT target_guid, credential_set_name
        INTO   l_target_guid, l_set_name
        FROM   MGMT_TARGET_CREDENTIALS
        WHERE  credential_guid=:new.credential_guid;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            l_target_guid := null;
    END;

    IF l_target_guid IS NOT NULL THEN
        IF :new.credential_value IS NOT NULL THEN
            l_cred_value := decrypt(:new.credential_value);
        ELSE
            l_cred_value := null;
        END IF;

        MGMT_CREDENTIAL.compute_associated_info(:new.credential_guid,
                                                l_target_guid,
                                                l_set_name,
                                                :new.credential_set_column,
                                                l_cred_value,
                                                :new.credential_type_name,
                                                :new.credential_type_column,
                                                :new.key_value,
                                                :new.assoc_target_guid);
    END IF;

END;
/

