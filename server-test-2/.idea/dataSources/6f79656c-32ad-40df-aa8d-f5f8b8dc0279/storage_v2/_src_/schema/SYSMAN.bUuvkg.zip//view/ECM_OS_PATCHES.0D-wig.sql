create view ECM$OS_PATCHES as
select
    snapshot_guid as ecm_snapshot_id,
    name
from MGMT_HC_OS_COMPONENTS
where type = 'Patch'
/

