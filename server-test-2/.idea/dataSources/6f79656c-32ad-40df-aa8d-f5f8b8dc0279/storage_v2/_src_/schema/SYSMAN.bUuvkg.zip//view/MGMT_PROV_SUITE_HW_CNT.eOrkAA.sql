create view MGMT_PROV_SUITE_HW_CNT as
SELECT
    suite_inst_guid, sum(member_count) as member_count
FROM
(
    SELECT
        st.suite_inst_guid, SUM(clus.node_count) as member_count
    FROM
        mgmt_provision_clus_node_cnt clus, mgmt_prov_suite_inst_members st
    WHERE
        st.member_guid =  clus.cluster_guid and st.member_type = 'cluster'
    GROUP BY
        st.suite_inst_guid
    UNION ALL
    SELECT
        suite_inst_guid, count(*) as member_count
    FROM
        mgmt_prov_suite_inst_members
    WHERE
        member_type = 'hw'
    GROUP BY
        suite_inst_guid
)
GROUP BY suite_inst_guid
WITH READ ONLY
/

