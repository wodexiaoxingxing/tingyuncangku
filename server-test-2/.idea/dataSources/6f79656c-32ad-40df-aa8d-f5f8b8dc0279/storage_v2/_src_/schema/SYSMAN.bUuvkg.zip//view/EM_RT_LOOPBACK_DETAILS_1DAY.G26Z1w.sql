create view EM$RT_LOOPBACK_DETAILS_1DAY as
SELECT
        t.target_guid,
        METRIC_NAME, METRIC_COLUMN, MT.METRIC_GUID, column_label,
        ROLLUP_TIMESTAMP,
        VALUE_AVERAGE, VALUE_MINIMUM,
        VALUE_MAXIMUM, VALUE_SDEV
  FROM
        MGMT_METRICS_1HOUR d, MGMT_TARGETS t, MGMT_METRICS mt
  WHERE mt.metric_name = 'Response'
    AND mt.metric_column = 'Timing'
    AND mt.metric_guid = d.metric_guid
    AND d.target_guid = t.target_guid
    AND t.target_type = mt.target_type
    AND t.type_meta_ver = mt.type_meta_ver
    AND (t.category_prop_1 = mt.category_prop_1 OR mt.category_prop_1 = ' ')
    AND (t.category_prop_2 = mt.category_prop_2 OR mt.category_prop_2 = ' ')
    AND (t.category_prop_3 = mt.category_prop_3 OR mt.category_prop_3 = ' ')
    AND (t.category_prop_4 = mt.category_prop_4 OR mt.category_prop_4 = ' ')
    AND (t.category_prop_5 = mt.category_prop_5 OR mt.category_prop_5 = ' ')
    AND d.ROLLUP_TIMESTAMP >= (SYSDATE - 1)
/

