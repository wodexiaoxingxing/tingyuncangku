create view MGMT$CSM_IP_DAILY
            (TARGET_NAME, TARGET_TYPE, VISITOR, ROLLUP_TIMESTAMP, METRIC_NAME, SAMPLE_COUNT, AVERAGE, MINIMUM, MAXIMUM,
             STANDARD_DEVIATION, VARIANCE)
as
SELECT
  st.target_name, st.target_type,
  ru.visitor_node, ru.rollup_timestamp, ru.metric_name,
  SUM(ru.hits),
  DECODE(SUM(ru.hits),
    0, 0,
    SUM(ru.response_time_average * ru.hits)/SUM(ru.hits)),
  MIN(ru.response_time_minimum),
  MAX(ru.response_time_maximum),
  DECODE(
    SUM(ru.hits),
    0, 0,
    1, 0,
    SQRT(
      (SUM(ru.hits) *
        (SUM(DECODE(ru.hits,
          0, 0,
          (((ru.response_time_variance * ru.hits * (ru.hits - 1)) +
            POWER((ru.hits * ru.response_time_average), 2)) / ru.hits))
        )) - POWER(SUM(ru.response_time_average * ru.hits), 2)
      ) / (SUM(ru.hits) * (SUM(ru.hits) - 1))
    )
  ),
  DECODE(
    SUM(ru.hits),
    0, 0,
    1, 0,
    (SUM(ru.hits) *
      (SUM(DECODE(ru.hits,
        0, 0,
        (((ru.response_time_variance * ru.hits * (ru.hits - 1)) +
          POWER((ru.hits * ru.response_time_average), 2)) / ru.hits))
      )) - POWER(SUM(ru.response_time_average * ru.hits), 2)
    ) / (SUM(ru.hits) * (SUM(ru.hits) - 1))
  )
FROM
  MGMT_RT_IP_1DAY ru,
  MGMT_TARGET_ASSOCS tm,
  MGMT_TARGETS st,
  MGMT_TARGET_ASSOC_DEFS d
WHERE ru.target_guid = tm.assoc_target_guid
  AND tm.assoc_guid = d.assoc_guid
  AND d.assoc_def_name = 'supports_eum_on'
  AND d.scope_target_type = ' '
  AND st.target_guid = tm.source_target_guid
GROUP BY
  st.target_name, st.target_type,
  ru.visitor_node, ru.rollup_timestamp, ru.metric_name
WITH READ ONLY
/

