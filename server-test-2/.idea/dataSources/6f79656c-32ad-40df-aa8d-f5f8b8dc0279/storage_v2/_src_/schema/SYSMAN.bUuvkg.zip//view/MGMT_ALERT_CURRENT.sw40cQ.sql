create view MGMT$ALERT_CURRENT as
SELECT
            t.target_name, t.target_type, t.target_guid, c.violation_guid,
            m.metric_name, m.metric_column,c.policy_guid,
            m.metric_label,
            CASE
              WHEN m.is_transposed = 0 THEN
                 m.column_label
              ELSE
                 c.key_value
              END,
            c.key_value, null, null, null, null,
            c.collection_timestamp,
            DECODE (c.violation_level, 20, 'Warning', 25, 'Critical', 'Unknown'),
            c.violation_level,
            DECODE (c.violation_type, 0, 'Threshold Violation',
                                      1, 'Availability',
                                      2, 'Resource',
                                      3, 'Policy Violation',
                                         'Unknown'),
            c.message,c.message_nlsid,c.message_params,c.action_message,
            c.action_message_nlsid,c.action_message_params,
            tt.type_display_name
          FROM
            mgmt_targets t,
            mgmt_metrics m,
            mgmt_target_types tt,
            mgmt_current_violation c
          WHERE t.target_guid = c.target_guid
            AND m.metric_guid = c.policy_guid
            and tt.target_type = t.target_type
            and m.num_keys < 2
            and c.violation_type IN (0,1,2)
            and t.target_type = m.target_type
            and t.type_meta_ver = m.type_meta_ver
            and (t.category_prop_1 = m.category_prop_1
                 or m.category_prop_1 = ' ')
            and (t.category_prop_2 = m.category_prop_2
                 or m.category_prop_2 = ' ')
            and (t.category_prop_3 = m.category_prop_3
                 or m.category_prop_3 = ' ')
            and (t.category_prop_4 = m.category_prop_4
                 or m.category_prop_4 = ' ')
            and (t.category_prop_5 = m.category_prop_5
                 or m.category_prop_5 = ' ')
     UNION ALL
        SELECT
            t.target_name, t.target_type, t.target_guid, c.violation_guid,
            m.metric_name, m.metric_column,c.policy_guid,
            m.metric_label,
            CASE
              WHEN m.is_transposed = 0 THEN
                 m.column_label
              ELSE
                 k.key_part1_value
              END,
            k.key_part1_value,  k.key_part2_value,  k.key_part3_value,
            k.key_part4_value,  k.key_part5_value,
            c.collection_timestamp,
            DECODE (c.violation_level, 20, 'Warning', 25, 'Critical', 'Unknown'),
            c.violation_level,
            DECODE (c.violation_type, 0, 'Threshold Violation',
                                      1, 'Availability',
                                      2, 'Resource',
                                      3, 'Policy Violation',
                                         'Unknown'),
            c.message,c.message_nlsid,c.message_params,c.action_message,
            c.action_message_nlsid,c.action_message_params,
            tt.type_display_name
          FROM
            mgmt_targets t,
            mgmt_metrics m,
            mgmt_target_types tt,
            mgmt_current_violation c,
            mgmt_metrics_composite_keys k
          WHERE t.target_guid = c.target_guid
            and m.metric_guid = c.policy_guid
            and tt.target_type = t.target_type
            and t.target_type = m.target_type
            and m.num_keys > 1
            and c.violation_type IN (0,1,2)
            and t.type_meta_ver = m.type_meta_ver
            and (t.category_prop_1 = m.category_prop_1
                 or m.category_prop_1 = ' ')
            and (t.category_prop_2 = m.category_prop_2
                 or m.category_prop_2 = ' ')
            and (t.category_prop_3 = m.category_prop_3
                 or m.category_prop_3 = ' ')
            and (t.category_prop_4 = m.category_prop_4
                 or m.category_prop_4 = ' ')
            and (t.category_prop_5 = m.category_prop_5
                 or m.category_prop_5 = ' ')
            and c.target_guid = k.target_guid
            and c.key_value = k.composite_key
    WITH READ ONLY
/

