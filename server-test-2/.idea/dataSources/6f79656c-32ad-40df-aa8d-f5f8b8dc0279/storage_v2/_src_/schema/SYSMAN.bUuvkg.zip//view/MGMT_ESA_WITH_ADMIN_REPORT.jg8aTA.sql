create view MGMT$ESA_WITH_ADMIN_REPORT as
SELECT tgt.target_guid AS "TARGET_GUID",
           tgt.target_name AS "TARGET_NAME",
           esa_report.principal AS "PRINCIPAL",
           esa_report.object_name AS "OBJECT_NAME"
           FROM mgmt_esa_report esa_report, mgmt_ecm_gen_snapshot ecm, mgmt_targets tgt
           WHERE esa_report.ecm_snapshot_id = ecm.snapshot_guid AND
	   tgt.target_guid = ecm.target_guid AND
           ecm.is_current = 'Y' AND
           esa_report.report_name = 'WITH_ADMIN'
/

