create view MGMT$DELTA_INIT as
SELECT
  e.delta_time,
  e.operation,
  g.host_name,
  g.target_guid,
  g.target_name,
  g.target_type,
  n.value as name,
  d.name as attribute_name,
  d.old_value,
  d.value as new_value,
  ecm_util.GET_GENERIC_VALS_DATATYPE( d.value ) as datatype
FROM
  mgmt_delta_entry e,
  mgmt_delta_entry_values d,
  mgmt_delta_ids i,
  mgmt_delta_id_values n,
  mgmt_delta_snap p,
  mgmt_targets g
WHERE i.row_guid = e.row_guid and
  i.collection_type = 'MGMT_DB_INIT_PARAMS_ECM' and
  i.row_guid = n.delta_ids_guid and
  n.name='NAME' and
  e.delta_entry_guid = d.delta_entry_guid and
  p.delta_guid = e.delta_guid and
  p.snapshot_type = 'oracle_dbconfig' and
  p.target_type = 'oracle_database' and
  p.new_left_target_name = g.target_name and
  p.old_right_target_name = g.target_name and
  p.target_type = g.target_type and
  p.delta_type = 'HISTORY'
/

