create view ESM_COLLECTION_LATEST as
SELECT ecm.target_guid AS "TARGET_GUID",
         esm.property AS PROPERTY,
         esm.value AS VALUE,
         esm.value2 AS VALUE2
  FROM esm_collection esm, mgmt_ecm_gen_snapshot ecm
  WHERE esm.ecm_snapshot_id = ecm.snapshot_guid
  AND ecm.is_current = 'Y'
  AND ecm.snapshot_type in ('oracle_security', 'oracle_security_inst')
/

