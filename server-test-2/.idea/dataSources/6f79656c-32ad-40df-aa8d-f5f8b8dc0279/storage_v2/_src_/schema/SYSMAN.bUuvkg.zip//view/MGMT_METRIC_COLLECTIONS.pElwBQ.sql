create view MGMT_METRIC_COLLECTIONS
            (TARGET_GUID, METRIC_GUID, COLL_NAME, IS_REPOSITORY, STORE_METRIC, SCHEDULE, SCHEDULE_EX,
             LAST_COLLECTED_TIMESTAMP, STATUS_MESSAGE, SUSPENDED)
as
SELECT c.object_guid, cmt.metric_guid, c.coll_name,
         0, DECODE(c.store_metric, 1, 'Y', 'N'), c.interval,
         c.schedule_ex, cmt.last_collected_timestamp,
	 cmt.status_message, DECODE(c.is_enabled, 1, 0, 1)
    FROM mgmt_collections c,
         mgmt_collection_metric_tasks cmt
   WHERE c.object_guid = cmt.target_guid
     AND c.coll_name = cmt.coll_name
     AND c.object_type = 2
/

create trigger EM_INSERT_COLLECTION
    instead of insert
    on MGMT_METRIC_COLLECTIONS
    for each row
begin
    -- missing source code
end
/

create trigger EM_UPDATE_COLLECTION
    instead of update
    on MGMT_METRIC_COLLECTIONS
    for each row
begin
    -- missing source code
end
/

create trigger EM_DELETE_COLLECTION
    instead of delete
    on MGMT_METRIC_COLLECTIONS
    for each row
begin
    -- missing source code
end
/

