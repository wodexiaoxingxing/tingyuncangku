create view ECM$HARDWARE_MASTER as
select
  snapshot_guid as ecm_snapshot_id,
  vendor_name,
  system_config,
  machine_architecture,
  local_disk_space_in_gb,
  clock_freq_in_mhz,
  memory_size_in_mb,
  cpu_count,
  cpu_board_count,
  iocard_count,
  fan_count,
  power_supply_count
from MGMT_HC_HARDWARE_MASTER
/

