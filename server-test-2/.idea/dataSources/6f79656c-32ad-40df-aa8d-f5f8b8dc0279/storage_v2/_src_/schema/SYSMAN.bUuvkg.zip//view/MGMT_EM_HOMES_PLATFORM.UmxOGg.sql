create view MGMT$EM_HOMES_PLATFORM as
SELECT
  home.container_guid as home_id,
  plat.platform_id as platform_id,
  plat.platform_name as platform
FROM
  mgmt_inv_container home,
  mgmt_inv_container_property prop,
  mgmt_aru_platforms plat,
  mgmt_ecm_snapshot snap,
  mgmt_targets target
WHERE
  home.container_type = 'O' and
  home.container_guid = prop.container_guid and
  prop.property_name = 'ARU_PLATFORM_ID' and
  plat.platform_id = to_number(prop.property_value) and
  home.snapshot_guid = snap.snapshot_guid and
  snap.target_name = target.target_name and
  snap.target_type = target.target_type and
  snap.snapshot_type = 'host_configuration' and
  snap.is_current = 'Y'
UNION
SELECT
  distinct home.container_guid as home_id,
  plat.platform_id as platform_id,
  hos.property_value as platform
FROM
  mgmt_inv_container home,
  mgmt_ecm_snapshot snap,
  mgmt_targets htg,
  mgmt_target_properties hos,
  mgmt_aru_platforms plat
WHERE
  home.container_type = 'O' and
  home.snapshot_guid = snap.snapshot_guid and
  snap.snapshot_type = 'host_configuration' and
  snap.is_current = 'Y' and
  snap.target_name = htg.target_name and
  snap.target_type = htg.target_type and
  htg.target_type =  'host' and
  htg.target_guid  = hos.target_guid and
  hos.property_name = 'OS' and
  hos.property_value is not null and
  plat.em_os_name = hos.property_value and
        not exists (
           select
            property_value
           from
            mgmt_inv_container_property p
           where
               container_guid = home.container_guid  and
               p.property_name = 'ARU_PLATFORM_ID'
          )
WITH READ ONLY
/

