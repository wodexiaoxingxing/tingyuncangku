create view MGMT$DB_DBNINSTANCEINFO as
select
  g.host_name,
  s.target_name,
  s.target_type,
  s.target_guid,
  s.start_timestamp as collection_timestamp,
  i.database_name,
  i.global_name,
  i.banner,
  i.host_name as host,
  i.instance_name,
  i.startup_time,
  i.logins,
  i.log_mode,
  i.open_mode,
  i.default_temp_tablespace,
  i.characterset,
  i.national_characterset
from
  mgmt_targets g,
  mgmt_db_dbninstanceinfo_ecm i,
  mgmt_ecm_gen_snapshot s
where
  s.snapshot_guid = i.ecm_snapshot_id and
  s.target_guid = g.target_guid and
  s.is_current = 'Y'
/

