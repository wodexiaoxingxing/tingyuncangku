create view MGMT$CSA_CLIENT_RULE_VIOLS as
SELECT
  c.appid as application,
  c.compliance as compliance,
  c.csaclient as csaclient,
  c.snapshot_id as snapshotid,
  ecm_util.csa_client_rule_list(c.snapshot_id) as list
FROM MGMT$CSA_COLLECTIONS c
/

