create trigger BCN_STEPGROUP_INSERT_TRIGGER
    before insert
    on MGMT_BCN_STEPGROUP_DEFN
    for each row
DECLARE
  v_stepgroup_guid    RAW(16);
BEGIN

    IF (:new.txn_guid IS NOT NULL) AND
       (:new.name IS NOT NULL) THEN

      IF :new.stepgroup_guid IS NULL THEN
        v_stepgroup_guid :=
            dbms_obfuscation_toolkit.md5(
                   input => utl_raw.cast_to_raw(
                                   RAWTOHEX(:new.txn_guid) ||
                                   ';' || :new.stepgroup_type ||
                                   ';' || :new.name));
        :new.stepgroup_guid := v_stepgroup_guid;
      END IF;

    END IF;

END;
/

