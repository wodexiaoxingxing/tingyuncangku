create view MGMT$CSA_HOST_COOKIES as
SELECT
       s.display_target_name,
       c.name,
       c.value,
       s.snapshot_guid as snapshot_id,
       s.target_guid as target_id,
       s.start_timestamp as collection_timestamp
 FROM mgmt_ecm_gen_snapshot s,
      mgmt_ecm_csa_cookies c
WHERE s.snapshot_type = 'oracle_csa_host'
  AND s.is_current = 'Y'
  AND s.snapshot_guid = c.ecm_snapshot_id
  AND (EXISTS (SELECT * FROM mgmt_ecm_csa_general_info info,
                 mgmt_ecm_csa_appid_target_map m, mgmt_targets t
               WHERE s.snapshot_guid = info.ecm_snapshot_id
                 AND info.appid = m.appid
                 AND t.target_guid = m.target_guid)
      OR
      mgmt_user.has_priv(mgmt_user.get_current_em_user(), 'SUPER_USER') = 1)
WITH READ ONLY
/

