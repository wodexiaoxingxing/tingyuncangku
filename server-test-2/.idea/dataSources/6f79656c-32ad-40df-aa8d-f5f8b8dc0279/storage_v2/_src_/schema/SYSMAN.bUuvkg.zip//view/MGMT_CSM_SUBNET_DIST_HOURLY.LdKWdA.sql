create view MGMT$CSM_SUBNET_DIST_HOURLY
            (TARGET_NAME, TARGET_TYPE, VISITOR_SUBNET, ROLLUP_TIMESTAMP, METRIC_NAME, METRIC_VALUE, SAMPLE_COUNT) as
SELECT
  st.target_name, st.target_type,
  ru.visitor_subnet, ru.rollup_timestamp,
  ru.metric_name, ru.num_seconds, SUM(ru.hits)
FROM
  MGMT_RT_DOMAIN_DIST_1HOUR ru,
  MGMT_TARGET_ASSOCS tm,
  MGMT_TARGETS st,
  MGMT_TARGET_ASSOC_DEFS d
WHERE ru.target_guid = tm.assoc_target_guid
  AND tm.assoc_guid = d.assoc_guid
  AND d.assoc_def_name = 'supports_eum_on'
  AND d.scope_target_type = ' '
  AND st.target_guid = tm.source_target_guid
  AND ru.dist_value_type = 0
GROUP BY
  st.target_name, st.target_type,
  ru.visitor_subnet, ru.rollup_timestamp,
  ru.metric_name, ru.num_seconds
WITH READ ONLY
/

