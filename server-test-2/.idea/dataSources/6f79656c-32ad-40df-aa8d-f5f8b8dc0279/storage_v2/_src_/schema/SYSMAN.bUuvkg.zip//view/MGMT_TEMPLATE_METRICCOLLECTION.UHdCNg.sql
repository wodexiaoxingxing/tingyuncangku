create view MGMT$TEMPLATE_METRICCOLLECTION
            (TEMPLATE_NAME, TARGET_TYPE, TEMPLATE_GUID, METRIC_NAME, METRIC_COLUMN, METRIC_GUID, COLLECTION_NAME,
             IS_REPOSITORY, FREQUENCY_CODE, COLLECTION_FREQUENCY, UPLOAD_POLICY)
as
SELECT tt.template_name, tt.target_type, tt.template_guid,
           m.metric_name, m.metric_column, m.metric_guid,
           c.coll_name, m.is_repository,
           DECODE(c.frequency_code, 1, 'One Time',
                                    2, 'Interval',
                                    3, 'Daily',
                                    4, 'Weekly',
                                    5, 'Monthly',
                                    6, 'Yearly',
                                    'On-Demand'),
           DECODE(c.frequency_code,
                   1, TO_CHAR(c.start_time,'DD-MON-YY HH24:MI'),
                   2, to_char(interval),
                   3, to_char(execution_hours)||':'||to_char(execution_minutes),
                   4, to_char(execution_hours)||':'||to_char(execution_minutes),
                   5, to_char(execution_hours)||':'||to_char(execution_minutes),
                   6, to_char(execution_hours)||':'||to_char(execution_minutes),
                   'On-Demand'),
           c.upload_frequency
      FROM mgmt_templates tt,
           mgmt_metrics m,
           mgmt_collections c,
           mgmt_collection_metric_tasks cmt
     WHERE tt.target_type = m.target_type
       AND c.object_guid = tt.template_guid
       AND m.metric_guid = cmt.metric_guid
       AND c.object_guid = cmt.target_guid
       AND c.coll_name = cmt.coll_name
       AND c.object_type = 3
WITH READ ONLY
/

