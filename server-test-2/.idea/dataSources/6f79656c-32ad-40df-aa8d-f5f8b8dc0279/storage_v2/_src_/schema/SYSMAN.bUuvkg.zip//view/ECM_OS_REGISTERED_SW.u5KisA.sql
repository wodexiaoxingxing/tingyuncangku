create view ECM$OS_REGISTERED_SW as
select
    snapshot_guid as ecm_snapshot_id,
    name,
    vendor_name,
    version,
    count(*) as count
from MGMT_HC_VENDOR_SW_SUMMARY
group by snapshot_guid, name, vendor_name, version
/

