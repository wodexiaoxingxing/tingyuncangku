create view ECM$HIST_INV_PATCHES as
SELECT
  h.snapshot_guid AS ecm_snapshot_id,
  p.id,
  h.container_location,
  p.description,
  p.timestamp,
  p.is_rollbackable
FROM
  mgmt_inv_patch p,
  mgmt_inv_container h
WHERE p.container_guid = h.container_guid
WITH READ ONLY
/

