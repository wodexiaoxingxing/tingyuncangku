create view MGMT_PROVISION_CLUS_NODE_CNT as
SELECT
    cluster_guid, count(*) node_count
FROM
    mgmt_prov_cluster_nodes
GROUP BY
    cluster_guid
WITH READ ONLY
/

