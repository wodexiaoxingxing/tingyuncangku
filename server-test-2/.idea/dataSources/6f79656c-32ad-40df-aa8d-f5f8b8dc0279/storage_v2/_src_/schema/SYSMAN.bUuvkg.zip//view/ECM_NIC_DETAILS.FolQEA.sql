create view ECM$NIC_DETAILS as
select
  snapshot_guid as ecm_snapshot_id,
  name,
  flags,
  max_transfer_unit,
  mask,
  count(*) as count
from
  MGMT_HC_NIC_DETAILS
group by snapshot_guid, name, flags,max_transfer_unit, mask
/

