create PROCEDURE          "UPDATE_STREAM_CONNECT" 
is 
  sqlStr  varchar2(4000);  
  v_error_desc varchar2(400);
  v_s number;
begin
  create_procedure_log('update_stream_connect','start','message');
  for tableName in(select t.table_name as name from user_tables t where t.table_name like 'NB_STREAM_%') loop
  begin
      create_procedure_log('update_stream_connect',tableName.name,'message');
      sqlStr:='update ' ||tableName.name || ' set ts_connect_stream = ts_connect where tm_base > to_date(''2010-01-01 00:01'',''yyyy-mm-dd hh24:mi'') and tm_base < to_date(''2010-05-17 12:00'',''yyyy-mm-dd hh24:mi'')';
      execute immediate sqlStr;
      commit;
      /*
      sqlStr:='update ' ||tableName.name || ' set ts_connect = 0 where tm_base > to_date(''2010-01-01 00:01'',''yyyy-mm-dd hh24:mi'') and tm_base < to_date(''2010-05-17 12:00'',''yyyy-mm-dd hh24:mi'')';
      execute immediate sqlStr;
      commit;
      */
  exception when  others then
      v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
      DBMS_OUTPUT.PUT_LINE(sqlStr);
      create_procedure_log('update_stream_connect',v_error_desc,sqlcode);
  end;
  end loop;
  create_procedure_log('update_stream_connect','end','message');
end update_stream_connect;


/

