create PROCEDURE ALTER_LOG_FIELD
is
  sqlStr  varchar2(4000);
   tableName varchar2(32);--表名称
partNamePref varchar2(32);--分区前缀 
 

--本存储过程支持对两个ddc_log表的分区维护，
--增加，判断是否是30天内，如果是，可以增加一个（一次只增加一个),否则不能增加
--删除，判断是否是30天内，如果是，不能删除，否则删除最前一个分区（一次只能删除一个分区)


begin
  for  i in (select table_name,partition_name,partition_position from user_tab_partitions where table_name = 'NB_M_DDC_LOG_DSP') loop
  begin
    
         tableName := 'NB_M_DDC_LOG_DSP';
       partNamePref := 'PART_DDC_LOG_DSP_'||I.PARTITION_POSITION;
  
 
        sqlStr := 'alter table '||tableName||' RENAME PARTITION '||I.PARTITION_NAME||' TO '||partNamePref;
    --  dbms_output.put_line(sqlStr);
    execute   immediate   sqlStr ;

  
       exception when  others then
         dbms_output.put_line(sqlerrm); 
  end;
        
  end loop;

end ALTER_LOG_FIELD;


/

