create PROCEDURE "FETCH_SEQUENCE_MOB_PAGE" (tableStr in varchar, seqCount in integer, seqList out varchar) is
   seq integer;
   seq_cur sys_refcursor;
begin
  seqList := '';
  for i in 1 .. seqCount loop
    open seq_cur for 'select SEQ_NB_MOB_PAGE_ID_' || tableStr || '.nextval from dual';
    fetch seq_cur into seq;
    seqList := seqList || ',' || to_char(seq);
    close seq_cur;
  end loop;
  if length(seqList) > 0 then
     seqList := substr(seqList, 2);
  end if;
end FETCH_SEQUENCE_MOB_PAGE;


/

