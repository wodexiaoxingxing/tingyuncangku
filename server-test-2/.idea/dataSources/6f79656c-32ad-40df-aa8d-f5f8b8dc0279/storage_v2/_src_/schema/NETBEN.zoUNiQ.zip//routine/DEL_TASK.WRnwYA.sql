create PROCEDURE "DEL_TASK" (
   tId in number
)authid current_user is
   sqlStr varchar2(4000);
   v_s int;
   type tmp_cursor is ref cursor;
   columnArr tmp_cursor;
   columnName varchar2(100);
   columnStr varchar2(4000);
begin
   -- 任务ID找不到，直接返回
   select count(*) into v_s from nb_m_task where id = tId;
   if (v_s = 0) then create_procedure_log('del_task','任务ID未找到，ID：'||tId,'error'); return; end if;
   
   create_procedure_log('del_task','开始删除任务,任务ID：'||tId,'run');
   
   -- 首先判断任务是否可以删除（是否状态逻辑删除，且删除时间超过一个月）
   select status into v_s from nb_m_task where id = tId;
   if (v_s != -1) then create_procedure_log('del_task','任务不是逻辑删除，不能删除，任务ID：'||tId,'error'); return; end if;
   select round(mtime - (sysdate-30))into v_s from nb_m_task where id = tId;
   if (v_s > 0) then create_procedure_log('del_task','任务删除日期未过30天不能删除,任务ID：'||tId,'error'); return; end if;

   select count(*) into v_s from user_tables where table_name ='NB_ET_'||tId;
   if (v_s > 0) then 
      sqlStr:='drop table nb_et_'||tId;
      execute immediate sqlStr;
      dbms_output.put_line(sqlStr);
   end if;
   
   select count(*) into v_s from user_tables where table_name ='NB_ETT_'||tId;
   if (v_s > 0) then 
      sqlStr:='drop table nb_ett_'||tId;
      execute immediate sqlStr;
       dbms_output.put_line(sqlStr);
   end if;
   
   select count(*) into v_s from user_tables where table_name ='NB_ETD_'||tId;
   if (v_s > 0) then 
      sqlStr:='drop table nb_etd_'||tId;
      execute immediate sqlStr;
      dbms_output.put_line(sqlStr);
   end if;   
   
   -- 任务相关表
   -- 执行计划
   sqlStr:='delete from nb_m_task_schedule where task_id = :id';
   execute immediate sqlStr using tId;
   dbms_output.put_line(sqlStr);
   -- 步骤
   sqlStr:='delete from nb_m_task_page_seq where task_id = :id';
   execute immediate sqlStr using tId;
   dbms_output.put_line(sqlStr);
   -- 任务(排除相关)
   sqlStr:='delete from nb_m_task_ignore_hostid where task_id = :id';
   execute immediate sqlStr using tId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_task_ignore_probe where task_id = :id';
   execute immediate sqlStr using tId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_os_bs_filter where task_id = :id';
   execute immediate sqlStr using tId;
   dbms_output.put_line(sqlStr);
   
   -- 任务（数据服务器)
   sqlStr:='delete from nb_m_task_datasvr where task_id = :id';
   execute immediate sqlStr using tId;
   dbms_output.put_line(sqlStr);
   -- 任务对应的目标主机
   sqlStr:='delete from nb_m_task_dest where task_id = :id';
   execute immediate sqlStr using tId;
   dbms_output.put_line(sqlStr);
   -- 任务对应的分组
   sqlStr:='delete from nb_m_usergroup_task where task_id = :id';
   execute immediate sqlStr using tId;
   dbms_output.put_line(sqlStr);
   -- 用户对应任务
   sqlStr:='delete from nb_m_user_task where task_id = :id';
   execute immediate sqlStr using tId;
   dbms_output.put_line(sqlStr);
   -- 任务对应分类表
   sqlStr:='delete from nb_m_category_task where task_id = :id';
   execute immediate sqlStr using tId;
   dbms_output.put_line(sqlStr);
   -- 任务绑定表
   sqlStr:='delete from nb_m_task_bind_detail where task_id = :id';
   execute immediate sqlStr using tId;
   dbms_output.put_line(sqlStr);
 

   -- 业务相关表删除
   -- 警报
   sqlStr:='delete from nb_alarm_static where task_id = :id';
   execute immediate sqlStr using tId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_alarm_log_static where task_id =:id';
   execute immediate sqlStr using tId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_alarm_threshold where task_id =:id';
   execute immediate sqlStr using tId;
   dbms_output.put_line(sqlStr);

   -- 备份数据
   -- 任务表 
   sqlStr := 'select column_name from user_tab_columns where table_name = ''NB_M_TASK_HIS'''; 
   open columnArr for sqlStr;
   loop
        fetch columnArr into columnName;
        exit when columnArr%notfound;
        columnStr:=columnName||','||columnStr;
   end loop;
   columnStr:=substr(columnStr,1,length(columnStr)-1);
   sqlStr:='insert into nb_m_task_his('||columnStr||') select '||columnStr||' from nb_m_task where id = :id';
   -- dbms_output.put_line(sqlStr);
   execute immediate sqlStr using tId;  
   close columnArr;
     
   -- 任务主表
   sqlStr:='delete from nb_m_task where id = :id';
   execute immediate sqlStr using tId;
   dbms_output.put_line(sqlStr);
   
   commit;
   create_procedure_log('del_task','删除任务完成,任务ID：'||tId,'run');
exception when  others then
   create_procedure_log('del_task',sqlerrm|| ',sql:'||sqlStr,'error');
   rollback;
end del_task;


/

