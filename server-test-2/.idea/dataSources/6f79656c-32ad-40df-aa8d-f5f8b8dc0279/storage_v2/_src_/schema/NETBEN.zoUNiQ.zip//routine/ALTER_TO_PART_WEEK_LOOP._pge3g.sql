create procedure alter_to_part_week_loop(tableName varchar2,partNamePre varchar2,re_num number) authid current_user is
sqlStr varchar2(32767);
rangeDate date;
rangeDesc varchar2(8);
partName1 varchar2(64);
rangeName1 varchar2(64);

createDate date;
--拷贝数据用变量
stDesc varchar2(32);
etDesc varchar2(32);
begin
  create_procedure_log('alter_to_part_week_loop',tableName||',begin','run');
    begin
      sqlStr:='drop table '||tableName||'_t';
      dbms_output.put_line(sqlStr||';');
      --execute immediate sqlStr;表空间也要重写
    exception when others then
      create_procedure_log('alter_to_part_week_loop',tableName||','||sqlerrm,'error');  
    end; 
  DBMS_OUTPUT.ENABLE(999999999999999999999);
  createDate:=sysdate-re_num;
  rangeDate := trunc(createDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd'); 
  partName1:=partNamePre||'_'||rangeDesc;
  rangeName1:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';  
  sqlStr:=' create table '||tableName||'_t partition by range (tm_base) subpartition by hash(task_id) subpartitions 8( partition '||partName1||' values less than ('||rangeName1||')'||chr(13);
  for i in 1..re_num/7 loop    
  rangeDate := trunc(rangeDate + 7,'dd');
  rangeDesc := to_char(rangeDate,'yymmdd'); 
  sqlStr:=sqlStr||',partition '||partNamePre||'_'||rangeDesc||' values less than ('||'to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd''))'||chr(13);
 end loop;
 sqlStr:=sqlStr||')  tablespace netben_bg as select * from '||tableName||' where 1=0';
         

        dbms_output.put_line(sqlStr||';');
        --execute immediate sqlStr;
       
       
       
        -- 创建索引,这个语句要重写
         begin
          create_procedure_log('alter_to_part_tmp',tableName||','||'创建索引IDX_ALARM_TASK_TB_PT','run'); 
          sqlStr:='create index IDX_ALARM_TASK_TB_PT on '||tableName||'_t (TM_BASE, POINT_TOTAL)  LOCAL tableSpace NETBEN_IDX_NEW nologging';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_to_part_tmp',tableName||','||sqlStr||','||sqlerrm,'error'); 
        end;  
        /*
        begin
          create_procedure_log('alter_to_part_week_loop',tableName||','||'创建索引idx_nb_plg_id','run'); 
          sqlStr:='create index idx_nb_plg_id on '||tableName||'_t (id) local compress 1 tableSpace NETBEN_IDX_NEW nologging';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_to_part_week_loop',tableName||','||sqlStr||','||sqlerrm,'error'); 
        end;  
        
        begin
          create_procedure_log('alter_to_part_week_loop',tableName||','||'创建索引idx_nb_plg_csm','run'); 
          sqlStr:='create index idx_nb_plg_ch on '||tableName||'_t (ctime,host_id) local compress 2 tableSpace NETBEN_IDX_NEW nologging';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_to_part_week_loop',tableName||','||sqlStr||','||sqlerrm,'error'); 
        end;  
       
        
       begin
          create_procedure_log('alter_to_part_tmp',tableName||','||'创建索引in_page_perf','run'); 
          sqlStr:='create index in_dsp_mb_task on '||tableName||'_temp (tm_base,task_id) compress 2 LOCAL tableSpace NETBEN_IND nologging';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_to_part_tmp',tableName||','||sqlStr||','||sqlerrm,'error'); 
        end;
        */
        --注意时间的起始点，保留天数，i的最大值加1
        for i in 1..re_num loop
          stDesc:=to_char(sysdate - (re_num+1-i)-1,'yyyy-mm-dd');
          etDesc:=to_char(sysdate - (re_num-i)-1,'yyyy-mm-dd');
          sqlStr:='insert into '||tableName||'_t 
              select * from '||tableName||' where tm_base >= to_date('''||stDesc||''',''yyyy-mm-dd'') and tm_base<to_date('''||etDesc||''',''yyyy-mm-dd'')';
          dbms_output.put_line(sqlStr||';'); 
          dbms_output.put_line('commit;');       
        end loop;         
      sqlStr:='rename '||tableName|| ' to '||tableName||'_bk';
      dbms_output.put_line(sqlStr||';');             
      sqlStr:='rename '||tableName||'_t to '||tableName;
      dbms_output.put_line(sqlStr||';');  
      --改完名后把最后1天数据导过来
      stDesc:=to_char(sysdate-1,'yyyy-mm-dd');
      etDesc:=to_char(sysdate+1,'yyyy-mm-dd');
      sqlStr:='insert into '||tableName||' 
              select * from '||tableName||'_bk where tm_base >= to_date('''||stDesc||''',''yyyy-mm-dd'') and tm_base<to_date('''||etDesc||''',''yyyy-mm-dd'')';
      dbms_output.put_line(sqlStr||';'); 
      dbms_output.put_line('commit;');    
      create_procedure_log('alter_to_part_week_loop',tableName||',end','run');
      exception when others then
        create_procedure_log('alter_to_part_week_loop',tableName||','||sqlerrm,'error');  
end alter_to_part_week_loop;


/

