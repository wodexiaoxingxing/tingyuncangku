create PROCEDURE          "MAN_ALTER_PING_ADD_FIELD" 
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(4000);
  v_s number;
begin
  for tableName in(select t.table_name as name from user_tables t where t.table_name like 'NB_PING_%' ) loop
  begin
    create_procedure_log('alter_ping_add_field',tableName.name,'message');
   --     dbms_output.put_line(v_s);
    --    sqlStr := 'alter table '||tableName.Name||' drop primary key';
  --      execute   immediate   sqlStr ;
    --    dbms_output.put_line(sqlStr);
  --      sqlStr := 'create index lpk_'||tableName.Name||' on '||tableName.Name||'(id) nologging parallel 2';
   --      dbms_output.put_line(sqlStr);
 --     execute   immediate   sqlStr ;


 /* ##############
alter table tablename drop constraint column cascade

      select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='PAGE_SEQ';
    if v_s = 1 then
        sqlStr := 'alter table '||tableName.Name||' drop column PAGE_SEQ';
        execute   immediate   sqlStr ;
         dbms_output.put_line(sqlStr);
        sqlStr := 'alter table '||tableName.Name||' add PAGE_SEQ number default 1';
        execute   immediate   sqlStr ;
        dbms_output.put_line(sqlStr);
      els
      #################################

      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add PAGE_SEQ number default 1';
         dbms_output.put_line(sqlStr);
        execute   immediate   sqlStr ;
 dbms_output.put_line(sqlStr);
      end if;

       */

    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='DNS_SERVER';
      if v_s > 0 then
        sqlStr := 'alter table '||tableName.Name||' MODIFY DNS_SERVER varchar2(128) ';
    execute   immediate   sqlStr ;
 dbms_output.put_line(sqlStr);
      end if;

/*
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='BS_ID';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add BS_ID number';
        execute   immediate   sqlStr ;
 dbms_output.put_line(sqlStr);
      end if;

    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='BS_VER_ID';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add BS_VER_ID number';
        execute   immediate   sqlStr ;
 dbms_output.put_line(sqlStr);
      end if;
*/


    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlStr);
        create_procedure_log('alter_ping_add_field',v_error_desc,sqlcode);
  end;
  end loop;
end MAN_alter_ping_add_field;


/

