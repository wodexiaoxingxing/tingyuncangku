create procedure proc2(
para1 varchar2,
para2 out varchar2,
para3 in out varchar2
) as
v_name varchar2(2);
begin
para2 :='aaaaaaaaaaaaaaaaaaaa';
dbms_output.put_line(para2||para3)
end;

--调用proc2
BEGIN
var p1 varchar2(1);
var p2 varchar2(1);
var p3 varchar2(1);
exec :p2 := 'a';
exec proc1(:p1,:p2,:p3);
dbms_output.put_line('xxx')
END
/

