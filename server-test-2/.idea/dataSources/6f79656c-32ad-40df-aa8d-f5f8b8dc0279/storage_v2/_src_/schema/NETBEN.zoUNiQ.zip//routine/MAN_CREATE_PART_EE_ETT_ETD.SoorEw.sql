create PROCEDURE          "MAN_CREATE_PART_EE_ETT_ETD" authid current_user is

begin
 man_add_part_ee;
 man_add_part_etd;
 man_add_part_ett;
end man_create_part_EE_ETT_ETD;


/

