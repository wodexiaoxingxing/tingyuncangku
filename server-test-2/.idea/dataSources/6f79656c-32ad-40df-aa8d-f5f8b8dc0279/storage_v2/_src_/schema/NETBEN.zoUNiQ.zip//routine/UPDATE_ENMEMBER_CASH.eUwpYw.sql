create PROCEDURE "UPDATE_ENMEMBER_CASH" is
  bid     integer;
  mbid    integer;
  rate    float;
  bal     number;
  cid     integer;
  iid     integer;
  req_sts integer;
  prcn    varchar2(30);
begin
  prcn := 'updateEnMbrCash';
  CREATE_PROCEDURE_LOG(prcn, 'start', 'run');

  --统计前一天各会员各城市任务数量
  for data in (select sum(d.data_points) as points,
                      M.USERNAME,
                      d.impci_id,
                      d.member_id as member_id,
                      M.STATUS AS STATUS
                 from NB_DPMBR_DP_EN d
                 LEFT join NB_M_MEMBER m
                   on d.member_id = m.id
                where d.cdate >= trunc(sysdate - 1, 'DD')
                  and d.cdate < trunc(sysdate - 0, 'DD')
                  and m.mbr_type = 5
                group by d.member_id, d.impci_id, M.STATUS, M.USERNAME) loop
  
    -- 是否申请过激活
    cid := null;
    select count(0)
      into cid
      from nb_m_mbr_en_active_req r
     where r.member_id = data.member_id
       and r.impci_id = data.impci_id;
  
    -- 未申请过激活
    if cid = 0 then
      iid     := 0;
      req_sts := 0;
    else
     -- 申请过激活
      -- 读取直付城市ID
      select r.impci_id
        into iid
        from nb_m_mbr_en_active_req r
       where r.member_id = data.member_id
         and r.impci_id = data.impci_id;
      -- 读取审核状态
      select r.status
        into req_sts
        from nb_m_mbr_en_active_req r
       where r.member_id = data.member_id
         and r.impci_id = data.impci_id;
    end if;
  
    dbms_output.put_line('status: ' || req_sts || ', cid: ' || cid || ', iid: ' || iid);
    
   -- if req_sts = 1 and data.status = 2 then
      -- 查找是否有前一天记录，有则代表已经运行过了
      select count(0)
        into cid
        from nb_m_mbr_en_cash_balance d
       where d.ctime >= trunc(sysdate, 'DD')
         and d.ctime < trunc(sysdate + 1, 'DD')
         and member_id = data.member_id
         and impci_id = data.impci_id;
    
      if cid = 0 then
        -- rate
        --rate := 0.007;
        rate := 0;
        -- 未申请过激活,转换率为0
        if iid != 0 then
          select count(0)
            into cid
            from nb_m_probe_city_rate pcr
            join nb_m_location l
              on pcr.geo_id = l.grand_id
            join nb_m_important_city_isp ici
              on ici.loc_id = l.id
           where ici.id = data.impci_id;

           dbms_output.put_line('status 01: ' || ', cid: ' || cid || ', iid: ' || iid || ', req_sts: ' || req_sts);
           
          if cid != 0 then
            select pcr.rate
              into rate
              from nb_m_probe_city_rate pcr
              join nb_m_location l
                on pcr.geo_id = l.grand_id
              join nb_m_important_city_isp ici
                on ici.loc_id = l.id
             where ici.id = data.impci_id;
             dbms_output.put_line('rate0: ' || rate);
          end if;
        end if;
        
        if req_sts = 1 and data.status = 2 then
          rate := rate;
          dbms_output.put_line('rate: ' || rate);
          else
            rate := 0;
          end if;

        --dbms_output.put_line('rate:' || + rate);
        -- id
        select DPMBR_EN_CASH_BAL_ID_SEQ.Nextval into bid from dual;
        -- balance    
        mbid := null;
        select max(id)
          into mbid
          from nb_m_mbr_en_cash_balance
         where member_id = data.member_id;
      
        if mbid is null then
          bal := 0;
        else
          select balance
            into bal
            from nb_m_mbr_en_cash_balance
           where id = mbid;
        end if;
        -- data 
        insert into nb_m_mbr_en_cash_balance
          (id,
           member_id,
           data_points,
           rate,
           money,
           reason,
           balance,
           memo,
           ctime,
           req_id,
           impci_id,
           creator_id)
        values
          (bid,
           data.member_id,
           data.points,
           rate,
           data.points * rate,
           'DP',
           bal + data.points * rate,
           'impci_id: ' || data.impci_id,
           sysdate,
           0,
           data.impci_id,
           0);
        CREATE_PROCEDURE_LOG(prcn,
                             'insert data',
                             bid || ',' || data.member_id || ',' ||
                             data.points || ',' || rate || ',' ||
                             data.impci_id);
      else
        CREATE_PROCEDURE_LOG(prcn,
                             'has data',
                             data.member_id || ',' || data.impci_id);
      end if;

  end loop;
  commit;

  CREATE_PROCEDURE_LOG(prcn, 'run', 'end');

end UPDATE_ENMEMBER_CASH;


/

