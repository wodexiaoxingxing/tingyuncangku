create FUNCTION          "IPNUMTOSTR" (arg in integer) return varchar2 is
  Result varchar2(20);
p1 integer;
p2 integer ;
p3 integer ;
p4 integer ;
begin
p1:=mod(arg/(256*256*256),256);
p2:=mod((arg/(256*256)),256);
p3:=mod((arg/(256)),256);
p4:=mod((arg/(1)),256);

result:=p1||'.'||p2||'.'||p3||'.'||p4;

return(Result);
end IPNUMTOSTR;


/

