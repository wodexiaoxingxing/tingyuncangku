create procedure createROUTE(tableStr IN varchar2,res OUT number) authid current_user is
  sqlStr    varchar2(4000);
  errorDesc varchar2(4000);
begin
  create_procedure_log('createROUTE',
                       'create table:NB_ROUTE_' || tableStr,
                       'run');
  --create TABLE of NB_ROUTE
  sqlStr := 'create table NB_ROUTE_' || tableStr || '
  (
    TRACE_ID   NUMBER not null,
    TTL_ORDER  NUMBER,
    RTT_MAX    NUMBER,
    RTT_MIN    NUMBER,
    RTT_MEAN   NUMBER,
    DEST_IP    VARCHAR2(39),
    DEST_NAME  VARCHAR2(256),
    ERROR_CODE NUMBER
  )
  tablespace NETBEN';
  execute immediate sqlStr;

  sqlStr := 'create index IN_ROUTE_TRACE_ID_' || tableStr ||
            ' on NB_ROUTE_' || tableStr ||
            ' (TRACE_ID) tableSpace NETBEN_IDX_NEW';
  execute immediate sqlStr;
  res:=0;
  
exception
  when others then
    errorDesc := 'Error :' || sqlerrm || '  tableStr:' || tableStr;
    --DBMS_OUTPUT.PUT_LINE(v_error_desc);
    create_procedure_log('createROUTE', errorDesc, 'error');
    res:=1;
    
end createROUTE;


/

