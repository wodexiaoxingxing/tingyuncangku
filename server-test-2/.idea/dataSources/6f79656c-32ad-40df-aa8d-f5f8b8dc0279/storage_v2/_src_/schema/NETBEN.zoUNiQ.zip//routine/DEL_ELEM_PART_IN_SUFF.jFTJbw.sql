create PROCEDURE          "DEL_ELEM_PART_IN_SUFF" (
 order_curr number)
authid current_user is
sqlStr varchar2(4000);
v_error_desc varchar2(4000);
range_date_curr date;
v_s number;
v_p number;
v_partname varchar2(64);
v_rangedate_desc varchar2(128);
v_rangedate varchar2(128);

begin
    for elem in  (SELECT distinct substr(t.table_name,9) suff FROM user_tables t where t.partitioned='YES' and t.table_name like 'NB_ELEM_%')
    loop
        begin
            -- 3.判断是否要增加的分区已经存在,如果存在则增加，如果不存在则不处理
            v_partname:= 'PART_ELEM_'||elem.suff||'_'||order_curr;
            sqlStr := 'ALTER TABLE nb_elem_'||elem.suff||' DROP PARTITION '||v_partname;
            execute immediate sqlStr;
        exception when  others then
            v_error_desc := ' ERROR: sqlCode:'||sqlcode|| '   ' ||sqlStr;
            DBMS_OUTPUT.PUT_LINE(v_error_desc);
            create_procedure_log('auto_del_elem_part',v_error_desc,sqlcode);
        end;
    end loop;
end del_elem_part_in_suff;


/

