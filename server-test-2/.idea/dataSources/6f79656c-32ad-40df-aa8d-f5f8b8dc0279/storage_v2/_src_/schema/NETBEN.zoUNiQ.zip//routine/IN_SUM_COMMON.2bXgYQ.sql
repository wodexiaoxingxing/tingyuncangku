create PROCEDURE          "IN_SUM_COMMON" authid current_user
is
  sqlStr  varchar2(4000);
  v_error varchar2(4000);
  v_error_desc varchar2(4000);
  v_time_start date;
  v_time_end date;
  v_s number;
  
begin
if (to_number(to_char(sysdate,'hh24'))) >8 and (to_number(to_char(sysdate,'hh24'))) <20  then
  create_procedure_log('in_sum_common','in_sum_common begin','test');
  --算出统计的开始时间及结束时间
   --trunc(sysdate - 1 - mod(to_char(sysdate, 'hh24'), 1)
 
  v_time_start := trunc(sysdate - 1 ,'hh24');
  v_time_end := trunc(sysdate , 'hh24');

 
  --首先删除指定日期内的所有生成数据，防止重复生成数据
  sqlStr:='delete from nb_sum_main where time_range=:st or time_range<sysdate-10';
  execute immediate sqlStr using v_time_start;
  sqlStr:='delete from nb_sum_time where time_range=:st or time_range<sysdate-10';
  execute immediate sqlStr using v_time_start;
  commit;
  sqlStr:='delete from nb_sum_city where time_range=:st or time_range<sysdate-10';
  execute immediate sqlStr using v_time_start;
  commit;
  sqlStr:='delete from nb_sum_cdn where time_range=:st or time_range<sysdate-10';
  execute immediate sqlStr using v_time_start;
  commit;
  
  sqlStr:='delete from nb_sum_error where time_range=:st or time_range<sysdate-10';
  execute immediate sqlStr using v_time_start;
  commit;
  --循环，查寻出所有的表
  for tableName in(SELECT substr(t.table_name, 9) as name FROM user_tables t where t.table_name like 'NB_TRAN_%' and t.table_name != 'NB_TRAN_22'
      union  SELECT substr(t.table_name, 11) as name  FROM user_tables t where t.table_name like 'NB_STREAM_%' and t.table_name != 'NB_STREAM_22') loop
  begin
    -- 判断是否有普通监测
    select count(*)  INTO v_s FROM user_tables t where t.table_name = 'NB_TRAN_'||tableName.name;
     if v_s > 0 then 
    -- 1 生成性能概述主表 - 基本情况，性能指标
    v_error:='error:表后缀'||tableName.name||'--1.生成性能概述主表 - 基本情况，性能指标时发生错误';
    sqlStr:='insert into nb_sum_main
    select trunc(sysdate - 1 ,''hh24''),
       task_id,point_total,point_succ,point_total-point_succ point_err,
       round(decode(point_total, 0, 0, point_succ / point_total), 2) available,
       round(byte_total, 0) byte_total,
       round(rate_download, 0) rate_download,
       round(performance, 0) performance,
       round(ts_user, 0) ts_user,
       round(ts_connect, 0) ts_connect,
       round(ts_dns, 0) ts_dns,
       round(ts_first_packet, 0) ts_first_packet,
       round(stddev_perf,0) stddev_perf
       from(
         select t.task_id,sum(t.point_total) point_total,
            sum(case when t.error_code > 600000 then 0 else t.point_total end) point_succ,
            avg(case when t.error_code > 600000 then null else t.ts_total end) performance,
            avg(case when t.error_code > 600000 then null else t.byte_total end) byte_total,
            avg(case when p.error_code > 600000 then null else p.rate_download end) rate_download,
            avg(case when p.error_code > 600000 then null else p.ts_user end) ts_user,
            avg(case when p.error_code > 600000 then null else p.ts_dns end) ts_dns,
            avg(case when p.error_code > 600000 then null else p.ts_connect end) ts_connect,
            avg(case when p.error_code > 600000 then null else p.ts_first_packet end) ts_first_packet,
            stddev(case when p.error_code > 600000 then null else p.ts_total end) stddev_perf
          from nb_tran_'||tableName.name||' t,nb_page_'||tableName.name||' p 
         where t.tm_base between :sT and :eT and t.task_id in(select id from nb_m_task where task_option !=''P'')
               and t.id = p.tran_id and p.page_seq=1 and  t.is_noise = 0
         group by t.task_id)';
    execute immediate sqlStr using v_time_start,v_time_end;
    commit;
    -- 2 生成性能概述明细表 - 按时间排序
    v_error:='error:表后缀'||tableName.name||'--2 生成性能概述明细表 - 按时间排序时发生错误';
    sqlStr:='insert into nb_sum_time
       select  trunc(sysdate - 1 ,''hh24''),
          task_id,1,num_asc,num_desc,tm_hour,point_total,performance,available
       from(
         select task_id,tm_hour,point_total,
           round(performance,0) performance,
           round(decode(point_total,0,0,point_succ/point_total),2) available,
           row_number()over(partition by task_id order by performance) as num_asc,
           row_number()over(partition by task_id order by performance desc) as num_desc
           from (select t.task_id,trunc(t.tm_base,''hh'') tm_hour,
               sum(t.point_total) point_total,
               sum(case when t.error_code > 600000 then 0 else t.point_total end) point_succ,
               avg(case when t.error_code > 600000 then null else t.ts_total end) performance
          from nb_tran_'||tableName.name||' t
         where t.tm_base between :sT and :eT and t.task_id in(select id from nb_m_task where task_option !=''P'') and is_noise = 0
         group by task_id,trunc(t.tm_base,''hh''))
       )
       where num_asc <2 or num_desc <2';
    execute immediate sqlStr using v_time_start,v_time_end;
    commit;
    --3 生成性能概述明细表 - 城市性能排序
    v_error:='error:表后缀'||tableName.name||'--3 生成性能概述明细表 - 城市性能排序时发生错误';
    sqlStr:='insert into nb_sum_city
       select trunc(sysdate - 1 ,''hh24''),
          task_id,1,num_asc,num_desc,city_id,point_total,point_succ,point_err,performance,available
       from(
          select task_id,city_id,point_total,point_succ,
             point_total - point_succ point_err,
             round(decode(point_total,0,0,point_succ/point_total),2) available,
             round(performance,2) performance,
             row_number()over(partition by task_id order by performance) as num_asc,
             row_number()over(partition by task_id order by performance desc) as num_desc
          from (
             select t.task_id,t.city_id,
               sum(t.point_total) point_total,
               sum(case when t.error_code > 600000 then 0 else t.point_total end) point_succ,
               avg(case when t.error_code > 600000 then null else t.ts_total end) performance
             from nb_tran_'||tableName.name||' t
             where t.tm_base between :sT and :eT and t.task_id in(select id from nb_m_task where task_option !=''P'') and is_noise = 0
             group by t.task_id,t.city_id
             )
          )
         where num_asc<4 or num_desc <4';
    execute immediate sqlStr using v_time_start,v_time_end;
    commit;
    --4 生成性能概述明细表 - 城市错误排序
    v_error:='error:表后缀'||tableName.name||'--4 生成性能概述明细表 - 城市错误排序时发生错误';
    sqlStr:='insert into nb_sum_city
       select trunc(sysdate - 1 ,''hh24''),
           task_id,2,0,num_desc,city_id, point_total,point_succ,point_err,performance,available
       from (
          select task_id,city_id,point_total,point_succ,point_err,
               round(ts_total,0) performance,
               round(decode(point_total,0,0,point_succ/point_total),2) available,
               row_number() over(partition by task_id order by point_err desc) as num_desc
          from (select t.task_id,
                       t.city_id,
                       sum(t.point_total) point_total,
                       sum(case when t.error_code > 600000 then 0 else t.point_total end) point_succ,
                       sum(case when t.error_code > 600000 then t.point_total else 0 end) point_err,
                       avg(case when t.error_code > 600000 then null else t.ts_total end) ts_total
                  from nb_tran_'||tableName.name||' t
                 where t.tm_base between :sT and :eT and t.task_id in(select id from nb_m_task where task_option !=''P'') and is_noise = 0
                 group by t.task_id, t.city_id))
        where num_desc < 4 and point_err>0';
    execute immediate sqlStr using v_time_start,v_time_end;
    commit;
    --5 生成性能概述明细表 - 页面错误描述
     v_error:='error:表后缀'||tableName.name||'--5 生成性能概述明细表 - 页面错误描述时发生错误';
    sqlStr:='insert into nb_sum_error
       select trunc(sysdate - 1 ,''hh24''),
          task_id,1,0,num_desc,error_code,'''',point_err,perf_err
       from (
           select task_id,error_code,point_err,
              round(decode(point_err_total,0,0,point_err/point_err_total),2) perf_err,
              row_number()over(partition by task_id order by point_err desc) as num_desc
           from(
              select distinct
                 t.task_id,
                 t.error_code,
                 sum(point_total)over(partition by task_id,error_code) as point_err,
                 sum(point_total)over(partition by task_id) as point_err_total
              from nb_tran_'||tableName.name||' t
              where t.tm_base between :sT and :eT and t.task_id in(select id from nb_m_task where task_option !=''P'')
                 and t.error_code in(select e.err_code  from nb_m_error e where e.err_type = 3) and is_noise = 0
           )
        )where num_desc < 4';
    execute immediate sqlStr using v_time_start,v_time_end;
    commit;
    --6 生成cdn表 - 全cdn数据,无排序
    --先对任务进行判断，是否有cdn，然后设置其值
     v_error:='error:表后缀'||tableName.name||'--6 生成cdn表 - 全cdn数据,无排序时发生错误';
    
    for task in(SELECT id as id FROM nb_m_task t where t.cdn = 0 and t.agreement_id in(select id from nb_m_agreement where table_str=tableName.name) and t.type !=3) loop
        sqlStr:='update nb_m_task set cdn = 1 where id = :t1 and
                  (select count(distinct dest_ip) from nb_tran_'||tableName.name||' t
                  where t.tm_base between :sT and :eT
                     and task_id =:t2) > 1';
         execute immediate sqlStr using task.id,v_time_start,v_time_end,task.id;
         commit;
         create_procedure_log(tableName.name,sqlStr,task.id);
         sqlStr:='update nb_m_task set cdn=-1 where cdn = 0 and id=:t1';
         execute immediate sqlStr using task.id;
         commit;
    end loop;
    --然后对有多主机的任务进行cdn数据分析
    sqlStr:='insert into nb_sum_cdn
       select trunc(sysdate - 1 ,''hh24''),
            task_id,decode(dest_ip,null,''DNS is wrong'',dest_ip),point_total,
            point_succ, performance,round(decode(point_total,0,0,point_succ / point_total),2) available
       from (
         select t.task_id,
             t.dest_ip,
             sum(t.point_total) point_total,
             sum(case when t.error_code > 600000 then 0 else t.point_total end) point_succ,
             avg(case when t.error_code > 600000 then null else t.ts_total end) performance
         from nb_tran_'||tableName.name||' t
         where t.tm_base between :sT and :eT and t.task_id in(select id from nb_m_task where cdn = 1 and task_option != ''p'')
               and dest_ip is not null and is_noise = 0
         group by task_id,t.dest_ip
       )';
     execute immediate sqlStr using v_time_start,v_time_end;
     commit;
     end if;
     
     --------------------------------------------------------------------------------------------------------------------------------------
     -- 开始生成stream
    
     select count(*)  INTO v_s FROM user_tables t where t.table_name = 'NB_STREAM_'||tableName.name;
     if v_s > 0 then 
     -- 1 生成性能概述主表 - 基本情况，性能指标
    v_error:='error:表后缀'||tableName.name||'--stream 1.生成性能概述主表 - 基本情况，性能指标时发生错误';
    sqlStr:='insert into nb_sum_main
    select trunc(sysdate - 1 ,''hh24''),
       task_id,point_total,point_succ,point_total-point_succ point_err,
       round(decode(point_total, 0, 0, point_succ / point_total), 2) available,
       round(byte_total, 0) byte_total,
       round(rate_download, 0) rate_download,
       round(performance, 0) performance,
       round(ts_user, 0) ts_user,
       round(ts_connect, 0) ts_connect,
       round(ts_dns, 0) ts_dns,
       round(ts_first_packet, 0) ts_first_packet,
       round(stddev_perf,0) stddev_perf
       from(
         select s.task_id,sum(s.point_total) point_total,
            sum(case when s.error_code > 600000 then 0 else s.point_total end) point_succ,
            avg(case when s.error_code > 600000 then null else s.ts_total end) performance,
            avg(case when s.error_code > 600000 then null else s.byte_total end) byte_total,
            avg(case when s.error_code > 600000 then null else s.rate_download end) rate_download,
            avg(case when s.error_code > 600000 then null else s.ts_total+s.buffer_count*1000 end) ts_user,
            avg(case when s.error_code > 600000 then null else s.ts_buffer end) ts_dns,
            avg(case when s.error_code > 600000 then null else s.ts_connect end) ts_connect,
            avg(case when s.error_code > 600000 then null else s.ts_rebuffer end) ts_first_packet,
            stddev(case when s.error_code > 600000 then null else s.ts_total end) stddev_perf
          from nb_stream_'||tableName.name||' s 
         where s.tm_base between :sT and :eT  and  s.is_noise = 0
         group by s.task_id)';
    execute immediate sqlStr using v_time_start,v_time_end;
    commit;
    -- 2 生成性能概述明细表 - 按时间排序
    v_error:='error:表后缀'||tableName.name||'--stream 2 生成性能概述明细表 - 按时间排序时发生错误';
    sqlStr:='insert into nb_sum_time
       select  trunc(sysdate - 1 ,''hh24''),
          task_id,1,num_asc,num_desc,tm_hour,point_total,performance,available
       from(
         select task_id,tm_hour,point_total,
           round(performance,0) performance,
           round(decode(point_total,0,0,point_succ/point_total),2) available,
           row_number()over(partition by task_id order by performance) as num_asc,
           row_number()over(partition by task_id order by performance desc) as num_desc
           from (select t.task_id,trunc(t.tm_base,''hh'') tm_hour,
               sum(t.point_total) point_total,
               sum(case when t.error_code > 600000 then 0 else t.point_total end) point_succ,
               avg(case when t.error_code > 600000 then null else t.ts_total end) performance
          from nb_stream_'||tableName.name||' t
         where t.tm_base between :sT and :eT and t.is_noise = 0
         group by task_id,trunc(t.tm_base,''hh''))
       )
       where num_asc <2 or num_desc <2';
    execute immediate sqlStr using v_time_start,v_time_end;
    commit;
    --3 生成性能概述明细表 - 城市性能排序
    v_error:='error:表后缀'||tableName.name||'--stream 3 生成性能概述明细表 - 城市性能排序时发生错误';
    sqlStr:='insert into nb_sum_city
       select trunc(sysdate - 1 ,''hh24''),
          task_id,1,num_asc,num_desc,city_id,point_total,point_succ,point_err,performance,available
       from(
          select task_id,city_id,point_total,point_succ,
             point_total - point_succ point_err,
             round(decode(point_total,0,0,point_succ/point_total),2) available,
             round(performance,2) performance,
             row_number()over(partition by task_id order by performance) as num_asc,
             row_number()over(partition by task_id order by performance desc) as num_desc
          from (
             select t.task_id,t.city_id,
               sum(t.point_total) point_total,
               sum(case when t.error_code > 600000 then 0 else t.point_total end) point_succ,
               avg(case when t.error_code > 600000 then null else t.ts_total end) performance
             from nb_stream_'||tableName.name||' t
             where t.tm_base between :sT and :eT and t.is_noise = 0
             group by t.task_id,t.city_id
             )
          )
         where num_asc<4 or num_desc <4';
    execute immediate sqlStr using v_time_start,v_time_end;
    commit;
    --4 生成性能概述明细表 - 城市错误排序
    v_error:='error:表后缀'||tableName.name||'--stream 4 生成性能概述明细表 - 城市错误排序时发生错误';
    sqlStr:='insert into nb_sum_city
       select trunc(sysdate - 1 ,''hh24''),
           task_id,2,0,num_desc,city_id, point_total,point_succ,point_err,performance,available
       from (
          select task_id,city_id,point_total,point_succ,point_err,
               round(ts_total,0) performance,
               round(decode(point_total,0,0,point_succ/point_total),2) available,
               row_number() over(partition by task_id order by point_err desc) as num_desc
          from (select t.task_id,
                       t.city_id,
                       sum(t.point_total) point_total,
                       sum(case when t.error_code > 600000 then 0 else t.point_total end) point_succ,
                       sum(case when t.error_code > 600000 then t.point_total else 0 end) point_err,
                       avg(case when t.error_code > 600000 then null else t.ts_total end) ts_total
                  from nb_stream_'||tableName.name||' t
                 where t.tm_base between :sT and :eT and t.is_noise = 0
                 group by t.task_id, t.city_id))
        where num_desc < 4 and point_err>0';
    execute immediate sqlStr using v_time_start,v_time_end;
    commit;
    --5 生成性能概述明细表 - 页面错误描述
     v_error:='error:表后缀'||tableName.name||'--stream 5 生成性能概述明细表 - 页面错误描述时发生错误';
    sqlStr:='insert into nb_sum_error
       select trunc(sysdate - 1 ,''hh24''),
          task_id,1,0,num_desc,error_code,'''',point_err,perf_err
       from (
           select task_id,error_code,point_err,
              round(decode(point_err_total,0,0,point_err/point_err_total),2) perf_err,
              row_number()over(partition by task_id order by point_err desc) as num_desc
           from(
              select distinct
                 t.task_id,
                 t.error_code,
                 sum(point_total)over(partition by task_id,error_code) as point_err,
                 sum(point_total)over(partition by task_id) as point_err_total
              from nb_stream_'||tableName.name||' t
              where t.tm_base between :sT and :eT 
                 and t.error_code in(select e.err_code  from nb_m_error e where e.err_type = 3) and t.is_noise = 0
           )
        )where num_desc < 4';
    execute immediate sqlStr using v_time_start,v_time_end;
    commit;
    --6 生成cdn表 - 全cdn数据,无排序
    --先对任务进行判断，是否有cdn，然后设置其值
     v_error:='error:表后缀'||tableName.name||'--stream 6 生成cdn表 - 全cdn数据,无排序时发生错误';
    
    for task in(SELECT id as id FROM nb_m_task t where t.cdn = 0 and t.agreement_id in(select id from nb_m_agreement where table_str=tableName.name) and t.type=3) loop
        sqlStr:='update nb_m_task set cdn = 1 where id = :t1 and
                  (select count(distinct dest_ip) from nb_stream_'||tableName.name||' t
                  where t.tm_base between :sT and :eT
                     and task_id =:t2) > 1';
         execute immediate sqlStr using task.id,v_time_start,v_time_end,task.id;
         commit;
         create_procedure_log(tableName.name,sqlStr,task.id);
         sqlStr:='update nb_m_task set cdn=-1 where cdn = 0 and id=:t1';
         execute immediate sqlStr using task.id;
         commit;
    end loop;
    --然后对有多主机的任务进行cdn数据分析
    sqlStr:='insert into nb_sum_cdn
       select trunc(sysdate - 1 ,''hh24''),
            task_id,decode(dest_ip,null,''DNS is wrong'',dest_ip),point_total,
            point_succ, performance,round(decode(point_total,0,0,point_succ / point_total),2) available
       from (
         select t.task_id,
             t.dest_ip,
             sum(t.point_total) point_total,
             sum(case when t.error_code > 600000 then 0 else t.point_total end) point_succ,
             avg(case when t.error_code > 600000 then null else t.ts_total end) performance
         from nb_stream_'||tableName.name||' t
         where t.tm_base between :sT and :eT 
               and dest_ip is not null and t.is_noise = 0
         group by task_id,t.dest_ip
       )';
     execute immediate sqlStr using v_time_start,v_time_end;
     commit;
     end if;
     --如果创建序列失败，则显示出失败代码
    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || v_error;
        --DBMS_OUTPUT.PUT_LINE(v_error_desc);
        create_procedure_log('in_sum_common',v_error_desc,'error');
    end;
    end loop;
    
    create_procedure_log('in_sum_common','in_sum_common end','message');
   end if;--当大于6点种时再开始计算
end in_sum_common;


/

