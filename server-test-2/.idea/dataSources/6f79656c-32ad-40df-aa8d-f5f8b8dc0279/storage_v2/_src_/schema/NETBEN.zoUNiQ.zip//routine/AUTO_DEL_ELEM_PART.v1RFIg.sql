create PROCEDURE          "AUTO_DEL_ELEM_PART" authid current_user is
sqlStr varchar2(4000);
v_error_desc varchar2(4000);
order_curr number;
range_date_curr date;
v_s number;
v_p number;
v_partname varchar2(64);
v_rangedate_desc varchar2(128);
v_rangedate varchar2(128);

begin
 -- 1 计算出当前日期所对应的应该插入分区的时间范围及序号,是根据当前日期算出下周的周日，
 --   即为了安全，将会提前两周处理,每周开始日期为周日
    select order_num,sunday into order_curr,range_date_curr from nb_part_calendar t
        where t.sunday = (select trunc(sysdate - (41 + to_char( sysdate,'d')),'d') from dual);
     -- 2.取出所有已经建立分区的elem表后缀，开始循环 注：无分区的表不处理
    for elem in  (SELECT distinct substr(t.table_name,9) suff FROM user_tables t where t.partitioned='YES' and t.table_name like 'NB_ELEM_%')
    loop
        begin
            -- 3.判断是否要增加的分区已经存在,如果存在则增加，如果不存在则不处理
            v_partname:= 'PART_ELEM_'||elem.suff||'_'||order_curr;
            v_rangedate_desc:=to_char(range_date_curr,'yyyy-mm-dd');
            v_rangedate:='to_date('''||v_rangedate_desc||''',''yyyy-mm-dd'')';
            -- 判断增加的分区是否已经存在 
            select count(*) into v_s from user_tab_partitions t where t.partition_name= v_partname;
            -- 存在则删除分区
            if v_s > 0 then
               select count(*) into v_p from user_tab_partitions p where p.table_name='NB_ELEM_'||elem.suff;
               -- 安全检查，如果该elem表所属的分区数少于7,则警告并不执行删除分区的操作
               if v_p > 8 then
                   sqlStr := 'ALTER TABLE nb_elem_'||elem.suff||' DROP PARTITION '||v_partname;
                   execute immediate sqlStr;
               else
                   v_error_desc:='The count of patitions is less than 7,delete cancel.partname:'||v_partname||'  rangedate:'||v_rangedate_desc;
                   create_procedure_log('auto_del_elem_part',v_error_desc,'alarm');
                   dbms_output.put_line(v_error_desc);
               end if;
            else
               -- 不存在则写警告日志
               v_error_desc:='The partition is not exist,cannot delete,partname:'||v_partname||' rangedate'||v_rangedate_desc;
               dbms_output.put_line(v_error_desc);
               create_procedure_log('auto_del_elem_art',v_error_desc,'alarm');
            end if;
        exception when  others then
            v_error_desc := ' ERROR: sqlCode:'||sqlcode|| '   ' ||sqlStr;
            DBMS_OUTPUT.PUT_LINE(v_error_desc);
            create_procedure_log('auto_del_elem_part',v_error_desc,sqlcode);
        end;
    end loop;
end auto_del_elem_part;


/

