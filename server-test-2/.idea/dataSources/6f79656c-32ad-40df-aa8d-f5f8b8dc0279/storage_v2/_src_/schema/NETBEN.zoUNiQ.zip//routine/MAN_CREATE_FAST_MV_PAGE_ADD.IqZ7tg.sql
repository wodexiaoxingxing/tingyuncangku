create PROCEDURE          "MAN_CREATE_FAST_MV_PAGE_ADD" authid current_user
is
  sqlStr  varchar2(4000);
  v_name varchar2(400);
  v_error_desc varchar2(4000);
  l_name varchar2(400);
  v_s number;
--  CURSOR c_emp IS SELECT substr(t.table_name,9) FROM user_tables t where t.table_name like 'NB_PAGE_%';
/*CURSOR c_emp IS
select substr(mv.MVIEW_NAME, 9)
  from user_mviews mv, user_objects ob
 where mview_name like 'MV_PAGE_%'
   and mview_name = object_name
   and sysdate - created > 1;
   */
CURSOR c_emp IS SELECT substr(t.object_name,9) from user_objects t where object_name like 'MV_PAGE%' and object_type='MATERIALIZED VIEW' and sysdate-created>1;
begin
OPEN c_emp;
LOOP
  begin
    create_procedure_log('create_fast_mv_page_all','create mv_page_'||v_name,'message');
    FETCH c_emp INTO v_name;
    EXIT WHEN c_emp%NOTFOUND;
    --创建物化视图日志
 --   if (to_number(v_name) <20000 )then
    select count(*)  INTO v_s FROM user_tables t where t.table_name = 'MLOG$_NB_PAGE_'||v_name;
    if v_s >0 then
        sqlStr:=  'drop materialized view log on nb_page_'||v_name;
        execute immediate sqlstr;
 DBMS_OUTPUT.PUT_LINE(sqlStr);
    end if;
        sqlStr:='create materialized view log on nb_page_'||v_name||' with rowid,
          sequence (TASK_ID,
                    PAGE_SEQ,
                    CITY_ID,
                    ISP_ID,
                    NET_SPEED_ID,
                    ERROR_CODE,
                    IS_NOISE,
                    DEST_IP,
                    TM_BASE,
                    CONT_ERR_TOTAL,
                    CONT_ELE_TOTAL,
                    POINT_TOTAL,
                    BYTE_TOTAL,
                    RATE_DOWNLOAD,
                    TS_TOTAL,
                    TS_PAGE_BASE,
                    TS_DNS,
                    TS_CONNECT,
                    TS_SSL,
                    TS_REDIRECT,
                    TS_REQUEST,
                    TS_FIRST_PACKET,
                    TS_CLIENT,
                    TS_CONTENTS,
                    TS_EXTRA_DATA,
                    TS_OPEN_PAGE,
                    TS_USER,
                    TS_NETWORK,
                    TS_CLOSE,
                    BYTE_PAGE_BASE,
                    RATE_DOWNLOAD_PAGE_BASE,
                    NUM_FIRST_ELEM,
                    BYTE_FIRST,
                    NUM_HOST,
                    TS_DNS_TOTAL,
                    NUM_CONNECT,
                    TS_CONNECT_TOTAL,
                    NUM_DOM,
                    NUM_IFRAME,
                    NUM_NO_COMPRESS_ELEM,
                    NUM_NO_EXPIRE_ELEM,
                    NUM_NO_ETAG_ELEM,
                    OS_VER_ID,
                    BS_ID,
                    BS_VER_ID) including new values ';

 l_name := 'creating materialized view log on nb_page_'||v_name;
 DBMS_OUTPUT.PUT_LINE(l_name);
  DBMS_OUTPUT.PUT_LINE(sqlStr);
      execute immediate sqlStr;
  l_name := 'materialized view log on nb_page_'||v_name||'created!';
 DBMS_OUTPUT.PUT_LINE(l_name);

    select count(*)  INTO v_s FROM user_tables t where t.table_name = 'MV_PAGE_'||v_name;
    if v_s > 0 then
    --删除物化视图
    --DBMS_OUTPUT.PUT_LINE('drop mv_tran_'||v_name);
      sqlStr:='drop materialized view mv_page_'||v_name;
      execute immediate sqlStr;
 --DBMS_OUTPUT.PUT_LINE(sqlStr);
    end if;
    --page物化视图
     create_procedure_log('create_fast_mv_page_all','start materialized view  mv_page_'||v_name,'message');
    sqlStr:='create materialized view MV_PAGE_'||v_name||'
    refresh fast
    start with sysdate next sysdate + 4/24
    as
    (select task_id,
        page_seq,
        city_id,
        isp_id,
        net_speed_id,
        error_code,
        is_noise,
        dest_ip,
        (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8)/24) as tm_hour8,
        os_ver_id,
        bs_id,
        bs_ver_id,
        count(*) as c1,
        count(cont_err_total) as c2,
        count(cont_ele_total) as c3,
        count(point_total) as c4,
        count(byte_total) as c5,
        count(rate_download) as c6,
        count(ts_total) as c7,
        count(ts_page_base) as c8,
        count(ts_dns) as c9,
        count(ts_connect) as c10,
        count(ts_ssl) as c11,
        count(ts_redirect) as c12,
        count(ts_request) as c13,
        count(ts_first_packet) as c14,
        count(ts_client) as c15,
        count(ts_contents) as c16,
        count(ts_extra_data) as c17,
        count(ts_open_page) as c18,
        count(ts_user) as c19,
        count(ts_network) as c20,
        count(ts_close) as c21,
        count(byte_page_base) as c22,
        count(rate_download_page_base) as c23,
        count(num_first_elem) as c24,
        count(byte_first) as c25,
        count(num_host) as c26,
        count(ts_dns_total) as c27,
        count(num_connect) as c28,
        count(ts_connect_total) as c29,
        count(num_dom) as c30,
        count(num_iframe) as c31,
        count(num_no_compress_elem) as c32,
        count(num_no_expire_elem) as c33,
        count(num_no_etag_elem) as c34,
              avg(cont_err_total) as cont_err_total,
              avg(cont_ele_total) as cont_ele_total,
              sum(point_total) as point_total,
              avg(byte_total) as byte_total,
              avg(rate_download) as rate_download,
              avg(ts_total) as ts_total,
              avg(ts_page_base) as ts_page_base,
              avg(ts_dns) as ts_dns,
              avg(ts_connect) as ts_connect,
              avg(ts_ssl) as ts_ssl,
              avg(ts_redirect) as ts_redirect,
              avg(ts_request) as ts_request,
              avg(ts_first_packet) as ts_first_packet,
              avg(ts_client) as ts_client,
              avg(ts_contents) as ts_contents,
              avg(ts_extra_data) as ts_extra_data,
              avg(ts_open_page) as ts_open_page,
              avg(ts_user) as ts_user,
              avg(ts_network) as ts_network,
              avg(ts_close) as ts_close,
              avg(byte_page_base) as byte_page_base,
              avg(rate_download_page_base) as rate_download_page_base,
              avg(num_first_elem) as num_first_elem,
              avg(byte_first) as byte_first,
              avg(num_host) as num_host,
              avg(ts_dns_total) as ts_dns_total,
              avg(num_connect) as num_connect,
              avg(ts_connect_total) as ts_connect_total,
              avg(num_dom) as num_dom,
              avg(num_iframe) as num_iframe,
              avg(num_no_compress_elem) as num_no_compress_elem,
              avg(num_no_expire_elem) as num_no_expire_elem,
              avg(num_no_etag_elem) as num_no_etag_elem
    from NB_PAGE_'||v_name||'
    group by task_id,
           page_seq,
         city_id,
         isp_id,
         net_speed_id,
       error_code,
           is_noise,
           dest_ip,
           (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8) / 24),
        os_ver_id,
        bs_id,
        bs_ver_id)';

  l_name := 'creating materialized view mv_page_'||v_name;
 DBMS_OUTPUT.PUT_LINE(l_name);
      execute immediate sqlStr;
  l_name := 'materialized view mv_page_'||v_name||'created!';
 DBMS_OUTPUT.PUT_LINE(l_name);
 --   end if;

  --索引
    sqlStr:='create index IN_MV_PAGE_ERROR_'||v_name||' on MV_PAGE_'||v_name||' (TASK_ID,TM_HOUR8, ERROR_CODE, CITY_ID) nologging  tableSpace NETBEN_IDX';
    execute   immediate   sqlStr;
  DBMS_OUTPUT.PUT_LINE(sqlStr);
 --   索引
/*    sqlStr:='create index IN_MV_PAGE_PERF_'||v_name||' on MV_PAGE_'||v_name||' (TASK_ID,TM_HOUR8, CITY_ID, ISP_ID) nologging parallel 2 tableSpace NETBEN_IDX';
    execute   immediate   sqlStr;
 DBMS_OUTPUT.PUT_LINE(sqlStr);
*/
   --如果创建失败，则显示出失败的表
   exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:' || v_name;
        DBMS_OUTPUT.PUT_LINE(v_error_desc);
        create_procedure_log('create_fast_mv_page_all',v_error_desc,sqlcode);
    end;
END LOOP;

CLOSE c_emp;

end MAN_create_fast_mv_page_add;


/

