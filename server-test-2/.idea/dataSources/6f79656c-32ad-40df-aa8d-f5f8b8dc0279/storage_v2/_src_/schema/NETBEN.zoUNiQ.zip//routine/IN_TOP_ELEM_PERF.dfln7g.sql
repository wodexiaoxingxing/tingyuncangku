create PROCEDURE "IN_TOP_ELEM_PERF" (tableStr in number,
                                             taskId   in number) authid current_user is
  s            number;
  sqlStr       varchar2(4000);
  errorDesc    varchar2(4000);
  startDate    date;
  endDate      date;
begin
  create_procedure_log('in_top_elem_perf','tableStr:' || tableStr || ' taskId:' || taskId || '  begin','run');
  select count(*) INTO s FROM user_tables where table_name = 'NB_ET_' || taskId;
  if s < 1 then
    create_procedure_log('in_top_elem_perf','tableStr:' || tableStr || ' taskId:' || taskId ||' 任务表未找到','alarm');
    return;
  end if;

  startDate := trunc(sysdate-10, 'dd');
  endDate   := trunc(sysdate, 'dd');
  --删除指定日期内的所有生成数据，防止重复生成数据
  sqlStr:='delete nb_top_elem_perf where task_id = :tid and tm_day >= :sDate and tm_day < :eDate';
  execute immediate sqlStr using taskId,startDate,endDate;
  commit;
  sqlStr := 'insert into nb_top_elem_perf
               (task_id,tm_day,url,url_id,performance,byte_total,point_succ,table_str)
                select ' || taskId ||
                    ',un.tm_day,e.url,un.url_id,un.perf,un.byte,un.point_succ,'||tableStr||'
                from
                    (select num_.*
                       from
                         (select row_.*,row_number()over(order by perf desc nulls last) as num_perf,
                                     row_number()over(order by byte desc nulls last) as num_byte
                          from (select trunc(tm_base, ''dd'') tm_day,
                                  url_id,
                                  round(avg(case when error_code > 600000 then null else ts_element end),0) as perf,
                                  round(avg(case when error_code > 600000 then null else byte_total end),0) as byte,
                                  sum(case when error_code > 600000 then 0 else 1 end) as point_succ
                               from nb_et_' || taskId || '
                               where tm_base >= :startDate and tm_base < :endDate
                               group by url_id,
                                     trunc(tm_base, ''dd'')
                               )row_
                           where row_.point_succ > 5
                          ) num_
                        where num_.num_perf < 31 or num_.num_byte < 31
                        ) un,
                      nb_e_url_' || tableStr || ' e
               where un.url_id = e.id
             ';
  execute immediate sqlStr using startDate, endDate;
  commit;
  --如果在一个外循环中出现错误，则此外循环将无法完成，而跳到下一循环
exception
  when others then
    errorDesc := 'tableStr:' || tableStr || ' taskId:' || taskId ||' Error:' || sqlerrm;
    --DBMS_OUTPUT.PUT_LINE(errorDesc);
    create_procedure_log('in_top_elem_perf', errorDesc, 'error');

end in_top_elem_perf;


/

