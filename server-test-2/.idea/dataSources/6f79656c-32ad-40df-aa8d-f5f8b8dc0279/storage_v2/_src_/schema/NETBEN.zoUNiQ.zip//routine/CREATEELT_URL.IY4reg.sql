create procedure createELT_URL(tableStr in varchar2,res OUT number) authid current_user is
  sqlStr       varchar2(8000);
  errorDesc    varchar2(4000);
  ---------------- 主变量 ---------------------------------------------------------------------------
  v_order      number;
  v_range_date date;
  v_partname1  varchar2(128);
  v_rangedate1 varchar2(128);
  v_partname2  varchar2(128);
  v_rangedate2 varchar2(128);
  v_partname3  varchar2(128);
  v_rangedate3 varchar2(128);

begin

  create_procedure_log('createELT_URL', 'create table:NB_ELT_URL_' || tableStr, 'run');

  -- 创建NB_el_task_XXX表（用于向下兼容，一旦新元素架构发生性能问题，可以快速在线回滚）
  -- 首先计算出elem的分区名称及值范围
  select order_num, sunday
    into v_order, v_range_date
    from nb_part_calendar t
   where t.sunday = (select trunc(sysdate + 8 - to_char(sysdate, 'd'), 'd') from dual);

  v_partname1  := 'PART_ELT_URL_' || tableStr || '_' || v_order;
  v_rangedate1 := 'to_date(' || chr(39) || to_char(v_range_date, 'yyyy-mm-dd') || chr(39) || ',' || chr(39) || 'yyyy-mm-dd' || chr(39) || ')';

  select order_num, sunday
    into v_order, v_range_date
    from nb_part_calendar t
   where t.sunday = (select trunc(sysdate + 15 - to_char(sysdate, 'd'), 'd') from dual);

  v_partname2  := 'PART_ELT_URL_' || tableStr || '_' || v_order;
  v_rangedate2 := 'to_date(' || chr(39) || to_char(v_range_date, 'yyyy-mm-dd') || chr(39) || ',' || chr(39) || 'yyyy-mm-dd' || chr(39) || ')';

  select order_num, sunday
    into v_order, v_range_date
    from nb_part_calendar t
   where t.sunday = (select trunc(sysdate + 22 - to_char(sysdate, 'd'), 'd') from dual);

  v_partname3  := 'PART_ELT_URL_' || tableStr || '_' || v_order;
  v_rangedate3 := 'to_date(' || chr(39) || to_char(v_range_date, 'yyyy-mm-dd') || chr(39) || ',' || chr(39) || 'yyyy-mm-dd' || chr(39) || ')';
  sqlStr       := 'create table NB_ELT_URL_' || tableStr || '
    (
      TASK_ID       NUMBER,
      ID            NUMBER,
      ELEM_TYPE_ID  NUMBER,
      CTIME         DATE
    ) pctfree 0
    partition by range (CTIME)(
                  partition ' || v_partname1 || ' values less than (' || v_rangedate1 || '),
                  partition ' || v_partname2 || ' values less than (' || v_rangedate2 || '),
                  partition ' || v_partname3 || ' values less than (' || v_rangedate3 || ')) tableSpace netben_bg';
  execute immediate sqlStr;

  --索引
  sqlStr := 'create index IDX_NB_ELT_URL_' || tableStr || ' on NB_ELT_URL_' || tableStr || ' (TASK_ID,ID) compress 2 local tableSpace  NETBEN_IDX_NEW nologging';
  execute immediate sqlStr;
  res:=0;
  
exception
  when others then
    errorDesc := 'Error :' || sqlerrm || '  tableStr:' || tableStr;
    --DBMS_OUTPUT.PUT_LINE(v_error_desc);
    create_procedure_log('createELT_URL', errorDesc, 'error');
    res:=1;
    
end createELT_URL;


/

