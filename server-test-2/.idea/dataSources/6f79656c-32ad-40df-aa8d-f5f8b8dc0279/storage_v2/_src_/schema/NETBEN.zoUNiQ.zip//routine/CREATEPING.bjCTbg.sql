create procedure createPING(tableStr IN varchar2,res OUT number) authid current_user is
  sqlStr varchar2(4000);
  errorDesc varchar2(4000);
begin

create_procedure_log('createPING',
				   'create table:NB_PING_' || tableStr,
				   'run');
           
  sqlStr := 'create table NB_PING_' || tableStr || '
  (
    PING_ID           NUMBER not null,
    ID                NUMBER,
    TASK_ID           NUMBER,
    PAGE_SEQ          NUMBER,
    CITY_ID           NUMBER,
    ISP_ID            NUMBER,
    NET_SPEED_ID      NUMBER,
    TM_BASE           DATE,
    PROBE_IP          NUMBER,
    MEMBER_ID         NUMBER,
    DNS_SERVER        VARCHAR2(128),
    ERROR_CODE        NUMBER,
    DEST_IP           VARCHAR2(39),  
    TS_TOTAL          NUMBER,      
    TS_PING_START     NUMBER,
    TS_PING_MAX       NUMBER,
    TS_PING_MIN       NUMBER,
    PING_PACKET_LOST  NUMBER,
    PING_RESULT       VARCHAR2(512),
    IS_NOISE          NUMBER,
    POINT_TOTAL       NUMBER default 1,
    TRACERT_RESULT    VARCHAR2(512),
    NSLOOKUP_RESULT   VARCHAR2(512),
    CTIME             DATE       
  ) pctfree 0
  tablespace NETBEN_BG';
  execute immediate sqlStr;

 
  sqlStr := 'create index IN_PING_ID_' || tableStr || ' on NB_PING_' || tableStr || ' (PING_ID) tableSpace NETBEN_IDX_NEW nologging' ;
  execute immediate sqlStr;
  
  sqlStr := 'create index IN_PING_PAGEID_' || tableStr || ' on NB_PING_' || tableStr || ' (ID) tableSpace NETBEN_IDX_NEW nologging';
  execute immediate sqlStr;

  sqlStr := 'create index IN_PING_PERF_' || tableStr || ' on NB_PING_' || tableStr || ' (TM_BASE,TASK_ID) tableSpace NETBEN_IDX_NEW nologging';
  execute immediate sqlStr;
 res:=0;
 
exception
  when others then
    errorDesc := 'Error :' || sqlerrm || '  tableStr:' || tableStr;
    --DBMS_OUTPUT.PUT_LINE(v_error_desc);
    create_procedure_log('createPING', errorDesc, 'error');
    res:=1;
    
end createPING;


/

