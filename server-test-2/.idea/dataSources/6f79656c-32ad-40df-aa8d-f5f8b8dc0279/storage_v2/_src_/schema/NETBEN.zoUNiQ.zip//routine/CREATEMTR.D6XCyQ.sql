create procedure createMTR(tableStr IN varchar2)
    authid current_user is
    sqlStr varchar2(4000);
begin
    --创建MTR
    sqlStr := 'create table NB_MTR_' || tableStr || '
  (
      id              NUMBER not null,
      agreement_id    NUMBER,
      task_id         NUMBER,
      tm_base         TIMESTAMP(6),
      probe_ip        NUMBER,
      host_id         NUMBER,
      country_id      NUMBER,
      region_id       NUMBER,
      city_id         NUMBER,
      isp_id          NUMBER,
      net_speed_id    NUMBER,
      dns_server      VARCHAR2(128),
      os_id           NUMBER,
      dest_ip         VARCHAR2(128),
      dest_country_id NUMBER,
      dest_region_id  NUMBER,
      dest_city_id    NUMBER,
      dest_isp_id     NUMBER,
      error_code      NUMBER,
      nbfs_path       VARCHAR2(128),
      hop_number      NUMBER,
      packets_loss    NUMBER,
      packets_snt     NUMBER,
      packets_last    NUMBER,
      pings_avg       NUMBER,
      pings_best      NUMBER,
      pings_wrst      NUMBER,
      pings_stdev     NUMBER,
      is_noise        NUMBER,
      ctime           TIMESTAMP(6),
      member_id       NUMBER,
      district_id     INTEGER,
      point_total     NUMBER
  ) pctfree 0';
    execute immediate sqlStr;
    --主键
    sqlStr := 'alter table NB_MTR_' || tableStr || ' add constraint PK_NB_MTR_' || tableStr ||
              ' primary key (ID) using index ';
    execute immediate sqlStr;

    --创建MTR
    sqlStr := 'create table NB_MTR_ITEM_' || tableStr || '
  (
      id               NUMBER not null,
      task_id          NUMBER,
      tm_base          TIMESTAMP(6),
      host_id          NUMBER,
      country_id       NUMBER,
      region_id        NUMBER,
      city_id          NUMBER,
      district_id      NUMBER,
      dns_server       VARCHAR2(128),
      os_id            NUMBER,
      dest_ip          VARCHAR2(128),
      dest_country_id  NUMBER,
      dest_region_id   NUMBER,
      dest_city_id     NUMBER,
      dest_isp_id      NUMBER,
      error_code       NUMBER,
      nbfs_path        VARCHAR2(128),
      last_id          NUMBER,
      hop_no           NUMBER,
      pre_hop          VARCHAR2(128),
      cur_hop          VARCHAR2(128),
      pre_hop_country_id   NUMBER,
      pre_hop_region_id    NUMBER,
      pre_hop_city_id      NUMBER,
      pre_hop_isp_id       NUMBER,
      hop_country_id   NUMBER,
      hop_region_id    NUMBER,
      hop_city_id      NUMBER,
      hop_isp_id       NUMBER,
      is_last          NUMBER,
      hop_number       NUMBER,
      packets_loss     NUMBER,
      packets_snt      NUMBER,
      packets_last     NUMBER,
      pings_avg        NUMBER,
      pings_best       NUMBER,
      pings_wrst       NUMBER,
      pings_stdev      NUMBER,
      cur_hop_number   NUMBER,
      cur_packets_loss NUMBER,
      cur_packets_snt  NUMBER,
      cur_packets_last NUMBER,
      cur_pings_avg    NUMBER,
      cur_pings_best   NUMBER,
      cur_pings_wrst   NUMBER,
      cur_pings_stdev  NUMBER,
      is_noise         NUMBER,
      net_speed_id     NUMBER,
      isp_id           NUMBER,
      member_id        NUMBER,
      pre_hop_aggr     VARCHAR2(128),
      cur_hop_aggr     VARCHAR2(128),
      agreement_id     NUMBER,
      point_total      NUMBER,
      probe_ip         NUMBER
  ) pctfree 0';
    execute immediate sqlStr;
    --主键
    sqlStr := 'alter table NB_MTR_ITEM_' || tableStr || ' add constraint PK_NB_MTR_ITEM_' || tableStr ||
              ' primary key (ID) using index ';
    execute immediate sqlStr;

END createMTR;
/

