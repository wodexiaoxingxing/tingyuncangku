create procedure alter_page_to_part_copy(tablestr number) authid current_user is
sqlStr varchar2(32767);
rangeDate date;
rangeDesc varchar2(8);
partName1 varchar2(64);
rangeName1 varchar2(64);
partName2 varchar2(64);
rangeName2 varchar2(64);
partName3 varchar2(64);
rangeName3 varchar2(64);
partName4 varchar2(64);
rangeName4 varchar2(64);
partName5 varchar2(64);
rangeName5 varchar2(64);
partName6 varchar2(64);
rangeName6 varchar2(64);
partName7 varchar2(64);
rangeName7 varchar2(64);
partName8 varchar2(64);
rangeName8 varchar2(64);
partName9 varchar2(64);
rangeName9 varchar2(64);
partName10 varchar2(64);
rangeName10 varchar2(64);
createDate date;
--拷贝数据用变量
stDesc varchar2(32);
etDesc varchar2(32);
begin
  DBMS_OUTPUT.ENABLE(999999999999999999999);
  createDate:=sysdate-60;
  rangeDate := trunc(createDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd'); 
  partName1:='part_page_'||tableStr||'_'||rangeDesc;
  rangeName1:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';      
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd'); 
  partName2:='part_page_'||tableStr||'_'||rangeDesc;
  rangeName2:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName3:='part_page_'||tableStr||'_'||rangeDesc;
  rangeName3:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName4:='part_page_'||tableStr||'_'||rangeDesc;
  rangeName4:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';      
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd'); 
  partName5:='part_page_'||tableStr||'_'||rangeDesc;
  rangeName5:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName6:='part_page_'||tableStr||'_'||rangeDesc;
  rangeName6:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName7:='part_page_'||tableStr||'_'||rangeDesc;
  rangeName7:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';      
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd'); 
  partName8:='part_page_'||tableStr||'_'||rangeDesc;
  rangeName8:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName9:='part_page_'||tableStr||'_'||rangeDesc;
  rangeName9:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName10:='part_page_'||tableStr||'_'||rangeDesc;
  rangeName10:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
  -- 1 创建临时表
  create_procedure_log('alter_page_to_part',tableStr||',begin','run');
    begin
      sqlStr:='drop table nb_page_'||tablestr||'_temp';
      dbms_output.put_line(sqlStr||';');
      --execute immediate sqlStr;
    exception when others then
      create_procedure_log('alter_page_to_part',tableStr||','||sqlerrm,'error');  
    end; 
          
    sqlStr:=' create table NB_PAGE_'||tableStr||'_temp(
            id NUMBER not null,tran_id NUMBER,task_id NUMBER,city_id NUMBER,isp_id NUMBER,net_speed_id NUMBER,
            tm_base DATE,tm_day DATE,tm_hour DATE,tm_half_hour DATE,
            probe_ip NUMBER,page_seq NUMBER,error_code NUMBER,
            error_path VARCHAR2(256),cont_err_total NUMBER,cont_ele_total NUMBER,redirect_total NUMBER,
            point_total NUMBER default 1,byte_total NUMBER,rate_download NUMBER,
            dest_ip VARCHAR2(39),ping_result VARCHAR2(512),tracert_result VARCHAR2(512),
            http_server VARCHAR2(256),http_via VARCHAR2(256),ts_total NUMBER,
            ts_page_base NUMBER,ts_dns NUMBER,ts_connect NUMBER,ts_ssl NUMBER,ts_redirect NUMBER,ts_request NUMBER,
            ts_first_packet NUMBER,ts_client NUMBER,ts_contents NUMBER,ts_extra_data NUMBER,ts_open_page  NUMBER,
            ts_user NUMBER,ts_network NUMBER,ts_close NUMBER,is_noise NUMBER,nslookup_result VARCHAR2(512),
            script_error_result VARCHAR2(2000),dns_server  VARCHAR2(128),byte_page_base NUMBER,
            rate_download_page_base NUMBER,num_first_elem NUMBER,
            byte_first NUMBER,num_host NUMBER,ts_dns_total  NUMBER,num_connect NUMBER,
            ts_connect_total NUMBER,num_dom NUMBER,num_iframe NUMBER,num_no_compress_elem NUMBER,
            num_no_expire_elem NUMBER,num_no_etag_elem NUMBER,percent_cpu NUMBER,
            percent_cpu_task NUMBER,percent_mem  NUMBER,
            percent_mem_task NUMBER,rate_avg NUMBER,
            version_id NUMBER,os_ver_id NUMBER,
            bs_id NUMBER,bs_ver_id NUMBER,
            flash_ver VARCHAR2(64),log_msg_result VARCHAR2(512),
            band_width NUMBER,member_id INTEGER,
            num_elem_lazy INTEGER,ts_first_paint INTEGER,
            ts_full_screen INTEGER,ts_unload_start INTEGER,
            ts_unload_end INTEGER,ts_dom_load  INTEGER,
            ts_dom_interact INTEGER,ts_dom_cont_load_start INTEGER,
            ts_dom_cont_load_end INTEGER,ts_dom_complete INTEGER,
            ts_load_evt_start INTEGER,ts_load_evt_end INTEGER,
            dns_server_ip NUMBER,src_path VARCHAR2(512),cpu_trend_result VARCHAR2(512),
            mem_trend_result VARCHAR2(512),bitrate_trend_result VARCHAR2(512),
            script_exec_segments_result VARCHAR2(512),ts_script_total INTEGER,
            ts_dns_proj INTEGER,ts_connect_proj INTEGER,ts_first_packet_proj  INTEGER,
            ctime  DATE ) partition by range (TM_BASE)(
              partition '||partName1||' values less than ('||rangeName1||'),
              partition '||partName2||' values less than ('||rangeName2||'),
              partition '||partName3||' values less than ('||rangeName3||'),
              partition '||partName4||' values less than ('||rangeName4||'),
              partition '||partName5||' values less than ('||rangeName5||'),
              partition '||partName6||' values less than ('||rangeName6||'),
              partition '||partName7||' values less than ('||rangeName7||'),
              partition '||partName8||' values less than ('||rangeName8||'),
              partition '||partName9||' values less than ('||rangeName9||'),
              partition '||partName10||' values less than ('||rangeName10||'))
              tablespace netben_bg';   
        dbms_output.put_line(sqlStr||';');
        --execute immediate sqlStr;
        -- 删除物化视图
        begin
          sqlStr:='drop materialized view log on nb_page_'||tableStr;
          --execute immediate sqlStr;
          dbms_output.put_line(sqlStr||';');
        exception when  others then
          dbms_output.put_line(sqlStr||';');
        end;
        begin
          sqlStr:='drop materialized view mv_page_'||tableStr;
          --execute immediate sqlStr;
          dbms_output.put_line(sqlStr||';');
        exception when  others then
          dbms_output.put_line(sqlStr||';');
        end;
        
       
       
        -- 修改索引名称，空出名称
        create_procedure_log('alter_page_to_part',tableStr||','||'修改索引名称','run');  
        begin
          sqlStr:='alter index in_page_perf_'||tableStr||' rename to in_page_perf_'||tablestr||'_bak';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_page_to_part',tableStr||','||sqlStr||','||sqlerrm,'error');  
        end;
        
        begin
          sqlStr:='alter index in_page_error_'||tableStr||' rename to in_page_error_'||tablestr||'_bak';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_page_to_part',tableStr||','||sqlStr||','||sqlerrm,'error');  
        end;
            
        begin
          sqlStr:='alter index in_page_tranid_'||tableStr||' rename to in_page_tranid_'||tablestr||'_bak';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_page_to_part',tableStr||','||sqlStr||','||sqlerrm,'error');  
        end;
           
        begin
          sqlStr:='alter index in_page_id_'||tableStr||' rename to in_page_id_'||tablestr||'_bak';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_page_to_part',tableStr||','||sqlStr||','||sqlerrm,'error');  
        end;
        
        begin
          sqlStr:='alter index in_page_ctime_'||tableStr||' rename to in_page_ctime_'||tablestr||'_bak';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_page_to_part',tableStr||','||sqlStr||','||sqlerrm,'error');  
        end;
        
        
       
        -- 创建索引  
        begin
          create_procedure_log('alter_page_to_part',tableStr||','||'创建索引in_page_perf','run'); 
          sqlStr:='create index in_page_perf_'||tableStr||' on nb_page_'||tableStr||'_temp (tm_base,task_id) compress LOCAL parallel 4 tableSpace NETBEN_IND nologging';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_page_to_part',tableStr||','||sqlStr||','||sqlerrm,'error'); 
        end;  
        
        begin
          create_procedure_log('alter_page_to_part',tableStr||','||'创建索引in_page_ctime','run'); 
          sqlStr:='create index in_page_ctime_'||tableStr||' on nb_page_'||tableStr||'_temp (tm_base,ctime) compress LOCAL parallel 4 tableSpace NETBEN_IND nologging';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_page_to_part',tableStr||','||sqlStr||','||sqlerrm,'error');  
        end;  
        
        begin
          create_procedure_log('alter_page_to_part',tableStr||','||'创建索引in_page_tranid','run'); 
          sqlStr:='create index in_page_tranid_'||tableStr||' on nb_page_'||tableStr||'_temp (tran_id) local tableSpace NETBEN_IND nologging';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_page_to_part',tableStr||','||sqlStr||','||sqlerrm,'error'); 
        end;
          
        begin
          create_procedure_log('alter_page_to_part',tableStr||','||'创建索引in_page_id','run'); 
          sqlStr:='create index in_page_id_'||tableStr||' on nb_page_'||tableStr||'_temp (id) local tableSpace NETBEN_IND nologging';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_page_to_part',tableStr||','||sqlStr||','||sqlerrm,'error'); 
        end;
        for i in 1..30 loop
          stDesc:=to_char(sysdate - 3 * (31-i)-1,'yyyy-mm-dd');
          etDesc:=to_char(sysdate-3*(30-i)-1,'yyyy-mm-dd');
          sqlStr:='insert into nb_page_'||tablestr||'_temp 
             (ID,TRAN_ID,TASK_ID,CITY_ID,ISP_ID,NET_SPEED_ID,TM_BASE,TM_DAY,TM_HOUR,TM_HALF_HOUR,PROBE_IP,PAGE_SEQ,ERROR_CODE,ERROR_PATH,CONT_ERR_TOTAL,CONT_ELE_TOTAL,REDIRECT_TOTAL,POINT_TOTAL,BYTE_TOTAL,RATE_DOWNLOAD,BYTE_PAGE_BASE,RATE_DOWNLOAD_PAGE_BASE,DNS_SERVER,DNS_SERVER_IP,DEST_IP,PING_RESULT,TRACERT_RESULT,NSLOOKUP_RESULT,SCRIPT_ERROR_RESULT,
              HTTP_SERVER,HTTP_VIA,TS_TOTAL,TS_PAGE_BASE,TS_DNS,TS_CONNECT,TS_SSL,TS_REDIRECT,TS_REQUEST,TS_FIRST_PACKET,TS_CLIENT,TS_CONTENTS,TS_EXTRA_DATA,TS_OPEN_PAGE,TS_USER,TS_NETWORK,TS_CLOSE,NUM_FIRST_ELEM,BYTE_FIRST,NUM_HOST,TS_DNS_TOTAL,NUM_CONNECT,TS_CONNECT_TOTAL,NUM_DOM,NUM_IFRAME,NUM_NO_COMPRESS_ELEM,NUM_NO_EXPIRE_ELEM,NUM_NO_ETAG_ELEM,
              PERCENT_CPU,PERCENT_CPU_TASK,PERCENT_MEM,PERCENT_MEM_TASK,RATE_AVG,BAND_WIDTH,MEMBER_ID,VERSION_ID,OS_VER_ID,BS_ID,BS_VER_ID,FLASH_VER,LOG_MSG_RESULT,NUM_ELEM_LAZY,TS_FIRST_PAINT,TS_FULL_SCREEN,TS_UNLOAD_START,TS_UNLOAD_END,TS_DOM_LOAD,TS_DOM_INTERACT,TS_DOM_CONT_LOAD_START,TS_DOM_CONT_LOAD_END,TS_DOM_COMPLETE,TS_LOAD_EVT_START,
              TS_LOAD_EVT_END,SRC_PATH,CPU_TREND_RESULT,MEM_TREND_RESULT,BITRATE_TREND_RESULT,SCRIPT_EXEC_SEGMENTS_RESULT,TS_SCRIPT_TOTAL,TS_DNS_PROJ,TS_CONNECT_PROJ,TS_FIRST_PACKET_PROJ,IS_NOISE,CTIME
              )
              select ID,TRAN_ID,TASK_ID,CITY_ID,ISP_ID,NET_SPEED_ID,TM_BASE,TM_DAY,TM_HOUR,TM_HALF_HOUR,PROBE_IP,PAGE_SEQ,ERROR_CODE,ERROR_PATH,CONT_ERR_TOTAL,CONT_ELE_TOTAL,REDIRECT_TOTAL,POINT_TOTAL,BYTE_TOTAL,RATE_DOWNLOAD,BYTE_PAGE_BASE,RATE_DOWNLOAD_PAGE_BASE,DNS_SERVER,DNS_SERVER_IP,DEST_IP,PING_RESULT,TRACERT_RESULT,NSLOOKUP_RESULT,SCRIPT_ERROR_RESULT,
              HTTP_SERVER,HTTP_VIA,TS_TOTAL,TS_PAGE_BASE,TS_DNS,TS_CONNECT,TS_SSL,TS_REDIRECT,TS_REQUEST,TS_FIRST_PACKET,TS_CLIENT,TS_CONTENTS,TS_EXTRA_DATA,TS_OPEN_PAGE,TS_USER,TS_NETWORK,TS_CLOSE,NUM_FIRST_ELEM,BYTE_FIRST,NUM_HOST,TS_DNS_TOTAL,NUM_CONNECT,TS_CONNECT_TOTAL,NUM_DOM,NUM_IFRAME,NUM_NO_COMPRESS_ELEM,NUM_NO_EXPIRE_ELEM,NUM_NO_ETAG_ELEM,
              PERCENT_CPU,PERCENT_CPU_TASK,PERCENT_MEM,PERCENT_MEM_TASK,RATE_AVG,BAND_WIDTH,MEMBER_ID,VERSION_ID,OS_VER_ID,BS_ID,BS_VER_ID,FLASH_VER,LOG_MSG_RESULT,NUM_ELEM_LAZY,TS_FIRST_PAINT,TS_FULL_SCREEN,TS_UNLOAD_START,TS_UNLOAD_END,TS_DOM_LOAD,TS_DOM_INTERACT,TS_DOM_CONT_LOAD_START,TS_DOM_CONT_LOAD_END,TS_DOM_COMPLETE,TS_LOAD_EVT_START,
              TS_LOAD_EVT_END,SRC_PATH,CPU_TREND_RESULT,MEM_TREND_RESULT,BITRATE_TREND_RESULT,SCRIPT_EXEC_SEGMENTS_RESULT,TS_SCRIPT_TOTAL,TS_DNS_PROJ,TS_CONNECT_PROJ,TS_FIRST_PACKET_PROJ,IS_NOISE,CTIME
             from nb_page_'||tablestr||' where tm_base >= to_date('''||stDesc||''',''yyyy-mm-dd'') and tm_base<to_date('''||etDesc||''',''yyyy-mm-dd'')';
          dbms_output.put_line(sqlStr||';'); 
          dbms_output.put_line('commit;');       
        end loop;         
      sqlStr:='rename nb_page_'||tablestr|| ' to nb_page_'||tablestr||'_bk';
      dbms_output.put_line(sqlStr||';');             
      sqlStr:='rename nb_page_'||tablestr||'_temp to nb_page_'||tablestr;
      dbms_output.put_line(sqlStr||';');  
      --改完名后把最后1天数据导过来
      stDesc:=to_char(sysdate-1,'yyyy-mm-dd');
      etDesc:=to_char(sysdate+1,'yyyy-mm-dd');
      sqlStr:='insert into nb_page_'||tablestr||'(ID,TRAN_ID,TASK_ID,CITY_ID,ISP_ID,NET_SPEED_ID,TM_BASE,TM_DAY,TM_HOUR,TM_HALF_HOUR,PROBE_IP,PAGE_SEQ,ERROR_CODE,ERROR_PATH,CONT_ERR_TOTAL,CONT_ELE_TOTAL,REDIRECT_TOTAL,POINT_TOTAL,BYTE_TOTAL,RATE_DOWNLOAD,BYTE_PAGE_BASE,RATE_DOWNLOAD_PAGE_BASE,DNS_SERVER,DNS_SERVER_IP,DEST_IP,PING_RESULT,TRACERT_RESULT,NSLOOKUP_RESULT,SCRIPT_ERROR_RESULT,
              HTTP_SERVER,HTTP_VIA,TS_TOTAL,TS_PAGE_BASE,TS_DNS,TS_CONNECT,TS_SSL,TS_REDIRECT,TS_REQUEST,TS_FIRST_PACKET,TS_CLIENT,TS_CONTENTS,TS_EXTRA_DATA,TS_OPEN_PAGE,TS_USER,TS_NETWORK,TS_CLOSE,NUM_FIRST_ELEM,BYTE_FIRST,NUM_HOST,TS_DNS_TOTAL,NUM_CONNECT,TS_CONNECT_TOTAL,NUM_DOM,NUM_IFRAME,NUM_NO_COMPRESS_ELEM,NUM_NO_EXPIRE_ELEM,NUM_NO_ETAG_ELEM,
              PERCENT_CPU,PERCENT_CPU_TASK,PERCENT_MEM,PERCENT_MEM_TASK,RATE_AVG,BAND_WIDTH,MEMBER_ID,VERSION_ID,OS_VER_ID,BS_ID,BS_VER_ID,FLASH_VER,LOG_MSG_RESULT,NUM_ELEM_LAZY,TS_FIRST_PAINT,TS_FULL_SCREEN,TS_UNLOAD_START,TS_UNLOAD_END,TS_DOM_LOAD,TS_DOM_INTERACT,TS_DOM_CONT_LOAD_START,TS_DOM_CONT_LOAD_END,TS_DOM_COMPLETE,TS_LOAD_EVT_START,
              TS_LOAD_EVT_END,SRC_PATH,CPU_TREND_RESULT,MEM_TREND_RESULT,BITRATE_TREND_RESULT,SCRIPT_EXEC_SEGMENTS_RESULT,TS_SCRIPT_TOTAL,TS_DNS_PROJ,TS_CONNECT_PROJ,TS_FIRST_PACKET_PROJ,IS_NOISE,CTIME
              )
              select ID,TRAN_ID,TASK_ID,CITY_ID,ISP_ID,NET_SPEED_ID,TM_BASE,TM_DAY,TM_HOUR,TM_HALF_HOUR,PROBE_IP,PAGE_SEQ,ERROR_CODE,ERROR_PATH,CONT_ERR_TOTAL,CONT_ELE_TOTAL,REDIRECT_TOTAL,POINT_TOTAL,BYTE_TOTAL,RATE_DOWNLOAD,BYTE_PAGE_BASE,RATE_DOWNLOAD_PAGE_BASE,DNS_SERVER,DNS_SERVER_IP,DEST_IP,PING_RESULT,TRACERT_RESULT,NSLOOKUP_RESULT,SCRIPT_ERROR_RESULT,
              HTTP_SERVER,HTTP_VIA,TS_TOTAL,TS_PAGE_BASE,TS_DNS,TS_CONNECT,TS_SSL,TS_REDIRECT,TS_REQUEST,TS_FIRST_PACKET,TS_CLIENT,TS_CONTENTS,TS_EXTRA_DATA,TS_OPEN_PAGE,TS_USER,TS_NETWORK,TS_CLOSE,NUM_FIRST_ELEM,BYTE_FIRST,NUM_HOST,TS_DNS_TOTAL,NUM_CONNECT,TS_CONNECT_TOTAL,NUM_DOM,NUM_IFRAME,NUM_NO_COMPRESS_ELEM,NUM_NO_EXPIRE_ELEM,NUM_NO_ETAG_ELEM,
              PERCENT_CPU,PERCENT_CPU_TASK,PERCENT_MEM,PERCENT_MEM_TASK,RATE_AVG,BAND_WIDTH,MEMBER_ID,VERSION_ID,OS_VER_ID,BS_ID,BS_VER_ID,FLASH_VER,LOG_MSG_RESULT,NUM_ELEM_LAZY,TS_FIRST_PAINT,TS_FULL_SCREEN,TS_UNLOAD_START,TS_UNLOAD_END,TS_DOM_LOAD,TS_DOM_INTERACT,TS_DOM_CONT_LOAD_START,TS_DOM_CONT_LOAD_END,TS_DOM_COMPLETE,TS_LOAD_EVT_START,
              TS_LOAD_EVT_END,SRC_PATH,CPU_TREND_RESULT,MEM_TREND_RESULT,BITRATE_TREND_RESULT,SCRIPT_EXEC_SEGMENTS_RESULT,TS_SCRIPT_TOTAL,TS_DNS_PROJ,TS_CONNECT_PROJ,TS_FIRST_PACKET_PROJ,IS_NOISE,CTIME
              from nb_page_'||tablestr||'_bk where tm_base >= to_date('''||stDesc||''',''yyyy-mm-dd'') and tm_base<to_date('''||etDesc||''',''yyyy-mm-dd'')';
      dbms_output.put_line(sqlStr||';'); 
      dbms_output.put_line('commit;');    
      create_procedure_log('alter_page_to_part',tableStr||',end','run');
      exception when others then
        create_procedure_log('alter_page_to_part',tableStr||','||sqlerrm,'error');  
end alter_page_to_part_copy;


/

