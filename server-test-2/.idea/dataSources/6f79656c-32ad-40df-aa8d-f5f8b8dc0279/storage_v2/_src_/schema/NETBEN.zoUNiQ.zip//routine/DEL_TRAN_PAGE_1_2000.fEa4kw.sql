create PROCEDURE          "DEL_TRAN_PAGE_1_2000" 
authid current_user
is
  sqlStr varchar2(4000);
  v_error_desc varchar2(4000);
  task sys_refcursor;
  v_taskId number;
begin
--首先取出小于2000的表后缀
for tableName in(select distinct table_str as name from nb_m_agreement where owner_id < 2000) loop
  begin
  --内循环，取出一个表内的所有任务ID      
  sqlStr := 'select id from nb_m_task where owner_id ='||tableName.Name;
  open task for sqlStr;
  loop
    fetch task into v_taskId;
    EXIT WHEN task%NOTFOUND;
    for i in 1..100 loop
        sqlStr:='delete from nb_tran_'||tableName.Name||' where tm_base between sysdate - 71 -(100-'||i||')*2 -3
           and sysdate - 71 - (100-'||i||')*2  and task_id='||v_taskId;
        execute immediate sqlStr;
        commit;
        sqlStr:='delete from nb_page_'||tableName.Name||' where tm_base between sysdate - 71 -(100-'||i||')*2 -3
           and sysdate - 71 - (100-'||i||')*2  and task_id='||v_taskId;
        execute immediate sqlStr;
        commit;
    end loop;
    create_procedure_log('del_tran_page_1_2000','tableStr-task_id:'||tableName.name||'-'||v_taskId,0);
  end loop;
  close task;
      --如果在一个外循环中出现错误，则此外循环将无法完成，而跳到下一循环
  exception when  others then
        v_error_desc := ' Error: tableName='||tableName.name||' sqlStr ='|| sqlstr ;
        create_procedure_log('del_tran_page_1_2000',v_error_desc,sqlcode);
  end;        
end loop;        
end del_tran_page_1_2000;


/

