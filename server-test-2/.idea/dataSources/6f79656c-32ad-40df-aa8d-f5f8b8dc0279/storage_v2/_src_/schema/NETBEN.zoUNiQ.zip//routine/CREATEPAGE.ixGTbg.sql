create PROCEDURE createPAGE(tableStr IN varchar2,res OUT number) authid current_user is
  sqlStr     varchar2(8000);
  createDate date := sysdate;
  rangeDate  date;
  rangeDesc  varchar2(8);
  partName1  varchar2(64);
  rangeName1 varchar2(64);
  partName2  varchar2(64);
  rangeName2 varchar2(64);
  partName3  varchar2(64);
  rangeName3 varchar2(64);
  errorDesc varchar2(4000);
BEGIN

  create_procedure_log('createPAGE', 'create table:NB_PAGE_' || tableStr, 'run');

  --创建page
  rangeDate  := trunc(createDate + 7, 'd');
  rangeDesc  := to_char(rangeDate, 'yymmdd');
  partName1  := 'part_page_' || tableStr || '_' || rangeDesc;
  rangeName1 := 'to_date(''' || to_char(rangeDate, 'yyyy-mm-dd') || ''',''yyyy-mm-dd'')';
  rangeDate  := trunc(rangeDate + 7, 'd');
  rangeDesc  := to_char(rangeDate, 'yymmdd');
  partName2  := 'part_page_' || tableStr || '_' || rangeDesc;
  rangeName2 := 'to_date(''' || to_char(rangeDate, 'yyyy-mm-dd') || ''',''yyyy-mm-dd'')';
  rangeDate  := trunc(rangeDate + 7, 'd');
  rangeDesc  := to_char(rangeDate, 'yymmdd');
  partName3  := 'part_page_' || tableStr || '_' || rangeDesc;
  rangeName3 := 'to_date(''' || to_char(rangeDate, 'yyyy-mm-dd') || ''',''yyyy-mm-dd'')';
  sqlStr     := 'create table NB_PAGE_' || tableStr || '
    (
      ID                              NUMBER not null,
      TRAN_ID                         NUMBER,
      TASK_ID                         NUMBER,
      CITY_ID                         NUMBER,
      ISP_ID                          NUMBER,
      NET_SPEED_ID                    NUMBER,
      TM_BASE                         DATE,
      TM_DAY                          DATE,
      TM_HOUR                         DATE,
      TM_HALF_HOUR                    DATE,
      PROBE_IP                        NUMBER,
      PAGE_SEQ                        NUMBER,
      ERROR_CODE                      NUMBER,
      ERROR_PATH                      VARCHAR2(256),
      CONT_ERR_TOTAL                  NUMBER,
      CONT_ELE_TOTAL                  NUMBER,
      REDIRECT_TOTAL                  NUMBER,
      POINT_TOTAL                     NUMBER default 1,
      BYTE_TOTAL                      NUMBER,  
      RATE_DOWNLOAD                   NUMBER,
      BYTE_PAGE_BASE                  NUMBER,
      RATE_DOWNLOAD_PAGE_BASE         NUMBER,
      DNS_SERVER                      VARCHAR2(128),  
      DNS_SERVER_IP                   NUMBER,
      DEST_IP                         VARCHAR2(39),
      PING_RESULT                     VARCHAR2(512),
      TRACERT_RESULT                  VARCHAR2(512),
      NSLOOKUP_RESULT                 VARCHAR2(512),
      SCRIPT_ERROR_RESULT             VARCHAR2(2000),
      PCAP_PATH                       VARCHAR2(512),
      HTTP_SERVER                     VARCHAR2(256),
      HTTP_VIA                        VARCHAR2(256),      
      TS_TOTAL                        NUMBER,
      TS_PAGE_BASE                    NUMBER,
      TS_DNS                          NUMBER,
      TS_CONNECT                      NUMBER,
      TS_SSL                          NUMBER,
      TS_REDIRECT                     NUMBER,
      TS_REQUEST                      NUMBER,
      TS_FIRST_PACKET                 NUMBER,
      TS_CLIENT                       NUMBER,
      TS_CONTENTS                     NUMBER,
      TS_EXTRA_DATA                   NUMBER,
      TS_OPEN_PAGE                    NUMBER,
      TS_USER                         NUMBER,
      TS_NETWORK                      NUMBER,
      TS_CLOSE                        NUMBER,
      NUM_FIRST_ELEM                  NUMBER,
      BYTE_FIRST                      NUMBER,
      NUM_HOST                        NUMBER,
      TS_DNS_TOTAL                    NUMBER,
      NUM_CONNECT                     NUMBER,
      TS_CONNECT_TOTAL                NUMBER,
      NUM_DOM                         NUMBER,
      NUM_IFRAME                      NUMBER,
      NUM_NO_COMPRESS_ELEM            NUMBER,
      NUM_NO_EXPIRE_ELEM              NUMBER,
      NUM_NO_ETAG_ELEM                NUMBER,
      PERCENT_CPU                     NUMBER,
      PERCENT_CPU_TASK                NUMBER,  
      PERCENT_MEM                     NUMBER,  
      PERCENT_MEM_TASK                NUMBER,  
      RATE_AVG                        NUMBER,
      BAND_WIDTH                      NUMBER,
      MEMBER_ID                       INTEGER,
      VERSION_ID                      INTEGER,
      OS_VER_ID                       INTEGER,
      BS_ID                           INTEGER,
      BS_VER_ID                       INTEGER,
      FLASH_VER                       VARCHAR2(32),
      LOG_MSG_RESULT                  VARCHAR2(512),
      NUM_ELEM_LAZY                   INTEGER,
      TS_FIRST_PAINT                  INTEGER,
      TS_FULL_SCREEN                  INTEGER,
      TS_UNLOAD_START                 INTEGER,
      TS_UNLOAD_END                   INTEGER,
      TS_DOM_LOAD                     INTEGER,
      TS_DOM_INTERACT                 INTEGER,
      TS_DOM_CONT_LOAD_START          INTEGER,
      TS_DOM_CONT_LOAD_END            INTEGER,
      TS_DOM_COMPLETE                 INTEGER,
      TS_LOAD_EVT_START               INTEGER,
      TS_LOAD_EVT_END                 INTEGER,
      src_path                        VARCHAR2(512),      -- 页面源码路径
      cpu_trend_result                VARCHAR2(512),      -- CPU变化趋势
      mem_trend_result                VARCHAR2(512),      -- 内存变化趋势
      bitrate_trend_result            VARCHAR2(512),      -- 流量变化趋势
      script_exec_segments_result     VARCHAR2(512),      -- JS执行过程
      ts_script_total                 INTEGER,            -- 脚本执行总时间
      ts_dns_proj                     INTEGER,            -- DNS投影时间
      ts_connect_proj                 INTEGER,            -- 建联投影时间
      ts_first_packet_proj            INTEGER,            -- 首包投影时间
      QUEUE_TIME            NUMBER, 
    APPLICATION_SERVER_TIME         NUMBER, 
    APPLICATION_ID                  NUMBER, 
    APPLICATION_INSTANCE_ID         NUMBER, 
    TRACE_GUID                      VARCHAR2(512),  
    ACTION_NAME                     VARCHAR2(512),
      IS_NOISE                        INTEGER,
      ctime                           DATE      
    ) partition by range (TM_BASE)(
              partition ' || partName1 || ' values less than (' || rangeName1 || '), 
              partition ' || partName2 || ' values less than (' || rangeName2 || '),
              partition ' || partName3 || ' values less than (' || rangeName3 || '))
          tableSpace netben_bg';
  execute immediate sqlStr;
  
  -- 创建索引  
  sqlStr := 'create index in_page_perf_' || tableStr || ' on nb_page_' || tableStr || ' (task_id,tm_base) LOCAL compress 1 tableSpace NETBEN_idx_new nologging';
  execute immediate sqlStr;
  sqlStr := 'create index in_page_ctime_' || tableStr || ' on nb_page_' || tableStr || ' (tm_base,ctime) LOCAL tableSpace NETBEN_idx_new nologging';
  execute immediate sqlStr;
  sqlStr := 'create index in_page_tranid_' || tableStr || ' on nb_page_' || tableStr || ' (tran_id) local tableSpace NETBEN_idx_new nologging';
  execute immediate sqlStr;
  sqlStr := 'create index in_page_id_' || tableStr || ' on nb_page_' || tableStr || ' (id) local tableSpace NETBEN_idx_new nologging';
  execute immediate sqlStr;
  res:=0;
exception
  when others then
    errorDesc := 'Error :' || sqlerrm || '  tableStr:' || tableStr;
    --DBMS_OUTPUT.PUT_LINE(v_error_desc);
    create_procedure_log('createPAGE', errorDesc, 'error');
    res:=1;
END createPAGE;


/

