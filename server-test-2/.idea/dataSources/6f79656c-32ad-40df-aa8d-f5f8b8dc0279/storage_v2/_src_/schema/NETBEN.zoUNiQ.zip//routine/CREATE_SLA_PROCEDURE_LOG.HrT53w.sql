create PROCEDURE create_sla_procedure_log
( 
  step IN varchar2,
  task_id IN number,
  avg_cost in number,
  sla_rate IN number,
  descr IN clob,
  rtime in date,
  app_flows in number,
  wifi_flows in number,
  t_count in number
)
 authid current_user
 is
begin
    insert into nb_sla_procedure_log values(step,task_id,avg_cost,sla_rate,descr,sysdate,rtime,app_flows,wifi_flows,t_count);
    commit;
end create_sla_procedure_log;
/

