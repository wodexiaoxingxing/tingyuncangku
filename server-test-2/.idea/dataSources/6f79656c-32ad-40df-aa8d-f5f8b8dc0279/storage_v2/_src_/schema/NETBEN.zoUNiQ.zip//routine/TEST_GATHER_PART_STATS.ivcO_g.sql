create procedure test_gather_part_stats is
type tabType is table of varchar2(32) index by BINARY_INTEGER;
tabTypeImpl tabType;
DROP_ERROR exception;
ADD_ERROR exception;
sqlStr varchar2(4000);
currDate date := trunc(sysdate,'d');

partNameNew varchar2(64);
partValueNew varchar2(64);
partDate date;
begin
  DBMS_OUTPUT.ENABLE (1000000);
  tabTypeImpl(1):='NB_PAGE';
  tabTypeImpl(2):='MT_PAGE';
  tabTypeImpl(3):='NB_TRAN';
  tabTypeImpl(4):='NB_PING';  
  --收集尚未有统计信息的分区
  for s in 1..tabTypeImpl.count loop
      for tab in(select tabName,partName from (
      select table_name tabName, partition_name partName from user_tab_partitions where  table_name like tabTypeImpl(s) and （num_rows is null or num_rows=0 ) where rownum<100;)
       )
      loop
        begin          
           sqlStr:='execute dbms_stats.gather_table_stats(ownname => ''NETBEN'',tabname => ''' ||tab.table_name ||''' ,partname => ''' ||tab.partition_name ||''',estimate_percent => dbms_stats.auto_sample_size ,method_opt => ''for all indexed columns'' ,cascade => true);';
           --dbms_output.put_line(sqlStr||';');
           execute immediate sqlStr;      
        end;
      end loop;
  end loop;
end test_gather_part_stats;


/

