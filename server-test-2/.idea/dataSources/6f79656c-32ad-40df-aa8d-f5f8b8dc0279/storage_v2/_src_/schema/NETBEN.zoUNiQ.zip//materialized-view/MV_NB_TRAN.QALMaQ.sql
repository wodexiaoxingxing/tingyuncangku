create materialized view MV_NB_TRAN
    refresh force on demand
as
(select task_id,
       city_id,
       isp_id,
       net_speed_id,
       error_code,
       tm_hour4,
       (tm_hour4 - mod(to_number(to_char(tm_hour4, 'hh24')) + 8, 8) / 24) as tm_hour8,
       (tm_hour4 - mod(to_number(to_char(tm_hour4, 'hh24')) + 12, 12) / 24) as tm_hour12,
       trunc(tm_hour4, 'dd') as tm_day,
       point_total,
       round(ts_total,0) as ts_total
  from (select task_id,
               city_id,
               isp_id,
               net_speed_id,
               error_code,
               (tm_hour -
               mod(to_number(to_char(tm_hour, 'hh24')) + 4, 4) / 24) as tm_hour4,
               sum(point_total) as point_total,
               avg(ts_total) as ts_total
          from netben.nb_tran
         group by task_id,
                  city_id,
                  isp_id,
                  net_speed_id,
                  error_code,
                  (tm_hour -
                  mod(to_number(to_char(tm_hour, 'hh24')) + 4, 4) / 24)))

/

