create PROCEDURE probe_summary_test AUTHID current_user IS
  total NUMBER;
  dt DATE;
BEGIN
  create_procedure_log('probe_summary_test', 'probe_summary_test begin', 'begin');

  SELECT SYSDATE INTO dt FROM DUAL;
  SELECT COUNT(1) INTO total FROM nb_m_proberuntime_log_mobile WHERE time_stamp > TRUNC(dt);

  IF total > 0 THEN

    DELETE FROM nb_m_probe_summary WHERE calc_date = TRUNC(dt);
    commit;


    INSERT INTO nb_m_probe_summary
      (host_id, company_id, user_name, online_time, system_flows, app_flows, app_wifi_flows, calc_date)
      SELECT host_id,
             company_id,
             user_name,
             COUNT(1) * 10 AS online_time,
             SUM(traffic_total) AS system_flows,
             SUM(traffic_app) AS app_flows,
             DECODE(SUM(traffic_wifi_app), null, 0, SUM(traffic_wifi_app)) AS app_wifi_flows,
             TRUNC(dt) AS calc_date
        FROM nb_m_proberuntime_log_mobile t
       WHERE time_stamp > TRUNC(dt)
    GROUP BY host_id, company_id, user_name;
    COMMIT;

  END IF;

  create_procedure_log('probe_summary_test', 'probe_summary_test end', 'end');

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM);
    create_procedure_log('probe_summary_test', SQLERRM, 'error');

END probe_summary_test;


/

