create PROCEDURE          "MAN_CREATE_TABLE_EE" authid current_user is
  sqlStr  varchar2(8000);
  ---------------- ?????? ---------------------------------------------------------------------------
  createDate date := sysdate;
  orderNum   number;
  rangeDate  varchar2(128);
  partname1  varchar2(128);
  ee_partname1  varchar2(128);
  rangedate1 varchar2(128);
  partname2  varchar2(128);
  ee_partname2  varchar2(128);
  rangedate2 varchar2(128);
  partname3  varchar2(128);
  ee_partname3  varchar2(128);
  rangedate3 varchar2(128);
  tableStr  varchar2(128);
  --------------- ????????----------------------------------------------------------------------------
  c int;
begin
     -- 2.??????????????????????et???????????????? ????????????????????
   for et in  (SELECT distinct substr(t.table_name,7) task
               from user_tables t
               where table_name like 'NB_EC%' )        loop
 begin
        tableStr := et.task;
 --??????????elem??????????????????
    select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 8 - to_char( createDate,'d'),'d') from dual);
        partname1:='PART_EC_'||tableStr||'_'||orderNum;
        ee_partname1:='PART_EE_'||tableStr||'_'||orderNum;
        rangedate1:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';
         --DBMS_OUTPUT.PUT_LINE(rangedate1);
    select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 15 - to_char( createDate,'d'),'d') from dual);
        partname2:='PART_EC_'||tableStr||'_'||orderNum;
        ee_partname2:='PART_EE_'||tableStr||'_'||orderNum;
        rangedate2:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';
    select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 22 - to_char( createDate,'d'),'d') from dual);
        partname3:='PART_EC_'||tableStr||'_'||orderNum;
        ee_partname3:='PART_EE_'||tableStr||'_'||orderNum;
        rangedate3:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';

SELECT COUNT(*) INTO C FROM USER_TABLES WHERE TABLE_NAME= 'NB_EE_'||tableStr ;
IF C<1 THEN
    --??????????
       sqlStr:='create table NB_EE_'||tableStr||'
    (
      URL_ID           NUMBER,
      PAGE_ID          NUMBER,
      TASK_ID          NUMBER,
      CITY_ID          NUMBER,
      ISP_ID           NUMBER,
      NET_SPEED_ID     NUMBER,
      TM_BASE          DATE,
      DOMAIN_ID        NUMBER,
      ELEM_TYPE_ID     NUMBER,
      PROBE_IP         NUMBER,
      ELEMENT_SEQ      NUMBER,
      RECORD_TYPE      CHAR(1),
      ERROR_CODE       NUMBER,
      REDIRECT_TOTAL   NUMBER,
      URL_IP           NUMBER,
      BYTE_TOTAL       NUMBER,
      TS_START_OFFSET  NUMBER,
      TS_DNS           NUMBER,
      TS_CONNECT       NUMBER,
      TS_SSL           NUMBER,
      TS_REDIRECT      NUMBER,
      TS_REQUEST       NUMBER,
      TS_FIRST_PACKET  NUMBER,
      TS_REMAIN_PACKET NUMBER,
      TS_ELEMENT       NUMBER,
      TS_CLOSE         NUMBER,
      TS_BLOCK         NUMBER,
      BYTE_SENT        NUMBER,
      RATE_DOWNLOAD	   NUMBER,
      RATE_UPLOAD	   NUMBER,
      POINT_TOTAL	   NUMBER
    ) pctfree 0
    partition by range (TM_BASE)(
                  partition '||ee_partname1||' values less than ('||rangedate1||') TABLESPACE NETBEN_BG,
                  partition '||ee_partname2||' values less than ('||rangedate2||') TABLESPACE NETBEN_BG,
                  partition '||ee_partname3||' values less than ('||rangedate3||') TABLESPACE NETBEN_BG)';

--DBMS_OUTPUT.PUT_LINE(sqlStr);
execute   immediate   sqlStr;


    --???????? tm_base,url_id,error_code
    sqlStr:='create index IDX_EE_UID_'||tableStr||' on NB_EE_'||tableStr||' (URL_ID,TM_BASE,ERROR_CODE) local
            (partition '||ee_partname1||',partition '||ee_partname2||',partition '||ee_partname3||') compress 1 PCTFREE 0
            tableSpace  NETBEN_IND nologging';

--DBMS_OUTPUT.PUT_LINE(sqlStr);
execute   immediate   sqlStr;

    --???????? tm_base,domain_id,error_code
    sqlStr:='create index IDX_EE_DID_'||tableStr||' on NB_EE_'||tableStr||' (DOMAIN_ID,TM_BASE,ERROR_CODE) local
            (partition '||ee_partname1||',partition '||ee_partname2||',partition '||ee_partname3||') compress 2 PCTFREE 0
            tableSpace  NETBEN_IND';

--DBMS_OUTPUT.PUT_LINE(sqlStr);
execute   immediate   sqlStr;

    --???????? tm_base,type_id,error_code
    sqlStr:='create index IDX_EE_TID_'||tableStr||' on NB_EE_'||tableStr||' (ELEM_TYPE_ID,TM_BASE,ERROR_CODE) local
            (partition '||ee_partname1||',partition '||ee_partname2||',partition '||ee_partname3||') compress 2 PCTFREE 0
            tableSpace  NETBEN_IND';

--DBMS_OUTPUT.PUT_LINE(sqlStr);
execute   immediate   sqlStr;

END IF;

 exception when  others then
   DBMS_OUTPUT.PUT_LINE('error:'||tableStr);
     MON_PC_ERROR_LOG('CREATE_TABLE_EE',sqlerrm,tableStr);
  --DBMS_OUTPUT.PUT_LINE(tableStr||' ERROR!');


end;


       end loop;

end MAN_CREATE_TABLE_EE;


/

