create PROCEDURE          "ADD_RATE_TABLE_ALL" authid current_user
is 
  sqlStr  varchar2(4000);  
  v_error_desc varchar2(400);
  v_s number;
begin
  for tableName in(select t.table_name as name ,substr(t.table_name,11) as suff from user_tables t where t.table_name like 'NB_STREAM_%') loop
  begin
    DBMS_OUTPUT.PUT_LINE(tableName.name);
    select count(*)  INTO v_s FROM user_tables t where t.table_name = 'NB_RATE_'||tableName.suff;
    if v_s < 1 then
      sqlStr := 'create table NB_RATE_'||tableName.suff||'
                  (
                    STREAM_ID NUMBER not null,
                    S1  NUMBER,S2  NUMBER,S3  NUMBER,S4  NUMBER,S5  NUMBER,S6  NUMBER,S7  NUMBER,S8  NUMBER,S9  NUMBER,S10 NUMBER,
                    S11 NUMBER,S12 NUMBER,S13 NUMBER,S14 NUMBER,S15 NUMBER,S16 NUMBER,S17 NUMBER,S18 NUMBER,S19 NUMBER,S20 NUMBER,
                    S21 NUMBER,S22 NUMBER,S23 NUMBER,S24 NUMBER,S25 NUMBER,S26 NUMBER,S27 NUMBER,S28 NUMBER,S29 NUMBER,S30 NUMBER,
                    S31 NUMBER,S32 NUMBER,S33 NUMBER,S34 NUMBER,S35 NUMBER,S36 NUMBER,S37 NUMBER,S38 NUMBER,S39 NUMBER,S40 NUMBER,
                    S41 NUMBER,S42 NUMBER,S43 NUMBER,S44 NUMBER,S45 NUMBER,S46 NUMBER,S47 NUMBER,S48 NUMBER,S49 NUMBER,S50 NUMBER,
                    S51 NUMBER,S52 NUMBER,S53 NUMBER,S54 NUMBER,S55 NUMBER,S56 NUMBER,S57 NUMBER,S58 NUMBER,S59 NUMBER,S60 NUMBER
                  )tablespace NETBEN';
            execute immediate sqlStr ;
            sqlStr := 'create index PK_NB_RATE_'||tableName.Suff||'
                      on NB_RATE_1759 (STREAM_ID) tablespace NETBEN';
            execute immediate sqlStr;
      end if;       
    exception when  others then
        v_error_desc := 'Error Code:'|| sqlerrm || '  tableStr:'||tableName.Suff ;
        create_procedure_log('add_rate_table_all',v_error_desc,sqlcode);
  end;
  end loop;
end add_rate_table_all;


/

