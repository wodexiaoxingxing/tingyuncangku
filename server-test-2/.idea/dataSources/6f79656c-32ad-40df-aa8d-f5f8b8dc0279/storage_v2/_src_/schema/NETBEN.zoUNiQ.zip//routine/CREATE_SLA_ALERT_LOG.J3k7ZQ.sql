create PROCEDURE create_sla_alert_log
( 
  task_id IN number,
  t_count IN number,
  avg_cost in number,
  sla_rate IN number,
  rtime in date
, app_flows in number
, wifi_flows in number
, remark in varchar2
)
 authid current_user
 is
    task_name varchar2(1000);
    user_code varchar2(1000);
    user_id number;
    time1 date;
    time2 date:=sysdate;
begin
    select a.name,b.code,b.id into task_name,user_code,user_id from nb_m_task a left join nb_m_user b  on a.owner_id = b.id where a.id = task_id;
    insert into nb_sla_alert_log(task_id,task_name,user_code,count,avg_cost,sla_rate,ctime,rtime,app_flows,wifi_flows,remark) values(task_id,task_name,user_code,t_count,avg_cost,sla_rate,sysdate,rtime,app_flows,wifi_flows,remark);

    --更新任务的mtime
    select mtime into time1 from nb_m_task where id = task_id;
    update nb_m_task set mtime=time2 where id = task_id;
    insert into nb_m_syslog values('nb_m_task#'||task_id,'[UPDATE]mtime, '||to_char(time1,'yyyy-mm-dd hh24:mi:ss')||' -> '||to_char(time2,'yyyy-mm-dd hh24:mi:ss')||';',user_id,'0.0.0.0',sysdate,user_code,3,0,null,null);
    -- 保存日志
    create_sla_procedure_log('update nb_m_task',task_id,avg_cost,sla_rate,'mtime:'||to_char(time1,'yyyy-mm-dd hh24:mi:ss')||' -> '||to_char(time2,'yyyy-mm-dd hh24:mi:ss'),rtime,app_flows,wifi_flows,t_count);
    commit;
    exception
     when others then
     create_sla_procedure_log('procedure:error',task_id,avg_cost,sla_rate,'create_sla_alert_log '||sqlerrm,rtime,app_flows,wifi_flows,t_count);
end create_sla_alert_log;
/

