create PROCEDURE          "TESTINSERT" (id in varchar2,
                                       uc in varchar2,
                                       un in varchar2,
                                       up in varchar2,
                                       vd in date) is
   sqlstr varchar2(4000);
begin
   sqlstr := 'insert into test_user(id,user_code,user_name,user_pwd,validity_date) values (:id,:uc,:un,:up,:vd)';
   execute immediate sqlstr using id,uc,un,up,vd;
end testinsert;


/

