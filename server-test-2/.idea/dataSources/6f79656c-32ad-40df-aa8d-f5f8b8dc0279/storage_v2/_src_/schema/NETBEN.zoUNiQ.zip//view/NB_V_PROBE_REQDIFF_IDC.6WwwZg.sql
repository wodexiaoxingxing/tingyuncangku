create view NB_V_PROBE_REQDIFF_IDC as
select city as city, city_id as city_id, total_REQ as total_req, probe_num as probe_num, probe_num - total_REQ as diff from
(
select t2.city as city, t2.CITY_ID as city_id, ceil(t2.PROBE_REQ + decode(REQ, null, 0, REQ)) as total_REQ, decode(sum(s.probe_num), null, 0, sum(s.probe_num)) as probe_num
from
(select t.city, t.city_id as loc_id, sum(t.PROBE_REQ) as REQ from nb_v_probe_req_idc_custom t
group by t.city, t.city_id) right outer join nb_v_probe_req_idc t2 on loc_id=t2.city_id
left outer join nb_v_probe_stats s on t2.CITY_ID=s.city_id and s.speed_id=8
group by t2.city, t2.CITY_ID, t2.PROBE_REQ + decode(REQ, null, 0, REQ)
order by total_REQ desc
)
order by diff


/

