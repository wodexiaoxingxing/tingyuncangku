create procedure up_bs_ver authid current_user is
begin
    create_procedure_log('up_bs_ver','begin','run');
update nb_m_user_agent_t set os_ver_id = 2  where os_version like '%XP%' and os_ver_id = 0 ;
commit;
update nb_m_user_agent_t set os_ver_id = 3  where os_version like '%2003%' and os_ver_id = 0;
commit;
update nb_m_user_agent_t set os_ver_id = 4  where os_version like '%Vista%' and os_ver_id = 0;
commit;
update nb_m_user_agent_t set os_ver_id = 5  where os_version like '%2008%' and os_ver_id = 0;
commit;
update nb_m_user_agent_t set os_ver_id = 6  where os_version like '% 7%' and os_ver_id = 0;
commit;
update nb_m_user_agent_t set os_ver_id = 7  where os_version like '% 8%' and os_ver_id = 0;
commit;
update nb_m_user_agent_t set os_ver_id = 8  where os_version like '%2012%' and os_ver_id = 0;
commit;
update nb_m_user_agent_t set os_ver_id = 9  where os_version like '%2008 R2%' and os_ver_id = 0;
commit;

update nb_m_user_agent_t set bs_id = 1  where bs_id = 0 and browser_version like '%I%';
commit;
update nb_m_user_agent_t set bs_id = 1 where bs_id = 0 and is_number(substr(browser_version,1,1))>0;
commit;
update nb_m_user_agent_t set bs_id = 2 where bs_id = 0 and browser_version like '%F%';
commit;
update nb_m_user_agent_t set bs_id = 3 where bs_id = 0 and browser_version like '%S%';
commit;
update nb_m_user_agent_t set bs_id = 4 where bs_id = 0 and browser_version like '%A%';
commit;
update nb_m_user_agent_t set bs_id = 11 where bs_id = 0 and browser_version like '%C%';
commit;

--修改IE浏览器小版本
update nb_m_user_agent_t
   set bs_ver_id = case
                     when substr(browser_version, 1, 1) = 'I' then
                      substr(browser_version,
                             2,
                             instr(browser_version, '.', 1, 1) - 2)
                     else
                      substr(browser_version,
                             1,
                             instr(browser_version, '.', 1, 1) - 1)
                   end
 where bs_id = 1 and bs_ver_id = 0;
 commit;
 update nb_m_user_agent_t set bs_ver_id = 0 where bs_ver_id is null;
 commit;
-- 修改firefox小版本
update nb_m_user_agent_t
   set bs_ver_id = case
                     when substr(browser_version, 1, 1) = 'F' then
                      substr(browser_version,
                             2,
                             instr(browser_version, '.', 1, 1) - 2)
                     else
                      substr(browser_version,
                             1,
                             instr(browser_version, '.', 1, 1) - 1)
                   end +100
 where bs_id = 2 and bs_ver_id = 0;
 commit;
 update nb_m_user_agent_t set bs_ver_id = 0 where bs_ver_id is null;
 commit;

   create_procedure_log('up_bs_ver','end','run');
end up_bs_ver;


/

