create procedure UPDATE_PROBE_ONLINE_WEEKLY is
begin
  execute immediate 'truncate table NB_M_PROBE_ONLINE_WEEKLY';
  --首先处理pc相关数据，注：真机wap监测相关数据也在此语句中生成
  insert into NB_M_PROBE_ONLINE_WEEKLY(conn_id,Isp_Id,City_Id,PROBE_NUM) 
  select connId,
         ispId,
         cityId,
         probNum
    from (select decode(p.SPEED_ID, 5, 9, 6, 9, 7, 9, p.speed_id) connId,
                 p.ISP_ID ispId,
                 p.city_id cityId,
                 count(*)/2016 probNum
            from nb_m_proberuntime_log p
           where p.TEMP_DISABLED = 0
             and p.time_stamp > sysdate - 7
             and p.ACL_DISABLED = 0
             and p.os is not null
             and p.bs is not null
           group by decode(p.SPEED_ID, 5, 9, 6, 9, 7, 9, p.speed_id),
                    p.ISP_ID,
                    p.city_id
          having count(*) >= 2);
  commit;
  --然后处理手机监测相关数据
  insert into NB_M_PROBE_ONLINE_WEEKLY(conn_id,Isp_Id,City_Id,PROBE_NUM) 
  select connId,
         ispId,
         cityId,
         probNum
    from (select p.speed_id connId,
                 p.ISP_ID ispId,
                 p.city_id cityId,
                 count(*)/2016 probNum
            from nb_m_proberuntime_log_mobile p
           where p.TEMP_DISABLED = 0
             and p.time_stamp > sysdate - 7
             and p.ACL_DISABLED = 0
           group by p.speed_id,
                    p.ISP_ID,
                    p.city_id
          having count(*) >= 2);
  commit;
end UPDATE_PROBE_ONLINE_WEEKLY;


/

