create PROCEDURE create_el_tables_if_not_exists authid current_user
is
  sqlStr  varchar2(4000);
  tableStr varchar2(1000);
  c int;

    ---------------- 主变量 ---------------------------------------------------------------------------
  createDate date := sysdate;
  orderNum   number;
  rangeDate  varchar2(128);
  partname1  varchar2(128);
  ee_partname1  varchar2(128);
  rangedate1 varchar2(128);
  partname2  varchar2(128);
  ee_partname2  varchar2(128);
  rangedate2 varchar2(128);
  partname3  varchar2(128);
  ee_partname3  varchar2(128);
  rangedate3 varchar2(128);



  v_order number;
  v_range_date date;
  v_partname1 varchar2(128);
  v_rangedate1 varchar2(128);
  v_partname2 varchar2(128);
  v_rangedate2 varchar2(128);
  v_partname3 varchar2(128);
  v_rangedate3 varchar2(128);

  --------------- 临时变量----------------------------------------------------------------------------
  s number;
begin
  --若存在表 NB_EC_xxx 且 不存在表 NB_EE_xxx，则自动创建表NB_EE_xxx, NB_EE_xxx, NB_E_URL_xxx等表（由于之前NETBEN_BG不存在导致后续的表没创建成功）
for item in (select substr(t.table_name, 11) as name from user_tables t where t.table_name like 'NB_EC_%' ) loop
    begin
    select count(*) into c  from  user_tables t where t.table_name='NB_EE_'||item.name;
    if (c=0) then
      tableStr :=item.name;
  --首先计算出elem的分区名称及值范围
    select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 8 - to_char( createDate,'d'),'d') from dual);
        partname1:='PART_EC_'||tableStr||'_'||orderNum;
        ee_partname1:='PART_EE_'||tableStr||'_'||orderNum;
        rangedate1:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';
         DBMS_OUTPUT.PUT_LINE(rangedate1);
    select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 15 - to_char( createDate,'d'),'d') from dual);
        partname2:='PART_EC_'||tableStr||'_'||orderNum;
        ee_partname2:='PART_EE_'||tableStr||'_'||orderNum;
        rangedate2:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';
    select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 22 - to_char( createDate,'d'),'d') from dual);
        partname3:='PART_EC_'||tableStr||'_'||orderNum;
        ee_partname3:='PART_EE_'||tableStr||'_'||orderNum;
        rangedate3:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';

        sqlStr:='create table NB_EE_'||tableStr||'
    (
      URL_ID           NUMBER,
      PAGE_ID          NUMBER,
      PAGE_SEQ       INTEGER,
      TASK_ID          NUMBER,
      CITY_ID          NUMBER,
      ISP_ID           NUMBER,
      NET_SPEED_ID     NUMBER,
      TM_BASE          DATE,
      DOMAIN_ID        NUMBER,
      ELEM_TYPE_ID     NUMBER,
    OS_VER_ID   INTEGER,
    BS_ID      INTEGER,
    BS_VER_ID    INTEGER,
      PROBE_IP         NUMBER,
      MEMBER_ID        INTEGER,
      ELEMENT_SEQ      NUMBER,
      RECORD_TYPE      CHAR(1),
      ERROR_CODE       NUMBER,
      REDIRECT_TOTAL   NUMBER,
      URL_IP           NUMBER,
      BYTE_TOTAL       NUMBER,
      TS_START_OFFSET  NUMBER,
      TS_DNS           NUMBER,
      TS_CONNECT       NUMBER,
      TS_SSL           NUMBER,
      TS_REDIRECT      NUMBER,
      TS_REQUEST       NUMBER,
      TS_FIRST_PACKET  NUMBER,
      TS_REMAIN_PACKET NUMBER,
      TS_ELEMENT       NUMBER,
      TS_CLOSE         NUMBER,
      TS_BLOCK         NUMBER,
      BYTE_SENT        NUMBER,
      RATE_DOWNLOAD     NUMBER,
      RATE_UPLOAD     NUMBER,
      POINT_TOTAL     NUMBER
    ) pctfree 0
    tablespace NETBEN_BG
    partition by range (TM_BASE)(
                  partition '||ee_partname1||' values less than ('||rangedate1||'),
                  partition '||ee_partname2||' values less than ('||rangedate2||'),
                  partition '||ee_partname3||' values less than ('||rangedate3||'))';
    execute   immediate   sqlStr;

    --元素索引 tm_base,url_id,error_code
    sqlStr:='create index IDX_EE_UID_'||tableStr||' on NB_EE_'||tableStr||' (URL_ID,TM_BASE,ERROR_CODE) local
            (partition '||ee_partname1||',partition '||ee_partname2||',partition '||ee_partname3||') compress 1
            tableSpace  NETBEN_IND nologging';
    execute   immediate   sqlStr;
    --域名索引 tm_base,domain_id,error_code
    sqlStr:='create index IDX_EE_DID_'||tableStr||' on NB_EE_'||tableStr||' (DOMAIN_ID,TM_BASE,ERROR_CODE) local
            (partition '||ee_partname1||',partition '||ee_partname2||',partition '||ee_partname3||') compress 2
            tableSpace  NETBEN_IND';
    execute   immediate   sqlStr;
    --类型索引 tm_base,type_id,error_code
    sqlStr:='create index IDX_EE_TID_'||tableStr||' on NB_EE_'||tableStr||' (ELEM_TYPE_ID,TM_BASE,ERROR_CODE) local
            (partition '||ee_partname1||',partition '||ee_partname2||',partition '||ee_partname3||') compress 2
            tableSpace  NETBEN_IND';
    execute   immediate   sqlStr;

  sqlStr:='create table NB_E_URL_'||tableStr||'
  (
    ID    INTEGER,
    URL    VARCHAR2(4000)
  ) pctfree 0
  ';
  execute   immediate   sqlStr;

  -- primary key
    sqlStr:='alter table NB_E_URL_'||tableStr||'
      add constraint PK_NB_E_URL_'||tableStr||' primary key (ID)
      using index
      tablespace NETBEN';
    execute   immediate   sqlStr;

  sqlStr:='create table NB_ET_URL_'||tableStr||'
  (
    ID      INTEGER,
    TASK_ID    INTEGER,
    DOMAIN_ID  INTEGER,
    ELEM_TYPE_ID  INTEGER,
    MTIME    INTEGER,
    POINT    INTEGER
  )
  ';
  execute   immediate   sqlStr;

  sqlStr:='create index IN_ET_URL_TID_'||tableStr||' on NB_ET_URL_'||tableStr||' (TASK_ID) tablespace NETBEN_IND';
    execute   immediate   sqlStr;


   -- 创建NB_ELEM_XXX表（用于向下兼容，一旦新元素架构发生性能问题，可以快速在线回滚）
    --首先计算出elem的分区名称及值范围
     select order_num,sunday into v_order,v_range_date from nb_part_calendar t
        where t.sunday = (select trunc(sysdate + 8 - to_char( sysdate,'d'),'d') from dual);
        v_partname1:='PART_EL_URL_'||tableStr||'_'||v_order;
        v_rangedate1:='to_date('||chr(39)||to_char(v_range_date,'yyyy-mm-dd')||chr(39)||','||chr(39)||'yyyy-mm-dd'||chr(39)||')';
   select order_num,sunday into v_order,v_range_date from nb_part_calendar t
        where t.sunday = (select trunc(sysdate + 15 - to_char( sysdate,'d'),'d') from dual);
        v_partname2:='PART_EL_URL_'||tableStr||'_'||v_order;
        v_rangedate2:='to_date('||chr(39)||to_char(v_range_date,'yyyy-mm-dd')||chr(39)||','||chr(39)||'yyyy-mm-dd'||chr(39)||')';
   select order_num,sunday into v_order,v_range_date from nb_part_calendar t
        where t.sunday = (select trunc(sysdate + 22 - to_char( sysdate,'d'),'d') from dual);
        v_partname3:='PART_EL_URL_'||tableStr||'_'||v_order;
        v_rangedate3:='to_date('||chr(39)||to_char(v_range_date,'yyyy-mm-dd')||chr(39)||','||chr(39)||'yyyy-mm-dd'||chr(39)||')';
    sqlStr:='create table NB_EL_URL_'||tableStr||'
    (
      ID      NUMBER,
      URL     VARCHAR2(4000),
      CTIME    DATE
    ) pctfree 0
    partition by range (CTIME)(
                  partition '||v_partname1||' values less than ('||v_rangedate1||'),
                  partition '||v_partname2||' values less than ('||v_rangedate2||'),
                  partition '||v_partname3||' values less than ('||v_rangedate3||'))';
    execute   immediate   sqlStr;

    --索引
    sqlStr:='create index IDX_NB_EL_URL_'||tableStr||' on NB_EL_URL_'||tableStr||' (ID) local
            (partition '||v_partname1||',partition '||v_partname2||',partition '||v_partname3||')
            tableSpace  NETBEN_IND';
    execute   immediate   sqlStr;


  -- 创建NB_ELEM_XXX表（用于向下兼容，一旦新元素架构发生性能问题，可以快速在线回滚）
    --首先计算出elem的分区名称及值范围
     select order_num,sunday into v_order,v_range_date from nb_part_calendar t
        where t.sunday = (select trunc(sysdate + 8 - to_char( sysdate,'d'),'d') from dual);
        v_partname1:='PART_ELT_URL_'||tableStr||'_'||v_order;
        v_rangedate1:='to_date('||chr(39)||to_char(v_range_date,'yyyy-mm-dd')||chr(39)||','||chr(39)||'yyyy-mm-dd'||chr(39)||')';
   select order_num,sunday into v_order,v_range_date from nb_part_calendar t
        where t.sunday = (select trunc(sysdate + 15 - to_char( sysdate,'d'),'d') from dual);
        v_partname2:='PART_ELT_URL_'||tableStr||'_'||v_order;
        v_rangedate2:='to_date('||chr(39)||to_char(v_range_date,'yyyy-mm-dd')||chr(39)||','||chr(39)||'yyyy-mm-dd'||chr(39)||')';
   select order_num,sunday into v_order,v_range_date from nb_part_calendar t
        where t.sunday = (select trunc(sysdate + 22 - to_char( sysdate,'d'),'d') from dual);
        v_partname3:='PART_ELT_URL_'||tableStr||'_'||v_order;
        v_rangedate3:='to_date('||chr(39)||to_char(v_range_date,'yyyy-mm-dd')||chr(39)||','||chr(39)||'yyyy-mm-dd'||chr(39)||')';
    sqlStr:='create table NB_ELT_URL_'||tableStr||'
    (
      TASK_ID NUMBER,
      ID      NUMBER,
      ELEM_TYPE_ID  NUMBER,
      CTIME    DATE
    ) pctfree 0
    partition by range (CTIME)(
                  partition '||v_partname1||' values less than ('||v_rangedate1||'),
                  partition '||v_partname2||' values less than ('||v_rangedate2||'),
                  partition '||v_partname3||' values less than ('||v_rangedate3||'))';
    execute   immediate   sqlStr;

    --索引
    sqlStr:='create index IDX_NB_ELT_URL_'||tableStr||' on NB_ELT_URL_'||tableStr||' (TASK_ID,ID) local
            (partition '||v_partname1||',partition '||v_partname2||',partition '||v_partname3||')
            tableSpace  NETBEN_IND';
    execute   immediate   sqlStr;

    end if;
 end;
 end loop;
 end create_el_tables_if_not_exists;


/

