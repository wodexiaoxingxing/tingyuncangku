create PROCEDURE          "ALTER_STREAM_ADD_FIELD_L" 
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(400);
  v_s number;
begin
  for tableName in(select t.table_name as name from user_tables t where t.table_name like 'NB_STREAM_%') loop
  begin
      --删除指定的字段
      /*select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TS_CONNECT_STREAM';
      if v_s = 1 then
        sqlStr := 'alter table '||tableName.Name||' DROP column TS_CONNECT_STREAM';
        execute   immediate   sqlStr ;
      end if;

      */


      select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='VERSION_ID';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add VERSION_ID number';
     execute   immediate   sqlStr ;
 dbms_output.put_line(sqlStr);
      end if;

    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='OS_VER_ID';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add OS_VER_ID number';
    execute   immediate   sqlStr ;
 dbms_output.put_line(sqlStr);
      end if;

    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='BS_ID';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add BS_ID number';
        execute   immediate   sqlStr ;
 dbms_output.put_line(sqlStr);
      end if;

    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='BS_VER_ID';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add BS_VER_ID number';
        execute   immediate   sqlStr ;
 dbms_output.put_line(sqlStr);
      end if;

    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='FLASH_VER';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add FLASH_VER varchar2(64)';
        execute   immediate   sqlStr ;
 dbms_output.put_line(sqlStr);
      end if;


    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlStr);
        create_procedure_log('alter_stream_add_field',v_error_desc,sqlcode);
  end;
  end loop;

end alter_stream_add_field_L;


/

