create view NB_V_PROBE_STATS as
select t.city_id as CITY_ID,
       t.isp_id AS ISP_ID,
       t.speed_id as SPEED_ID,
       count(*) as PROBE_NUM
  from nb_m_proberuntime_log t
 where (t.city_id not like '48%' or t.dns_valid = 1)
   and t.city_id = t.city_id_ipdb
   and t.isp_id = t.isp_id_ipdb
   and t.temp_disabled = 0
   and t.acl_disabled = 0
   and t.speed_id <> 9
   and time_stamp =
       (select /** INDEX_FFS( t IDX_PROBRUNTIME_LOG_time) */
         max(time_stamp)
          from nb_m_proberuntime_log t
         where t.time_stamp > sysdate - 1
           and t.time_stamp <
               (select max(time_stamp) from nb_m_proberuntime_log))
 group by city_id, isp_id, speed_id
 union all
 select tm.city_id as CITY_ID,
       tm.isp_id AS ISP_ID,
       tm.speed_id as SPEED_ID,
       count(*) as PROBE_NUM
  from nb_m_proberuntime_log_mobile tm
 where  tm.time_stamp =
       (select
         max(time_stamp)
          from nb_m_proberuntime_log_mobile
         where time_stamp > sysdate - 1
           and time_stamp <
               (select max(time_stamp) from nb_m_proberuntime_log_mobile))
 group by city_id, isp_id, speed_id


/

