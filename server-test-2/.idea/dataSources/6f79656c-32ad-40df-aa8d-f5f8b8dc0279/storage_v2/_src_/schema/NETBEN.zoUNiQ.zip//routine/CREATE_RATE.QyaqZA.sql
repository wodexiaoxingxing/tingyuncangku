create PROCEDURE create_rate authid current_user
is
  sqlStr  varchar2(4000);
  tableStr varchar2(1000);
  c int;
begin
  --若存在表 NB_STREAM_xxx 且 不存在表 NB_RATE_xxx，则自动创建表NB_RATE_xxx
for item in (select substr(t.table_name, 11) as name from user_tables t where t.table_name like 'NB_STREAM_%' and rownum<6) loop
    begin
       dbms_output.put_line(item.name);
    select count(*) into c  from  user_tables t where t.table_name='NB_RATE_'||item.name;
    if (c=0) then
      tableStr :=item.name;
  sqlStr:='create table NB_RATE_'||tableStr||'
  (
    STREAM_ID NUMBER not null,
    S1 NUMBER,
  S2 NUMBER,
  S3 NUMBER,
  S4 NUMBER,
  S5 NUMBER,
  S6 NUMBER,
  S7 NUMBER,
  S8 NUMBER,
  S9 NUMBER,
  S10 NUMBER,
  S11 NUMBER,
  S12 NUMBER,
  S13 NUMBER,
  S14 NUMBER,
  S15 NUMBER,
  S16 NUMBER,
  S17 NUMBER,
  S18 NUMBER,
  S19 NUMBER,
  S20 NUMBER,
  S21 NUMBER,
  S22 NUMBER,
  S23 NUMBER,
  S24 NUMBER,
  S25 NUMBER,
  S26 NUMBER,
  S27 NUMBER,
  S28 NUMBER,
  S29 NUMBER,
  S30 NUMBER,
  S31 NUMBER,
  S32 NUMBER,
  S33 NUMBER,
  S34 NUMBER,
  S35 NUMBER,
  S36 NUMBER,
  S37 NUMBER,
  S38 NUMBER,
  S39 NUMBER,
  S40 NUMBER,
  S41 NUMBER,
  S42 NUMBER,
  S43 NUMBER,
  S44 NUMBER,
  S45 NUMBER,
  S46 NUMBER,
  S47 NUMBER,
  S48 NUMBER,
  S49 NUMBER,
  S50 NUMBER,
  S51 NUMBER,
  S52 NUMBER,
  S53 NUMBER,
  S54 NUMBER,
  S55 NUMBER,
  S56 NUMBER,
  S57 NUMBER,
  S58 NUMBER,
  S59 NUMBER,
  S60 NUMBER
  ) pctfree 0
  tablespace NETBEN';
  dbms_output.put_line(sqlStr);
 --  execute immediate sqlStr;
  sqlStr:='create index PK_NB_RATE_'||tableStr||' on NB_RATE_'||tableStr||' (STREAM_ID) tablespace NETBEN_IND';
 dbms_output.put_line(sqlStr);
 --   execute immediate sqlStr;
 end if;
 end;
 end loop;
 end create_rate;


/

