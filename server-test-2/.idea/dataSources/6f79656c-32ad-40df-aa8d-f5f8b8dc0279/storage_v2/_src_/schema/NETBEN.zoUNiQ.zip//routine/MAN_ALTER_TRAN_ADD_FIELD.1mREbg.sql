create PROCEDURE "MAN_ALTER_TRAN_ADD_FIELD"
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(400);
  v_s number;
begin
  for tableName in(select t.table_name as name from user_tables t where t.table_name like 'NB_TRAN_%' ) loop
  begin

    --删除主键
/* 
   select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='ID';
    if v_s = 1 then
       sqlStr:= 'alter table '||tableName.Name||' drop column ID';
       execute immediate sqlStr;
    end if;
    --删除tm_day2
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TM_DAY2';
    if v_s = 1 then
       sqlStr:= 'alter table '||tableName.Name||' drop column TM_DAY2';
       execute immediate sqlStr;
    end if;
    --删除tm_day4
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TM_DAY4';
    if v_s = 1 then
       sqlStr:= 'alter table '||tableName.Name||' drop column TM_DAY4';
       execute immediate sqlStr;
    end if;
    --删除tm_day8
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TM_DAY8';
    if v_s = 1 then
       sqlStr:= 'alter table '||tableName.Name||' drop column TM_DAY8';
       execute immediate sqlStr;
    end if;
    --删除tm_day16
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TM_DAY16';
    if v_s = 1 then
       sqlStr:= 'alter table '||tableName.Name||' drop column TM_DAY16';
       execute immediate sqlStr;
    end if;
*/
     select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='SRC_PATH';
      if v_s > 0 then
        sqlStr := 'alter table '||tableName.Name||' drop column  SRC_PATH  ';
      execute   immediate   sqlStr ;
  --dbms_output.put_line(sqlStr);
      end if;
 
     select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='DNS_SERVER_IP';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add DNS_SERVER_IP number';
      execute   immediate   sqlStr ;
 --dbms_output.put_line(sqlStr);
      end if;

     select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='CPU_TREND_RESULT';
      if v_s > 0 then
        sqlStr := 'alter table '||tableName.Name||' drop column cpu_trend_result';
      execute   immediate   sqlStr ;
  --dbms_output.put_line(sqlStr);
      end if;
 
     select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='MEM_TREND_RESULT';
      if v_s > 0 then
        sqlStr := 'alter table '||tableName.Name||' drop column MEM_TREND_RESULT  ';
      execute   immediate   sqlStr ;
 --dbms_output.put_line(sqlStr);
      end if;
     select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='BITRATE_TREND_RESULT';
      if v_s > 0 then
        sqlStr := 'alter table '||tableName.Name||' drop column BITRATE_TREND_RESULT  ';
      execute   immediate   sqlStr ;
  --dbms_output.put_line(sqlStr);
      end if;
 
     select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='SCRIPT_EXEC_SEGMENTS_RESULT';
      if v_s > 0 then
        sqlStr := 'alter table '||tableName.Name||' drop column SCRIPT_EXEC_SEGMENTS_RESULT   ';
      execute   immediate   sqlStr ;
 --dbms_output.put_line(sqlStr);
      end if;
     select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TS_SCRIPT_TOTAL';
      if v_s > 0 then
        sqlStr := 'alter table '||tableName.Name||' drop column TS_SCRIPT_TOTAL   ';
      execute   immediate   sqlStr ;
  --dbms_output.put_line(sqlStr);
      end if;
 
     select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TS_DNS_PROJ';
      if v_s > 0 then
        sqlStr := 'alter table '||tableName.Name||' drop column TS_DNS_PROJ   ';
      execute   immediate   sqlStr ;
 --dbms_output.put_line(sqlStr);
      end if;

     select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TS_CONNECT_PROJ';
      if v_s > 0 then
        sqlStr := 'alter table '||tableName.Name||' drop column TS_CONNECT_PROJ   ';
      execute   immediate   sqlStr ;
 --dbms_output.put_line(sqlStr);
      end if;
     select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TS_FIRST_PACKET_PROJ';
      if v_s > 0 then
        sqlStr := 'alter table '||tableName.Name||' drop column TS_FIRST_PACKET_PROJ   ';
      execute   immediate   sqlStr ;
 --dbms_output.put_line(sqlStr);
      end if;
      
      
    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
         dbms_output.PUT_LINE(sqlStr);
        create_procedure_log('alter_lt_tran_add_field',v_error_desc,sqlcode);
  end;
  end loop;
end MAN_alter_tran_add_field;


/

