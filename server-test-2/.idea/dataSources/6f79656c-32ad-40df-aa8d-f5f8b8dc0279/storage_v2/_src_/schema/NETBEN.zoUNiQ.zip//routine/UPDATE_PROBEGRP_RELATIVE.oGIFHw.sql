create PROCEDURE          "UPDATE_PROBEGRP_RELATIVE" authid current_user is
  sqlStr varchar2(4000);

begin
  sqlStr:='truncate table nb_m_conn_isp';
  execute immediate sqlStr;
  sqlStr:='truncate table nb_m_connisp_city';
  execute immediate sqlStr;
  --Idc
  sqlStr := 'insert into nb_m_conn_isp value 
               select seq_nb_ops_probegrp.nextval, speed_id, isp_id, ''''
               from (select distinct speed_id, isp_id
                     from nb_m_probe_stats
                     where speed_id = 8 and probe_num > 0.7)';
   execute immediate sqlStr;
   commit;

   sqlStr := 'insert into nb_m_connisp_city value
                select distinct  ci.id,city.city_id
                from (select city_id, speed_id || ''_'' || isp_id as si
                      from nb_m_probe_stats
                      where speed_id || ''_'' || isp_id in
                          (select distinct speed_id || ''_'' || isp_id
                           from nb_m_probe_stats
                           where speed_id = 8 and probe_num > 0.7)) city,
                     (select id, conn_id || ''_'' || isp_id as ci from nb_m_conn_isp) ci
              where city.si = ci.ci';
   execute immediate sqlStr;
   commit;


--LastMails
   sqlStr := 'insert into nb_m_conn_isp value
                select seq_nb_ops_probegrp.nextval, speed_id, isp_id, ''''
                from (select distinct speed_id, isp_id
                      from nb_m_probe_stats
                      where speed_id <> 8 and probe_num > 1)';
   execute immediate sqlStr;
   commit;    

   sqlStr :='insert into nb_m_connisp_city value
               select conn_isp.id, stats.city_id
                 from nb_m_conn_isp conn_isp, nb_m_probe_stats stats
                where conn_isp.conn_id = stats.speed_id
                 and conn_isp.isp_id = stats.isp_id
                 and stats.speed_id <> 8
                group by conn_isp.id, stats.city_id
                 having sum(stats.probe_num) > 1.7
                order by conn_isp.id, stats.city_id';
   execute immediate sqlStr;
   commit;
end update_probegrp_relative;


/

