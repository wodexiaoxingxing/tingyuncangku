create procedure procdefault2(
  p1 varchar2 default 'remark',
  p2 varchar2
) as
begin
  dbms_output.put_line(p1);
end;

 exec procdefault2(p2 =>'aa');
/

