create PROCEDURE          "CREATETRACEROUTETABLETEST" (
tableStr IN varchar2
) authid current_user
is
sqlStr varchar2(4000);
begin
	sqlStr := 'create table TEST_UTG_TRACE_' || tableStr || '(id integer) tablespace NETBEN';
	execute immediate sqlStr;
end createTracerouteTableTest;


/

