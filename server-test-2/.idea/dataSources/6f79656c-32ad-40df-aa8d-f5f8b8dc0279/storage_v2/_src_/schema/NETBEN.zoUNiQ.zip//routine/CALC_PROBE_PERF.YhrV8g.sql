create procedure calc_probe_perf is
  sqlStr   varchar2(8000);
  v_s number;
begin
  create_procedure_log('calc_probe_perf','begin','run');
  -- 1 生成临时数据
  select count(*)  INTO v_s FROM user_tables t where t.table_name = 'TMP_T_TS_CONNECT';
    if v_s > 0 then
      sqlStr:='drop table tmp_t_ts_connect';
      execute immediate sqlStr;
    end if;
    sqlStr:='
        create table tmp_t_ts_connect as
            select p.task_id
              from (select task_id, round(avg(ts_connect), 0) ts_connect
                      from nb_m_ddc_log_col l
                      left join nb_m_task t
                        on l.task_id = t.id
                     where l.tm_base >= trunc(sysdate-1)
                       and l.tm_base < trunc(sysdate)
                       and l.error_code <> 612029
                       and l.ts_connect > 0
                       and t.type in (1, 2)
                       and l.status = 0
                       and l.is_noise in (0, 7, 8)
                     group by l.task_id) p
             where p.ts_connect > 1000';
    execute immediate sqlStr ;
    commit;
    create_procedure_log('calc_probe_perf','1.1 生成临时数据完成','run');

    sqlStr:='truncate table nb_m_probe_perf_blacklist_tmp';
    execute immediate sqlStr ;

    sqlStr:='insert into nb_m_probe_perf_blacklist_tmp
          select p.host_id,''TS_CONNECT'' as perf_type
            from (
              select l.host_id, round(avg(ts_connect), 0) ts_connect
                from nb_m_ddc_log_col l
                left join nb_m_task t
                  on l.task_id = t.id
               where l.tm_base >= trunc(sysdate-1)
                 and l.tm_base < trunc(sysdate)
                 and t.type in (1, 2) and t.status = 1 and t.expire > sysdate -1
                 and l.error_code <> 612029
                 and l.ts_connect >0
                 and l.status = 0
                 and l.is_noise in (0,7,8)
                 and l.host_id <10000000
                 and t.id not in (select task_id from tmp_t_ts_connect)
                 group by l.host_id) p
             where p.ts_connect >1000';
    execute immediate sqlStr ;
    commit;
    create_procedure_log('calc_probe_perf','1.2 生成临时数据完成','run');
    -- 2 更新主机与性能 正式库
    select count(*) into v_s from nb_m_probe_perf_blacklist_tmp;
    --network_sendmail('mservice@tingyun.com','probe_perf','perf ts_connect count '||v_s);
    if (v_s < 1500) then
      sqlStr:='merge into nb_m_probe_perf_blacklist a using (select *
                  from nb_m_probe_perf_blacklist_tmp
                 where host_id not in (select ph.id
                                         from nb_m_probe_host ph, nb_m_member m
                                        where ph.member_id = m.id
                                          and m.mbr_type = 4))  b
                 on (a.host_id=b.host_id and a.perf_type = b.perf_type)
               when matched then update set a.mtime = sysdate
               when not matched then insert values(b.host_id,b.perf_type,sysdate,sysdate)';
      execute immediate sqlStr;
      commit;
    else
      create_procedure_log('calc_probe_perf','2 超出了1500个节点','error');
      return;
    end if;
    create_procedure_log('calc_probe_perf','2 更新主机与错误代码正式库完成','run');

    --3 删除超出10天的数据
    sqlStr:='delete from nb_m_probe_perf_blacklist where mtime < trunc(sysdate -10)';
    execute immediate sqlStr;
    commit;
    create_procedure_log('calc_probe_perf','3 删除超出10天的数据完成','run');

    --4 将生成的临时数据记日志
    sqlStr:='insert into nb_m_probe_perf_blacklist_log select host_id,perf_type,sysdate from nb_m_probe_perf_blacklist_tmp';
    execute immediate sqlStr;
    commit;
   --结束

 create_procedure_log('calc_probe_perf','end','run');
 exception when  others then
   create_procedure_log('calc_probe_perf',sqlerrm,'error');
end calc_probe_perf;

/

