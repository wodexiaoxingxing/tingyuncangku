create PROCEDURE create_procedure_log
( procName IN varchar2,
  descr IN varchar2,
  errorCode IN varchar2
)
 authid current_user
 is
   sqlStr varchar2(4000);
begin
   sqlStr:='insert into nb_procedure_log values(SEQ_PROCEDURE_LOG.Nextval,
                '''||procName||''','''||descr||''','''||errorCode||''',sysdate)';
    execute   immediate  sqlStr;
    commit;
end create_procedure_log;


/

