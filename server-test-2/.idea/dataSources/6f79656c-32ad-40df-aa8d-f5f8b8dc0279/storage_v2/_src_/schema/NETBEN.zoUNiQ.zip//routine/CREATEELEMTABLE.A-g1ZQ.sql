create procedure createElemTable(taskId in number) authid current_user is
  sqlStr        varchar2(8000);
  errorDesc     varchar2(4000);
  ---------------- 主变量 ---------------------------------------------------------------------------
  createDate    date := sysdate;
  orderNum      number;
  rangeDate     varchar2(128);
  partname1     varchar2(128);
  etd_partname1 varchar2(128);
  ett_partname1 varchar2(128);
  rangedate1    varchar2(128);
  partname2     varchar2(128);
  etd_partname2 varchar2(128);
  ett_partname2 varchar2(128);
  rangedate2    varchar2(128);
  partname3     varchar2(128);
  etd_partname3 varchar2(128);
  ett_partname3 varchar2(128);
  rangedate3    varchar2(128);
  --------------- 临时变量----------------------------------------------------------------------------
  s             number;

begin

  create_procedure_log('createElemTable', 'create table:nb_et_' || taskId, 'run');

  -- 判断是否该任务ID合法
  select count(*) into s from nb_m_task where id = taskId;
  if s = 0 then
    create_procedure_log('createElemTable', 'task:' || taskId || '不存在', 'warning');
    return;
  end if;

  -- 判断是否指定表已经建立
  select count(*) into s from user_tables where table_name = 'NB_ET_' || taskId;
  if s > 0 then
    create_procedure_log('createElemTable', 'table:nb_et_' || taskId || '已经存在', 'warning');
    return;
  end if;

  -- 创建element
  -- 首先计算出elem的分区名称及值范围
  select order_num, to_char(sunday, 'yyyy-mm-dd')
    into orderNum, rangeDate
    from nb_part_calendar t
   where t.sunday = (select trunc(createDate + 8 - to_char(createDate, 'd'), 'd') from dual);

  partname1     := 'PART_ET_' || taskId || '_' || orderNum;
  etd_partname1 := 'PART_ETD_' || taskId || '_' || orderNum;
  ett_partname1 := 'PART_ETT_' || taskId || '_' || orderNum;
  rangedate1    := 'to_date(''' || rangeDate || ''',''yyyy-mm-dd'')';

  select order_num, to_char(sunday, 'yyyy-mm-dd')
    into orderNum, rangeDate
    from nb_part_calendar t
   where t.sunday = (select trunc(createDate + 15 - to_char(createDate, 'd'), 'd') from dual);

  partname2     := 'PART_ET_' || taskId || '_' || orderNum;
  etd_partname2 := 'PART_ETD_' || taskId || '_' || orderNum;
  ett_partname2 := 'PART_ETT_' || taskId || '_' || orderNum;
  rangedate2    := 'to_date(''' || rangeDate || ''',''yyyy-mm-dd'')';

  select order_num, to_char(sunday, 'yyyy-mm-dd')
    into orderNum, rangeDate
    from nb_part_calendar t
   where t.sunday = (select trunc(createDate + 22 - to_char(createDate, 'd'), 'd') from dual);

  partname3     := 'PART_ET_' || taskId || '_' || orderNum;
  etd_partname3 := 'PART_ETD_' || taskId || '_' || orderNum;
  ett_partname3 := 'PART_ETT_' || taskId || '_' || orderNum;
  rangedate3    := 'to_date(''' || rangeDate || ''',''yyyy-mm-dd'')';

  sqlStr := 'create table NB_ET_' || taskId || '
  (
  URL_ID                   NUMBER,
  PAGE_ID                  NUMBER,
  PAGE_SEQ                 INTEGER,
  TASK_ID                  NUMBER,
  CITY_ID                  NUMBER,
  ISP_ID                   NUMBER,
  NET_SPEED_ID             NUMBER,
  TM_BASE                  DATE,
  DOMAIN_ID                NUMBER,
  ELEM_TYPE_ID             NUMBER,
  OS_VER_ID                INTEGER,
  BS_ID                    INTEGER,
  BS_VER_ID                INTEGER,
  PROBE_IP                 NUMBER,
  MEMBER_ID                INTEGER,
  ELEMENT_SEQ              NUMBER,
  RECORD_TYPE              CHAR(1),
  ERROR_CODE               NUMBER,
  REDIRECT_TOTAL           NUMBER,
  URL_IP                   NUMBER,
  BYTE_TOTAL               NUMBER,
  TS_START_OFFSET          NUMBER,
  TS_DNS                   NUMBER,
  TS_CONNECT               NUMBER,
  TS_SSL                   NUMBER,
  TS_REDIRECT              NUMBER,
  TS_REQUEST               NUMBER,
  TS_FIRST_PACKET          NUMBER,
  TS_REMAIN_PACKET         NUMBER,
  TS_ELEMENT               NUMBER,
  TS_CLOSE                 NUMBER,
  TS_BLOCK                 NUMBER,
  BYTE_SENT                NUMBER,
  RATE_DOWNLOAD            NUMBER,
  RATE_UPLOAD              NUMBER,
  FIRST_SCREEN             NUMBER,
  LAZY_LOAD                INTEGER,
  CDN_ID                   INTEGER,
  POINT_TOTAL              NUMBER,
  QUEUE_TIME               NUMBER,
  APPLICATION_SERVER_TIME  NUMBER，
  QUIC_VERSION             VARCHAR2(10),
  PROTOCOL_VERSION         VARCHAR2(10),
  NUM_QUIC_HANDSHAKE       NUMBER,
  TS_QUIC_FIRST_100        NUMBER,
  QUIC_PACKET_LOST         NUMBER,
  QUIC_CONNECTION_ID       VARCHAR2(30),
  DEST_IP_VERSION INTEGER
  ) pctfree 0
    partition by range (TM_BASE)(
                  partition ' || partname1 || ' values less than (' || rangedate1 || '),
                  partition ' || partname2 || ' values less than (' || rangedate2 || '),
                  partition ' || partname3 || ' values less than (' || rangedate3 || '))
              tablespace NETBEN_NEW';
  execute immediate sqlStr;

  -- 页面索引 page_id
  sqlStr := 'create index IDX_ET_PID_' || taskId || ' on NB_ET_' || taskId || ' (PAGE_ID) local tableSpace  NETBEN_IND nologging';
  execute immediate sqlStr;

  -- 元素索引 tm_base,url_id
  sqlStr := 'create index IDX_ET_UID_' || taskId || ' on NB_ET_' || taskId || ' (TM_BASE,URL_ID) local compress 2 tableSpace  NETBEN_IND nologging';
  execute immediate sqlStr;

  --创建域名表
  sqlStr := 'create table NB_ETD_' || taskId || '
    (
      PAGE_ID          NUMBER,
      TASK_ID          NUMBER,
      CITY_ID          NUMBER,
      ISP_ID           NUMBER,
      NET_SPEED_ID     NUMBER,
      TM_BASE          DATE,
      DOMAIN_ID        NUMBER,
      OS_VER_ID        INTEGER,
      BS_ID            INTEGER,
      BS_VER_ID        INTEGER,
      PROBE_IP         NUMBER,
      MEMBER_ID        INTEGER,
      URL_IP           NUMBER,
      BYTE_TOTAL       NUMBER,
      TS_DNS           NUMBER,
      TS_CONNECT       NUMBER,
      TS_SSL           NUMBER,
      TS_REDIRECT      NUMBER,
      TS_REQUEST       NUMBER,
      TS_FIRST_PACKET  NUMBER,
      TS_REMAIN_PACKET NUMBER,
      TS_ELEMENT       NUMBER,
      TS_CLOSE         NUMBER,
      TS_BLOCK         NUMBER,
      BYTE_SENT        NUMBER,
      RATE_DOWNLOAD    NUMBER,
      RATE_UPLOAD      NUMBER,
      POINT_TOTAL      NUMBER,
      POINT_SUCC       NUMBER,
      POINT_DNS        NUMBER,
      POINT_CONN       NUMBER,
      POINT_SSL        NUMBER
    ) pctfree 0
    partition by range (TM_BASE)(
                  partition ' || etd_partname1 || ' values less than (' || rangedate1 || '),
                  partition ' || etd_partname2 || ' values less than (' || rangedate2 || '),
                  partition ' || etd_partname3 || ' values less than (' || rangedate3 || '))
              tablespace NETBEN_NEW';
  execute immediate sqlStr;

  -- 域名索引 tm_base,domain_id
  sqlStr := 'create index IDX_ETD_DID_' || taskId || ' on NB_ETD_' || taskId || ' (TM_BASE,DOMAIN_ID) local compress 2 tableSpace  NETBEN_IND nologging';
  execute immediate sqlStr;

  -- 创建元素类型表
  sqlStr := 'create table NB_ETT_' || taskId || '
    (
      PAGE_ID          NUMBER,
      TASK_ID          NUMBER,
      CITY_ID          NUMBER,
      ISP_ID           NUMBER,
      NET_SPEED_ID     NUMBER,
      TM_BASE          DATE,
      ELEM_TYPE_ID     NUMBER,
      OS_VER_ID        INTEGER,
      BS_ID            INTEGER,
      BS_VER_ID        INTEGER,
      PROBE_IP         NUMBER,
      MEMBER_ID        INTEGER,
      BYTE_TOTAL       NUMBER,
      TS_DNS           NUMBER,
      TS_CONNECT       NUMBER,
      TS_SSL           NUMBER,
      TS_REDIRECT      NUMBER,
      TS_REQUEST       NUMBER,
      TS_FIRST_PACKET  NUMBER,
      TS_REMAIN_PACKET NUMBER,
      TS_ELEMENT       NUMBER,
      TS_CLOSE         NUMBER,
      TS_BLOCK         NUMBER,
      BYTE_SENT        NUMBER,
      RATE_DOWNLOAD    NUMBER,
      RATE_UPLOAD      NUMBER,
      POINT_TOTAL      NUMBER,
      POINT_SUCC       NUMBER,
      POINT_DNS        NUMBER,
      POINT_CONN       NUMBER,
      POINT_SSL        NUMBER
    ) pctfree 0
    partition by range (TM_BASE)(
                  partition ' || ett_partname1 || ' values less than (' || rangedate1 || '),
                  partition ' || ett_partname2 || ' values less than (' || rangedate2 || '),
                  partition ' || ett_partname3 || ' values less than (' || rangedate3 || '))
              tablespace NETBEN_NEW';
  execute immediate sqlStr;

  --类型索引 tm_base,type_id
  sqlStr := 'create index IDX_ETT_TID_' || taskId || ' on NB_ETT_' || taskId || ' (TM_BASE,ELEM_TYPE_ID) local compress 2 tableSpace  NETBEN_IND nologging';
  execute immediate sqlStr;

exception
  when others then
    errorDesc := 'Error :' || sqlerrm || '  taskId:' || taskId;
    --DBMS_OUTPUT.PUT_LINE(v_error_desc);
    create_procedure_log('create_elem_task', errorDesc, 'error');

end createElemTable;
/

