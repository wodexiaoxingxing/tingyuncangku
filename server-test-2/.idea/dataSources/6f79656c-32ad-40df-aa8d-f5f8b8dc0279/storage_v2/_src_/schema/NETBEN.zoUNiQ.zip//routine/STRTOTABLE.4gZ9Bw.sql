create Function StrToTable(@str varchar(1000)) Returns @tableName Table
(
   str2table varchar(50)
)
As
Begin
set @str = @str+','
Declare @insertStr varchar(50)
Declare @newstr varchar(1000)
set @insertStr = left(@str,charindex(',',@str)-1)
set @newstr = stuff(@str,1,charindex(',',@str),'')
Insert @tableName Values(@insertStr)
while(len(@newstr)>0)
begin
   set @insertStr = left(@newstr,charindex(',',@newstr)-1)
   Insert @tableName Values(@insertStr)
   set @newstr = stuff(@newstr,1,charindex(',',@newstr),'')
end
Return
End
;


/

