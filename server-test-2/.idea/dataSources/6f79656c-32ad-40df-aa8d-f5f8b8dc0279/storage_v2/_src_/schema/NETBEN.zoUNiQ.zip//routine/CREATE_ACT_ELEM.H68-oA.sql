create PROCEDURE          "CREATE_ACT_ELEM" authid current_user is
  sqlStr       varchar2(4000);

begin
  create_procedure_log('create_act_elem', 'create_act_elem begin', 'test');

  --循环，查寻出所有的表
  for tableName in (select table_str as name from nb_act_table) loop
 
      --开始生成页面错误数据
      sqlStr := 'merge into nb_act_elem s
         using (select *
         from (select e.task_id,
                      e.url_protocol || ''://'' || e.url_host || '':''||e.url_port||
                      regexp_substr(e.url_path, ''[0-9a-zA-Z/}_:.-]+'') url,
                      e.url_host,
                      regexp_substr(e.url_path, ''[0-9a-zA-Z/}_:.-]+'') url_path,
                      count(1) count
                 from nb_elem_'||tableName.name||' e
                where e.tm_base >= :sDate
                  and e.tm_base < :eDate
                group by e.task_id,
                         e.url_protocol || ''://'' || e.url_host || '':''||e.url_port||
                         regexp_substr(e.url_path, ''[0-9a-zA-Z/}_:.-]+''),
                         e.url_host,
                         regexp_substr(e.url_path, ''[0-9a-zA-Z/}_:.-]+''))
        where count > 10) g
        on (g.task_id = s.task_id and g.url = s.url)
        when matched then
         update set mtime = sysdate 
        when not matched then
         insert values (g.task_id, g.url, g.url_host, g.url_path,sysdate,sysdate)';
      execute immediate sqlStr using trunc(sysdate - 1, 'dd'), trunc(sysdate, 'dd');
      commit;
      end loop;
  create_procedure_log('create_act_elem', 'create_act_elem end', 'test');
end create_act_elem;


/

