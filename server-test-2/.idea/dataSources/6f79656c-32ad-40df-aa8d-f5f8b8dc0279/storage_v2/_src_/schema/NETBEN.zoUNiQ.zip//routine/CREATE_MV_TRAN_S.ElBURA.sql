create PROCEDURE          "CREATE_MV_TRAN_S" (
  v_name in varchar2
) authid current_user
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(4000);
  v_s number;
  begin
    --创建物化视图日志
    select count(*)  INTO v_s FROM all_objects t where t.object_name = 'MLOG$_NB_TRAN_'||v_name;
    if v_s > 0 then
        sqlStr:=  'drop materialized view log on nb_tran_'||v_name;
        execute immediate sqlstr;
    end if;
        sqlStr:='create materialized view log on nb_tran_'||v_name||' with rowid,
           sequence (task_id,
	      	    city_id,
		          isp_id,
		          net_speed_id,
		          error_code,
		          ping_error,
              is_noise,
              tm_hour,
              point_total,
              ts_total,
              ts_ping_avg,
              ping_packet_lost) including new values';
         execute immediate sqlStr;
    select count(*)  INTO v_s FROM all_objects t where t.object_name = 'MV_TRAN_'||v_name;
    if v_s > 0 then
    begin
   -- DBMS_OUTPUT.PUT_LINE('begin drop mv_tran_'||v_name);
    --删除物化视图
    --DBMS_OUTPUT.PUT_LINE('drop mv_tran_'||v_name);
    sqlStr:='drop materialized view mv_tran_'||v_name;
    execute immediate sqlStr;
    end;
    end if;


    --Tran物化视图
    --DBMS_OUTPUT.PUT_LINE('begin create materialized view  mv_tran_'||v_name);
    sqlStr:='create materialized view MV_TRAN_'||v_name||'
		refresh fast
		start with sysdate next sysdate + 4/24
		as
    (select task_id,
		    city_id,
		    isp_id,
		    net_speed_id,
		    error_code,
		    ping_error,
        is_noise,
        (tm_hour - mod(to_number(to_char(tm_hour, ''hh24'')) + 8, 8) / 24) as tm_hour8,
        (tm_hour - mod(to_number(to_char(tm_hour, ''hh24'')) + 12, 12) / 24) as tm_hour12,
        trunc(tm_hour, ''dd'') as tm_day,
        count(*) as c1,
        count(point_total) as c2,
        count(ts_total) as c3,
        count(ts_ping_avg) as c4,
        count(ping_packet_lost) as c5,
		    sum(point_total) as point_total,
		    avg(ts_total) as ts_total,
				avg(ts_ping_avg) as ts_ping_avg,
        avg(ping_packet_lost) as ping_packet_lost
	  from NB_TRAN_'||v_name||'
	  group by task_id,
	         city_id,
	         isp_id,
	         net_speed_id,
		       error_code,
		       ping_error,
           is_noise,
           (tm_hour - mod(to_number(to_char(tm_hour, ''hh24'')) + 8, 8) / 24),
		       (tm_hour - mod(to_number(to_char(tm_hour, ''hh24'')) + 12, 12) / 24),
            trunc(tm_hour, ''dd''))';

    execute   immediate   sqlStr;
    --索引
	sqlStr:='create index IN_MV_TRAN_ERROR_'||v_name||' on MV_TRAN_'||v_name||' (TASK_ID,TM_HOUR8, ERROR_CODE, CITY_ID ) tableSpace NETBEN_IDX';
  execute immediate sqlStr;
    --索引
	sqlStr:='create index IN_MV_TRAN_PERF_'||v_name||' on MV_TRAN_'||v_name||' (TASK_ID,TM_HOUR8, CITY_ID,  ISP_ID) tableSpace NETBEN_IDX';
  execute   immediate   sqlStr;


   --如果创建失败，则显示出失败的表
   exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:' || v_name;
        DBMS_OUTPUT.PUT_LINE(v_error_desc);
        create_procedure_log('create_fast_mv_tran_all',v_error_desc,sqlcode);


end create_mv_tran_s;


/

