create PROCEDURE "MAN_ALTER_ETD_ADD_FIELD"
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(400);
  v_s number;
begin
  for tableName in(select t.table_name as name  from user_tables t where t.table_name like 'NB_ETD_%'
 ) loop
  begin
      select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='MEMBER_ID';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add (
                  MEMBER_ID INTEGER -- 节点ID  
                                              )';
   execute   immediate   sqlStr ;
  dbms_output.put_line(sqlStr);
      end if;

    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlStr);
        create_procedure_log('alter_etd_add_field',v_error_desc,sqlcode);
  end;
  end loop;

end MAN_alter_etd_add_field;


/

