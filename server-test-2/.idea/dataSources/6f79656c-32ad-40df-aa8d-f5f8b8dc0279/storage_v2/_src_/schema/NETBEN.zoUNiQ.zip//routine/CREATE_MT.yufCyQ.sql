create procedure create_mt authid current_user is
sqlStr varchar2(4000);
rangeDate date;
rangeDesc varchar2(8);
partName1 varchar2(64);
rangeName1 varchar2(64);
partName2 varchar2(64);
rangeName2 varchar2(64);
partName3 varchar2(64);
rangeName3 varchar2(64);
partName4 varchar2(64);
rangeName4 varchar2(64);
partName5 varchar2(64);
rangeName5 varchar2(64);
partName6 varchar2(64);
rangeName6 varchar2(64);
partName7 varchar2(64);
rangeName7 varchar2(64);
partName8 varchar2(64);
rangeName8 varchar2(64);
partName9 varchar2(64);
rangeName9 varchar2(64);
partName10 varchar2(64);
rangeName10 varchar2(64);
createDate date;
v_s number;
tableStr number;
begin
  createDate:=sysdate-55;
  --select order_num,sunday into orderNum,rangeDate from nb_part_calendar t where t.sunday = trunc(createDate+7,'d');
 
  for tab in(SELECT t.table_name as name FROM user_tables t where t.table_name like 'NB_PAGE_%')loop
    begin
      tableStr:=substr(tab.name,9);
      --先删除一下数据
      sqlStr:='drop table mt_page_'||tableStr;
      execute immediate sqlStr;
      
      rangeDate := trunc(createDate + 7,'d');
      rangeDesc := to_char(rangeDate,'yyyymmdd'); 
      partName1:='p_mt_page_'||tableStr||'_'||rangeDesc;
      rangeName1:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';      
      rangeDate := trunc(rangeDate + 7,'d');
      rangeDesc := to_char(rangeDate,'yyyymmdd'); 
      partName2:='p_mt_page_'||tableStr||'_'||rangeDesc;
      rangeName2:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
      rangeDate := trunc(rangeDate + 7,'d');
      rangeDesc := to_char(rangeDate,'yyyymmdd');
      partName3:='p_mt_page_'||tableStr||'_'||rangeDesc;
      rangeName3:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
      rangeDate := trunc(rangeDate + 7,'d');
      rangeDesc := to_char(rangeDate,'yyyymmdd');
      partName4:='p_mt_page_'||tableStr||'_'||rangeDesc;
      rangeName4:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';      
      rangeDate := trunc(rangeDate + 7,'d');
      rangeDesc := to_char(rangeDate,'yyyymmdd'); 
      partName5:='p_mt_page_'||tableStr||'_'||rangeDesc;
      rangeName5:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
      rangeDate := trunc(rangeDate + 7,'d');
      rangeDesc := to_char(rangeDate,'yyyymmdd');
      partName6:='p_mt_page_'||tableStr||'_'||rangeDesc;
      rangeName6:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
      rangeDate := trunc(rangeDate + 7,'d');
      rangeDesc := to_char(rangeDate,'yyyymmdd');
       partName7:='p_mt_page_'||tableStr||'_'||rangeDesc;
      rangeName7:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';      
      rangeDate := trunc(rangeDate + 7,'d');
      rangeDesc := to_char(rangeDate,'yyyymmdd'); 
      partName8:='p_mt_page_'||tableStr||'_'||rangeDesc;
      rangeName8:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
      rangeDate := trunc(rangeDate + 7,'d');
      rangeDesc := to_char(rangeDate,'yyyymmdd');
      partName9:='p_mt_page_'||tableStr||'_'||rangeDesc;
      rangeName9:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
      rangeDate := trunc(rangeDate + 7,'d');
      rangeDesc := to_char(rangeDate,'yyyymmdd');
      partName10:='p_mt_page_'||tableStr||'_'||rangeDesc;
      rangeName10:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
      
      sqlStr:='create table mt_page_'||tableStr||'(
                  task_id                 NUMBER,
                  page_seq                NUMBER,
                  city_id                 NUMBER,
                  isp_id                  NUMBER,
                  net_speed_id            NUMBER,
                  error_code              NUMBER,
                  is_noise                INTEGER,
                  dest_ip                 VARCHAR2(39),
                  tm_base                 DATE,
                  os_ver_id               INTEGER,
                  bs_id                   INTEGER,
                  bs_ver_id               INTEGER,
                  cont_err_total          NUMBER,
                  cont_ele_total          NUMBER,
                  point_total             NUMBER,
                  byte_total              NUMBER,
                  rate_download           NUMBER,
                  ts_total                NUMBER,
                  ts_page_base            NUMBER,
                  ts_dns                  NUMBER,
                  ts_connect              NUMBER,
                  ts_ssl                  NUMBER,
                  ts_redirect             NUMBER,
                  ts_request              NUMBER,
                  ts_first_packet         NUMBER,
                  ts_client               NUMBER,
                  ts_contents             NUMBER,
                  ts_user                 NUMBER,
                  ts_network              NUMBER,
                  byte_page_base          NUMBER,
                  rate_download_page_base NUMBER,
                  num_first_elem          NUMBER,
                  byte_first              NUMBER,
                  num_host                NUMBER,
                  ts_dns_total            NUMBER,
                  num_connect             NUMBER,
                  ts_connect_total        NUMBER,
                  num_dom                 NUMBER,
                  num_elem_lazy           NUMBER,
                  ts_first_paint          NUMBER,
                  ts_full_screen          NUMBER,
                  ts_unload_start         NUMBER,
                  ts_unload_end           NUMBER,
                  ts_dom_load             NUMBER,
                  ts_dom_interact         NUMBER,
                  ts_dom_cont_load_start  NUMBER,
                  ts_dom_cont_load_end    NUMBER,
                  ts_dom_complete         NUMBER,
                  ts_load_evt_start       NUMBER,
                  ts_load_evt_end         NUMBER
             )
              partition by range (TM_BASE)(
                      partition '||partName1||' values less than ('||rangeName1||'),
                      partition '||partName2||' values less than ('||rangeName2||'),
                      partition '||partName3||' values less than ('||rangeName3||'),
                      partition '||partName4||' values less than ('||rangeName4||'),
                      partition '||partName5||' values less than ('||rangeName5||'),
                      partition '||partName6||' values less than ('||rangeName6||'),
                      partition '||partName7||' values less than ('||rangeName7||'),
                      partition '||partName8||' values less than ('||rangeName8||'),
                      partition '||partName9||' values less than ('||rangeName9||'),
                      partition '||partName10||' values less than ('||rangeName10||'))';   
          execute immediate sqlStr;
          sqlStr:='create index IDX_MT_PAGE_PERF_'||tableStr||' on MT_PAGE_'||tableStr||' (tm_base,task_id) local
                    tableSpace NETBEN_IND';                  
          execute immediate sqlStr;
        <<next>>
          null;   
        exception when others then
          create_procedure_log('create_mt',tableStr||','||sqlerrm,'error');  
      end;
     end loop;          
end create_mt;


/

