create view SS_V_TRANSCATION as
SELECT b.id,
       b.order_id,
       b.order_time,
       b.user_id,
       b.ctime as pay_Time,
       b.status as pay_Status,
       b.cash_back,
       b.cash_payable,
       b.cash_certificate,
       b.cash_use_number,
       b.cash_recharge,
       nvl(I.ID, 0) as invoice_Id,
       nvl(I.STATUS, 0) AS INVOICE_STATUS
  FROM SS_BILL B, SS_INVOICE I
 where B.ID = I.BILL_ID(+)


/

