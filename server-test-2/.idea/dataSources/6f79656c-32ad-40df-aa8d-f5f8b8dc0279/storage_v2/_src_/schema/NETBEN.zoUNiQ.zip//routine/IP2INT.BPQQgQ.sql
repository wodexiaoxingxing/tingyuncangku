create FUNCTION IP2INT(arg in varchar2) return int is
  result int;

  p1  integer;
  p2  integer;
  p3  integer;
  ret int;
begin
  select instr(arg, '.', 1, 1) into p1 from dual;
  ret := TO_NUMBER(substr(arg, 1, p1 - 1)) * 16777216;
  select instr(arg, '.', 1, 2) into p2 from dual;
  ret := ret + TO_NUMBER(substr(arg, p1 + 1, p2 - p1)) * 65536;
  select instr(arg, '.', 1, 3) into p3 from dual;
  ret := ret + TO_NUMBER(substr(arg, p2 + 1, p3 - p2)) * 256;

  result := ret + TO_NUMBER(substr(arg, p3 + 1, 4));

  if result > 2147483647 then
     result := result - 4294967295 - 1;    
    end if; 
--   2147483647 
--   4294967295
--   4278190080
--   -1062731502
---- 3232235794 192.168.1.18

---- 16843009   1.1.1.1
  return(result);

end IP2INT;


/

