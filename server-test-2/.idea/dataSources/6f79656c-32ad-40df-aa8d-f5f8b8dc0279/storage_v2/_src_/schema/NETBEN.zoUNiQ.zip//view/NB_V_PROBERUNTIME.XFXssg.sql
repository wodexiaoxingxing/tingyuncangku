create view NB_V_PROBERUNTIME as
select "TIME_STAMP","IPADDRESS","MEMBER_ID","MEMBER_TYPE","CITY_ID","ISP_ID","SPEED_ID","STATUS","TASK_NUMBER","LOAD_AVERAGE","ATIME","CTIME","TASK_PIECE_NUMBER","TOTAL_TASK_PIECE_NUMBER","LATEST_TASK_EXPIRE","CITY_ID_IPDB","ISP_ID_IPDB","VERSION","TASK_REQ_MISS","C_ERRORS","T_ERRORS","DNS_SERVER","DNS_VALID","CONNS","TEMP_DISABLED","ACL_DISABLED","HOST_ID","OS","BS","LOST","DELAY","DELAY_MODE","GIVEUP","SCORES","RTIME","MEM","DSK","MOBILE_NODE","MOBILE_NODE_STATUS","VM","STREAM_OPT","DNSI","JS","MEMS","CPU","FLASH","IS_MULTI_PORT","MULTI_PORTS","GETWAY","GETWAY_HOP_COUNT","TRACEROUTE_HOP_EXCEPTION","IS_CROOS_ISP","IPVER" from nb_m_proberuntime_log l where l.time_stamp=(
select
max(time_stamp) from nb_m_proberuntime_log t
where t.time_stamp > sysdate - 1/96
--and t.time_stamp<(
--select max(time_stamp) from nb_m_proberuntime_log)
)
/

