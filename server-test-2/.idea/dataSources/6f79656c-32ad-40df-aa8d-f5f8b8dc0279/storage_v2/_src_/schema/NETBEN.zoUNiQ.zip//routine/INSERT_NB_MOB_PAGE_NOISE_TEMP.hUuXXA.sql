create PROCEDURE "INSERT_NB_MOB_PAGE_NOISE_TEMP" IS sql_str VARCHAR ( 4000 );
user_table_str VARCHAR ( 20 );
user_table_name VARCHAR2 ( 200 );
user_table_count int;
temp_table_count int;
CURSOR table_str_cursor IS SELECT
a.table_str 
FROM
	NB_M_AGREEMENT a
	INNER JOIN NB_M_AGREE_DETAIL ad ON ad.agreement_id = a.id 
	AND ad.status = 1 
	AND SYSDATE <= ad.expire 
GROUP BY
	a.table_str;
cursor table_name_cursor ( page_name VARCHAR, tran_name VARCHAR ) IS SELECT
table_name 
FROM
	user_tables 
WHERE
	table_name = page_name 
	OR table_name = tran_name;
BEGIN
  SELECT count(*) INTO temp_table_count FROM user_tables WHERE table_name = 'NB_MOB_PAGE_NOISE_TEMP';
	IF temp_table_count > 0 THEN
	 sql_str := 'DELETE FROM NB_MOB_PAGE_NOISE_TEMP';
	 execute IMMEDIATE sql_str;
	 commit;
	END IF;
	OPEN table_str_cursor;
	LOOP
	FETCH table_str_cursor INTO user_table_str;
	exit 
	WHEN table_str_cursor % notfound;
	FOR user_table_name IN table_name_cursor ( 'NB_MOB_PAGE_' || user_table_str, 'NB_MOB_TRAN_' || user_table_str )
	LOOP
	BEGIN
	exit 
	WHEN table_name_cursor % notfound;
	sql_str := 'INSERT INTO NB_MOB_PAGE_NOISE_TEMP SELECT
	p.id as page_id,p.task_id,t.OWNER_ID,p.tm_base,''' || user_table_name.table_name || '''
	FROM
	(
	SELECT
	* 
	FROM
  ' || user_table_name.table_name || '
	WHERE
	tm_base >= SYSDATE - 7
	AND is_noise = 0 
	) p LEFT JOIN nb_m_task t on p.task_id = t.id 
	WHERE
	(
	SELECT
		count( * ) 
	FROM
		NB_EC_' || user_table_str || ' ec
		INNER JOIN (
		SELECT
			a.* 
		FROM
			NB_EC_' || user_table_str || ' a
			INNER JOIN NB_EC_' || user_table_str || ' b ON b.ELEMENT_SEQ = 2 
			AND INSTR( b.element_type, ''text/html'' ) > 0 
			AND b.HTTP_STAT_CODE = 404
			AND a.page_id = b.page_id 
			AND a.task_id = b.task_id 
		WHERE
			a.ELEMENT_SEQ = 1 
			AND a.http_stat_code = 302 
		) ec_inner ON ec.page_id = ec_inner.page_id 
	WHERE
		ec.element_seq > ec_inner.element_seq 
		AND ec.http_stat_code != 404 
		AND ec.page_id = p.id 
		AND ec.task_id = p.task_id 
	) > 0 
	OR
	(SELECT COUNT(*) FROM NB_EC_' || user_table_str || ' a INNER JOIN NB_EC_' || user_table_str || ' b ON b.ELEMENT_SEQ = 2 AND INSTR( b.element_type, ''javascript'' ) > 0 AND a.page_id = b.page_id and a.task_id = b.task_id WHERE a.page_id = p.id and a.ELEMENT_SEQ = 1 and a.http_stat_code = 302 AND a.task_id = p.task_id) > 0
	ORDER BY p.tm_base';
	execute IMMEDIATE sql_str;
	commit;
	exception when  others then dbms_output.put_line('catch ' ||SQLERRM || ' table_name: ' ||  user_table_name.table_name);
	END;
END LOOP;

END LOOP;
close table_str_cursor;

END INSERT_NB_MOB_PAGE_NOISE_TEMP;
/

