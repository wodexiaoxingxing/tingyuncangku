create procedure haier_test(id number) authid current_user is
sqlStr varchar2(4000);
begin
  sqlstr:='update nb_m_task set mtime = sysdate,sla_probes=100,status=1 where id = '||id;
  --execute immediate sqlStr;
  dbms_output.put_line(sqlStr);
  commit;
  for i in 1..10 loop
    
    sqlStr:='update nb_m_task set mtime = sysdate,sla_probes=sla_probes+50,status=1 where id = '||id;
    --execute immediate sqlStr;
    dbms_output.put_line(sqlStr);
    commit;
  end loop;
  
  sqlStr:='update nb_m_task set mtime = sysdate,status=0 where id = '||id;
  --execute immediate sqlStr;
  dbms_output.put_line(sqlStr);
  commit;
end haier_test;


/

