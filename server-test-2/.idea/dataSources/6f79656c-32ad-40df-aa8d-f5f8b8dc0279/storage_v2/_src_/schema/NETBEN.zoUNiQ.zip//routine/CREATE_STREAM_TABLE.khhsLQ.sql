create PROCEDURE          "CREATE_STREAM_TABLE" (
       tableStr IN varchar2
) authid current_user
is
sqlStr  varchar2(4000);
begin
  --创建Stream sequence 
    sqlStr:='create sequence SEQ_NB_STREAM_ID_'||tableStr||'
			minvalue 1
			maxvalue 9999999999999999999999999
			start with 1
			increment by 1
			cache 10000';  
    execute immediate sqlStr;	
  
  --创建Stream 表
  sqlStr:='create table NB_STREAM_'||tableStr||'
  (
  ID             NUMBER not null,
  TASK_ID        NUMBER,
  CITY_ID        NUMBER,
  ISP_ID         NUMBER,
  NET_SPEED_ID   NUMBER,
  TM_BASE        DATE,
  TM_DAY         DATE,
  TM_HOUR        DATE,
  TM_HALF_HOUR   DATE,
  PROBE_IP       NUMBER,
  MEMBER_ID      NUMBER,
  ERROR_CODE     NUMBER,
  POINT_TOTAL    NUMBER default 1,
  BYTE_TOTAL     NUMBER,
  RATE_DOWNLOAD  NUMBER,
  DNS_SERVER     VARCHAR2(39),
  DEST_IP        VARCHAR2(39),
  PING_RESULT    VARCHAR2(512),
  TRACERT_RESULT VARCHAR2(512),
  HTTP_SERVER    VARCHAR2(256),
  HTTP_VIA       VARCHAR2(256),
  PROTOCOL_TYPE  VARCHAR2(256),
  RECE_PACKAGE   NUMBER,
  LOSE_PACKAGE   NUMBER,
  URL_SOURCE     VARCHAR2(256),
  URL_DEST       VARCHAR2(256),
  REBUFFER_DESC  VARCHAR2(1024),
  BUFFER_COUNT   NUMBER,
  TS_TOTAL       NUMBER,
  TS_DNS         NUMBER,
  TS_CONNECT     NUMBER,
  TS_BUFFER      NUMBER,
  TS_REBUFFER    NUMBER,
  TS_FIRST_PLAY  NUMBER,
  TS_PLAY        NUMBER,
  TS_FULL        NUMBER,
  TS_USER        NUMBER,
  IS_NOISE       NUMBER default 0
  )
  tablespace NETBEN';
  execute immediate sqlStr;	
  
  sqlStr:='alter table NB_STREAM_'||tableStr||'
    add constraint PK_NB_STREAM_'||tableStr||' primary key (ID)
    using index 
    tablespace NETBEN';
  execute immediate sqlStr;	
  
  -- NB_STREAM 索引	              
	  sqlStr:='create index IN_NB_STREAM_PERF_'||tableStr||' on NB_STREAM_'||tableStr||' (TASK_ID,TM_BASE, CITY_ID,ISP_ID) tableSpace NETBEN_IDX';  
    execute   immediate   sqlStr;	
    sqlStr:='create index IN_NB_STREAM_ERROR_'||tableStr||' on NB_STREAM_'||tableStr||' (TASK_ID,TM_BASE,ERROR_CODE, CITY_ID) tableSpace NETBEN_IDX';  
    execute   immediate   sqlStr;	
  
    --创建LT_Tran sequence 
    sqlStr:='create sequence SEQ_LT_STREAM_ID_'||tableStr||'
			minvalue 1
			maxvalue 9999999999999999999999999
			start with 1
			increment by 1
			cache 20';  
    execute   immediate   sqlStr;	
     sqlStr:='create table LT_STREAM_'||tableStr||'
		(
		  ID             NUMBER not null,
		  TASK_ID        NUMBER,
		  CITY_ID        NUMBER,
		  ISP_ID         NUMBER,
		  NET_SPEED_ID   NUMBER,
		  TM_DAY         DATE,
		  TM_DAY2        DATE,
		  TM_DAY4        DATE,
		  TM_DAY8        DATE,
		  TM_DAY16       DATE,
		  ERROR_CODE     NUMBER,
      POINT_TOTAL    NUMBER,
		  TS_TOTAL       NUMBER
		)';  
    execute   immediate   sqlStr;
    --主键  
    sqlStr:='alter table LT_STREAM_'||tableStr||'
		  add constraint PK_LT_STREAM_'||tableStr||' primary key (ID)
		  using index ';
    execute   immediate   sqlStr;
    --索引
	sqlStr:='create index IN_LT_STREAM_PERF_'||tableStr||' on LT_STREAM_'||tableStr||' (TM_DAY, CITY_ID, TASK_ID, ISP_ID) tableSpace NETBEN_IDX';
	execute   immediate   sqlStr;
    
  --创建Stream物化视图日志
  sqlStr:='create materialized view log on NB_STREAM_'||tableStr||' with rowid,
		sequence (task_id,
			city_id,
			isp_id,
			net_speed_id,
			error_code,
			is_noise,
			dest_ip,
			tm_hour,
			point_total,
			rate_download,
      buffer_count,
			ts_total,
			ts_dns,
      ts_connect,
			ts_buffer,
			ts_rebuffer,
      ts_first_play,
			ts_play,
			ts_full,
      ts_user,
      rece_package,
      lose_package
			) including new values';
	 execute immediate sqlStr;
   
   --创建Stream物化视图 
    sqlStr:='create materialized view MV_STREAM_'||tableStr||'
		refresh fast
		start with sysdate next sysdate + 4/24 
		as
		(select task_id,
		city_id,
		isp_id,
		net_speed_id,
		error_code,
		is_noise,
		dest_ip,
		(tm_hour - mod(to_number(to_char(tm_hour, '||chr(39)||'hh24'||chr(39)||')) + 8, 8) / 24) as tm_hour8,
		(tm_hour - mod(to_number(to_char(tm_hour, '||chr(39)||'hh24'||chr(39)||')) + 12, 12) / 24) as tm_hour12,
		trunc(tm_hour, '||chr(39)||'dd'||chr(39)||') as tm_day,
		count(*) as c1,
		count(point_total) as c2,
		count(rate_download) as c3,
		count(ts_total) as c4,
		count(ts_dns) as c5,
		count(ts_connect) as c6,
		count(ts_buffer) as c7,
		count(ts_rebuffer) as c8,
    count(ts_first_play) as c9,
		count(ts_play) as c10,
		count(ts_full) as c11,
    count(ts_user) as c12,
    count(rece_package) as c13,
    count(lose_package) as c14,
    count(buffer_count) as c15,
    avg(buffer_count) as buffer_count,
		sum(point_total) as point_total,
		avg(rate_download) as rate_download,
		avg(ts_total) as ts_total,
		avg(ts_dns) as ts_dns,
		avg(ts_connect) as ts_connect,
		avg(ts_buffer) as ts_buffer,
		avg(ts_rebuffer) as ts_rebuffer,
    avg(ts_first_play) as ts_first_play,
		avg(ts_play) as ts_play,
		avg(ts_full) as ts_full,
    avg(ts_user) as ts_user,
		avg(rece_package) as rece_package,
		avg(lose_package) as lose_package
		from NB_STREAM_'||tableStr||' 
		group by task_id,
			city_id,
			isp_id,
			net_speed_id,
			error_code,
			is_noise,
			dest_ip,
			(tm_hour - mod(to_number(to_char(tm_hour, '||chr(39)||'hh24'||chr(39)||')) + 8, 8) / 24),
			(tm_hour - mod(to_number(to_char(tm_hour, '||chr(39)||'hh24'||chr(39)||')) + 12, 12) / 24),
			trunc(tm_hour, '||chr(39)||'dd'||chr(39)||'))';
    execute   immediate   sqlStr;    

   -- MV_STREAM 索引	              
	  sqlStr:='create index IN_MV_STREAM_PERF_'||tableStr||' on MV_STREAM_'||tableStr||' (TASK_ID,TM_HOUR8, CITY_ID,ISP_ID) tableSpace NETBEN_IDX';  
    execute   immediate   sqlStr;	
     sqlStr:='create index IN_MV_STREAM_ERROR_'||tableStr||' on MV_STREAM_'||tableStr||' (TASK_ID,TM_HOUR8, ERROR_CODE,CITY_ID) tableSpace NETBEN_IDX';  
    execute   immediate   sqlStr;		   
   
  
end create_stream_table;


/

