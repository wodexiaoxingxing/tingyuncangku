create PROCEDURE          "UPDATE_PAGE_BYTE_PB" is
  sqlStr  varchar2(4000);
  v_name varchar2(400);
  v_error_desc varchar2(400);
  CURSOR c_emp IS SELECT t.object_name FROM all_objects t where t.object_name like 'NB_PAGE_%';
begin
OPEN c_emp;
LOOP
  begin
    FETCH c_emp INTO v_name;
    EXIT WHEN c_emp%NOTFOUND;
    --修改表
    DBMS_OUTPUT.PUT_LINE('ALTER '||v_name);
    sqlStr:='alter table '||v_name||' add (BYTE_PAGE_BASE NUMBER DEFAULT 0,RATE_DOWNLOAD_PAGE_BASE NUMBER DEFAULT 0)';
    execute   immediate   sqlStr;
    commit;

        --如果创建失败，则显示出失败的表
    exception when  others then
        v_error_desc := 'ERROR: code: '|| sqlcode || ' '||v_name;
        DBMS_OUTPUT.PUT_LINE(v_error_desc);
    end;
END LOOP;

CLOSE c_emp;

end update_page_byte_pb;


/

