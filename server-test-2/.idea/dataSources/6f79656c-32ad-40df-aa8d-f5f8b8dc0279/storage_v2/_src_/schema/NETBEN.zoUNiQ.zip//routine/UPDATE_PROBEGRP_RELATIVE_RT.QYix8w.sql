create procedure update_probegrp_relative_rt authid current_user is
  sqlStr varchar2(4000);

begin
  --sqlStr:='truncate table nb_m_conn_isp_rt';
  sqlStr:='delete from nb_m_conn_isp_rt';
  execute immediate sqlStr;
  --sqlStr:='truncate table nb_m_connisp_city_rt';
  sqlStr:='delete from nb_m_connisp_city_rt';
  execute immediate sqlStr;

  sqlStr := 'insert into nb_m_conn_isp_rt
               select distinct isp_id*16+speed_id, speed_id, isp_id, '''', 0
                     from nb_v_probe_stats where speed_id=8 and (isp_id < 101 or isp_id > 117) ';
   execute immediate sqlStr;
   --commit;

   sqlStr :='insert into nb_m_connisp_city_rt value
               select conn_isp.id, stats.city_id, 0
                 from nb_m_conn_isp_rt conn_isp, nb_v_probe_stats stats
                where conn_isp.conn_id = stats.speed_id
                 and conn_isp.isp_id = stats.isp_id
                 and stats.speed_id=8  and (stats.isp_id < 101 or stats.isp_id > 117)
                group by conn_isp.id, stats.city_id
                 having sum(stats.probe_num) > 0
                order by conn_isp.id, stats.city_id';
   execute immediate sqlStr;
   --commit;

--LastMail
   sqlStr := 'insert into nb_m_conn_isp_rt
               select distinct isp_id*16+9, 9, isp_id, '''', 0
                     from nb_v_probe_stats where  speed_id in (5, 6, 7) and (isp_id < 101 or isp_id > 117)';
   execute immediate sqlStr;
   --commit;

   sqlStr :='insert into nb_m_connisp_city_rt value
               select conn_isp.id, stats.city_id, 0
                 from nb_m_conn_isp_rt conn_isp, nb_v_probe_stats stats
               where conn_isp.conn_id = 9
                 and conn_isp.isp_id = stats.isp_id
                 and stats.speed_id in (5, 6, 7)  and (stats.isp_id < 101 or stats.isp_id > 117)
               group by conn_isp.id, stats.city_id
                 having sum(stats.probe_num) > 0
                 order by conn_isp.id, stats.city_id';
   execute immediate sqlStr;

--WAP
   sqlStr := 'insert into nb_m_conn_isp_rt
               select distinct isp_id*speed_id, speed_id, isp_id, '''', decode(mobile_node, 11, 1, 12, 1, 0) as support_mobile
                     from nb_v_probe_stats_new where  speed_id >= 10 and (isp_id < 101 or isp_id > 117)';
   execute immediate sqlStr;
   --commit;

   sqlStr :='insert into nb_m_connisp_city_rt
               select conn_isp.id, stats.city_id, decode(stats.mobile_node, 11, 1, 12, 1, 0) as support_mobile
                 from nb_m_conn_isp_rt conn_isp, nb_v_probe_stats_new stats
               where conn_isp.conn_id >= 10
                 and conn_isp.isp_id = stats.isp_id
                 and conn_isp.support_mobile = decode(stats.mobile_node, 11, 1, 12, 1, 0)
                 and stats.speed_id >=10  and (stats.isp_id < 101 or stats.isp_id > 117)
               group by conn_isp.id, stats.city_id, decode(stats.mobile_node, 11, 1, 12, 1, 0)
                 having sum(stats.probe_num) > 0
                 order by conn_isp.id, stats.city_id';
   execute immediate sqlStr;

   commit;
end update_probegrp_relative_rt;


/

