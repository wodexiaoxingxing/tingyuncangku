create FUNCTION          "CALC_BUFFERCOUNT_GRADE" (p1 in number,p2 in number)
  return number is
  result number;
begin
  result := 100 - (p1/100 * 400 + p2/100 * 500);
  result := case
              when result < 0 then
               0
              else
               result
            end;

  return(Result);
end calc_buffercount_grade;


/

