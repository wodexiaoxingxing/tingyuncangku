create procedure tmp_calc_bill_mob_ping authid current_user is
  sqlStr       varchar2(4000);
  errorDesc varchar2(4000);
  startDate date := trunc(to_date('2014-01-01','yyyy-mm-dd'),'dd');
  endDate date := trunc(sysdate ,'dd');
begin
  -- 用于测试增加输出缓存
  dbms_output.enable(buffer_size=>null) ;
  create_procedure_log('tmp_calc_bill_mob_ping', 'tmp_calc_bill_mob_ping begin', 'test');
 

  --循环，查寻出所有的表
  for tableName in (select distinct table_str as name from nb_m_agreement) loop
  begin
     
      --从ping监测表中生成每日的数据,暂时只取手机页面PING的数据，普通页面ping从page表中取
      begin
        sqlStr := 'insert into nb_bill_task_day value
                     select p.task_id, trunc(p.tm_base, ''dd''), sum(p.point_total), sysdate
                        from nb_ping_'||tableName.name||' p,nb_m_task t
                       where p.tm_base >= :sDate and p.tm_base < :eDate
                         and p.is_noise = 0
                         and t.agreement_id in(select id from nb_m_agreement where table_str = '||tableName.name||')
                         and t.task_option = ''P''
                         and t.type = 102
                         and p.task_id = t.id
                       group by p.task_id, trunc(p.tm_base, ''dd'')';
        execute immediate sqlStr using startDate,endDate;
        commit;
      exception when  others then
        errorDesc := sqlerrm||',tableName:nb_ping_' || tableName.name ;
        DBMS_OUTPUT.PUT_LINE(errorDesc);
        create_procedure_log('tmp_calc_bill_mob_ping',errorDesc,'warning');
      end;
  end;
  end loop;
  create_procedure_log('tmp_calc_bill_mob_ping', 'calc_bill_day end', 'test');
end tmp_calc_bill_mob_ping;


/

