create procedure in_lt_stream_period(sd date,days number) authid current_user
is
   sqlStr varchar2(4000);
   startDate date ;
   endDate date := trunc(sysdate,'dd');
   errorDesc varchar2(4000);
   v_s number;

begin
create_procedure_log('in_lt_stream_period','begin','run');
if sd is null or days is null then
  startDate:=trunc(sysdate-1,'dd');
  endDate:=startDate+1;
else
  startDate:=trunc(sd,'dd');
  endDate:=startDate+days;
end if;
for item in (select substr(t.table_name, 11) as name from user_tables t where t.table_name like 'NB_STREAM_%') loop
begin
   --判断是否该表已经创建
  create_procedure_log('insert_longterm_stream','tableStr:'||item.name,'run');
   --DBMS_OUTPUT.PUT_LINE(item.name||'  '||to_char(sysdate,'hh24:mi:ss'));
   select count(*) into v_s from user_tables t where t.table_name = 'LT_STREAM_'||item.name;
   if (v_s<1) then
       --表不存在，创建新表
       sqlStr:='create table LT_STREAM_'||item.name||'
		       (
      		 TASK_ID        NUMBER NOT NULL,
		       CITY_ID        NUMBER NOT NULL,
		       ISP_ID         NUMBER NOT NULL,
		       NET_SPEED_ID   NUMBER NOT NULL,
					 dest_city_id   number,
					 dest_isp_id    number,
					 dest_ip        VARCHAR2(39),
		       TM_DAY         DATE,
           ERROR_CODE     NUMBER ,
           POINT_TOTAL    NUMBER ,
           TS_TOTAL       NUMBER ,
           TS_CONNECT     NUMBER ,
           TS_BUFFER      NUMBER ,
           TS_REBUFFER    NUMBER ,
           BUFFER_COUNT   NUMBER ,
           ts_dns         number,
           ts_connect_tcp number,
           ts_first_packet number,
           rate_download  number,
           ts_redirect    number,
           ts_first_play  number,
           ts_play        number,
           ts_full        number,
           ts_user        number,
           rece_package   number,
           lose_package   number,
           ts_contents    number,
           PLAY_IN_5S	number,
           FLUENCY		number,
           DATA_RATE       NUMBER,
					 ts_ssl number

		       )';
         execute   immediate   sqlStr;
         --创建索引
         sqlStr:='create index IN_LT_STREAM_PERF_'||item.name||' on LT_STREAM_'||item.name||' (task_id,tm_day,city_id,isp_id,error_code) tableSpace netben_ind';
	       execute   immediate   sqlStr;
     end if;

  --删除指定日期的长期库中的数据,防止重复数据
  sqlStr := 'delete from lt_stream_'||item.name||' where tm_day  >=:sDate and tm_day < :eDate';
  execute immediate sqlStr using startDate,endDate;
  commit;

  --从实时库中插入指定日期的数据
  sqlStr:='insert into lt_stream_'||item.name||'
           (task_id,city_id,isp_id,dest_city_id,dest_isp_id,dest_ip,net_speed_id,tm_day,error_code,
            point_total,ts_total,ts_connect,ts_buffer,ts_rebuffer,buffer_count,
            ts_dns,ts_connect_tcp,ts_first_packet,rate_download,ts_redirect,ts_first_play,
            ts_play,ts_full,ts_user,rece_package,lose_package,ts_contents,play_in_5s,fluency,data_rate,ts_ssl)
        select
		       task_id,
		       city_id,
		       isp_id,
					 dest_city_id,
					 dest_isp_id,
					 dest_ip,
		       net_speed_id,
		       trunc(tm_base,''dd'') as tm_day,
           error_code,
		       sum(point_total),
           round(avg(ts_total),0) as ts_total,
           round(avg(ts_connect),0) as ts_connect,
		       round(avg(ts_buffer),0) as ts_buffer,
           round(avg(ts_rebuffer),0) as ts_rebuffer,
           round(avg(buffer_count),2) as buffer_count,
           round(avg(ts_dns),0) as ts_dns,
           round(avg(ts_connect_tcp),0) as ts_connect_tcp,
           round(avg(ts_first_packet),0) as ts_first_packet,
           round(avg(rate_download),0) as rate_download,
           round(avg(ts_redirect),0) as ts_redirect,
           round(avg(ts_first_play),0) as ts_first_play,
           round(avg(ts_play),0) as ts_play,
           round(avg(ts_full),0) as ts_full,
           round(avg(ts_user),0) as ts_user,
           round(avg(rece_package),2) as rece_package,
           round(avg(lose_package),2) as lose_package,
           round(avg(ts_contents),0) as ts_contents,
           round(avg(play_in_5s),2) as play_in_5s,
           round( avg(fluency),2) as fluency,
           round( avg(DATA_RATE),2) as DATA_RATE,
					 round(avg(ts_ssl),0) as ts_ssl
		    from NB_STREAM_'||item.name||'
           where tm_base >= :sDate and  tm_base < :eDate and is_noise = 0 and buffer_count >= 0
		       group by task_id,
		                city_id,
		                isp_id,
										dest_city_id,
										dest_isp_id,
										dest_ip,
		                net_speed_id,
                    trunc(tm_base,''dd''),
		                error_code
		    ';
       execute immediate sqlStr using startDate,endDate;
       commit;
     exception when  others then
        errorDesc := 'Error Code:'|| sqlerrm || '  tablestr:'||item.name ;
        create_procedure_log('in_lt_stream_period',errorDesc,'error');
  end;
end loop;
create_procedure_log('in_lt_stream_period','end','run');
end in_lt_stream_period;
/

