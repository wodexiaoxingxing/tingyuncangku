create PROCEDURE "MAN_ALTER_MV_PAGE"
is
  sqlStr  varchar2(8000);
--  v_error_desc varchar2(4000);
  v_s number;
  tableStr varchar2(100);
begin
  for tableName in(

 SELECT NUM,a.table_name name,b.num_rows
  FROM (select count(*) NUM, table_name
          from user_tab_columns t
         where table_name like 'MV_PAGE%'
         group by table_name
         ORDER BY 1 desc) a,user_tables b
         where a.table_name=b.table_name
    --     AND b.TABLE_NAME='MV_PAGE_1751'
 --        and num<100

   ) loop
  begin
 select substr(tableName.Name,9) into tablestr from dual;
 
    select count(*)  INTO v_s FROM user_tables  t where t.table_name = 'MLOG$_NB_PAGE_'||tableStr;
    
--dbms_output.put_line(  v_s );  
    if v_s >0 then
        sqlStr := 'drop materialized view log on NB_PAGE_'||tableStr;

--dbms_output.put_line(sqlStr);
execute   immediate   sqlStr ;
      end if;
 



 --创建物化日志
 sqlStr:='create materialized view log on NB_PAGE_'||tableStr||' with rowid,
          sequence (task_id,page_seq,
              city_id,
              isp_id,
              net_speed_id,
              error_code,
              is_noise,
              dest_ip,
              tm_base,
              cont_err_total,
              cont_ele_total,
              point_total,
              byte_total,
              rate_download,
              ts_total,ts_page_base,
              ts_dns,ts_connect,
              ts_ssl,ts_redirect,
              ts_request,ts_first_packet,
              ts_client,ts_contents,ts_extra_data,
               ts_user,
              ts_network,
              ts_close,
              byte_page_base,
              rate_download_page_base,
              num_first_elem,
              byte_first,
              num_host,
              ts_dns_total,
              num_connect,
              ts_connect_total,
              num_dom,
              OS_VER_ID,
              BS_ID,
              BS_VER_ID,
              NUM_ELEM_LAZY,
        TS_FIRST_PAINT,
        TS_FULL_SCREEN,
        TS_UNLOAD_START,
        TS_UNLOAD_END,
        TS_DOM_LOAD,
        TS_DOM_INTERACT,
        TS_DOM_CONT_LOAD_START,
        TS_DOM_CONT_LOAD_END,
        TS_DOM_COMPLETE,
        TS_LOAD_EVT_START,
        TS_LOAD_EVT_END
              ) including new values';
execute   immediate   sqlStr ;
--dbms_output.put_line(sqlStr);
 
 
 
  ----------------------------------------


 --删除物化视图
      select count(*) INTO v_s from user_mviews T where T.MVIEW_NAME = 'MV_PAGE_'||tableStr;

      if v_s >0 then
        sqlStr := 'drop materialized view MV_PAGE_'||tableStr;
execute   immediate   sqlStr ;
--dbms_output.put_line(sqlStr);
       end if;
    --创建物化视图

  sqlStr:='create materialized view MV_PAGE_'||tableStr||'
    refresh fast
    start with sysdate next sysdate + 4/24
    as
    (select task_id,
        page_seq,
        city_id,
        isp_id,
        net_speed_id,
        error_code,
        is_noise,
        dest_ip,
        (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8) / 24) as tm_hour8,
        os_ver_id,
        bs_id,
        bs_ver_id,
        count(*) as c1,
        count(cont_err_total) as c2,
        count(cont_ele_total) as c3,
        count(point_total) as c4,
        count(byte_total) as c5,
        count(rate_download) as c6,
        count(ts_total) as c7,
        count(ts_page_base) as c8,
        count(ts_dns) as c9,
        count(ts_connect) as c10,
        count(ts_ssl) as c11,
        count(ts_redirect) as c12,
        count(ts_request) as c13,
        count(ts_first_packet) as c14,
        count(ts_client) as c15,
        count(ts_contents) as c16,
        count(ts_user) as c17,
        count(ts_network) as c18,
        count(byte_page_base) as c19,
        count(rate_download_page_base) as c20,
        count(num_first_elem) as c21,
        count(byte_first) as c22,
        count(num_host) as c23,
        count(ts_dns_total) as c24,
        count(num_connect) as c25,
        count(ts_connect_total) as c26,
        count(num_dom) as c27,
        count(NUM_ELEM_LAZY) as c28,
    count(TS_FIRST_PAINT) as c29,
    count(TS_FULL_SCREEN) as c30,
    count(TS_UNLOAD_START) as c31,
    count(TS_UNLOAD_END) as c32,
    count(TS_DOM_LOAD) as c33,
    count(TS_DOM_INTERACT) as c34,
    count(TS_DOM_CONT_LOAD_START) as c35,
    count(TS_DOM_CONT_LOAD_END) as c36,
    count(TS_DOM_COMPLETE) as c37,
    count(TS_LOAD_EVT_START) as c38,
    count(TS_LOAD_EVT_END) as c39,
              avg(cont_err_total) as cont_err_total,
              avg(cont_ele_total) as cont_ele_total,
              sum(point_total) as point_total,
              avg(byte_total) as byte_total,
              avg(rate_download) as rate_download,
              avg(ts_total) as ts_total,
              avg(ts_page_base) as ts_page_base,
              avg(ts_dns) as ts_dns,
              avg(ts_connect) as ts_connect,
              avg(ts_ssl) as ts_ssl,
              avg(ts_redirect) as ts_redirect,
              avg(ts_request) as ts_request,
              avg(ts_first_packet) as ts_first_packet,
              avg(ts_client) as ts_client,
              avg(ts_contents) as ts_contents,
              avg(ts_user) as ts_user,
              avg(ts_network) as ts_network,
              avg(byte_page_base) as byte_page_base,
              avg(rate_download_page_base) as rate_download_page_base,
              avg(num_first_elem) as num_first_elem,
              avg(byte_first) as byte_first,
              avg(num_host) as num_host,
              avg(ts_dns_total) as ts_dns_total,
              avg(num_connect) as num_connect,
              avg(ts_connect_total) as ts_connect_total,
              avg(num_dom) as num_dom,
                avg(NUM_ELEM_LAZY) as NUM_ELEM_LAZY,
        avg(TS_FIRST_PAINT) as TS_FIRST_PAINT,
        avg(TS_FULL_SCREEN) as TS_FULL_SCREEN,
        avg(TS_UNLOAD_START) as TS_UNLOAD_START,
        avg(TS_UNLOAD_END) as TS_UNLOAD_END,
        avg(TS_DOM_LOAD) as TS_DOM_LOAD,
        avg(TS_DOM_INTERACT) as TS_DOM_INTERACT,
        avg(TS_DOM_CONT_LOAD_START) as TS_DOM_CONT_LOAD_START,
        avg(TS_DOM_CONT_LOAD_END) as TS_DOM_CONT_LOAD_END,
        avg(TS_DOM_COMPLETE) as TS_DOM_COMPLETE,
        avg(TS_LOAD_EVT_START) as TS_LOAD_EVT_START,
        avg(TS_LOAD_EVT_END) as TS_LOAD_EVT_END
    from NB_PAGE_'||tableStr||'
    group by task_id,
           page_seq,
         city_id,
         isp_id,
         net_speed_id,
       error_code,
           is_noise,
           dest_ip,
           (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8) / 24),
        os_ver_id,
        bs_id,
        bs_ver_id)';
--dbms_output.put_line(sqlStr);
execute   immediate   sqlStr ;


  --索引
  sqlStr:='create index IN_MV_PAGE_ERROR_'||tableStr||' on MV_PAGE_'||tableStr||' (TASK_ID,TM_HOUR8, ERROR_CODE, CITY_ID) tableSpace NETBEN_IND';
execute   immediate   sqlStr ;
--dbms_output.put_line(sqlerrm);
    --索引
  sqlStr:='create index IN_MV_PAGE_PERF_'||tableStr||' on MV_PAGE_'||tableStr||' (TASK_ID,TM_HOUR8, CITY_ID,ISP_ID) tableSpace NETBEN_IND';
 execute   immediate   sqlStr ;
--dbms_output.put_line(sqlStr);
  --end if;

    exception when  others then
     --   v_error_desc := 'Error Code:'|| sqlerrm || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlerrm);
       MON_PC_ERROR_LOG('MAN_ALTER_MV_PAGE',sqlerrm,tableName.Name);
 end;
  end loop;
end MAN_ALTER_MV_PAGE;


/

