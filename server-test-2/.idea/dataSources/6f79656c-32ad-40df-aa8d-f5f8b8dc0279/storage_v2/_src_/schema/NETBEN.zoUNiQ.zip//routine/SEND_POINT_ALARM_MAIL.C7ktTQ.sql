create PROCEDURE          "SEND_POINT_ALARM_MAIL" is
  l_mailhost    VARCHAR2(64) := 'mail.networkbench.com';
  l_from        VARCHAR2(64) := 'noreply@networkbench.com';
  l_subject     VARCHAR2(64) := 'point alarm';
  l_to          VARCHAR2(64) := 'hy@networkbench.com';
  l_data        VARCHAR2(256);
  l_mail_conn   UTL_SMTP.connection;
  currDate date := sysdate;
  sqlStr varchar2(4000);
  userName varchar2(256);
  userEmail varchar2(256);
  errorDesc varchar2(4000);
  
begin
  
  for item in (select alarm_id,alarm_type,count,alarm_count from nb_point_alarm_log where cdate >= trunc(currDate,'dd') and cDate < trunc(currDate+1,'dd')) loop
  begin
    dbms_output.put_line(item.alarm_id);
    sqlStr:='select user_name,user_email from nb_point_alarm_table where id =:id';
    execute immediate sqlStr into userName,userEmail using item.alarm_id;
    if (item.alarm_type = 1) then 
      l_subject:='Point alarm,type:Onhand user:' || userName;
    else
      l_subject:='Point alarm,type:Overrun user:'|| userName;
    end if;
    l_data:='SetCount:'||item.count||' AlarmCount:'||item.alarm_count;
    l_mail_conn := UTL_SMTP.open_connection(l_mailhost, 25);
    UTL_SMTP.helo(l_mail_conn, l_mailhost);
    UTL_SMTP.mail(l_mail_conn, l_from);
    UTL_SMTP.rcpt(l_mail_conn, l_to);
    UTL_SMTP.open_data(l_mail_conn);
    UTL_SMTP.write_data(l_mail_conn, 'Date: ' || TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') || Chr(13));
    UTL_SMTP.write_data(l_mail_conn, 'From: ' || l_from || Chr(13));
    UTL_SMTP.write_data(l_mail_conn, 'Subject: ' || l_subject || Chr(13));
    UTL_SMTP.write_data(l_mail_conn, 'To: ' || l_to || Chr(13));
    UTL_SMTP.write_data(l_mail_conn, '' || Chr(13));
    UTL_SMTP.write_data(l_mail_conn, l_subject|| Chr(13));
    UTL_SMTP.write_data(l_mail_conn,l_data||Chr(13));
    UTL_SMTP.write_data(l_mail_conn,to_char(sysdate,'yyyy-mm-dd hh24:mi'));    
    UTL_SMTP.close_data(l_mail_conn);
    UTL_SMTP.quit(l_mail_conn);
    exception when  others then
        errorDesc := 'Error Code:'|| sqlcode ;
        --DBMS_OUTPUT.PUT_LINE(v_error_desc);
        create_procedure_log('send_point_alarm_mail',errorDesc,sqlcode);
    end;
  end loop;  
 
end send_point_alarm_mail;


/

