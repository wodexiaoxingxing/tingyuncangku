create PROCEDURE          "CREATE_MV_MOBAPP_PAGE_S" (
  v_name in varchar2
)authid current_user
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(4000);
  v_s number;
  begin
    --创建物化视图日志
    select count(*)  INTO v_s FROM all_objects t where t.object_name = 'MLOG$_NB_MOBAPP_PAGE_'||v_name;
    if v_s > 0 then
        sqlStr:=  'drop materialized view log on nb_mobapp_page_'||v_name;
        execute immediate sqlstr;
    end if;
        sqlStr:='create materialized view log on nb_mobapp_page_'||v_name||' with rowid,
           sequence (task_id,page_seq,
	      	    city_id,
		          isp_id,
		          net_speed_id,
		          error_code,
              is_noise,
              tm_base,
              point_total,
              ts_total,
              byte_total,
              byte_sent
              ) including new values';
         execute immediate sqlStr;
    select count(*)  INTO v_s FROM all_objects t where t.object_name = 'MV_MOBAPP_PAGE_'||v_name;
    if v_s > 0 then
    --删除物化视图
    --DBMS_OUTPUT.PUT_LINE('drop mv_tran_'||v_name);
    sqlStr:='drop materialized view mv_mobapp_page_'||v_name;
    execute immediate sqlStr;
    end if;


    --page物化视图
    DBMS_OUTPUT.PUT_LINE('begin create materialized view  mv_mobapp_page_'||v_name);
    sqlStr:='create materialized view mv_mobapp_page_'||v_name||'
		refresh fast
		start with sysdate next sysdate + 4/24
		as
    (select task_id,
        page_seq,
		    city_id,
		    isp_id,
		    net_speed_id,
		    error_code,
        is_noise,
        (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8) / 24) as tm_hour8,
        count(*) as c1,
        count(point_total) as c2,
        count(ts_total) as c3,
        count(byte_total) as c4,
        count(byte_sent) as c5,
		          sum(point_total) as point_total,
              avg(ts_total) as ts_total,
              avg(byte_total) as byte_total,
		          avg(byte_sent) as byte_sent
	  from nb_mobapp_page_'||v_name||'
	  group by task_id,
           page_seq,
	         city_id,
	         isp_id,
	         net_speed_id,
		       error_code,
           is_noise,
           (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8) / 24))';
    execute   immediate   sqlStr;
  --索引
		sqlStr:='create index IN_MV_MOBAPP_PAGE_ERROR_'||v_name||' on MV_MOBAPP_PAGE_'||v_name||' (TASK_ID,TM_HOUR8, ERROR_CODE, CITY_ID) tableSpace NETBEN_IDX';
    execute   immediate   sqlStr;
    --索引
		--sqlStr:='create index IN_MV_MOBAPP_PAGE_PERF_'||v_name||' on MV_MOBAPP_PAGE_'||v_name||' (TASK_ID,TM_HOUR8, CITY_ID, ISP_ID) tableSpace NETBEN_IDX';
    --execute   immediate   sqlStr;


   --如果创建失败，则显示出失败的表
   exception when  others then
        v_error_desc := 'Error:'|| sqlerrm || '  table:' || v_name;
        DBMS_OUTPUT.PUT_LINE(v_error_desc);
        create_procedure_log('create_fast_mv_mobapp_page_s',v_error_desc,'error');
end create_mv_mobapp_page_s;


/

