create view NB_V_SCORE_BALANCE_MAX_T as
SELECT "ID","MEMBER_ID","CDATE","SCORE","SCORE_BALANCE","DATA_POINTS","DATA_POINTS_TOTAL","REASON" from nb_m_score_balance_t WHERE ID IN
(
select MAX(ID)
from nb_m_score_balance_t
group by member_id
)


/

