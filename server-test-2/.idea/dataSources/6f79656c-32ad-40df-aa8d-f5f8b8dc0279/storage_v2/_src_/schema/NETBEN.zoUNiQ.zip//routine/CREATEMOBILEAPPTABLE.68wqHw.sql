create procedure createMobileAppTable(
       tableStr IN varchar2
) authid current_user
is
sqlStr  varchar2(4000);
begin
  --create trace sequence 
    sqlStr:='create sequence SEQ_NB_MOBAPP_TRAN_ID_'||tableStr||'
      minvalue 1
      maxvalue 9999999999999999999999999
      start with 1
      increment by 1
      cache 500';  
    execute immediate sqlStr;  
  
  --create TABLE of NB_MOBAPP_TRAN
  sqlStr:='create table NB_MOBAPP_TRAN_'||tableStr||'
  (
	ID             NUMBER not null,
	TASK_ID        NUMBER,
	CITY_ID        INTEGER,
	ISP_ID         INTEGER,
	NET_SPEED_ID   INTEGER,
	MEMBER_ID      INTEGER,
	PROBE_IP       NUMBER,
	OS_ID          INTEGER,
	HW_ID          INTEGER,
	MB_TYPE        INTEGER,
	BB_ID          INTEGER,
	WIFI           INTEGER,
	SCREEN_WIDTH   INTEGER,
	SCREEN_HEIGHT  INTEGER,
	IMEI           INTEGER,
	MOBILE_SIGNAL  INTEGER,
	PERCENT_CPU    INTEGER,
	PERCENT_MEM    INTEGER,
	TM_BASE        DATE,
	TS_TOTAL       INTEGER,
	ERROR_CODE     INTEGER,
	POINT_TOTAL    INTEGER default 1,
	IS_NOISE       INTEGER default 0,
	DEST_IP        VARCHAR2(39)
  ) pctfree 0
  tablespace NETBEN';
  execute immediate sqlStr;  
  
  sqlStr:='alter table NB_MOBAPP_TRAN_'||tableStr||'
    add constraint PK_NB_MOBAPP_TRAN_'||tableStr||' primary key (ID)
    using index 
    tablespace NETBEN';
  execute immediate sqlStr;  
  
  -- NB_MOBAPP_TRAN index
  sqlStr:='create index IN_MOBTRAN_'||tableStr||' on NB_MOBAPP_TRAN_'||tableStr||' (TASK_ID,TM_BASE,ERROR_CODE) tableSpace NETBEN_IDX_NEW';  
    execute   immediate   sqlStr;
    
  --create page sequence 
    sqlStr:='create sequence SEQ_NB_MOBAPP_PAGE_ID_'||tableStr||'
      minvalue 1
      maxvalue 9999999999999999999999999
      start with 1
      increment by 1
      cache 500';  
    execute immediate sqlStr;  
  
  --create TABLE of NB_MOBAPP_PAGE
  sqlStr:='create table NB_MOBAPP_PAGE_'||tableStr||'
  (
	ID            NUMBER,
	TRAN_ID       NUMBER,
	TASK_ID       NUMBER,
	CITY_ID       INTEGER,
	ISP_ID        INTEGER,
	NET_SPEED_ID  INTEGER,
	PAGE_SEQ      INTEGER,
	PROBE_IP      NUMBER,
	TM_BASE       DATE,
	TS_TOTAL      INTEGER,
	ERROR_CODE    INTEGER,
	ERROR_PATH    VARCHAR2(256),
	BYTE_TOTAL    INTEGER,
	BYTE_SENT     INTEGER,
	LOG_MSG       VARCHAR2(256),
	POINT_TOTAL   INTEGER default 1,
	IS_NOISE      INTEGER default 0
  ) pctfree 0
  tablespace NETBEN';
  execute immediate sqlStr;  
  
  sqlStr:='alter table NB_MOBAPP_PAGE_'||tableStr||'
    add constraint PK_NB_MOBAPP_PAGE_'||tableStr||' primary key (ID)
    using index 
    tablespace NETBEN';
  execute immediate sqlStr;  
  
  -- NB_MOBAPP_PAGE index
  sqlStr:='create index IN_MOBPAGE_'||tableStr||' on NB_MOBAPP_PAGE_'||tableStr||' (TASK_ID,TM_BASE,ERROR_CODE) tableSpace NETBEN_IDX_NEW';  
    execute   immediate   sqlStr;
    
  --create TABLE of NB_MOBAPP_ACTION
  sqlStr:='create table NB_MOBAPP_ACTION_'||tableStr||'
  (
	PAGE_ID      NUMBER,
	TASK_ID      NUMBER,
	ACTION_SEQ   INTEGER,
	ACTION_NAME  VARCHAR2(256),
	PROBE_IP     NUMBER,
	TM_BASE      DATE,
	TS_TOTAL     INTEGER,
	ERROR_CODE   INTEGER,
	ERROR_PATH   VARCHAR2(256),
	BYTE_TOTAL   INTEGER,
	BYTE_SENT    INTEGER,
	LOG_MSG      VARCHAR2(256)
  ) pctfree 0
  tablespace NETBEN';
  execute immediate sqlStr;
  
  -- NB_MOBAPP_ACTION index
  sqlStr:='create index IN_MOBACT_PAGEID_'||tableStr||' on NB_MOBAPP_ACTION_'||tableStr||' (PAGE_ID) tableSpace NETBEN_IDX_NEW';  
    execute   immediate   sqlStr;
    
  -- create materialized view for NB_MOBAPP_TRAN
  sqlStr:='create materialized view log on NB_MOBAPP_TRAN_'||tableStr||' tablespace netben_mv with rowid,
     sequence (task_id,
      city_id,
        isp_id,
        net_speed_id,
        error_code,
      is_noise,
      tm_base,
      point_total,
      ts_total
      ) including new values';
   execute immediate sqlStr;

    sqlStr:='create materialized view MV_MOBAPP_TRAN_'||tableStr||' tablespace netben_mv
    refresh fast
    start with sysdate next sysdate + 4/24
    as
    (select task_id,
        city_id,
        isp_id,
        net_speed_id,
        error_code,
        is_noise,
        (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8) / 24) as tm_hour8,
        count(*) as c1,
        count(point_total) as c2,
        count(ts_total) as c3,
              sum(point_total) as point_total,
              avg(ts_total) as ts_total
    from nb_mobapp_tran_'||tableStr||'
    group by task_id,
           city_id,
           isp_id,
           net_speed_id,
           error_code,
           is_noise,
           (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8) / 24))';
    execute   immediate   sqlStr;

  sqlStr:='create index IN_MV_MOBTRAN_'||tableStr||' on MV_MOBAPP_TRAN_'||tableStr||' (TASK_ID,TM_HOUR8, ERROR_CODE, CITY_ID) tableSpace NETBEN_IDX_NEW';
    execute   immediate   sqlStr;

  -- create materialized view for NB_MOBAPP_PAGE
  sqlStr:='create materialized view log on NB_MOBAPP_PAGE_'||tableStr||' tablespace netben_mv with rowid,
     sequence (task_id,page_seq,
      city_id,
        isp_id,
        net_speed_id,
        error_code,
      is_noise,
      tm_base,
      point_total,
      ts_total,
      byte_total,
      byte_sent
      ) including new values';
   execute immediate sqlStr;
     
    sqlStr:='create materialized view MV_MOBAPP_PAGE_'||tableStr||' tablespace netben_mv
    refresh fast
    start with sysdate next sysdate + 4/24
    as
    (select task_id,
        page_seq,
        city_id,
        isp_id,
        net_speed_id,
        error_code,
        is_noise,
        (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8) / 24) as tm_hour8,
        count(*) as c1,
        count(point_total) as c2,
        count(ts_total) as c3,
        count(byte_total) as c4,
        count(byte_sent) as c5,
              sum(point_total) as point_total,
              avg(ts_total) as ts_total,
              avg(byte_total) as byte_total,
              avg(byte_sent) as byte_sent
    from nb_mobapp_page_'||tableStr||'
    group by task_id,
           page_seq,
           city_id,
           isp_id,
           net_speed_id,
           error_code,
           is_noise,
           (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8) / 24))';
    execute   immediate   sqlStr;

  sqlStr:='create index IN_MV_MOBPAGE_'||tableStr||' on MV_MOBAPP_PAGE_'||tableStr||' (TASK_ID,TM_HOUR8, ERROR_CODE, CITY_ID) tableSpace NETBEN_IDX_NEW';
    execute   immediate   sqlStr;    
end createMobileAppTable;
/

