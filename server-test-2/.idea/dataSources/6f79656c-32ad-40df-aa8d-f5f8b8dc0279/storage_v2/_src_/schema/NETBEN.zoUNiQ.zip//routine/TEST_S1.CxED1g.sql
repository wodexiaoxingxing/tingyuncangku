create procedure test_s1 is
sqlStr varchar2(4000);
begin
  sqlStr:='rename mv_page_2323 to mv_page_111';
  execute immediate sqlStr;
  create_procedure_log('test_s1','aaa','run');
end test_s1;


/

