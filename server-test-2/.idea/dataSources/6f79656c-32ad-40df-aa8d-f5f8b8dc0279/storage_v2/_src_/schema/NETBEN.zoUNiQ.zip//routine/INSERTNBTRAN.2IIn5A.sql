create PROCEDURE          "INSERTNBTRAN" 
(
      tableStr IN varchar2,
      ID             NUMBER ,
	  TASK_ID        NUMBER,
	  CITY_ID        NUMBER,
	  ISP_ID         NUMBER,
	  NET_SPEED_ID   NUMBER,
	  TM_BASE        DATE,
	  TM_HOUR        DATE,
	  TM_DAY         DATE,
	  TM_HALF_HOUR   DATE,
	  PROBE_IP       NUMBER,
	  ERROR_CODE     NUMBER,
	  CONT_ERR_TOTAL NUMBER,
	  ERROR_PAGE_SEQ NUMBER,
	  PAGE_TOTAL     NUMBER,
	  BYTE_TOTAL     NUMBER,
	  TS_TOTAL       NUMBER,
	  TS_NETWORK     NUMBER,
	  TS_PING_AVG    NUMBER,
	  TS_PING_START  NUMBER,
	  PING_ERROR	 NUMBER,
	  POINT_TOTAL    NUMBER,
	  DNS_SERVER	 VARCHAR2,
	  DEST_IP        VARCHAR2,
	  MEMBER_ID		 NUMBER,
	  IS_NOISE		 NUMBER
) authid current_user
is
  sqlStr  varchar2(4000);  
BEGIN

	sqlStr:='insert into NB_TRAN_'||tableStr||'
	(
	  ID              ,
	  TASK_ID         ,
	  CITY_ID         ,
	  ISP_ID          ,
	  NET_SPEED_ID    ,
	  TM_BASE         ,
	  TM_HOUR         ,
	  TM_DAY          ,
	  TM_HALF_HOUR    ,
	  PROBE_IP        ,
	  ERROR_CODE      ,
	  CONT_ERR_TOTAL  ,
	  ERROR_PAGE_SEQ  ,
	  PAGE_TOTAL      ,
	  BYTE_TOTAL      ,
	  TS_TOTAL        ,
	  TS_NETWORK      ,
	  TS_PING_AVG     ,
	  TS_PING_START   ,
	  PING_ERROR	  ,
	  POINT_TOTAL     ,
	  DNS_SERVER	  ,
	  DEST_IP     	  ,
	  MEMBER_ID		  ,
	  IS_NOISE		 
	)    
    values (
	  :ID              ,
	  :TASK_ID         ,
	  :CITY_ID         ,
	  :ISP_ID          ,
	  :NET_SPEED_ID    ,
	  :TM_BASE         ,
	  :TM_HOUR         ,
	  :TM_DAY          ,
	  :TM_HALF_HOUR    ,
	  :PROBE_IP        ,
	  :ERROR_CODE      ,
	  :CONT_ERR_TOTAL  ,
	  :ERROR_PAGE_SEQ  ,
	  :PAGE_TOTAL      ,
	  :BYTE_TOTAL      ,
	  :TS_TOTAL        ,
	  :TS_NETWORK      ,
	  :TS_PING_AVG     ,
	  :TS_PING_START   ,
	  :PING_ERROR	   ,
	  :POINT_TOTAL	   ,
	  :DNS_SERVER	   ,
	  :DEST_IP		   ,
	  :MEMBER_ID	   ,
	  :IS_NOISE		 	
	  )
    ';  

    EXECUTE IMMEDIATE sqlStr 
      USING 
      ID              ,
	  TASK_ID         ,
	  CITY_ID         ,
	  ISP_ID          ,
	  NET_SPEED_ID    ,
	  TM_BASE         ,
	  TM_HOUR         ,
	  TM_DAY          ,
	  TM_HALF_HOUR    ,
	  PROBE_IP        ,
	  ERROR_CODE      ,
	  CONT_ERR_TOTAL  ,
	  ERROR_PAGE_SEQ  ,
	  PAGE_TOTAL      ,
	  BYTE_TOTAL      ,
	  TS_TOTAL        ,
	  TS_NETWORK      ,
	  TS_PING_AVG     ,
	  TS_PING_START   ,
	  PING_ERROR	  ,
	  POINT_TOTAL 	  ,
	  DNS_SERVER	  ,
	  DEST_IP		  ,
	  MEMBER_ID		  ,
	  IS_NOISE		 	
	  ;    

END insertNBTran;


/

