create procedure createMOB_TRAN(tableStr IN varchar2,res OUT number) authid current_user is
  sqlStr    varchar2(4000);
  errorDesc varchar2(4000);
begin
  create_procedure_log('createMOB_TRAN',
                       'create table:NB_MOB_TRAN_' || tableStr,
                       'run');
  --创建TRAN
  sqlStr := 'create table NB_MOB_TRAN_' || tableStr || '
    (
      ID              NUMBER not null,
      TASK_ID         NUMBER,
      CITY_ID         NUMBER,
      ISP_ID          NUMBER,
      NET_SPEED_ID    NUMBER,
      TM_BASE         DATE,
      PROBE_IP        NUMBER,
      ERROR_CODE      NUMBER,
      CONT_ERR_TOTAL  NUMBER,
      POINT_TOTAL     NUMBER default 1,
      ERROR_PAGE_SEQ  NUMBER,  
      PAGE_TOTAL      NUMBER,  
      BYTE_TOTAL      NUMBER,  
      DNS_SERVER   VARCHAR2(128),  
      DNS_SERVER_IP   NUMBER,
      DEST_IP         VARCHAR2(39),
      TS_TOTAL        NUMBER,
      TS_NETWORK      NUMBER,
      MEMBER_ID     INTEGER,
      OS_VER_ID   INTEGER,
      BS_ID      INTEGER,
      BS_VER_ID    INTEGER,
      HW_ID    INTEGER,
      MOBILE_SIGNAL  INTEGER,
      SCREEN_WIDTH  INTEGER,
      SCREEN_HEIGHT  INTEGER,
      longitude  NUMBER,
      latitude  NUMBER,
      IS_NOISE      INTEGER      
    ) pctfree 0';
  execute immediate sqlStr;
  --主键 
  sqlStr := 'alter table NB_MOB_TRAN_' || tableStr || '
      add constraint PK_NB_MOB_TRAN_' || tableStr ||
            ' primary key (ID)
      using index ';
  execute immediate sqlStr;
  --索引
  sqlStr := 'create index IN_MOB_TRAN_PERF_' || tableStr ||
            ' on NB_MOB_TRAN_' || tableStr ||
            ' (TM_BASE,TASK_ID) tableSpace NETBEN_IDX_NEW';
  execute immediate sqlStr;

  --创建Page sequence 
  sqlStr := 'create sequence SEQ_NB_MOB_PAGE_ID_' || tableStr || '
      minvalue 1
      maxvalue 9999999999999999999999999
      start with 1
      increment by 1
      cache 500';
  execute immediate sqlStr;
  res:=0;
  
exception
  when others then
    errorDesc := 'Error :' || sqlerrm || '  tableStr:' || tableStr;
    --DBMS_OUTPUT.PUT_LINE(v_error_desc);
    create_procedure_log('createMOB_TRAN', errorDesc, 'error');
    res:=1;
    
END createMOB_TRAN;


/

