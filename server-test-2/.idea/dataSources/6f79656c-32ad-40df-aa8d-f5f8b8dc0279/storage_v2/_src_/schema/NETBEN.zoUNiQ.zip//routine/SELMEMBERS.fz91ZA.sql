create PROCEDURE "SELMEMBERS"(name_pattern in varchar2, mid out integer) is
  return  integer;
begin
  select id
    into mid
    from nb_m_member
   where username like concat(name_pattern, '%');

  return mid;
end;


/

