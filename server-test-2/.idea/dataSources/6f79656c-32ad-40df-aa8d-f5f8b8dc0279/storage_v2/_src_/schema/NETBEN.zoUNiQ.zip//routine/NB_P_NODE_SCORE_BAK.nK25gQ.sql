create procedure NB_P_NODE_SCORE_bak is

begin

  INSERT INTO NB_M_SCORE_BALANCE
    (ID,
     MEMBER_ID,
     CDATE,
     SCORE,
     SCORE_BALANCE,
     DATA_POINTS,
     DATA_POINTS_TOTAL,
     REASON,
     net_id)
    SELECT SCORE_BAL_ID_SEQ.Nextval,
           MEMBER_ID,
           DD,
           SCORE,
           SCORE_BALANCE,
           DP,
           DP_TOTAL,
           'DP',
           net_id
      FROM (SELECT MEMBER_ID,
                   DD,
                   SCORE,
                   SUM(SCORE) OVER(partition by member_id ORDER BY DD) SCORE_BALANCE,
                   DP,
                   SUM(DP) OVER(partition by member_id, net_id ORDER BY DD) DP_TOTAL,
                   net_id
              FROM (SELECT member_id,
                           trunc(CDATE, 'DD') DD,
                           SUM(SCORE) SCORE,
                           SUM(DATA_POINTS) DP,
                           net_id
                      FROM NB_MBR_SCORE sc
                     WHERE not exists (select *
                              from nb_m_score_balance ba
                             where sc.member_id = ba.member_id)
                       AND CDATE < TRUNC(SYSDATE, 'DD')
                     GROUP BY member_id, TRUNC(CDATE, 'DD'),net_id
                     ORDER BY member_id, DD)
             group BY MEMBER_ID, DD, SCORE, DP, net_id
             ORDER BY DD, MEMBER_ID);
  INSERT INTO NB_M_SCORE_BALANCE
    (ID,
     MEMBER_ID,
     CDATE,
     SCORE,
     SCORE_BALANCE,
     DATA_POINTS,
     DATA_POINTS_TOTAL,
     REASON,
     net_id)
    SELECT SCORE_BAL_ID_SEQ.Nextval,
           MEMBER_ID,
           DD,
           SCORE,
           SCORE_BALANCE,
           DP,
           DP_TOTAL,
           'DP',
           net_id
      FROM (SELECT MEMBER_ID,
                   DD,
                   SCORE,
                   SUM(SCORE) OVER(partition by member_id ORDER BY DD) + SCORE_BAL SCORE_BALANCE,
                   DP,
                   SUM(DP) OVER(partition by member_id, net_id ORDER BY DD) + DP_TO DP_TOTAL,
                   net_id
              FROM (SELECT T.member_id,
                           trunc(T.CDATE, 'DD') DD,
                           SUM(T.SCORE) SCORE,
                           SUM(T.DATA_POINTS) DP,
                           T1.score_balance SCORE_BAL,
                           T1.data_Points_total DP_TO,
                           t.net_id
                      FROM NB_MBR_SCORE T, NB_V_SCORE_BALANCE_MAX T1
                     WHERE T.MEMBER_ID = T1.MEMBER_ID
                       AND T.CDATE > = T1.CDATE + 1
                       AND T.CDATE < TRUNC(SYSDATE, 'DD')
                     GROUP BY T.member_id,
                              TRUNC(T.CDATE, 'DD'),
                              T1.score_balance,
                              T1.data_Points_total,
                              t.net_id
                     ORDER BY member_id, DD)
             group BY MEMBER_ID, DD, SCORE, DP, SCORE_BAL, DP_TO, net_id
             ORDER BY DD, MEMBER_ID);
commit;
end NB_P_NODE_SCORE_bak;


/

