create PROCEDURE          "UPDATE_TRAN_IS_NOISE" authid current_user
is
  sqlStr  varchar2(4000);  
  v_name varchar2(400);
  v_error_desc varchar2(400);
  CURSOR c_emp IS SELECT substr(t.object_name,8) FROM all_objects t where t.object_name like 'NB_TRAN_%';
begin
OPEN c_emp;
LOOP
  begin
    FETCH c_emp INTO v_name;
    EXIT WHEN c_emp%NOTFOUND;
   
    --修改表
    DBMS_OUTPUT.PUT_LINE('start alter table  NB_TRAN'||v_name);
    sqlStr:='alter table NB_TRAN'||v_name||' add IS_NOISE NUMBER default 0';
    execute immediate sqlStr;
    --删除物化视图
    DBMS_OUTPUT.PUT_LINE('drop mv_TRAN'||v_name);
    sqlStr:='drop materialized view mv_tran'||v_name;
    execute immediate sqlStr;
    
     
    --Tran物化视图
    sqlStr:='create materialized view MV_TRAN'||v_name||'
		refresh   force
		start with sysdate next sysdate + 4/24 
		with primary key   as
		(select task_id,
		       city_id,
		       isp_id,
		       net_speed_id,
		       error_code,
		       ping_error,
           is_noise,
		       tm_hour4,
		       (tm_hour4 - mod(to_number(to_char(tm_hour4, '||chr(39)||'hh24'||chr(39)||')) + 8, 8) / 24) as tm_hour8,
		       (tm_hour4 - mod(to_number(to_char(tm_hour4, '||chr(39)||'hh24'||chr(39)||')) + 12, 12) / 24) as tm_hour12,
		       trunc(tm_hour4, '||chr(39)||'dd'||chr(39)||') as tm_day,
		       point_total,
		       round(ts_total,0) as ts_total,
		       round(ts_ping_avg,0) as ts_ping_avg
		  from (select task_id,
		               city_id,
		               isp_id,
		               net_speed_id,
		               error_code,
		               (case when ping_error=0 then 0 else -1 end) as ping_error,
                   is_noise,
		               (tm_hour -
		               mod(to_number(to_char(tm_hour, '||chr(39)||'hh24'||chr(39)||')) + 4, 4) / 24) as tm_hour4,
		               sum(point_total) as point_total,
		               avg(ts_total) as ts_total,
				       avg(ts_ping_avg) as ts_ping_avg
		          from NB_TRAN'||v_name||'
		         group by task_id,
		                  city_id,
		                  isp_id,
		                  net_speed_id,
		                  error_code,
		                  ping_error,
                      is_noise,
		                  (tm_hour -
		                  mod(to_number(to_char(tm_hour, '||chr(39)||'hh24'||chr(39)||')) + 4, 4) / 24)))';  
    execute   immediate   sqlStr;
    --索引
	sqlStr:='create index IN_MV_TRAN_ERROR'||v_name||' on MV_TRAN_'||v_name||' (TM_HOUR4, ERROR_CODE, CITY_ID, TASK_ID) tableSpace NETBEN_IDX';  
    execute   immediate   sqlStr;
    --索引
	sqlStr:='create index IN_MV_TRAN_PERF'||v_name||' on MV_TRAN_'||v_name||' (TM_HOUR4, CITY_ID, TASK_ID, ISP_ID) tableSpace NETBEN_IDX';  
    execute   immediate   sqlStr;    
    
  
        --如果创建失败，则显示出失败的表
    exception when  others then
        v_error_desc := '            ERROR: code: '|| sqlcode || '   NB_TRAN'||v_name;
        DBMS_OUTPUT.PUT_LINE(v_error_desc);
       
    end;
END LOOP;

CLOSE c_emp;  
  
end update_tran_is_noise;


/

