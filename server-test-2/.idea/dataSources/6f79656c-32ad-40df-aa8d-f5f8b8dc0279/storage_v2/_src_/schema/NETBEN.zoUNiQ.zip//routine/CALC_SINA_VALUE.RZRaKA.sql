create PROCEDURE          "CALC_SINA_VALUE" is
  type task_row is table of tmp_sina_task%rowtype;
  type field_row is table of tmp_sina_field%rowtype;
  v_task    task_row;
  v_field   field_row;
  calc_time date;
  sqltext   varchar2(4000);
  errorDesc varchar2(4000);
begin
  sqltext := 'truncate table tmp_sina_mid'; --清空中间表
  execute immediate sqltext;
  calc_time := trunc(sysdate, 'dd');
  select * bulk collect into v_task from tmp_sina_task order by id;
  select * bulk collect
    into v_field
    from tmp_sina_field t
   order by t.field, t.type;
  for i in 1 .. 1 loop
    for j in 1 .. 1 loop
      if (v_task(i).type <> 3 and v_field(j).type <> 3) then
        --处理任务类型1，2
        sqltext := 'insert into tmp_sina_mid SELECT ' || '''' || v_field(j).name || '''' ||
                   ',task_id,
       city_id,
       isp_id,
       (CASE
         WHEN point_base = 0 THEN
          0
         ELSE
          ROUND(' || v_field(j).field || ' / point_base, 0)
       END) AS ' || v_field(j).field || ',
       (CASE
         WHEN point_total = 0 THEN
          0
         ELSE
          point_succ / point_total
       END) AS percent_succ,
       page_seq
  FROM (SELECT task_id,
               PAGE_SEQ,
               city_id,
               isp_id,
               SUM(point_total) AS point_total,
               SUM(CASE
                     WHEN error_code > 600000 THEN
                      0
                     ELSE
                      point_total
                   END) AS point_succ,
               SUM(CASE
                     WHEN per < 0.05 OR per > 0.95 OR error_code > 600000 THEN
                      0
                     ELSE
                      point_total
                   END) AS point_base,
               SUM(CASE
                     WHEN per < 0.05 OR per > 0.95 OR error_code > 600000 THEN
                      0
                     ELSE ' || v_field(j).field ||
                   ' * point_total
                   END) AS ' || v_field(j).field || ',
             SUM(CASE
                     WHEN per < 0.05 OR per > 0.95 THEN
                      point_total
                    ELSE
                     0
                  END) AS point_trim
          FROM (SELECT
                 task_id,
                 isp_id,
                 city_id,' || v_field(j).field || ' as ' || v_field(j)
                  .field || ',
                 point_total,
                 page_seq,
                 error_code,
                 percent_rank() over(partition by PAGE_SEQ,task_id, city_id, isp_id order by ' || v_field(j)
                  .field ||
                   ') as per
                  From NB_page_23771
                 WHERE is_noise = 0
                   and task_id=:task_id
                   AND tm_base >=:a
                  AND tm_base <=:b)
        GROUP BY task_id,page_seq,city_id, isp_id ) ORDER BY city_id, isp_id, task_id';
      
          execute immediate sqltext
          using v_task(i).task_id, calc_time - 7, calc_time;
      end if;
    
      --处理任务类型3
     
      if (v_task(i).type = 3 and v_field(j).type = 3) then
      
        sqltext := 'insert into tmp_sina_mid SELECT ' || '''' || v_field(j).name || '''' ||
                   ',task_id,
       city_id,
       isp_id,
       (CASE
         WHEN point_base = 0 THEN
          0
         ELSE
          ROUND(' || v_field(j).field || ' / point_base, 0)
       END) AS ' || v_field(j).field || ',
       (CASE
         WHEN point_total = 0 THEN
          0
         ELSE
          point_succ / point_total
       END) AS percent_succ,
       null
  FROM (SELECT task_id,
               city_id,
               isp_id,
               SUM(point_total) AS point_total,
               SUM(CASE
                     WHEN error_code > 600000 THEN
                      0
                     ELSE
                      point_total
                   END) AS point_succ,
               SUM(CASE
                     WHEN  per > 0.98 OR error_code > 600000 THEN
                      0
                     ELSE
                      point_total
                   END) AS point_base,
               SUM(CASE
                     WHEN  per > 0.98 OR error_code > 600000 THEN
                      0
                     ELSE ' || v_field(j).field ||
                   ' * point_total
                   END) AS ' || v_field(j).field || ',
             SUM(CASE
                     WHEN  per > 0.98 THEN
                      point_total
                    ELSE
                     0
                  END) AS point_trim
          FROM (SELECT
                 task_id,
                 isp_id,
                 city_id,' || v_field(j).field || ' as ' || v_field(j)
                  .field || ',
                 point_total,
                 error_code,
                 percent_rank() over(partition by task_id, city_id, isp_id order by ' || v_field(j)
                  .field || ') as per
                  From NB_stream_23771
                 WHERE is_noise = 0
                   and task_id=:task_id
                   AND tm_base >=:a
                  AND tm_base <=:b)
          GROUP BY city_id, isp_id, task_id)
        ORDER BY city_id, isp_id, task_id';
         --dbms_output.put_line(sqltext);
        execute immediate sqltext
          using v_task(i).task_id, calc_time - 7, calc_time;
      end if;
      
      commit;
    end loop;
  end loop;
exception
  when others then
    errorDesc := ' Error Code:' || sqlcode;
    DBMS_OUTPUT.PUT_LINE(errorDesc);
end;


/

