create view NB_V_MEMBER_DISABLED as
SELECT ID, USERNAME from netben.NB_M_MEMBER t where STATUS=0


/

