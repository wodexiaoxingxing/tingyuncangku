create procedure in_lt_ping_period(sd date,days number) authid current_user
is
   sqlStr varchar2(4000);
   startDate date;
   endDate date;
   errorDesc varchar2(4000);
   v_s number;
begin
create_procedure_log('in_lt_ping_period','begin','run');
if sd is null or days is null then
  startDate:=trunc(sysdate-1,'dd');
  endDate:=startDate+1;
else
  startDate:=trunc(sd,'dd');
  endDate:=startDate+days;
end if;
for item in (select substr(t.table_name, 9) as name from user_tables t where t.table_name like 'NB_PING_%') loop
begin
   create_procedure_log('in_lt_ping_period','tableStr:'||item.name,'run');
   --判断是否该表已经创建
   select count(*) into v_s from user_tables t where t.table_name = 'LT_PING_'||item.name;
   if (v_s<1) then
       --表不存在，创建新表
        sqlStr:='create table LT_PING_'||item.name||'
         (
            TASK_ID        NUMBER,
            PAGE_SEQ       NUMBER default 1,
            CITY_ID        NUMBER,
            ISP_ID         NUMBER,
						dest_city_id   number,
						dest_isp_id    number
						dest_ip        VARCHAR2(39),
            NET_SPEED_ID   NUMBER,
            TM_DAY         DATE,
            ERROR_CODE     NUMBER,
            POINT_TOTAL    NUMBER,
            TS_TOTAL       NUMBER,
            PING_PACKET_LOST NUMBER
          )';
         execute   immediate   sqlStr;
         --创建索引
         sqlStr:='create index IN_LT_PING_PERF_'||item.name||' on LT_PING_'||item.name||' (task_id,tm_day,error_code) tableSpace netben_ind_NEW';
         execute   immediate   sqlStr;
     end if;

  --删除指定日期的长期库中的数据,防止重复数据
  sqlStr := 'delete from lt_ping_'||item.name||' where tm_day  >=:sDate and tm_day < :eDate';
  execute immediate sqlStr using startDate,endDate;
  commit;

  --从实时库中插入指定日期的数据
  sqlStr:='insert into lt_ping_'||item.name||'
           (task_id,page_seq,city_id,isp_id,dest_city_id,dest_isp_id,dest_ip,net_speed_id,tm_day,error_code,
            point_total,ts_total,ping_packet_lost)
        select
           task_id,
           page_seq,
           city_id,
           isp_id,
					 dest_city_id,
					 dest_isp_id,
					 dest_ip,
           net_speed_id,
           trunc(tm_base,''dd'') as tm_day,
           error_code,
           sum(point_total),
           round(avg(ts_total),0) as ts_total,
           round(avg(ping_packet_lost),0) as ping_packet_lost
        from NB_PING_'||item.name||'
           where tm_base >= :sDate and  tm_base < :eDate and is_noise = 0
           group by task_id,
                    page_seq,
                    trunc(tm_base,''dd''),
                    error_code,
                    city_id,
                    isp_id,
										dest_city_id,
										dest_isp_id,
										dest_ip,
                    net_speed_id
        ';
       execute immediate sqlStr using startDate,endDate;
       commit;
     exception when  others then
        errorDesc := 'Tabel Str ' || item.name || ' Error Code:'|| sqlcode || '  Sql:' ;
        create_procedure_log('in_lt_ping_period',errorDesc,'error');
  end;
end loop;
create_procedure_log('in_lt_ping_period','end','run');
end in_lt_ping_period;
/

