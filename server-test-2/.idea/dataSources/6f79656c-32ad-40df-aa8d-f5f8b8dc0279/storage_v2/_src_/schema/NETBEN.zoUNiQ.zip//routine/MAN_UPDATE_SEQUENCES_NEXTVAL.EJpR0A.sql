create PROCEDURE          "MAN_UPDATE_SEQUENCES_NEXTVAL" 
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(4000);
  v_s number;
begin
  for seqName in(
    select s.sequence_name as name
    from  USER_SEQUENCES s
           inner join TEMP_USER_SEQUENCES s0 on s.sequence_name = s0.sequence_name
    where s0.last_number > s.last_number
    
  ) loop
  begin
    select s0.last_number - s.last_number into v_s
    from USER_SEQUENCES s
           inner join TEMP_USER_SEQUENCES s0 on s.sequence_name = s0.sequence_name
    where s0.last_number > s.last_number and s.sequence_name = seqname.name;
      if v_s > 0 then
        sqlStr := 'alter sequence '|| seqName.name || ' increment by ' || v_s;
  execute   immediate   sqlStr ;
  dbms_output.put_line(sqlStr);
  sqlStr := 'select '|| seqName.name || '.nextval from dual';
  execute   immediate   sqlStr ;
  dbms_output.put_line(sqlStr);
  sqlStr := 'alter sequence '|| seqName.name || ' increment by 1';
  execute   immediate   sqlStr ;
  dbms_output.put_line(sqlStr);
      end if;

    exception when  others then
        v_error_desc := 'Error Code:'|| sqlerrm || '  Sql:'||sqlStr ;
        --DBMS_OUTPUT.PUT_LINE(sqlStr);
     --   create_procedure_log('alter_lt_page_add_field',v_error_desc,sqlerrm);

  end;
  end loop;
end MAN_update_sequences_nextval;


/

