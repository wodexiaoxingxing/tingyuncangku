create function is_date(dt varchar2, ft varchar2) return integer is
  val    date;
  inFt  varchar2(32);
begin
  if ft is null then
     inFt:='yyyy-mm-dd hh24:mi:ss';
  else
    inFt:=ft;
  end if;
  val := to_date(dt, '''' || inFt || '''');
  return 1;
exception
  when others then
    return 0;
end is_date;


/

