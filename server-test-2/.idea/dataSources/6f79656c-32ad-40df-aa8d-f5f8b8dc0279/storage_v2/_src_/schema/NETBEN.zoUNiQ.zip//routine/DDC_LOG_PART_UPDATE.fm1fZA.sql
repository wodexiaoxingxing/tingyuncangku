create PROCEDURE "DDC_LOG_PART_UPDATE" (
    suff in varchar2, -- col/dsp
    updateType in varchar2 -- add/del
)
authid current_user is
tableName varchar2(32);--表名称
partNamePref varchar2(32);--分区前缀
sqlStr varchar2(4000);
position_min number; --最小分区的位置
part_name_min varchar2(64);--最小分区的名称
position_curr number;--当前日期的分区的位置
position_max number;--最大分区的位置
part_date_max date;--最大分区的日期
part_name_new varchar2(64);--要新增的分区的名称
part_value_new varchar2(128);--要新增的分区的值范围
date_curr date;--当前日期
date_base date ;--基准日期
error_desc varchar2(1000);

--本存储过程支持对两个ddc_log表的分区维护，
--增加，判断是否是30天内，如果是，可以增加一个（一次只增加一个),否则不能增加
--删除，判断是否是30天内，如果是，不能删除，否则删除最前一个分区（一次只能删除一个分区)
begin
    if (suff = 'col') then
       tableName := 'NB_M_DDC_LOG_COL';
       partNamePref := 'PART_DDC_LOG_COL_';
       date_base  := TO_DATE(' 2011-08-28', 'SYYYY-MM-DD');
    elsif (suff = 'dsp') then
       tableName := 'NB_M_DDC_LOG_DSP';
       partNamePref := 'PART_DDC_LOG_DSP_';
       date_base  := TO_DATE(' 2012-07-01', 'SYYYY-MM-DD');     
    end if;

    --取出当前日期分区的相对位置
    date_curr:=sysdate;
 

  --select partition_position into position_curr from user_tab_partitions p
    --     where table_name = tableName and partition_name = partNamePref||to_char(date_curr,'yymmdd');

position_curr := sysdate-date_base;
          
    --取出最大一个分区的相对位置及分区名称
     select date_base+to_number(substr(partition_name,18)),to_number(substr(partition_name,18))+1 into part_date_max,position_max
         from user_tab_partitions where partition_position =
           (select max(partition_position)
              from user_tab_partitions p
             where table_name = tableName)
        and table_name = tableName;
        
       --       dbms_output.put_line(part_date_max);       
        --      dbms_output.put_line(position_max);        
               
    --取出最小一个分区的相对位置及分区名称
    select partition_name,partition_position into part_name_min,position_min
         from user_tab_partitions where partition_position =
           (select min(partition_position)
              from user_tab_partitions p
             where table_name = tableName)
        and table_name = tableName;
           
        --      dbms_output.put_line(part_name_min);       
        --      dbms_output.put_line(position_min);   
  
    --如果是删除一个分区
    if (updateType = 'del') then
    --dbms_output.put_line('curr='||position_curr||' min='||position_min);
        if (position_curr - position_min > 30) then
            sqlStr := 'ALTER TABLE '|| tableName || ' DROP PARTITION '||part_name_min;
          dbms_output.put_line(sqlStr);
            execute immediate sqlStr;
            create_procedure_log('ddc_log_part_update','drop ' || tableName||' part: '||part_name_min,'execute');
        else
            create_procedure_log('ddc_log_part_update','drop ' || tableName||' part: '||part_name_min||'在30天以内，不能删除','alarm');
        end if;
    
        
    elsif (updateType = 'add') then
        part_name_new := partNamePref || position_max;
        part_value_new :='to_date('''||to_char(part_date_max+1,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
         dbms_output.put_line(position_max );
              
       if (position_max - position_curr < 30) then
            sqlStr := 'ALTER TABLE '||tableName || ' ADD PARTITION '||part_name_new||' VALUES LESS THAN('||part_value_new||')';
            dbms_output.put_line(sqlStr);
            execute immediate sqlStr;
            create_procedure_log('ddc_log_part_update','add ' || tableName||' part: '||part_name_new,'execute');
        else
            create_procedure_log('ddc_log_part_update','add ' || tableName||' part: '||part_name_new||'在30天以外，不能增加','alarm');
       end if;
    end if;
 
    exception when  others then
        if (updateType = 'del') then
            error_desc := 'Error Code:'|| sqlerrm || ';drop  tableName:' || tableName || ' part:'|| part_name_min ;
        else
            error_desc := 'Error Code:'|| sqlerrm || ';add   tableName:' || tableName || ' part:'|| part_name_new ;
        end if;
        create_procedure_log('ddc_log_part_update',error_desc,'error');
                      dbms_output.put_line(sqlerrm);
end ddc_log_part_update;


/

