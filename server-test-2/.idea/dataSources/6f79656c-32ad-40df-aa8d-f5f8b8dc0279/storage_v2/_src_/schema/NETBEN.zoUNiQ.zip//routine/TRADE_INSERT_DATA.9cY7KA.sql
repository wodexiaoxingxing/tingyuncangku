create PROCEDURE "TRADE_INSERT_DATA" (
  sDate in date,eDate in date
) authid current_user
is
  sqlStr varchar2(8000);
  startDate date:=trunc(sDate,'dd');
  endDate date:=trunc(eDate,'dd');
  dataCount number:=endDate-startDate;
  calcDate date;
  errorDesc varchar2(4000);
  reportCode varchar2(32);
  currYear char(4);
  currOrder char(2);
  ctime date:=sysdate;
begin
endDate:=trunc(endDate,'dd');
--首先取出需要处理的行业数据
for trade in (select id,code,table_str,task_type from nb_trade_list) loop
begin
   create_procedure_log('trade_insert_data','tableStr:'||trade.table_str,'message');
   -- 1 每天生成基础数据
   -- 删除指定天的数据
   sqlStr:='delete from nb_trade_day where tm_day>=:sDate and tm_day<:eDate and table_str=:tableStr';
   execute immediate sqlStr using startDate,endDate,trade.table_str;
   commit;
   sqlStr:='delete from nb_trade_stream_day where tm_day>=:sDate and tm_day<:eDate and table_str=:tableStr';
   execute immediate sqlStr using startDate,endDate,trade.table_str;
   commit;
   -- 开始生成数据
   -- 首先生成流媒体数据，指定流媒体的表后缀
   -- 流媒体与页面数据分开，流媒体的数据插入nb_trade_stream_day这个表
   if (trade.task_type=3) then
     sqlStr:='insert into nb_trade_stream_day
             (tm_day,task_id,table_str,point_total,point_error,point_succ,ts_total,ts_user,ctime,rate_download,
             ts_dns,ts_connect,ts_buffer,ts_rebuffer,ts_first_play,ts_play,ts_full,rece_package,lose_package,
             ts_connect_tcp,ts_first_packet,ts_contents,play_in_5s,fluency,buffer_count,data_rate)
         select
             tm_day,task_id,:tableStr,point_total,point_error,point_succ,ts_total,ts_user,sysdate,rate_download,
             ts_dns,ts_connect,ts_buffer,ts_rebuffer,ts_first_play,ts_play,ts_full,rece_package,lose_package,
             ts_connect_tcp,ts_first_packet,ts_contents,play_in_5s,fluency,buffer_count,data_rate
         from(
           select
             trunc(tm_base,''dd'') as tm_day,
  		       task_id,
  		       sum(point_total) as point_total,
             sum(case when error_code > 600000 then point_total else 0 end) as point_error,
             sum(case when error_code > 600000 then 0 else point_total end) as point_succ,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_total end),0) as ts_total,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_first_play end),0) as ts_user,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else rate_download end),0) as rate_download,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_dns end),0) as ts_dns,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_connect end),0) as ts_connect,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_buffer end),0) as ts_buffer,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_rebuffer end),0) as ts_rebuffer,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_first_play end),0) as ts_first_play,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_play end),0) as ts_play,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_full end),0) as ts_full,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else rece_package end),0) as rece_package,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else lose_package end),0) as lose_package,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_connect_tcp end),0) as ts_connect_tcp,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_first_packet end),0) as ts_first_packet,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_contents end),0) as ts_contents,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else play_in_5s end),0) as play_in_5s,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else fluency end),0) as fluency,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else buffer_count end),0) as buffer_count,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else data_rate end),0) as data_rate
  		     from(
             select
                tm_base,
                task_id,
                point_total,
                ts_total,
                ts_user,
                ts_first_play,
                rate_download,
                error_code,
                ts_dns,
                ts_connect,
                ts_buffer,
                ts_rebuffer,
                ts_play,
                ts_full,
                rece_package,
                lose_package,
                ts_connect_tcp,ts_first_packet,ts_contents,play_in_5s,fluency,buffer_count,data_rate,
                percent_rank() over(partition by task_id,trunc(tm_base,''dd'') order by ts_total) as per
             from  nb_stream_'||trade.table_str||'
             where tm_base >= :sDate and  tm_base < :eDate and is_noise = 0 and ts_total>0 and rate_download>0
                   and task_id in (select id from nb_m_task where owner_id=:tabStr)
               )
           
  		     group by task_id,trunc(tm_base,''dd'')
          )';
     execute immediate sqlStr using trade.table_str,startDate,endDate,trade.table_str;
     commit;
   else
   --然后生成页面数据
     sqlStr:='insert into nb_trade_day
             (tm_day,task_id,table_str,point_total,point_error,point_succ,ts_total,ts_user,
             stddev_total,stddev_user,ctime,rate_download,rate_user,ts_network,byte_total,byte_first,
             rate_download_page_base,cont_ele_total,byte_page_base,ts_page_base,
             ts_dns,ts_connect,ts_ssl,ts_redirect,ts_request,ts_first_packet,ts_client,ts_contents,ts_extra_data,ts_open_page,ts_close,
             ts_connect_total,ts_dns_total,num_first_elem,num_host,num_connect,num_dom,cont_err_total)
         select
             tm_day,task_id,:tableStr,point_total,point_error,point_succ,ts_total,ts_user,
             stddev_total,stddev_user,sysdate,rate_download,rate_user,ts_network,byte_total,byte_first,
             rate_download_page_base,cont_ele_total,byte_page_base,ts_page_base,
             ts_dns,ts_connect,ts_ssl,ts_redirect,ts_request,ts_first_packet,ts_client,ts_contents,ts_extra_data,ts_open_page,ts_close,
             ts_connect_total,ts_dns_total,num_first_elem,num_host,num_connect,num_dom,cont_err_total
         from(
           select
             trunc(tm_base,''dd'') as tm_day,
  		       task_id,
  		       sum(point_total) as point_total,
             sum(case when error_code > 600000 then point_total else 0 end) as point_error,
             sum(case when error_code > 600000 then 0 else point_total end) as point_succ,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_total end),0) as ts_total,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_user end),0) as ts_user,
             round(stddev(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_total end),0) as stddev_total,
             round(stddev(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_user end),0) as stddev_user,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else rate_download end),0) as rate_download,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else byte_first/ts_user*1000 end),0) as rate_user,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_network end),0) as ts_network,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_dns_total end),0) as ts_dns_total,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else byte_total end),0) as byte_total,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else byte_first end),0) as byte_first,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else rate_download_page_base end),0) as rate_download_page_base,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else cont_ele_total end),0) as cont_ele_total,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else byte_page_base end),0) as byte_page_base,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_page_base end),0) as ts_page_base,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_dns end),0) as ts_dns,
             
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_connect end),0) as ts_connect,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_connect_total end),0) as ts_connect_total,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_ssl end),0) as ts_ssl,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_redirect end),0) as ts_redirect,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_request end),0) as ts_request,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_first_packet end),0) as ts_first_packet,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_client end),0) as ts_client,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_contents end),0) as ts_contents,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_extra_data end),0) as ts_extra_data,
             
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_open_page end),0) as ts_open_page,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else num_first_elem end),0) as num_first_elem,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else num_host end),0) as num_host,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else num_connect end),0) as num_connect,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else num_dom end),0) as num_dom,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else cont_err_total end),0) as cont_err_total,
             round(avg(case when error_code > 600000 or per > 0.95 or per < 0.05 then null else ts_close end),0) as ts_close
  		     from(
             select
                tm_base,task_id,point_total,ts_total,ts_user,rate_download,error_code,byte_total,byte_first,ts_network,
                rate_download_page_base,cont_ele_total,byte_page_base,ts_page_base,
                ts_dns,ts_connect,ts_ssl,ts_redirect,ts_request,ts_first_packet,ts_client,ts_contents,ts_extra_data,ts_open_page,ts_close,
                ts_connect_total,ts_dns_total,num_first_elem,num_host,num_connect,num_dom,cont_err_total,
                percent_rank() over(partition by task_id,trunc(tm_base,''dd'') order by ts_total) as per
             from  nb_page_'||trade.table_str||'
             where tm_base >= :sDate and  tm_base < :eDate and is_noise = 0 and ts_user>0 and ts_total>0 and ts_network>0
                   and task_id in (select id from nb_m_task where  owner_id=:tabStr)
               )
           
  		     group by task_id,trunc(tm_base,''dd'')
          )';
     execute immediate sqlStr using trade.table_str,startDate,endDate,trade.table_str;
     commit;
   end if;
   --create_procedure_log('trade_insert_data','insert day tableStr:'||trade.table_str,'message');
   for i in 1..dataCount loop
     -- 2 生成周报表数据,计算上一周的数据
     -- 判断是否当前日期是否周日，是开始生成数据 否不生成数据 生成数据上周日-周六
     calcDate:=startDate+i;
     if (to_char(calcDate,'d')=1) then
     --报表code 行业code + 当前年份 + 报表类型 + 当前顺序号
       currYear:=to_char(calcDate-28,'yyyy');
       currOrder:=to_char(calcDate-28,'ww');
       reportCode:=trade.code || currYear || '1' || currOrder;
       -- 删除生成的数据
       sqlStr:='delete from nb_trade_report_detail where report_id=:repId';
       execute immediate sqlStr using to_number(reportCode);
       commit;
	   sqlStr:='delete from nb_trade_report_stream_detail where report_id=:repId';
       execute immediate sqlStr using to_number(reportCode);
       commit;
       -- 插入每周的页面数据
       --   页面数据和流媒体数据分开，页面数据插入nb_trade_report_detail表，流媒体数据插入nb_trade_report_stream_detail表
       sqlStr:='insert into nb_trade_report_detail
              (report_id,task_id,ts_total,ts_user,available,stddev_total,stddev_user,point_total,point_succ,ctime,rate_download,rate_user,
              rate_download_page_base,cont_ele_total,byte_total,byte_first,byte_page_base,
              ts_dns,ts_connect,ts_ssl,ts_redirect,ts_request,ts_first_packet,ts_client,ts_contents,ts_extra_data,ts_open_page,ts_close,
              ts_network,ts_page_base,ts_connect_total,ts_dns_total,num_first_elem,num_host,num_connect,num_dom,cont_err_total)
          select
             :reportId,task_id,ts_total,ts_user,available,stddev_total,stddev_user,point_total,point_succ,:ctime,rate_download,rate_user,
             rate_download_page_base,cont_ele_total,byte_total,byte_first,byte_page_base,
             ts_dns,ts_connect,ts_ssl,ts_redirect,ts_request,ts_first_packet,ts_client,ts_contents,ts_extra_data,ts_open_page,ts_close,
             ts_network,ts_page_base,ts_connect_total,ts_dns_total,num_first_elem,num_host,num_connect,num_dom,cont_err_total
          from
             (select
                task_id,
                round(case when sum(point_succ)=0 then 0 else sum(ts_total*point_succ)/sum(point_succ) end,0) as ts_total,
                round(case when sum(point_succ)=0 then 0 else sum(ts_user*point_succ)/sum(point_succ) end,0) as ts_user,
                round(sum(point_succ)/sum(point_total)*100,2) as available,
                round(case when sum(point_succ)=0 then 0 else sum(stddev_total*point_succ)/sum(point_succ) end,0) as stddev_total,
                round(case when sum(point_succ)=0 then 0 else sum(stddev_user*point_succ)/sum(point_succ) end,0) as stddev_user,
                sum(point_total) as point_total,
                sum(point_succ) as point_succ,
                round(case when sum(ts_network*point_succ)=0 then 0 else sum(byte_total*point_succ)/sum(ts_network*point_succ)*1000 end,0) as rate_download,
                round(case when sum(ts_user*point_succ)=0 then 0 else sum(byte_first*point_succ)/sum(ts_user*point_succ)*1000 end,0) as rate_user,
                round(case when sum(ts_page_base*point_succ)=0 then 0 else sum(byte_page_base*point_succ)/sum(ts_page_base*point_succ)*1000 end,0) as rate_download_page_base,
                round(case when sum(point_succ)=0 then 0 else sum(cont_ele_total*point_succ)/sum(point_succ) end,2) as cont_ele_total,
                round(case when sum(point_succ)=0 then 0 else sum(byte_total*point_succ)/sum(point_succ) end,0) as byte_total,
                round(case when sum(point_succ)=0 then 0 else sum(byte_first*point_succ)/sum(point_succ) end,0) as byte_first,
                round(case when sum(point_succ)=0 then 0 else sum(byte_page_base*point_succ)/sum(point_succ) end,0) as byte_page_base,
                round(case when sum(point_succ)=0 then 0 else sum(ts_page_base*point_succ)/sum(point_succ) end,0) as ts_page_base,
                round(case when sum(point_succ)=0 then 0 else sum(ts_network*point_succ)/sum(point_succ) end,0) as ts_network,
                round(case when sum(point_succ)=0 then 0 else sum(ts_dns_total*point_succ)/sum(point_succ) end,0) as ts_dns_total,
                round(case when sum(point_succ)=0 then 0 else sum(ts_dns*point_succ)/sum(point_succ) end,0) as ts_dns,
                
                round(case when sum(point_succ)=0 then 0 else sum(ts_connect*point_succ)/sum(point_succ) end,0) as ts_connect,
                round(case when sum(point_succ)=0 then 0 else sum(ts_connect_total*point_succ)/sum(point_succ) end,0) as ts_connect_total,
                round(case when sum(point_succ)=0 then 0 else sum(ts_ssl*point_succ)/sum(point_succ) end,0) as ts_ssl,
                round(case when sum(point_succ)=0 then 0 else sum(ts_redirect*point_succ)/sum(point_succ) end,0) as ts_redirect,
                round(case when sum(point_succ)=0 then 0 else sum(ts_request*point_succ)/sum(point_succ) end,0) as ts_request,
                round(case when sum(point_succ)=0 then 0 else sum(ts_first_packet*point_succ)/sum(point_succ) end,0) as ts_first_packet,
                round(case when sum(point_succ)=0 then 0 else sum(ts_client*point_succ)/sum(point_succ) end,0) as ts_client,
                round(case when sum(point_succ)=0 then 0 else sum(ts_contents*point_succ)/sum(point_succ) end,0) as ts_contents,
                round(case when sum(point_succ)=0 then 0 else sum(ts_extra_data*point_succ)/sum(point_succ) end,0) as ts_extra_data,
                
                round(case when sum(point_succ)=0 then 0 else sum(ts_open_page*point_succ)/sum(point_succ) end,0) as ts_open_page,
                round(case when sum(point_succ)=0 then 0 else sum(num_first_elem*point_succ)/sum(point_succ) end,0) as num_first_elem,
                round(case when sum(point_succ)=0 then 0 else sum(num_host*point_succ)/sum(point_succ) end,0) as num_host,
                round(case when sum(point_succ)=0 then 0 else sum(num_connect*point_succ)/sum(point_succ) end,0) as num_connect,
                round(case when sum(point_succ)=0 then 0 else sum(num_dom*point_succ)/sum(point_succ) end,0) as num_dom,
                round(case when sum(point_succ)=0 then 0 else sum(cont_err_total*point_succ)/sum(point_succ) end,0) as cont_err_total,
                round(case when sum(point_succ)=0 then 0 else sum(ts_close*point_succ)/sum(point_succ) end,0) as ts_close
             from nb_trade_day
             where table_str=:tableStr
                and tm_day >= :startDate
                and tm_day <  :endDate
             group by task_id)';
       --trunc(date,'d') 取某星期的第一天的日期，防止可能计算的不是周的第一天
       execute immediate sqlStr using reportCode,ctime,trade.table_str,trunc(calcDate-28,'d'),trunc(calcDate,'d');
       commit;

       -- 插入每周的流媒体数据
       --   页面数据和流媒体数据分开，页面数据插入nb_trade_report_detail表，流媒体数据插入nb_trade_report_stream_detail表
       sqlStr:='insert into nb_trade_report_stream_detail
              (report_id,task_id,ts_total,ts_user,available,stddev_total,stddev_user,point_total,point_succ,ctime,rate_download,
              ts_dns,ts_connect,ts_buffer,ts_rebuffer,ts_first_play,ts_play,ts_full,rece_package,lose_package,
              ts_connect_tcp,ts_first_packet,ts_contents,play_in_5s,fluency,buffer_count,data_rate)
          select
             :reportId,task_id,ts_total,ts_user,available,stddev_total,stddev_user,point_total,point_succ,:ctime,rate_download,
             ts_dns,ts_connect,ts_buffer,ts_rebuffer,ts_first_play,ts_play,ts_full,rece_package,lose_package,
             ts_connect_tcp,ts_first_packet,ts_contents,play_in_5s,fluency,buffer_count,data_rate
          from
             (select
                task_id,
                round(case when sum(point_succ)=0 then 0 else sum(ts_total*point_succ)/sum(point_succ) end,0) as ts_total,
                round(case when sum(point_succ)=0 then 0 else sum(ts_user*point_succ)/sum(point_succ) end,0) as ts_user,
                round(sum(point_succ)/sum(point_total)*100,2) as available,
                
                0 as stddev_total,
                0  as stddev_user,
                
                sum(point_total) as point_total,
                sum(point_succ) as point_succ,
                
                round(case when sum(point_succ)=0 then 0 else sum(rate_download*point_succ)/sum(point_succ) end,0) as rate_download,
                
                round(case when sum(point_succ)=0 then 0 else sum(ts_dns*point_succ)/sum(point_succ) end,0) as ts_dns,
                round(case when sum(point_succ)=0 then 0 else sum(ts_connect*point_succ)/sum(point_succ) end,0) as ts_connect,
                round(case when sum(point_succ)=0 then 0 else sum(ts_buffer*point_succ)/sum(point_succ) end,0) as ts_buffer,
                round(case when sum(point_succ)=0 then 0 else sum(ts_rebuffer*point_succ)/sum(point_succ) end,0) as ts_rebuffer,
                round(case when sum(point_succ)=0 then 0 else sum(ts_first_play*point_succ)/sum(point_succ) end,0) as ts_first_play,
                round(case when sum(point_succ)=0 then 0 else sum(ts_play*point_succ)/sum(point_succ) end,0) as ts_play,
                round(case when sum(point_succ)=0 then 0 else sum(ts_full*point_succ)/sum(point_succ) end,0) as ts_full,
                round(case when sum(point_succ)=0 then 0 else sum(rece_package*point_succ)/sum(point_succ) end,0) as rece_package,
                round(case when sum(point_succ)=0 then 0 else sum(lose_package*point_succ)/sum(point_succ) end,0) as lose_package,
                round(case when sum(point_succ)=0 then 0 else sum(ts_connect_tcp*point_succ)/sum(point_succ) end,0) as ts_connect_tcp,
                round(case when sum(point_succ)=0 then 0 else sum(ts_first_packet*point_succ)/sum(point_succ) end,0) as ts_first_packet,
                round(case when sum(point_succ)=0 then 0 else sum(ts_contents*point_succ)/sum(point_succ) end,0) as ts_contents,
                round(case when sum(point_succ)=0 then 0 else sum(play_in_5s*point_succ)/sum(point_succ) end,0) as play_in_5s,
                round(case when sum(point_succ)=0 then 0 else sum(fluency*point_succ)/sum(point_succ) end,0) as fluency,
                round(case when sum(point_succ)=0 then 0 else sum(buffer_count*point_succ)/sum(point_succ) end,0) as buffer_count,
                round(case when sum(point_succ)=0 then 0 else sum(data_rate*point_succ)/sum(point_succ) end,0) as data_rate
             from nb_trade_stream_day
             where table_str=:tableStr
                and tm_day >= :startDate
                and tm_day <  :endDate
             group by task_id)';
       --trunc(date,'d') 取某星期的第一天的日期，防止可能计算的不是周的第一天
       execute immediate sqlStr using reportCode,ctime,trade.table_str,trunc(calcDate-28,'d'),trunc(calcDate,'d');
       commit;
     end if;
   end loop;
   exception when  others then
      errorDesc := 'TableStr:'||trade.table_str||' Error Code:'|| sqlcode || '  Sql:' ;
      DBMS_OUTPUT.PUT_LINE(errorDesc);
      create_procedure_log('trade_insert_all_data',errorDesc,'error');
  end;
end loop;
   --开始计算行业指数，计算的范围是刚刚生成的数据
   --首先删除可能重复的数据(页面数据)
   sqlStr:='delete from nb_trade_report_index where report_id in(select distinct report_id from nb_trade_report_detail where ctime=:ctime)';
   execute immediate sqlStr using ctime;
   commit;
   --首先删除可能重复的数据(流媒体数据)
   sqlStr:='delete from nb_trade_report_index where report_id in(select distinct report_id from nb_trade_report_stream_detail where ctime=:ctime)';
   execute immediate sqlStr using ctime;
   commit;
   --总打开时间/总下载时间
   sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''T'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_total*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80 and ts_total < 40000
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
	--基础页面下载时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''B'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_page_base*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
	--网络层时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''N'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_network*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --DNS时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''D'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_dns*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --DNS解析总时间(dns总连接时间)
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''DT'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_dns_total*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --建立连接时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''C'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_connect*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --建立连接总时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''CT'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_connect_total*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --SSL握手时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''S'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_ssl*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --重定向时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''R'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_redirect*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --发出请求时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''Q'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_request*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --首包时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''F'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_first_packet*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --客户端时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''L'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_client*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --内容下载时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''O'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_contents*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
	--关闭连接时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''E'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_close*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
	--总字节数
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''BY'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(byte_total*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
	--基础页面下载字节数
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''PB'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(byte_page_base*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
	--下载速度
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''RD'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(rate_download*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
	--基础页面下载速度
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''RDP'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(rate_download_page_base*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --首屏下载字节数(首屏字节数)
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''FB'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(byte_first*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
	--页面元素个数（页面对象数）
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''EL'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(cont_ele_total*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
	--首屏对象数(首屏元素个数)
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''FE'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(num_first_elem*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --首屏时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''U'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_user*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80 and ts_user < 10000
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
	--DNS解析次数(dns总解析次数)
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''H'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(num_host*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --建立连接次数(总连接次数 )
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''CC'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(num_connect*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --DOM元素个数
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''DE'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(num_dom*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --内容错误个数(元素错误个数)
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''CE'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(cont_err_total*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --可用性
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''A'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(point_succ)/sum(point_total)*100,2) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --首屏下载速度
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''RU'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(rate_user*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --接收额外数据时间(额外等待时间)
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''X'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_extra_data*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --页面打开时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''P'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_open_page*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --******流媒体数据******--
	--DNS时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''D'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_dns*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_stream_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --TCP连接时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''CST'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_connect_tcp*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_stream_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --首包时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''F'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_first_packet*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_stream_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --内容下载时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''O'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_contents*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_stream_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --比特率(bps)
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''BR'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(rate_download*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_stream_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --码流
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''DR'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(data_rate*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_stream_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
	--监测时长(完整播放时间)
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''FU'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_full*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_stream_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
	--连接流媒体时间（缓冲前准备时间）
    sqlStr:='insert into nb_trade_report_index
               (report_id,field,trade_index,point_total,point_succ,ctime)
           select
               report_id,''CSS'',trade_index,point_total,point_succ,:ctime
           from(
             select
               report_id,
               round(sum(ts_connect*point_succ)/sum(point_succ),0) as trade_index,
               sum(point_total) as point_total,
               sum(point_succ) as point_succ
             from nb_trade_report_stream_detail
             where ctime=:ctime and available >= 80
             group by report_id)';
     execute immediate sqlStr using ctime,ctime;
     commit;
	 --缓冲时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''BF'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_buffer*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_stream_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --再缓冲时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''RB'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_rebuffer*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_stream_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
	 --播放时长(播放时间)
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''PL'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_play*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_stream_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --等待时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''WT'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_total*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_stream_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
	--首次播放时长(首次播放时间)
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''FP'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_first_play*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_stream_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --用户体验时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''UI'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_total*point_succ)/sum(point_succ) + sum(buffer_count*point_succ)/sum(point_succ) * 1000,0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_stream_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --再缓冲次数(缓冲次数)
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''BC'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(buffer_count*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_stream_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
	 --页面流媒体首播时间
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''TSU'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(ts_user*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_stream_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
	 --5秒成功率
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''P5'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(play_in_5s*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_stream_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --流畅度
    sqlStr:='insert into nb_trade_report_index
              (report_id,field,trade_index,point_total,point_succ,ctime)
          select
              report_id,''FC'',trade_index,point_total,point_succ,:ctime
          from(
            select
              report_id,
              round(sum(fluency*point_succ)/sum(point_succ),0) as trade_index,
              sum(point_total) as point_total,
              sum(point_succ) as point_succ
            from nb_trade_report_stream_detail
            where ctime=:ctime and available >= 80
            group by report_id)';
    execute immediate sqlStr using ctime,ctime;
    commit;
    --开始计算分数，并生成xml数据
    --首先删除可能生成的数据
   sqlStr:='delete from nb_trade_report_xml where report_id in(select distinct report_id from nb_trade_report_detail where ctime=:ctime)';
   execute immediate sqlStr using ctime;
   commit;
    sqlStr:='insert into nb_trade_report_xml
      (report_id,task_id,ts_total,ts_user,available,stddev_total,stddev_user,point_total,point_succ,grade,order_num,ctime,
       grade_total,grade_user,grade_stddev,grade_avail,rate_download,grade_rate_download,rate_user,
       grade_rate_user,rate_download_page_base,cont_ele_total,byte_total,byte_first,byte_page_base)
    select
      report_id,task_id,ts_total,ts_user,available,stddev_total,stddev_user,point_total,point_succ,grade,
      rank() over(partition by report_id order by grade desc) as rank,
      :ctime,grade_total,grade_user,grade_stddev,grade_avail,rate_download,grade_rate_download,
      rate_user,grade_rate_user,rate_download_page_base,cont_ele_total,byte_total,byte_first,byte_page_base
    from(
      select
        report_id,task_id,ts_total,ts_user,available,stddev_total,stddev_user,point_total,point_succ,
        calc_trade_grade_a(ts_total,t1,ts_user,u1,available,stddev_radio,s1,rate_download,rd1) as grade,
        calc_trade_grade_s(ts_total,t1) as grade_total,
        calc_trade_grade_s(ts_user,u1)*0.6+40 as grade_user,
        calc_trade_grade_s(stddev_radio,s1) as grade_stddev,
        round((available-80)/20*40+60,2) as grade_avail,
        rate_download,
        round(100*sin(rate_download*acos(-1)/(rd1*2)),2) as grade_rate_download,
        rate_user,
        round(100*sin(rate_user*acos(-1)/(ru1*2)),2) as grade_rate_user,
        rate_download_page_base,cont_ele_total,byte_total,byte_first,byte_page_base
      from(
        select
          report_id,task_id,ts_total,ts_user,available,stddev_total,stddev_user,point_total,point_succ,rate_download,rate_user,
                       rate_download_page_base,cont_ele_total,byte_total,byte_first,byte_page_base,
                       stddev_total/ts_total as stddev_radio,
                       max(ts_total) over(partition by report_id order by ts_total desc) + 20000 as t1,
                       max(ts_user) over(partition by report_id order by ts_user desc) * 2 as u1,
                       max(stddev_total/ts_total) over(partition by report_id order by stddev_total/ts_total desc) * 2 as s1,
                       max(rate_download) over(partition by report_id order by rate_download desc) as rd1,
                       max(rate_user) over(partition by report_id order by rate_user desc) +12000 as ru1
        from nb_trade_report_detail 
        where ctime=:ctime and ts_total>0 and ts_user>0  and available>0 and stddev_total > 0 
        union all 
        select
          report_id,task_id,ts_total,ts_user,available,stddev_total,stddev_user,point_total,point_succ,rate_download,
          0 as rate_user,0 as rate_download_page_base,
          buffer_count as cont_ele_total,0 as byte_total,0 as byte_first,0 as byte_page_base,
                       stddev_total/ts_total as stddev_radio,
                       max(ts_total) over(partition by report_id order by ts_total desc) + 20000 as t1,
                       max(ts_user) over(partition by report_id order by ts_user desc) * 2 as u1,
                       max(stddev_total/ts_total) over(partition by report_id order by stddev_total/ts_total desc) * 2 as s1,
                       max(rate_download) over(partition by report_id order by rate_download desc) as rd1,
                       0 as ru1 
        from nb_trade_report_stream_detail 
        where ctime=:ctime and ts_total>0 and ts_user>0  and available>0 and stddev_total > 0
      )
    )
    order by report_id,rank';
    execute immediate sqlStr using ctime,ctime,ctime;
    commit;
create_procedure_log('trade_insert_data','end','message');
end trade_insert_data;

/

