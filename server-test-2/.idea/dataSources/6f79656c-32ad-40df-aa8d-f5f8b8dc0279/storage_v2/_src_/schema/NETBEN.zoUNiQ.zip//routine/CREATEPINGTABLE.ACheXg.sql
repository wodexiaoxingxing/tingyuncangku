create procedure createPingTable(tableStr IN varchar2) authid current_user is
    sqlStr varchar2(4000);
begin
    --create ping sequence
    sqlStr := 'create sequence SEQ_NB_PING_ID_' || tableStr || ' minvalue 1 maxvalue 9999999999999999999999999 start with 1 increment by 1 cache 500';
    execute immediate sqlStr;

    sqlStr := 'create table NB_PING_' || tableStr || '
  (
    PING_ID           NUMBER not null,
    ID                NUMBER,
    TASK_ID           NUMBER,
    PAGE_SEQ          NUMBER,
    CITY_ID           NUMBER,
    ISP_ID            NUMBER,
    NET_SPEED_ID      NUMBER,
    TM_BASE           DATE,
    PROBE_IP          NUMBER,
    MEMBER_ID         NUMBER,
    DNS_SERVER        VARCHAR2(128),
    ERROR_CODE        NUMBER,
    DEST_IP           VARCHAR2(39),
    DEST_CITY_ID      NUMBER,
  DEST_ISP_ID       NUMBER,
    TS_TOTAL          NUMBER,
    TS_PING_START     NUMBER,
    TS_PING_MAX       NUMBER,
    TS_PING_MIN       NUMBER,
    PING_PACKET_LOST  NUMBER,
    PING_RESULT       VARCHAR2(512),
    IS_NOISE          NUMBER,
    POINT_TOTAL       NUMBER default 1,
    TRACERT_RESULT    VARCHAR2(512),
    NSLOOKUP_RESULT   VARCHAR2(512),
    CTIME             DATE      ,
    COUNTRY_ID        INTEGER,
    REGION_ID         INTEGER,
    DISTINCT_ID       INTEGER,
    DEST_COUNTRY_ID   INTEGER,
    DEST_REGION_ID    INTEGER,
    IS_CDN_COVER      INTEGER,
    IS_ISP_COVER      INTEGER ,
    CLIENT_VERSION    VARCHAR2(128),
    DEST_IP_VERSION   INTEGER,
      TRACE_ID            VARCHAR2(128),
      FEEDBACK            INTEGER
  ) pctfree 0
  tablespace NETBEN_BG';
    execute immediate sqlStr;


    sqlStr := 'create index IN_PING_ID_' || tableStr || ' on NB_PING_' || tableStr || ' (PING_ID) tableSpace NETBEN_IDX_NEW nologging' ;
    execute immediate sqlStr;

    sqlStr := 'create index IN_PING_PAGEID_' || tableStr || ' on NB_PING_' || tableStr || ' (ID) tableSpace NETBEN_IDX_NEW nologging';
    execute immediate sqlStr;

    sqlStr := 'create index IN_PING_PERF_' || tableStr || ' on NB_PING_' || tableStr || ' (TM_BASE,TASK_ID) tableSpace NETBEN_IDX_NEW nologging';
    execute immediate sqlStr;

end createPingTable;
/

