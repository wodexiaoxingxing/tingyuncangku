create PROCEDURE          "EXPORT_TXT" authid current_user is
  fhandle utl_file.file_type;
  sqlStr varchar2(4000);
  v_buffer varchar2(200);
begin
  sqlStr := 'alter session set NLS_LANGUAGE = ''AMERICAN''';
  execute immediate sqlStr;
  fhandle:=utl_file.fopen('GQ_EXP','examle_'|| to_char(sysdate,'yyyy-mm-dd')||'.cvs','w');
  v_buffer := 'taskName,errorCode';
  UTL_FILE.put_line(fhandle, v_buffer);
  FOR elem IN (SELECT t.name || ',' || p.error_code result  
    from netben.nb_page_1759 p,nb_m_task t 
    where p.task_id = t.id and tm_base > sysdate - 1
  )LOOP
    UTL_FILE.PUT_LINE(fhandle, elem.result);
  END LOOP;
  UTL_FILE.fclose(fhandle);
  
end export_txt;


/

