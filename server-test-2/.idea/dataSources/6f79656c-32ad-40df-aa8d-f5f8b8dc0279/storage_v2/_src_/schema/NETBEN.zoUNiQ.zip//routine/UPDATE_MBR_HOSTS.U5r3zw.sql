create procedure UPDATE_MBR_HOSTS is
begin
  insert into nb_m_mbr_hosts
select distinct l.mbr_id, l.host_id, l.loc_id, l.isp_id, decode(l.speed_id, 5, 9, 6, 9, 7, 9, 8, 8) from nb_m_probe_login_log l where l.ctime>sysdate - 1/24
and (l.mbr_id, l.host_id, l.loc_id, l.isp_id, decode(l.speed_id, 5, 9, 6, 9, 7, 9, 8, 8)) not in (select * from nb_m_mbr_hosts);
commit;
end UPDATE_MBR_HOSTS;


/

