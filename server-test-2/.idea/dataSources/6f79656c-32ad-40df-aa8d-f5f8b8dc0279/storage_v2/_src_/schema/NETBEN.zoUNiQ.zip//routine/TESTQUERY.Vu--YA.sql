create PROCEDURE          "TESTQUERY" (p_cursor out sys_refcursor) is
  OWNERID varchar2(16) := '1759';
  sqlstr varchar2(4000);
  errorcodes varchar2(4000);
begin
  DBMS_OUTPUT.PUT_LINE(' start procedure matrix ......');
  errorcodes := getpageerrorcodes();
  sqlstr := 'SELECT col0perf AS col0perf, (CASE WHEN col0total = 0 THEN NULL ELSE col0succ/col0total END) AS col0avail,
                    col0perf AS col1perf, (CASE WHEN col1total = 0 THEN NULL ELSE col1succ/col1total END) AS col1avail,
                    col0perf AS col2perf, (CASE WHEN col2total = 0 THEN NULL ELSE col2succ/col2total END) AS col2avail
             FROM
                (SELECT tran.task_id,
                        AVG(CASE WHEN tran.city_id = 481101 THEN tran.ts_total ELSE NULL END) AS col0perf,
                        COUNT(CASE WHEN tran.city_id <> 481101 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col0succ,
                        COUNT(CASE WHEN tran.city_id = 481101 THEN 1 ELSE NULL END) AS col0total,
                		    AVG(CASE WHEN tran.city_id = 483101 THEN tran.ts_total ELSE NULL END) AS col1perf,
                                    COUNT(CASE WHEN tran.city_id <> 483101 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col1succ,
                                    COUNT(CASE WHEN tran.city_id = 483101 THEN 1 ELSE NULL END) AS col1total,
                		    AVG(CASE WHEN tran.city_id = 484401 THEN tran.ts_total ELSE NULL END) AS col2perf,
                        COUNT(CASE WHEN tran.city_id <> 484401 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col2succ,
                        COUNT(CASE WHEN tran.city_id = 484401 THEN 1 ELSE NULL END) AS col2total
                FROM nb_tran_' || OWNERID || ' tran
                WHERE tran.task_id IN (SELECT id from nb_m_task t where t.owner_id = ' || OWNERID || ')
                      AND tran.tm_base > sysdate - interval ''5000'' MINUTE
                GROUP BY tran.task_id) matx
            ORDER BY matx.task_id ASC';
  DBMS_OUTPUT.put_line(' executing sqlstr: ');
  --DBMS_OUTPUT.put(sqlstr);           
  open p_cursor for sqlstr;  
  DBMS_OUTPUT.PUT_LINE(' end procedure matrix ......'); 
end testquery;


/

