create PROCEDURE          "IBTESTPROC" as
job_interval date := sysdate - 1/24;
pre_interval date := sysdate - 2/24;
begin

--任务错误
insert into nb_m_noc_error_task

  (select nvl((select max(id) from nb_m_noc_error_task), 0) + 1,
          tss.code,
          tss.name,
          tss.task_id,
          tss.type,
          tss.error_code,
          tss.err_name,
          tss.ERR_SUM,
          tss.Proportion,
          sysdate
     from (select u.code,
                  t.name,
                  l.task_id,
                  t.type,
                  l.error_code,
                  e.err_name,
                  count(*) ERR_SUM,
                  round(count(*) / ts.pnt * 100, 1) Proportion
             from nb_m_ddc_log_col l,
                  nb_m_task t,
                  netben.nb_m_user u,
                  netben.nb_m_error e,
                  (select l.task_id as tid, count(*) pnt
                     from nb_m_ddc_log_col l
                    where l.tm_base > job_interval
                    group by l.task_id) ts
            where l.tm_base > job_interval
              and l.task_id = ts.tid
              and l.error_code > 600000
              and u.id = t.owner_id
              and t.id = l.task_id
              and e.err_code = l.error_code
            group by u.code,
                     t.name,
                     l.task_id,
                     l.error_code,
                     e.err_name,
                     t.type,
                     ts.pnt) tss
    where tss.ERR_SUM > 10
      and tss.Proportion > 50);
commit;


-- 节点错误
insert into nb_m_noc_error_probe

  (select nvl((select max(id) from nb_m_noc_error_probe), 0) + 1,
       tss.cname,
       tss.iname,
       tss.host_id,
       tss.probe_ip,
       tss.speed_id,
       tss.error_code,
       tss.err_name,
       tss.ERR_SUM,
       tss.Proportion,sysdate
  from (select city.name cname,
               isp.name iname,
               l.host_id,
               l.probe_ip,
               l.speed_id,
               l.error_code,
               e.err_name,
               count(*) ERR_SUM,
               round(count(*) / ts.pnt * 100, 1) Proportion
          from nb_m_ddc_log_col l,
               nb_m_location city,
               nb_m_option_ext isp,
               netben.nb_m_error e,
               (select l.host_id as hid, count(*) pnt
                  from nb_m_ddc_log_col l
                 where l.tm_base > job_interval
                 group by l.host_id) ts
         where l.tm_base > job_interval
           and l.city_id = city.id
           and l.isp_id = isp.id
           and l.host_id = ts.hid
           and l.error_code > 600000
           and e.err_code = l.error_code
           and l.is_noise = 0
           and l.status = 0
         group by city.name,
                  isp.name,
                  l.host_id,
                  l.probe_ip,
                  l.speed_id,
                  l.error_code,
                  e.err_name,
                  ts.pnt) tss
 where tss.ERR_SUM > 5
   and tss.Proportion > 10);
commit;

-- 城市错误
insert into nb_m_noc_error_city

  (select nvl((select max(id) from nb_m_noc_error_city), 0) + 1,
           L2.c2,
                 L1.sum1,
                 L2.sum2,
                 round((L2.sum2 - L1.sum1) / L1.sum1 * 100, 2),
                 sysdate
            from (select city.name c2, count(*) sum2
                    from nb_m_ddc_log_col l, nb_m_location city
                   where l.city_id = city.id
                     and l.error_code > 600000
                     and l.tm_base > job_interval
                   group by city.name) L2,
                 (select city.name c1, count(*) sum1
                    from nb_m_ddc_log_col l, nb_m_location city
                   where l.city_id = city.id
                     and l.error_code > 600000
                     and l.tm_base < job_interval
                     and l.tm_base > pre_interval
                   group by city.name) L1

           where L1.sum1 > 10
             and L2.sum2 > 10
             and L1.c1 = L2.c2
             and (L2.sum2 - L1.sum1) / L1.sum1 > 0.5);
commit;


-- 运营商错误
insert into nb_m_noc_error_isp

  (select nvl((select max(id) from nb_m_noc_error_isp), 0) + 1,
          L2.i2,
          L1.sum1,
          L2.sum2,
          round((L2.sum2 - L1.sum1) / L1.sum1 * 100, 2),
          sysdate
     from (select isp.name i2, count(*) sum2
             from nb_m_ddc_log_col l, nb_m_option_ext isp
            where l.isp_id = isp.id
              and l.error_code > 600000
              and l.tm_base > job_interval
            group by isp.name) L2,
          (select isp.name i1, count(*) sum1
             from nb_m_ddc_log_col l, nb_m_option_ext isp
            where l.isp_id = isp.id
              and l.error_code > 600000
              and l.tm_base < job_interval
              and l.tm_base > pre_interval
            group by isp.name) L1
    where L1.sum1 > 10
      and L2.sum2 > 30
      and L1.i1 = L2.i2
      and (L2.sum2 - L1.sum1) / L1.sum1 > 0.2);
commit;


-- 城市无效
insert into nb_m_noc_invalid_city

  (select nvl((select max(id) from nb_m_noc_invalid_city), 0) + 1,
          l.city_id,
          c.name,
          l.log_message,
          count(*) sum,
          sysdate
     from nb_m_ddc_log_col l, nb_m_location c
    where l.tm_base > job_interval
      and l.status <> 0
      and l.city_id = c.id
    group by l.city_id, c.name, l.log_message);
commit;

-- 城市运营商无效
insert into nb_m_noc_invalid_city_isp

  (select nvl((select max(id) from nb_m_noc_invalid_city_isp), 0) + 1,
          l.city_id,
          c.name,
          l.isp_id,
          i.name,
          l.log_message,
          count(*),
          sysdate
     from nb_m_ddc_log_col l, nb_m_location c, nb_m_option i
    where l.tm_base > job_interval
      and l.status <> 0
      and l.city_id = c.id
      and l.isp_id = i.id
    group by l.city_id, c.name, l.isp_id, i.name, l.log_message);
commit;

-- 节点无效
insert into nb_m_noc_invalid_probe

  (select nvl((select max(id) from nb_m_noc_invalid_probe), 0) + 1,
          l.host_id,
          l.log_message,
          count(*),
          sysdate
     from nb_m_ddc_log_col l
    where l.tm_base > job_interval
      and l.status <> 0
    group by l.host_id, l.log_message);
commit;

-- 任务无效
insert into nb_m_noc_invalid_task

  (select nvl((select max(id) from nb_m_noc_invalid_task), 0) + 1,
          u.code,
          t.name,
          l.task_id,
          l.log_message,
          count(*),sysdate
     from nb_m_ddc_log_col l, nb_m_task t, nb_m_user u
    where l.tm_base > job_interval
      and l.status <> 0
      and u.id = t.owner_id
      and t.id = l.task_id
    group by u.code, t.name, l.task_id, l.log_message);
commit;

-- 任务节点无效
insert into nb_m_noc_invalid_task_probe

  (select nvl((select max(id) from nb_m_noc_invalid_task_probe), 0) + 1,
          u.code,
          t.name,
          l.task_id,
          l.host_id,
          l.log_message,
          count(*),
          sysdate
     from nb_m_ddc_log_col l, nb_m_task t, nb_m_user u
    where l.tm_base > job_interval
      and l.status <> 0
      and u.id = t.owner_id
      and t.id = l.task_id
    group by u.code, t.name, l.task_id, l.host_id, l.log_message);
commit;

-- 任务运营商无效
insert into nb_m_noc_invalid_isp

  (select nvl((select max(id) from nb_m_noc_invalid_isp), 0) + 1,
          l.isp_id,
          i.name,
          l.log_message,
          count(*),
          sysdate
     from nb_m_ddc_log_col l, nb_m_option i
    where l.tm_base > job_interval
      and l.status <> 0
      and l.isp_id = i.id
    group by l.isp_id, i.name, l.log_message);
commit;

end;


/

