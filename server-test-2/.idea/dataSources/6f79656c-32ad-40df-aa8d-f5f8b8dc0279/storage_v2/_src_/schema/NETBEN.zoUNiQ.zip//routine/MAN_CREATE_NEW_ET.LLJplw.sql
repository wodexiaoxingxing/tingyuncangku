create PROCEDURE          "MAN_CREATE_NEW_ET" 
is
  createDate date := sysdate;
  orderNum   number;
  rangeDate  varchar2(128);
  partname1  varchar2(128);
  etd_partname1  varchar2(128);
  ett_partname1  varchar2(128);
  rangedate1 varchar2(128);
  partname2  varchar2(128);
  etd_partname2  varchar2(128);
  ett_partname2  varchar2(128);
  rangedate2 varchar2(128);
  partname3  varchar2(128);
  etd_partname3  varchar2(128);
  ett_partname3  varchar2(128);
  rangedate3 varchar2(128);
--new 
  sqlStr  varchar2(4000);
  v_error_desc varchar2(4000);
  error_c varchar2(4000);
  t number;
   taskId varchar2(50);
   cursor cur_id is Select to_char(id) from NB_M_TASK;
   
   begin
OPEN cur_id;
LOOP
  begin
    FETCH cur_id INTO taskId;
    EXIT WHEN cur_id%NOTFOUND;
   select count(*) into t from user_tables where table_name='NB_ET_'||taskId;
   dbms_output.put_line(t);
   dbms_output.put_line(taskId);
if t=1 then
--创建ETD表
--计算表分区
     select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 8 - to_char( createDate,'d'),'d') from dual);
        partname1:='PART_ET_'||taskId||'_'||orderNum;
  etd_partname1:='PART_ET_'||taskId||'_'||orderNum;
  ett_partname1:='PART_ET_'||taskId||'_'||orderNum;
        rangedate1:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';
    select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 15 - to_char( createDate,'d'),'d') from dual);
        partname2:='PART_ET_'||taskId||'_'||orderNum;
  etd_partname2:='PART_ET_'||taskId||'_'||orderNum;
  ett_partname2:='PART_ET_'||taskId||'_'||orderNum;
        rangedate2:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';
    select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 22 - to_char( createDate,'d'),'d') from dual);
        partname3:='PART_ET_'||taskId||'_'||orderNum;
  etd_partname3:='PART_ET_'||taskId||'_'||orderNum;
  ett_partname3:='PART_ET_'||taskId||'_'||orderNum;
        rangedate3:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';

--建表
    sqlStr:='create table NB_ETD_'||taskId||'
    (
      PAGE_ID          NUMBER,
      TASK_ID          NUMBER,
      CITY_ID          NUMBER,
      ISP_ID           NUMBER,
      NET_SPEED_ID     NUMBER,
      TM_BASE          DATE,
      DOMAIN_ID        NUMBER,
      BYTE_TOTAL       NUMBER,
      TS_DNS           NUMBER,
      TS_CONNECT       NUMBER,
      TS_SSL           NUMBER,
      TS_REDIRECT      NUMBER,
      TS_REQUEST       NUMBER,
      TS_FIRST_PACKET  NUMBER,
      TS_REMAIN_PACKET NUMBER,
      TS_ELEMENT       NUMBER,
      TS_CLOSE         NUMBER,
      TS_BLOCK         NUMBER,
      BYTE_SENT        NUMBER,
      RATE_DOWNLOAD     NUMBER,
      RATE_UPLOAD     NUMBER,
      POINT_TOTAL     NUMBER,
      POINT_SUCC     NUMBER
    ) pctfree 0
    partition by range (TM_BASE)(
                  partition '||etd_partname1||' values less than ('||rangedate1||'),
                  partition '||etd_partname2||' values less than ('||rangedate2||'),
                  partition '||etd_partname3||' values less than ('||rangedate3||'))';
     dbms_output.put_line(sqlStr);
    execute   immediate   sqlStr;
    --域名索引 tm_base,domain_id
    sqlStr:='create index IDX_ETD_DID_'||taskId||' on NB_ETD_'||taskId||' (DOMAIN_ID,TM_BASE) local
            (partition '||etd_partname1||',partition '||etd_partname2||',partition '||etd_partname3||') compress 2 PCTFREE 0
            tableSpace  NETBEN_IDX nologging';
     dbms_output.put_line(sqlStr);
    execute   immediate   sqlStr;


--创建ETD表
 sqlStr:='create table NB_ETT_'||taskId||'
    (
      PAGE_ID          NUMBER,
      TASK_ID          NUMBER,
      CITY_ID          NUMBER,
      ISP_ID           NUMBER,
      NET_SPEED_ID     NUMBER,
      TM_BASE          DATE,
      ELEM_TYPE_ID     NUMBER,
      BYTE_TOTAL       NUMBER,
      TS_DNS           NUMBER,
      TS_CONNECT       NUMBER,
      TS_SSL           NUMBER,
      TS_REDIRECT      NUMBER,
      TS_REQUEST       NUMBER,
      TS_FIRST_PACKET  NUMBER,
      TS_REMAIN_PACKET NUMBER,
      TS_ELEMENT       NUMBER,
      TS_CLOSE         NUMBER,
      TS_BLOCK         NUMBER,
      BYTE_SENT        NUMBER,
      RATE_DOWNLOAD     NUMBER,
      RATE_UPLOAD     NUMBER,
      POINT_TOTAL     NUMBER,
      POINT_SUCC     NUMBER
    ) pctfree 0
    partition by range (TM_BASE)(
                  partition '||ett_partname1||' values less than ('||rangedate1||'),
                  partition '||ett_partname2||' values less than ('||rangedate2||'),
                  partition '||ett_partname3||' values less than ('||rangedate3||'))';
     dbms_output.put_line(sqlStr);
    execute   immediate   sqlStr;

    --类型索引 tm_base,type_id
    sqlStr:='create index IDX_ETT_TID_'||taskId||' on NB_ETT_'||taskId||' (ELEM_TYPE_ID,TM_BASE) local
            (partition '||ett_partname1||',partition '||ett_partname2||',partition '||ett_partname3||') compress 2 PCTFREE 0
            tableSpace  NETBEN_IDX nologging';
     dbms_output.put_line(sqlStr);
    execute   immediate   sqlStr;

end if;
    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
      --  raise_application_error ();
        dbms_output.PUT_LINE(sqlStr);
      MON_PC_ERROR_LOG('create_table_ET',sqlerrm,taskId);
end;
  end loop;
end MAN_CREATE_NEW_ET;


/

