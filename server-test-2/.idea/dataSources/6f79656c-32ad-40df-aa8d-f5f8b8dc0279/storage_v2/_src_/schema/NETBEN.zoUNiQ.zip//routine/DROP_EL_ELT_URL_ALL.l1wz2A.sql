create procedure drop_el_elt_url_all authid current_user is
sqlStr varchar2(4000);
errorDesc varchar2(4000);
s int;
begin
     s:=0;
     -- 用于测试增加输出缓存
     dbms_output.enable(buffer_size=>null) ;
     for str in  (
        select table_name from user_tables where table_name like 'NB_EL_URL_%')
     loop
        begin
            s:= s+1;
            sqlStr := 'drop table '|| str.table_name;
            dbms_output.put_line(s|| ' ' ||sqlStr);
            execute immediate sqlStr ;
         -- dbms_output.put_line('test_create_el('||str.table_str||')');
        exception when  others then
            errorDesc := sqlerrm || ',' || sqlStr;
            -- DBMS_OUTPUT.PUT_LINE(errorDesc);
            create_procedure_log('drop_el_elt_url_all',errorDesc,'error');
        end;
    end loop;
    s:=0;
    for str in  (
        select table_name from user_tables where table_name like 'NB_ELT_URL_%')
     loop
        begin
            s:= s+1;
            sqlStr := 'drop table '|| str.table_name;
            dbms_output.put_line(s|| ' ' ||sqlStr);
            execute immediate sqlStr ;
         -- dbms_output.put_line('test_create_el('||str.table_str||')');
        exception when  others then
            errorDesc := sqlerrm || ',' || sqlStr;
            -- DBMS_OUTPUT.PUT_LINE(errorDesc);
            create_procedure_log('drop_el_elt_url_all',errorDesc,'error');
        end;
    end loop;
    sqlStr :='truncate table nb_e_type_task';
    execute immediate sqlStr ;
end drop_el_elt_url_all;


/

