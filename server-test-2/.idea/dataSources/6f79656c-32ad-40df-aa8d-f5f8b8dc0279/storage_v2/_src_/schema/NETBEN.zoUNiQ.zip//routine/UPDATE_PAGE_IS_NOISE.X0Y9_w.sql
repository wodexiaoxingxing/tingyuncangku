create PROCEDURE          "UPDATE_PAGE_IS_NOISE" authid current_user
is
  sqlStr  varchar2(4000);  
  v_name varchar2(400);
  v_error_desc varchar2(400);
  CURSOR c_emp IS SELECT substr(t.object_name,8) FROM all_objects t where t.object_name like 'NB_PAGE_%';
begin
OPEN c_emp;
LOOP
  begin
    FETCH c_emp INTO v_name;
    EXIT WHEN c_emp%NOTFOUND;
    --修改表
    DBMS_OUTPUT.PUT_LINE('start alter table  NB_PAGE'||v_name);
    sqlStr:='alter table NB_PAGE'||v_name||' add is_noise NUMBER default 0';
    execute   immediate   sqlStr;
    
    --删除物化视图
    DBMS_OUTPUT.PUT_LINE('drop mv_page'||v_name);
    sqlStr:='drop materialized view mv_page'||v_name;
    execute immediate sqlStr;
    
    --Page物化视图
    DBMS_OUTPUT.PUT_LINE('create mv table  MV_PAGE'||v_name);
    sqlStr:='
    create materialized view MV_PAGE'||v_name||'
		refresh   force
		start with sysdate next sysdate + 4/24 
		with primary key   as
		(select task_id,
		        page_seq,
		       city_id,
		       isp_id,
		       net_speed_id,
		       error_code,
           is_noise,
		       tm_hour4,
		       (tm_hour4 - mod(to_number(to_char(tm_hour4, '||chr(39)||'hh24'||chr(39)||')) + 8, 8) / 24) as tm_hour8,
		       (tm_hour4 - mod(to_number(to_char(tm_hour4, '||chr(39)||'hh24'||chr(39)||')) + 12, 12) / 24) as tm_hour12,
		       trunc(tm_hour4, '||chr(39)||'dd'||chr(39)||') as tm_day,
		       point_total,
		       round(ts_total,0) as ts_total,
           round(rate_download,0) as rate_download,
		       round(ts_page_base,0) as ts_page_base,
		       round(ts_dns,0) as ts_dns,
		       round(ts_connect,0) as ts_connect,
		       round(ts_ssl,0) as ts_ssl,
		       round(ts_redirect,0) as ts_redirect,
		       round(ts_request,0) as ts_request,
		       round(ts_first_packet,0) as ts_first_packet,
		       round(ts_client,0) as ts_client,
		       round(ts_contents,0) as ts_contents,
		       round(ts_extra_data,0) as ts_extra_data,
		       round(ts_open_page,0) as ts_open_page,
		       round(ts_user,0) as ts_user,
		       round(ts_network,0) as ts_network,
		       round(ts_close,0) as ts_close
		  from (select task_id,
		               page_seq,
		               city_id,
		               isp_id,
		               net_speed_id,
		               error_code,
                   is_noise,
		               (tm_hour -
		               mod(to_number(to_char(tm_hour, '||chr(39)||'hh24'||chr(39)||')) + 4, 4) / 24) as tm_hour4,
		               sum(point_total) as point_total,
		               avg(ts_total) as ts_total,
                   avg(rate_download) as rate_download,
		               avg(ts_page_base) as ts_page_base,
		               avg(ts_dns) as ts_dns,
		               avg(ts_connect) as ts_connect,
		               avg(ts_ssl) as ts_ssl,
		               avg(ts_redirect) as ts_redirect,
		               avg(ts_request) as ts_request,
		               avg(ts_first_packet) as ts_first_packet,
		               avg(ts_client) as ts_client,
		               avg(ts_contents) as ts_contents,
		               avg(ts_extra_data) as ts_extra_data,
		               avg(ts_open_page) as ts_open_page,
		               avg(ts_user) as ts_user,
		               avg(ts_network) as ts_network,
		               avg(ts_close) as ts_close
		          from NB_PAGE'||v_name||'
		         group by task_id,
		                  page_seq,
		                  city_id,
		                  isp_id,
		                  net_speed_id,
		                  error_code,
                      is_noise,
		                  (tm_hour -
		                  mod(to_number(to_char(tm_hour, '||chr(39)||'hh24'||chr(39)||')) + 4, 4) / 24)))';  
    execute   immediate   sqlStr;
	--索引                  
		sqlStr:='create index IN_MV_PAGE_ERROR'||v_name||' on MV_PAGE'||v_name||' (TM_HOUR4, ERROR_CODE, CITY_ID, TASK_ID) tableSpace NETBEN_IDX';  
    execute   immediate   sqlStr;	
    --索引	              
		sqlStr:='create index IN_MV_PAGE_PERF'||v_name||' on MV_PAGE'||v_name||' (TM_HOUR4, CITY_ID, TASK_ID, ISP_ID) tableSpace NETBEN_IDX';  
    execute   immediate   sqlStr;		
    
  
        --如果创建失败，则显示出失败的表
    exception when  others then
        v_error_desc := '            ERROR:  code: '|| sqlcode || '   NB_PAGE'||v_name;
        DBMS_OUTPUT.PUT_LINE(v_error_desc);
        
    end;
END LOOP;

CLOSE c_emp;  
end update_page_is_noise;


/

