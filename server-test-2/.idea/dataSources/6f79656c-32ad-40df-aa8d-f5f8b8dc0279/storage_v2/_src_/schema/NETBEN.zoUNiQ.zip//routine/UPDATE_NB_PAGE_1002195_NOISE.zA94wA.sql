create PROCEDURE update_nb_page_1002195_noise is 
sqlStr VARCHAR2(4000);
BEGIN
create_procedure_log('update_nb_page_1002195__noise','begin','message');
for item in (select id,ts_total,task_id from nb_page_1002195 t where t.task_id in  (3040577,2951292,2947870,2950716,2950718,2950717,2950714,2950713,2950715,2169775,3009760)
and tm_base >= SYSDATE - 1/12 and TS_TOTAL > 10000) loop
BEGIN
 create_procedure_log('update_nb_page_1002195_to_noise','task_id:'||item.task_id,'message');
 sqlStr  := 'update nb_page_1002195 set(is_noise = 1) where id = :id';
 execute immediate   sqlStr using item.id;
 sqlStr  := 'insert into nb_page_1002195_noise_tmp (:id)';
 execute immediate   sqlStr using item.id;
 commit;
 end;
END loop;
create_procedure_log('update_nb_page_1002195_noise','end','run');
END update_nb_page_1002195_noise;
/

