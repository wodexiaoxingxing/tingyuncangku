create FUNCTION "FIELD_CONVERT" (field_constant in varchar2) return varchar2 is
  result varchar2(32);
begin
  if (field_constant = 'T') then
      result:='ts_total';
  elsif(field_constant = 'WT') then
      result:='ts_total';
  elsif(field_constant = 'RT') then
      result:='ts_total';    
  elsif(field_constant = 'U') then
      result:='ts_user';
  elsif(field_constant = 'D') then
      result:='ts_dns';
  elsif(field_constant = 'C') then 
      result:='ts_connect';
  elsif(field_constant = 'F') then
      result:='ts_first_packet';
  elsif(field_constant = 'PA') then
      result:='ts_total';
  elsif(field_constant = 'BF') then
      result:='ts_buffer';
  elsif(field_constant = 'RB') then
      result:='ts_rebuffer';
  elsif(field_constant = 'UI') then
      result:='(ts_total + buffer_count * 1000)';
  elsif(field_constant = 'EL') then
      result:='cont_ele_total';
  elsif(field_constant = 'CE') then
      result:='cont_err_total';
  elsif(field_constant = 'BY') then
      result:='byte_total';
  elsif(field_constant = 'PB') then
      result:='byte_page_base';
  elsif(field_constant = 'PPL') then
      result:='ping_packet_lost';
  elsif(field_constant = 'FRC') then
      result:='freeze_count';
  elsif(field_constant = 'FT') then
      result:='freeze_time';
  elsif(field_constant = 'FF') then
      result:='ts_first_frame';
  elsif(field_constant = 'THS') then
      result:='ts_hand_shake';
  elsif(field_constant = 'CR') then
      result:='caton_rate';
  elsif(field_constant = 'FL') then
      result:='rate_frame_loss';
  elsif(field_constant = 'FRPS') then
      result:='fps_decode';
  elsif(field_constant = 'FPS') then
      result:='(ts_connect + ts_buffer)';
  elsif(field_constant = 'HC') then
      result:='is_cdn_cover';                  
  elsif(field_constant = '' or field_constant is null) then
      result:='ts_total';    
  --如果是私有协议，保存的是字段名称
  else
      result:=field_constant;
  end if;
  return(result);
end field_convert;


/

