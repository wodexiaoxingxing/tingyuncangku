create PROCEDURE          "ALTER_LT_PAGE_ADD_FIELD" 
is 
  sqlStr  varchar2(4000);  
  v_error_desc varchar2(4000);
  v_s number;
begin

  for tableName in(select t.table_name as name from user_tables t where t.table_name like 'LT_PAGE_%') loop
  begin
    create_procedure_log('alter_lt_page_add_field',tableName.name,'message');
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TS_PAGE_BASE';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add TS_PAGE_BASE number';
        execute   immediate   sqlStr ;
      end if;
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TS_REDIRECT';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add TS_REDIRECT number';
        execute   immediate   sqlStr ;
      end if;
   select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TS_EXTRA_DATA';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add TS_EXTRA_DATA number';
        execute   immediate   sqlStr ;
      end if;
      
   select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TS_OPEN_PAGE';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add TS_OPEN_PAGE number';
        execute   immediate   sqlStr ;
      end if;
   select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TS_CLOSE';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add TS_CLOSE number';
        execute   immediate   sqlStr ;
      end if;
  
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='NUM_IFRAME';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add NUM_IFRAME number';
        execute   immediate   sqlStr ;
      end if;
      
       select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='NUM_NO_COMPRESS_ELEM';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add NUM_NO_COMPRESS_ELEM number';
        execute   immediate   sqlStr ;
      end if;
       select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='NUM_NO_EXPIRE_ELEM';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add NUM_NO_EXPIRE_ELEM number';
        execute   immediate   sqlStr ;
      end if;
       select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='NUM_NO_ETAG_ELEM';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add NUM_NO_ETAG_ELEM number';
        execute   immediate   sqlStr ;
      end if;
  
   
    exception when  others then
        v_error_desc := 'Error Code:'|| sqlerrm || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlStr);
        create_procedure_log('alter_lt_page_add_field',v_error_desc,sqlerrm);
  end;
  end loop;
end alter_lt_page_add_field;


/

