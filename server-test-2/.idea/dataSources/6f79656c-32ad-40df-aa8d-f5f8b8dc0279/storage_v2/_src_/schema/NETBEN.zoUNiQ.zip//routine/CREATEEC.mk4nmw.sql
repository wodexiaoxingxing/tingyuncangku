create procedure createEC(tableStr in varchar2,res OUT number) authid current_user is
  sqlStr       varchar2(8000);
  errorDesc    varchar2(4000);
  ---------------- 主变量 ---------------------------------------------------------------------------
  createDate   date := sysdate;
  orderNum     number;
  rangeDate    varchar2(128);
  partname1    varchar2(128);
  rangedate1   varchar2(128);
  partname2    varchar2(128);
  rangedate2   varchar2(128);
  partname3    varchar2(128);
  rangedate3   varchar2(128);

begin

  create_procedure_log('createEC', 'create table:nb_ec_' || tableStr, 'run');

  -- 创建nb_ec及nb_ee
  -- 首先计算出ec的分区名称及值范围
  select order_num, to_char(sunday, 'yyyy-mm-dd')
    into orderNum, rangeDate
    from nb_part_calendar t
   where t.sunday = (select trunc(createDate + 8 - to_char(createDate, 'd'), 'd') from dual);

  partname1    := 'PART_EC_' || tableStr || '_' || orderNum;
  rangedate1   := 'to_date(''' || rangeDate || ''',''yyyy-mm-dd'')';

  select order_num, to_char(sunday, 'yyyy-mm-dd')
    into orderNum, rangeDate
    from nb_part_calendar t
   where t.sunday = (select trunc(createDate + 15 - to_char(createDate, 'd'), 'd') from dual);

  partname2    := 'PART_EC_' || tableStr || '_' || orderNum;
  rangedate2   := 'to_date(''' || rangeDate || ''',''yyyy-mm-dd'')';

  select order_num, to_char(sunday, 'yyyy-mm-dd')
    into orderNum, rangeDate
    from nb_part_calendar t
   where t.sunday = (select trunc(createDate + 22 - to_char(createDate, 'd'), 'd') from dual);

  partname3    := 'PART_EC_' || tableStr || '_' || orderNum;
  rangedate3   := 'to_date(''' || rangeDate || ''',''yyyy-mm-dd'')';

  sqlStr := 'create table NB_EC_' || tableStr || '
    (
      URL_ID           NUMBER,
      PAGE_ID          NUMBER,
      ELEMENT_SEQ      NUMBER,
      TASK_ID          NUMBER,
      TM_BASE          DATE,
      URL_HOST         VARCHAR2(64),
      URL_PROTOCOL     VARCHAR2(16),
      URL_PORT         VARCHAR2(8),
      URL_PATH         VARCHAR2(4000),
      DNS_SERVER       VARCHAR2(128),
      ELEMENT_TYPE     VARCHAR2(32),
      HTTP_STAT_CODE   NUMBER,
      HTTP_HEAD_SIZE   NUMBER,
      HTTP_BODY_COMP   VARCHAR2(2),
      HTTP_SERVER      VARCHAR2(256),
      HTTP_VIA         VARCHAR2(256),
      HTTP_REQ_HEADER  VARCHAR2(4000),
      HTTP_RESP_HEADER VARCHAR2(4000),
      SOCKET_ID        NUMBER,
      DNS_RESOLVED     NUMBER,
      CONN_ESTABLISHED NUMBER,
      REQUESTED        NUMBER,
      APPLICATION_ID                  NUMBER, 
    APPLICATION_INSTANCE_ID         NUMBER, 
    TRACE_GUID                      VARCHAR2(512),  
    ACTION_NAME                     VARCHAR2(512)
    ) pctfree 0 
    partition by range (TM_BASE)(
                  partition ' || partname1 || ' values less than (' || rangedate1 || '),
                  partition ' || partname2 || ' values less than (' || rangedate2 || '),
                  partition ' || partname3 || ' values less than (' || rangedate3 || ')) tablespace netben_bg';
  execute immediate sqlStr;

  -- 元素索引 tm_base,url_id,error_code
  sqlStr := 'create index IDX_EC_PID_' || tableStr || ' on NB_EC_' || tableStr || ' (PAGE_ID) local tableSpace  NETBEN_IDX_NEW nologging';
  execute immediate sqlStr;
  res:=0;
  
exception
  when others then
    errorDesc := 'Error :' || sqlerrm || '  tableStr:' || tableStr;
    --DBMS_OUTPUT.PUT_LINE(v_error_desc);
    create_procedure_log('createEC', errorDesc, 'error');
    res:=1;
    
end createEC;


/

