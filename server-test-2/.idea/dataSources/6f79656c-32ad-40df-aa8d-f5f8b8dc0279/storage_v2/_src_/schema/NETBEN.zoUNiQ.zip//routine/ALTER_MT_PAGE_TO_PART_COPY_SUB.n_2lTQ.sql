create procedure alter_mt_page_to_part_copy_sub(tablestr number) authid current_user is
sqlStr varchar2(32767);
rangeDate date;
rangeDesc varchar2(8);
partName1 varchar2(64);
rangeName1 varchar2(64);
partName2 varchar2(64);
rangeName2 varchar2(64);
partName3 varchar2(64);
rangeName3 varchar2(64);
partName4 varchar2(64);
rangeName4 varchar2(64);
partName5 varchar2(64);
rangeName5 varchar2(64);
partName6 varchar2(64);
rangeName6 varchar2(64);
partName7 varchar2(64);
rangeName7 varchar2(64);
partName8 varchar2(64);
rangeName8 varchar2(64);
partName9 varchar2(64);
rangeName9 varchar2(64);
partName10 varchar2(64);
rangeName10 varchar2(64);
createDate date;
--拷贝数据用变量
stDesc varchar2(32);
etDesc varchar2(32);
begin
  DBMS_OUTPUT.ENABLE(999999999999999999999);
  createDate:=sysdate-100;
  rangeDate := trunc(createDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName1:='part_mt_page'||tableStr||'_'||rangeDesc;
  rangeName1:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName2:='part_mt_page'||tableStr||'_'||rangeDesc;
  rangeName2:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName3:='part_mt_page'||tableStr||'_'||rangeDesc;
  rangeName3:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName4:='part_mt_page'||tableStr||'_'||rangeDesc;
  rangeName4:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName5:='part_mt_page'||tableStr||'_'||rangeDesc;
  rangeName5:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName6:='part_mt_page'||tableStr||'_'||rangeDesc;
  rangeName6:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName7:='part_mt_page'||tableStr||'_'||rangeDesc;
  rangeName7:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName8:='part_mt_page'||tableStr||'_'||rangeDesc;
  rangeName8:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName9:='part_mt_page'||tableStr||'_'||rangeDesc;
  rangeName9:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName10:='part_mt_page'||tableStr||'_'||rangeDesc;
  rangeName10:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  -- 1 创建临时表
  create_procedure_log('alter_page_to_part',tableStr||',begin','run');
    begin
      sqlStr:='drop table MT_PAGE_'||tablestr||'_temp';
      dbms_output.put_line(sqlStr||';');
      --execute immediate sqlStr;
    exception when others then
      create_procedure_log('alter_page_to_part',tableStr||','||sqlerrm,'error');
    end;

    sqlStr:=' create table MT_PAGE_'||tableStr||'_temp(
  task_id                 NUMBER,
  page_seq                NUMBER,
  city_id                 NUMBER,
  isp_id                  NUMBER,
  net_speed_id            NUMBER,
  error_code              NUMBER,
  is_noise                INTEGER,
  dest_ip                 VARCHAR2(39),
  tm_base                 DATE,
  os_ver_id               INTEGER,
  bs_id                   INTEGER,
  bs_ver_id               INTEGER,
  cont_err_total          NUMBER,
  cont_ele_total          NUMBER,
  point_total             NUMBER,
  byte_total              NUMBER,
  rate_download           NUMBER,
  ts_total                NUMBER,
  ts_page_base            NUMBER,
  ts_dns                  NUMBER,
  ts_connect              NUMBER,
  ts_ssl                  NUMBER,
  ts_redirect             NUMBER,
  ts_request              NUMBER,
  ts_first_packet         NUMBER,
  ts_client               NUMBER,
  ts_contents             NUMBER,
  ts_user                 NUMBER,
  ts_network              NUMBER,
  byte_page_base          NUMBER,
  rate_download_page_base NUMBER,
  num_first_elem          NUMBER,
  byte_first              NUMBER,
  num_host                NUMBER,
  ts_dns_total            NUMBER,
  num_connect             NUMBER,
  ts_connect_total        NUMBER,
  num_dom                 NUMBER,
  num_elem_lazy           NUMBER,
  ts_first_paint          NUMBER,
  ts_full_screen          NUMBER,
  ts_unload_start         NUMBER,
  ts_unload_end           NUMBER,
  ts_dom_load             NUMBER,
  ts_dom_interact         NUMBER,
  ts_dom_cont_load_start  NUMBER,
  ts_dom_cont_load_end    NUMBER,
  ts_dom_complete         NUMBER,
  ts_load_evt_start       NUMBER,
  ts_load_evt_end         NUMBER
) partition by range (TM_BASE)
            subpartition by hash(task_id) subpartitions 8
             (
              partition '||partName1||' values less than ('||rangeName1||'),
              partition '||partName2||' values less than ('||rangeName2||'),
              partition '||partName3||' values less than ('||rangeName3||'),
              partition '||partName4||' values less than ('||rangeName4||'),
              partition '||partName5||' values less than ('||rangeName5||'),
              partition '||partName6||' values less than ('||rangeName6||'),
              partition '||partName7||' values less than ('||rangeName7||'),
              partition '||partName8||' values less than ('||rangeName8||'),
              partition '||partName9||' values less than ('||rangeName9||'),
              partition '||partName10||' values less than ('||rangeName10||'))
              tablespace netben_bg';
        dbms_output.put_line(sqlStr||';');
        --execute immediate sqlStr;
        -- 删除物化视图

        -- 修改索引名称，空出名称
        create_procedure_log('alter_page_to_part',tableStr||','||'修改索引名称','run');
        begin
          sqlStr:='alter index in_page_perf_'||tableStr||' rename to in_page_perf_'||tablestr||'_bak';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_page_to_part',tableStr||','||sqlStr||','||sqlerrm,'error');
        end;

        --begin
          --sqlStr:='alter index in_page_error_'||tableStr||' rename to in_page_error_'||tablestr||'_bak';
          --dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        --exception when others then
         -- create_procedure_log('alter_page_to_part',tableStr||','||sqlStr||','||sqlerrm,'error');
       -- end;

        begin
          sqlStr:='alter index IDX_MT_PAGE_PERF_'||tableStr||' rename to IDX_MT_PAGE_PERF_'||tablestr||'_bak';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_page_to_part',tableStr||','||sqlStr||','||sqlerrm,'error');
        end;




        -- 创建索引
        begin
          create_procedure_log('alter_page_to_part',tableStr||','||'创建索引in_page_perf','run');
          sqlStr:='create index IDX_MT_PAGE_PERF_'||tableStr||' on MT_PAGE_'||tableStr||'_temp (task_id,tm_base) LOCAL tableSpace NETBEN_IDX_NEW nologging';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_page_to_part',tableStr||','||sqlStr||','||sqlerrm,'error');
        end;

        for i in 1..100 loop
          stDesc:=to_char(sysdate - 1 * (101-i)-1,'yyyy-mm-dd');
          etDesc:=to_char(sysdate-1*(100-i)-1,'yyyy-mm-dd');
          sqlStr:='insert into MT_PAGE_'||tablestr||'_temp
             (task_id,page_seq,city_id,isp_id,net_speed_id,error_code,is_noise,dest_ip,tm_base,os_ver_id ,bs_id,bs_ver_id ,cont_err_total,cont_ele_total,point_total ,byte_total  ,rate_download ,ts_total,ts_page_base,ts_dns ,ts_connect  ,ts_ssl ,ts_redirect ,ts_request  ,ts_first_packet,ts_client   ,ts_contents ,ts_user,ts_network  ,byte_page_base,rate_download_page_base ,num_first_elem,byte_first ,num_host,ts_dns_total,num_connect ,ts_connect_total,num_dom,num_elem_lazy,ts_first_paint,ts_full_screen,ts_unload_start ,ts_unload_end,ts_dom_load ,ts_dom_interact ,ts_dom_cont_load_start,ts_dom_cont_load_end,ts_dom_complete,ts_load_evt_start,ts_load_evt_end
              )
              select task_id,page_seq,city_id,isp_id,net_speed_id,error_code,is_noise,dest_ip,tm_base,os_ver_id ,bs_id,bs_ver_id ,cont_err_total,cont_ele_total,point_total ,byte_total  ,rate_download ,ts_total,ts_page_base,ts_dns ,ts_connect  ,ts_ssl ,ts_redirect ,ts_request  ,ts_first_packet,ts_client   ,ts_contents ,ts_user,ts_network  ,byte_page_base,rate_download_page_base ,num_first_elem,byte_first ,num_host,ts_dns_total,num_connect ,ts_connect_total,num_dom,num_elem_lazy,ts_first_paint,ts_full_screen,ts_unload_start ,ts_unload_end,ts_dom_load ,ts_dom_interact ,ts_dom_cont_load_start,ts_dom_cont_load_end,ts_dom_complete,ts_load_evt_start,ts_load_evt_end
             from MT_PAGE_'||tablestr||' where tm_base >= to_date('''||stDesc||''',''yyyy-mm-dd'') and tm_base<to_date('''||etDesc||''',''yyyy-mm-dd'')';
          dbms_output.put_line(sqlStr||';');
          dbms_output.put_line('commit;');
        end loop;
      sqlStr:='rename MT_PAGE_'||tablestr|| ' to MT_PAGE_'||tablestr||'_bk';
      dbms_output.put_line(sqlStr||';');
      sqlStr:='rename MT_PAGE_'||tablestr||'_temp to MT_PAGE_'||tablestr;
      dbms_output.put_line(sqlStr||';');
      --改完名后把最后1天数据导过来
      stDesc:=to_char(sysdate-1,'yyyy-mm-dd');
      etDesc:=to_char(sysdate+1,'yyyy-mm-dd');
      sqlStr:='insert into MT_PAGE_'||tablestr||'(task_id,page_seq,city_id,isp_id,net_speed_id,error_code,is_noise,dest_ip,tm_base,os_ver_id ,bs_id,bs_ver_id ,cont_err_total,cont_ele_total,point_total ,byte_total  ,rate_download ,ts_total,ts_page_base,ts_dns ,ts_connect  ,ts_ssl ,ts_redirect ,ts_request  ,ts_first_packet,ts_client   ,ts_contents ,ts_user,ts_network  ,byte_page_base,rate_download_page_base ,num_first_elem,byte_first ,num_host,ts_dns_total,num_connect ,ts_connect_total,num_dom,num_elem_lazy,ts_first_paint,ts_full_screen,ts_unload_start ,ts_unload_end,ts_dom_load ,ts_dom_interact ,ts_dom_cont_load_start,ts_dom_cont_load_end,ts_dom_complete,ts_load_evt_start,ts_load_evt_end
              )
              select task_id,page_seq,city_id,isp_id,net_speed_id,error_code,is_noise,dest_ip,tm_base,os_ver_id ,bs_id,bs_ver_id ,cont_err_total,cont_ele_total,point_total ,byte_total  ,rate_download ,ts_total,ts_page_base,ts_dns ,ts_connect  ,ts_ssl ,ts_redirect ,ts_request  ,ts_first_packet,ts_client   ,ts_contents ,ts_user,ts_network  ,byte_page_base,rate_download_page_base ,num_first_elem,byte_first ,num_host,ts_dns_total,num_connect ,ts_connect_total,num_dom,num_elem_lazy,ts_first_paint,ts_full_screen,ts_unload_start ,ts_unload_end,ts_dom_load ,ts_dom_interact ,ts_dom_cont_load_start,ts_dom_cont_load_end,ts_dom_complete,ts_load_evt_start,ts_load_evt_end
              from MT_PAGE_'||tablestr||'_bk where tm_base >= to_date('''||stDesc||''',''yyyy-mm-dd'') and tm_base<to_date('''||etDesc||''',''yyyy-mm-dd'')';
      dbms_output.put_line(sqlStr||';');
      dbms_output.put_line('commit;');
      create_procedure_log('alter_page_to_part',tableStr||',end','run');
      exception when others then
        create_procedure_log('alter_page_to_part',tableStr||','||sqlerrm,'error');
end alter_mt_page_to_part_copy_sub;


/

