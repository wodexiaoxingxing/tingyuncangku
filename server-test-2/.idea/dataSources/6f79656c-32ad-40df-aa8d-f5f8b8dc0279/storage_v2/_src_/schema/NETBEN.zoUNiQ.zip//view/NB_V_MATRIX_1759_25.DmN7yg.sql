create view NB_V_MATRIX_1759_25 as
SELECT t.task_id, t.isp_id,
	SUM(CASE WHEN t.ping_error = 10 OR t.ping_packet_lost = 10000 THEN 0 ELSE t.ts_ping_avg END) AS perf,
	COUNT(CASE WHEN t.ping_error = 10 OR t.ping_packet_lost = 10000 THEN NULL ELSE 1 END) AS succ,
	SUM(CASE WHEN t.ping_error = 10 THEN 0 ELSE t.ping_packet_lost END) AS loss,
	COUNT(CASE WHEN t.ping_error = 10 THEN NULL ELSE 1 END) AS total
FROM NB_TRAN_1759 t
WHERE t.task_id IN (1109,1128) AND t.tm_base > sysdate - interval '15' MINUTE AND t.isp_id IN (16,17,18,19,20,21,22,23,24,25,26,27,28) AND t.is_noise = 0
GROUP BY t.task_id, t.isp_id
ORDER BY t.task_id, t.isp_id


/

