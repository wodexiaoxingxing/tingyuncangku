create procedure auto_add_ddc_log_speed_part authid current_user
is
part_string varchar2(10);
v_partname varchar2(30);
v_rangedate varchar2(100);
v_s number;
v_error_desc varchar2(4000);
sqlStr varchar2(2000);
begin
  --nb_m_ddc_speed_log
  select to_char(sysdate+1,'yymmdd') into part_string from dual;
  v_partname:='PART_DDC_SPEED_LOG_'||part_string;
  v_rangedate:=to_char(sysdate+1,'yyyymmdd');
  dbms_output.put_line(v_rangedate);
  select count(*) into v_s from user_tab_partitions t where t.partition_name= v_partname;
  if v_s<1 then
    sqlStr := 'ALTER TABLE nb_m_ddc_speed_log  ADD PARTITION '||v_partname||' VALUES LESS THAN(to_date('''||v_rangedate||''',''yyyymmdd''))  tablespace netben';

    execute immediate sqlStr;
    else
       v_error_desc:='The partition is exist,partname:'||v_partname||',rangedate:'||v_rangedate;
                create_procedure_log('auto_add_ddc_speed_log_part',v_error_desc,'alarm');
  end if;
  select to_char(sysdate+2,'yymmdd') into part_string from dual;
  v_partname:='PART_DDC_SPEED_LOG_'||part_string;
  v_rangedate:=to_char(sysdate+2,'yyyymmdd');
  select count(*) into v_s from user_tab_partitions t where t.partition_name= v_partname;
  if v_s<1 then
    sqlStr := 'ALTER TABLE nb_m_ddc_speed_log  ADD PARTITION '||v_partname||' VALUES LESS THAN(to_date('''||v_rangedate||''',''yyyymmdd''))  tablespace netben';

    execute immediate sqlStr;
    else
       v_error_desc:='The partition is exist,partname:'||v_partname||',rangedate:'||v_rangedate;
                create_procedure_log('auto_add_ddc_speed_log_part',v_error_desc,'alarm');
  end if;
  --nb_m_ddc_speed_log_v
  select to_char(trunc(ADD_MONTHS (sysdate, 1),'mm'),'yymmdd') into part_string from dual;
  v_partname:='PART_DDC_SPEED_LOG_V_'||part_string;
  v_rangedate:=to_char(trunc(ADD_MONTHS (sysdate, 1),'mm'),'yyyymmdd');
  select count(*) into v_s from user_tab_partitions t where t.partition_name= v_partname;
  if v_s<1 then
    sqlStr := 'ALTER TABLE nb_m_ddc_speed_log_v  ADD PARTITION '||v_partname||' VALUES LESS THAN(to_date('''||v_rangedate||''',''yyyymmdd''))  tablespace netben';

   execute immediate sqlStr;
    else
       v_error_desc:='The partition is exist,partname:'||v_partname||',rangedate:'||v_rangedate;
                create_procedure_log('auto_add_ddc_speed_log_v_part',v_error_desc,'alarm');
  end if;
  select to_char(trunc(ADD_MONTHS (sysdate, 2),'mm'),'yymmdd') into part_string from dual;
  v_partname:='PART_DDC_SPEED_LOG_V_'||part_string;
  v_rangedate:=to_char(trunc(ADD_MONTHS (sysdate, 2),'mm'),'yyyymmdd');
  select count(*) into v_s from user_tab_partitions t where t.partition_name= v_partname;
  if v_s<1 then
    sqlStr := 'ALTER TABLE nb_m_ddc_speed_log_v  ADD PARTITION '||v_partname||' VALUES LESS THAN(to_date('''||v_rangedate||''',''yyyymmdd''))  tablespace netben';

    execute immediate sqlStr;
    else
       v_error_desc:='The partition is exist,partname:'||v_partname||',rangedate:'||v_rangedate;
                create_procedure_log('auto_add_ddc_speed_log_v_part',v_error_desc,'alarm');
  end if;
  --NB_CESU_PING_LOG
  select to_char(trunc(ADD_MONTHS (sysdate, 1),'mm'),'yyyymm') into part_string from dual;
  v_partname:='PART_CESU_PING_LOG_'||part_string;
  v_rangedate:=to_char(trunc(ADD_MONTHS (sysdate, 1),'mm'),'yyyymmdd');
  select count(*) into v_s from user_tab_partitions t where t.partition_name= v_partname;
  if v_s<1 then
    sqlStr := 'ALTER TABLE NB_CESU_PING_LOG  ADD PARTITION '||v_partname||' VALUES LESS THAN(to_date('''||v_rangedate||''',''yyyymmdd''))  tablespace netben';
   execute immediate sqlStr;
    else
       v_error_desc:='The partition is exist,partname:'||v_partname||',rangedate:'||v_rangedate;
                create_procedure_log('auto_add_NB_CESU_PING_LOG_part',v_error_desc,'alarm');
  end if;
  select to_char(trunc(ADD_MONTHS (sysdate, 2),'mm'),'yyyymm') into part_string from dual;
  v_partname:='PART_CESU_PING_LOG_'||part_string;
  v_rangedate:=to_char(trunc(ADD_MONTHS (sysdate, 2),'mm'),'yyyymmdd');
  select count(*) into v_s from user_tab_partitions t where t.partition_name= v_partname;
  if v_s<1 then
    sqlStr := 'ALTER TABLE NB_CESU_PING_LOG  ADD PARTITION '||v_partname||' VALUES LESS THAN(to_date('''||v_rangedate||''',''yyyymmdd''))  tablespace netben';
    execute immediate sqlStr;
    else
       v_error_desc:='The partition is exist,partname:'||v_partname||',rangedate:'||v_rangedate;
                create_procedure_log('auto_add_NB_CESU_PING_LOG_part',v_error_desc,'alarm');
  end if;
  exception when  others then
            v_error_desc := ' error: sqlCode:'||sqlcode||'  可能错误,在新增分区时,插入的分区比现存最大分区范围值小,partname:'||v_partname||',rangedate:'||v_rangedate;
           create_procedure_log('auto_add_ddc_log_speed_part',v_error_desc,'error');

end auto_add_ddc_log_speed_part;


/

