create PROCEDURE "INSERT_DPMBR_DP" authid current_user is
   
   -- 定义一个数组变量
  type id_member is table of number;
  memberId id_member := id_member();
  
  type id_impci is table of number;
  impciId id_impci := id_impci();
   --定义变量 
  i  NUMBER;
  j  NUMBER;
  points NUMBER;
  netid NUMBER;
 
begin
  i:=1;
  j:=1;
    -- 初始化数组
    -- 数组扩展到5个元素
    memberId.extend(5); 
    memberId(1) := 4;
    memberId(2) := 5;
    memberId(3) := 8;
    memberId(4) := 9;
    memberId(5) := 10;
    ----循环开始得到impciId数组
    impciId.extend(5);
    
   WHILE (i<=5)  
     LOOP
        BEGIN 
              select distinct IMPCI_ID into impciId(i) from NB_M_DPMBR_IMPCI mImpci where mImpci.Member_Id = memberId(i);
              i:=i+1;
         END;
     ----循环结束
     END LOOP;
    
   ----循环开始
   WHILE (j<=5)  
     LOOP
        BEGIN 
              points:= ceil(dbms_random.value(0,100));
              netid:= ceil(dbms_random.value(0,2));
              insert into NB_DPMBR_DP (MEMBER_ID,IMPCI_ID,NET_ID,CDATE,DATA_POINTS) 
              values(memberId(j),impciId(j),netid,sysdate,points);
              commit;
              j:=j+1;
         END;
     ----循环结束
     END LOOP;
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
   
end INSERT_DPMBR_DP;


/

