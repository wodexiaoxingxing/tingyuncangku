create view NB_V_TASK as
select id,
       owner_id,
       creator_id,
       agreement_id,
       name,
       ctime,
       mtime,
       expire,
       type,
       task_option,
       url,
       probgrp_id,
       status,
       detail_id
  from nb_m_task
union all
select id,
       owner_id,
       creator_id,
       agreement_id,
       name,
       ctime,
       mtime,
       expire,
       type,
       task_option,
       url,
       probgrp_id,
       status,
       detail_id
  from nb_m_task_his
/

