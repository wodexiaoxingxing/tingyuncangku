create PROCEDURE          "ALTER_MOBAPP_TRAN_ADD_FIELD" 
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(400);
  v_s number;
begin
  for tableName in(select t.table_name as name from user_tables t where t.table_name like 'NB_MOBAPP_TRAN_%') loop
  begin
    
     
      select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='SCREEN_WIDTH';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add SCREEN_WIDTH  INTEGER';
        execute   immediate   sqlStr ;
      end if;
      select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='SCREEN_HEIGHT';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add SCREEN_HEIGHT  INTEGER';
        execute   immediate   sqlStr ;
      end if;
      select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='IMEI';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add IMEI  INTEGER';
        execute   immediate   sqlStr ;
      end if;
      select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='MOBILE_SIGNAL';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add MOBILE_SIGNAL  INTEGER';
        execute   immediate   sqlStr ;
      end if;
    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlStr);
        create_procedure_log('alter_mobapp_tran_add_field',v_error_desc,sqlcode);
  end;
  end loop;

end alter_mobapp_tran_add_field;


/

