create PROCEDURE          "TRADE_CREATE_REPORT" authid current_user is
  reportCode varchar2(32);
  prevRepCode varchar2(32);
  reportName varchar2(64);
  currYear char(4);
  prevYear char(4);
  currOrder char(2);
  prevOrder char(2);
  currDate date;
  startDate date;
  sqlStr varchar2(4000);
begin
  startDate:=trunc(sysdate-160,'d'); --开始日期，当前日期向前一周
  currDate:=startDate + 7;--先为当前日期赋值，便于计算月季年
  --一次生成100条记录
  for i in 1..300 loop
     currDate:=startDate + 7 * i;
     currYear:=to_char(currDate,'yyyy');
     --取出要处理的行业ID
     for trade in (select id,code,table_str from nb_trade_list t) loop
         --首先处理按周的数据
         currOrder:=to_char(currDate,'ww');
         prevOrder:=to_char(currDate-7,'ww');
         prevYear:=to_char(currDate-7,'yyyy');
         reportName:=currYear || '年第'||currOrder||'期周报';
         --报表code 行业code + 当前年份 + 报表类型 + 当前顺序号
         reportCode:=trade.code || currYear || '1' || currOrder;
         prevRepCode:=trade.code || prevYear || '1' || prevOrder;
         sqlStr:='insert into nb_trade_report(id,code,name,trade_id,table_str,type,year,order_num,prev_report_id,start_date,end_date)values(:id,:code,:name,:tradeId,:tableStr,:type,:year,:orderNum,:prevRepId,:sDate,:eDate)';
         execute immediate sqlStr using reportCode,reportCode,reportName,trade.id,trade.table_str,1,currYear,currOrder,prevRepCode,trunc(currDate,'d'),trunc(currDate,'d')+27;
         commit;
     end loop;

  end loop;
end trade_create_report;


/

