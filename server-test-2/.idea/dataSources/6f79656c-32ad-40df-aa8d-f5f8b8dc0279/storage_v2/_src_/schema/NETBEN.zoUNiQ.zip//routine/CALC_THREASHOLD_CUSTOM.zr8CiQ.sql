create procedure calc_threashold_custom authid current_user is
sqlStr varchar2(4000);
v_calc_date date;
v_s number;
v_error_desc varchar2(4000);
begin
create_procedure_log('calc_threashold_custom','begin','run');
--首先统计出需要计算阈值的所有表
  for tableStr in (SELECT table_str as name from nb_m_agreement where id in
      (select distinct agreement_id from nb_m_task where type=255 and expire >= sysdate-1 and status = 1 and id in
      (select distinct task_id from nb_alarm_static where if_dynamic = 1 and status = 1))
   )loop
   begin
       create_procedure_log('calc_threashold_custom','tableStr:'||tableStr.name,'run');
       -- 1 周期为上一天
       -- 计算出上一天的日期
       v_calc_date := trunc(sysdate-1, 'dd');
       -- 找出该表下的所有 计算周期为1的任务ID
       for task in (select task_id as id,field from nb_alarm_static where calc_cycle=1 and status = 1 and task_id in
           (select id from nb_m_task where type=255  and agreement_id in(select id from nb_m_agreement where table_str=tableStr.name))
       )loop
       create_procedure_log('calc_threashold_custom','calcCycle:1 tableStr:'||tableStr.name||' taskId:'||task.id,'run '||task.field);
           -- 判断是否要计算的数据已经存在
           select count(*)  into v_s from nb_alarm_threshold where calc_cycle in(1,2) and calc_date = trunc(sysdate-1, 'dd') and task_id = task.id and field=task.field;
           if v_s < 1 then
               sqlStr := 'insert into nb_alarm_threshold(task_id,calc_cycle,value,calc_date,create_date,field)
                             select task_id,1,ts_total,tm_base,sysdate,:field
                             from (select task_id,round(avg('||field_convert(task.field)||'),0) as ts_total,trunc(tm_base,''dd'') as tm_base
                                   from nb_custom_'||tableStr.name||'
                                   where task_id=:tid and tm_base >= :sdate and tm_base < :edate
                                         and error_code < 600000
                                         and is_noise = 0
                                   group by task_id,trunc(tm_base,''dd'')
                                  )';
               execute immediate sqlStr using task.field,task.id,trunc(sysdate-1,'dd'),trunc(sysdate,'dd');
               commit;
           end if;
        end loop;


        -- 2 周期为上周当天
        -- 找出该表下的所有 计算周期为2的任务ID
       for task in (select task_id as id,field from nb_alarm_static where calc_cycle=2 and status = 1 and task_id in
           (select id from nb_m_task where type=255  and agreement_id in(select id from nb_m_agreement where table_str=tableStr.name))
       )loop
       create_procedure_log('calc_threashold_custom','calcCycle:2 tableStr:'||tableStr.name||' taskId:'||task.id,'run '||task.field);
           -- 判断是否要计算的数据已经存在
           select count(*)  into v_s from nb_alarm_threshold where calc_cycle in(1,2) and calc_date = trunc(sysdate-7, 'dd') and task_id = task.id and field=task.field;
           if v_s < 1 then
               sqlStr := 'insert into nb_alarm_threshold(task_id,calc_cycle,value,calc_date,create_date,field)
                             select task_id,2,ts_total,tm_base,sysdate,:field
                             from (select task_id,round(avg('||field_convert(task.field)||'),0) as ts_total,trunc(tm_base,''dd'') as tm_base
                                   from nb_custom_'||tableStr.name||'
                                   where task_id=:tid and tm_base >= :sdate and tm_base < :edate
                                         and error_code < 600000
                                         and is_noise = 0
                                   group by task_id,trunc(tm_base,''dd'')
                                  )';
               execute immediate sqlStr using task.field,task.id,trunc(sysdate-7,'dd'),trunc(sysdate-6,'dd');
               commit;
           end if;
        end loop;

        -- 3 周期为上一周
        -- 找出该表下的所有 计算周期为3的任务ID
       for task in (select task_id as id,field from nb_alarm_static where calc_cycle=3 and status = 1 and task_id in
           (select id from nb_m_task where type=255  and agreement_id in(select id from nb_m_agreement where table_str=tableStr.name))
       )loop
       create_procedure_log('calc_threashold_custom','calcCycle:3 tableStr:'||tableStr.name||' taskId:'||task.id,'run '||task.field);
           -- 判断是否要计算的数据已经存在
           select count(*)  into v_s from nb_alarm_threshold where calc_cycle =3 and calc_date = trunc(sysdate-7, 'd') and task_id = task.id and field=task.field;
           if v_s < 1 then
               sqlStr := 'insert into nb_alarm_threshold(task_id,calc_cycle,value,calc_date,create_date,field)
                             select task_id,3,ts_total,tm_base,sysdate,:field
                             from (select task_id,round(sum('||field_convert(task.field)||'*point_total)/sum(point_total),0) as ts_total,trunc(tm_base,''d'') as tm_base
                                   from nb_custom_'||tableStr.name||'
                                   where task_id=:tid and tm_base >= :sdate and tm_base < :edate
                                         and error_code < 600000
                                         and is_noise = 0
                                   group by task_id,trunc(tm_base,''d'')
                                  )';
               execute immediate sqlStr using task.field,task.id,trunc(sysdate-7,'d'),trunc(sysdate,'d');
               commit;
           end if;
        end loop;

        -- 4 周期为上一月
        -- 找出该表下的所有 计算周期为4的任务ID
       for task in (select task_id as id,field from nb_alarm_static where calc_cycle=4 and status = 1 and task_id in
           (select id from nb_m_task where type=255  and agreement_id in(select id from nb_m_agreement where table_str=tableStr.name))
       )loop
       create_procedure_log('calc_threashold_custom','calcCycle:4 tableStr:'||tableStr.name||' taskId:'||task.id,'run '||task.field);
           -- 判断是否要计算的数据已经存在
           select count(*)  into v_s from nb_alarm_threshold where calc_cycle =4 and calc_date = trunc(add_months(sysdate,-1),'mm') and task_id = task.id and field=task.field;
           if v_s < 1 then
               sqlStr := 'insert into nb_alarm_threshold(task_id,calc_cycle,value,calc_date,create_date,field)
                             select task_id,4,ts_total,tm_base,sysdate,:field
                             from (select task_id,round(sum('||field_convert(task.field)||'*point_total)/sum(point_total),0) as ts_total,trunc(tm_base,''mm'') as tm_base
                                   from nb_custom_'||tableStr.name||'
                                   where task_id=:tid and tm_base >= :sdate and tm_base < :edate
                                         and error_code < 600000
                                         and is_noise = 0
                                   group by task_id,trunc(tm_base,''mm'')
                                  )';
               execute immediate sqlStr using task.field,task.id,trunc(add_months(sysdate,-1),'mm'),trunc(sysdate,'mm');
               commit;
           end if;
        end loop;
        exception when  others then
        v_error_desc := 'Error :'|| sqlerrm || '  tablestr:' || tableStr.name ;
        --DBMS_OUTPUT.PUT_LINE(v_error_desc);
        create_procedure_log('calc_threashold_custom',sqlerrm,'error');
   end;
   end loop;
   create_procedure_log('calc_threashold_custom','end','run');
end calc_threashold_custom;


/

