create function "SEL_MEMBERS"(name_pattern in varchar2)
  return sys_refcursor is
  ids sys_refcursor;
begin
  open ids for
    select id, username
      from nb_m_member
     where username like concat(name_pattern, '%');

  return ids;
end;


/

