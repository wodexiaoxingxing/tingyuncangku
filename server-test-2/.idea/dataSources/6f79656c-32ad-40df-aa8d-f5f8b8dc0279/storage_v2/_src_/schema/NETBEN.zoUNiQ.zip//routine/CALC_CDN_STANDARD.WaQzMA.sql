create procedure calc_cdn_standard authid current_user is
sqlStr varchar2(4000);
suff number;
stime date;
etime date;
s number;
total number;
begin
  total := 2000;
  create_procedure_log('calc_cdn_standard','begin','run');
  stime:=trunc(sysdate-14,'dd');
  etime:=trunc(sysdate,'dd');
  sqlStr:='truncate table nb_m_cdn_standard_tmp';
  execute immediate sqlStr;
  s:=0;
  -- 计算 dns,首包，建连，可用性 用全页面数据
  for suff in(SELECT id as name FROM nb_m_task  where type in(1,2) and task_option='F' and status = 1 and expire > sysdate -1) loop
    begin
      if s>total then exit; end if;
      s:=s+1;
      create_procedure_log('calc_cdn_standard','全页面：'||suff.name,'run');
      sqlStr:='truncate table nb_m_cdn_standard_tmp1';
      execute immediate sqlStr;
      sqlStr:='insert into nb_m_cdn_standard_tmp1(city_id,isp_id,dest_ip,point_total,point_succ,
           ts_dns,point_dns,ts_connect,point_connect,ts_first_packet,point_first_packet)
              select city_id,isp_id,dest_ip,sum(point_total) point_total,sum(point_succ) point_succ,
                 round(sum(ts_dns*point_dns)/sum(point_dns)) ts_dns,
                 sum(point_dns) point_dns,
                 round(sum(ts_connect*point_connect)/sum(point_connect)) ts_connect,
                 sum(point_connect) point_connect,
                 round(sum(ts_first_packet*point_first_packet)/sum(point_first_packet)) ts_first_packet,
                 sum(point_first_packet) point_first_packet
               from(
                  select city_id,
                         isp_id,
                         url_ip dest_ip,
                         sum(point_total) point_total,
                         sum(case when error_code < 600000 then 1 else 0 end) point_succ,
                         round(avg(case when error_code < 600000 and ts_dns>0 and ts_dns<2000 then  ts_dns else null end)) ts_dns,
                         sum(case when error_code < 600000 and ts_dns>0 and ts_dns<2000 then 1 else 0 end) point_dns,
                         round(avg(case when error_code < 600000 and ts_connect > 0 and ts_connect < 2000 then ts_connect else null end)) ts_connect,
                         sum(case when error_code < 600000 and ts_connect>0 and ts_connect < 2000 then 1 else 0 end) point_connect,
                         round(avg(case when error_code < 600000 and ts_first_packet>0 and ts_first_packet < 2000 then ts_first_packet else null end)) ts_first_packet,
                         sum(case when error_code < 600000 and ts_first_packet>0 and ts_first_packet < 2000 then 1 else 0 end) point_first_packet
                    from nb_et_'||suff.name||'
                   where tm_base > :st and tm_base < :et and cdn_id > 0 and cdn_id < 255
                   group by city_id, isp_id, url_ip
                 union all
                   select city_id,isp_id,dest_ip,point_total,point_succ,ts_dns,point_dns,ts_connect,point_connect,ts_first_packet,point_first_packet
                     from nb_m_cdn_standard_tmp
                 )

                 group by city_id,isp_id,dest_ip';
      execute immediate sqlStr using stime,etime ;
      commit;
      sqlStr:='truncate table nb_m_cdn_standard_tmp';
      execute immediate sqlStr;

      sqlStr:='insert into nb_m_cdn_standard_tmp select * from nb_m_cdn_standard_tmp1';
      execute immediate sqlStr;
      commit;
   exception when others then
      create_procedure_log('calc_cdn_standard','全页面：tableName:'||suff.name||','||sqlerrm,'error');
    end;
  end loop;
  -- 计算 下载速度 用单文件
 s:=0;
 for suff in(SELECT id as name FROM nb_m_task  where type in(1,2) and task_option='S' and status = 1 and expire > sysdate -1) loop
    begin
      if s>total then exit; end if;
      s:=s+1;
      create_procedure_log('calc_cdn_standard','单文件：'||suff.name,'run');
      sqlStr:='truncate table nb_m_cdn_standard_tmp1';
      execute immediate sqlStr;
      sqlStr:='insert into nb_m_cdn_standard_tmp1(city_id,isp_id,dest_ip,point_total,point_succ,
           ts_dns,point_dns,ts_connect,point_connect,ts_first_packet,point_first_packet,rate_download,point_rate_download)
              select city_id,isp_id,dest_ip,sum(point_total) point_total,sum(point_succ) point_succ,
                 round(sum(ts_dns*point_dns)/sum(point_dns)) ts_dns,
                 sum(point_dns) point_dns,
                 round(sum(ts_connect*point_connect)/sum(point_connect)) ts_connect,
                 sum(point_connect) point_connect,
                 round(sum(ts_first_packet*point_first_packet)/sum(point_first_packet)) ts_first_packet,
                 sum(point_first_packet) point_first_packet,
                 round(sum(rate_download*point_rate_download)/sum(point_rate_download)) rate_download,
                 sum(point_rate_download) point_rate_download
               from(
                  select city_id,
                         isp_id,
                         url_ip dest_ip,
                         sum(point_total) point_total,
                         sum(case when error_code < 600000 then 1 else 0 end) point_succ,
                         round(avg(case when error_code < 600000 and ts_dns>0 and ts_dns<2000 then  ts_dns else null end)) ts_dns,
                         sum(case when error_code < 600000 and ts_dns>0 and ts_dns<2000 then 1 else 0 end) point_dns,
                         round(avg(case when error_code < 600000 and ts_connect > 0 and ts_connect < 2000 then ts_connect else null end)) ts_connect,
                         sum(case when error_code < 600000 and ts_connect>0 and ts_connect < 2000 then 1 else 0 end) point_connect,
                         round(avg(case when error_code < 600000 and ts_first_packet>0 and ts_first_packet < 2000 then ts_first_packet else null end)) ts_first_packet,
                         sum(case when error_code < 600000 and ts_first_packet>0 and ts_first_packet < 2000 then 1 else 0 end) point_first_packet,
                         round(avg(case when error_code < 600000 and rate_download>400000 then rate_download else null end)) rate_download,
                         sum(case when error_code < 600000 and rate_download>400000 then 1 else 0 end) point_rate_download
                    from nb_et_'||suff.name||'
                   where tm_base > :st and tm_base < :et and cdn_id > 0 and cdn_id < 255
                   group by city_id, isp_id, url_ip
                 union all
                   select city_id,isp_id,dest_ip,point_total,point_succ,ts_dns,point_dns,ts_connect,point_connect,ts_first_packet,point_first_packet,rate_download,point_rate_download
                     from nb_m_cdn_standard_tmp
                 )

                 group by city_id,isp_id,dest_ip';
      execute immediate sqlStr using stime,etime ;
      commit;
      sqlStr:='truncate table nb_m_cdn_standard_tmp';
      execute immediate sqlStr;

      sqlStr:='insert into nb_m_cdn_standard_tmp select * from nb_m_cdn_standard_tmp1';
      execute immediate sqlStr;
      commit;
   exception when others then
      create_procedure_log('calc_cdn_standard','单文件：tableName:'||suff.name||','||sqlerrm,'error');
    end;
  end loop;
  --原设计均从同类型任务中出
  /*for suff in(SELECT id as name FROM nb_m_task  where type in(1,2) and task_option='S' and status = 1 and expire > sysdate -1) loop
    begin
      if s>2000 then exit; end if;
      s:=s+1;
      create_procedure_log('calc_cdn_standard',suff.name,'run');
      sqlStr:='truncate table nb_m_cdn_standard_tmp1';
      execute immediate sqlStr;
      sqlStr:='insert into nb_m_cdn_standard_tmp1(city_id,isp_id,dest_ip,point_total,point_succ,
           ts_dns,point_dns,ts_connect,point_connect,ts_first_packet,point_first_packet,rate_download,point_rate_download)
              select city_id,isp_id,dest_ip,sum(point_total) point_total,sum(point_succ) point_succ,
                 round(sum(ts_dns*point_dns)/sum(point_dns)) ts_dns,
                 sum(point_dns) point_dns,
                 round(sum(ts_connect*point_connect)/sum(point_connect)) ts_connect,
                 sum(point_connect) point_connect,
                 round(sum(ts_first_packet*point_first_packet)/sum(point_first_packet)) ts_first_packet,
                 sum(point_first_packet) point_first_packet,
                 round(sum(rate_download*point_rate_download)/sum(point_rate_download)) rate_download,
                 sum(point_rate_download) point_rate_download
               from(
                  select city_id,
                         isp_id,
                         url_ip dest_ip,
                         sum(point_total) point_total,
                         sum(case when error_code < 600000 then 1 else 0 end) point_succ,
                         round(avg(case when error_code < 600000 and ts_dns>0 and ts_dns<2000 then  ts_dns else null end)) ts_dns,
                         sum(case when error_code < 600000 and ts_dns>0 and ts_dns<2000 then 1 else 0 end) point_dns,
                         round(avg(case when error_code < 600000 and ts_connect > 0 and ts_connect < 2000 then ts_connect else null end)) ts_connect,
                         sum(case when error_code < 600000 and ts_connect>0 and ts_connect < 2000 then 1 else 0 end) point_connect,
                         round(avg(case when error_code < 600000 and ts_first_packet>0 and ts_first_packet < 2000 then ts_first_packet else null end)) ts_first_packet,
                         sum(case when error_code < 600000 and ts_first_packet>0 and ts_first_packet < 2000 then 1 else 0 end) point_first_packet,
                         round(avg(case when error_code < 600000 and rate_download>0 then rate_download else null end)) rate_download,
                         sum(case when error_code < 600000 and rate_download>0 then 1 else 0 end) point_rate_download
                    from nb_et_'||suff.name||'
                   where tm_base > :st and tm_base < :et and cdn_id > 0 and cdn_id < 255
                   group by city_id, isp_id, url_ip
                 union all
                   select city_id,isp_id,dest_ip,point_total,point_succ,ts_dns,point_dns,ts_connect,point_connect,ts_first_packet,point_first_packet,rate_download,point_rate_download
                     from nb_m_cdn_standard_tmp
                 )
                 where point_succ>0 and point_dns>0 and point_connect > 0 and point_first_packet>0 and point_rate_download > 0
                 group by city_id,isp_id,dest_ip';
      execute immediate sqlStr using stime,etime ;
      commit;
      sqlStr:='truncate table nb_m_cdn_standard_tmp';
      execute immediate sqlStr;

      sqlStr:='insert into nb_m_cdn_standard_tmp select * from nb_m_cdn_standard_tmp1';
      execute immediate sqlStr;
      commit;
   exception when others then
      create_procedure_log('calc_cdn_standard','tableName:'||suff.name||','||sqlerrm,'error');
    end;
  end loop;*/

  --计算城市运营商对应的最好的IP排名



  sqlStr:='insert into nb_m_cdn_better_destip(city_id,isp_id,dest_ip,order_num,ctime)
        select city_id,isp_id,dest_ip,order_num,sysdate
          from (select city_id,
                       isp_id,
                       dest_ip,
                       rank() over(partition by city_id, isp_id order by num_total) order_num
                  from (select city_id,
                               isp_id,
                               dest_ip,
                               (num_dns * 10 + num_connect * 10 +
                               num_first_packet * 10 + num_rate_download * 30 +
                               num_avail*40) / 100 num_total
                          from (select city_id,
                                       isp_id,
                                       dest_ip,
                                       rank() over(partition by city_id, isp_id order by ts_dns) num_dns,
                                       rank() over(partition by city_id, isp_id order by ts_connect) num_connect,
                                       rank() over(partition by city_id, isp_id order by ts_first_packet) num_first_packet,
                                       rank() over(partition by city_id, isp_id order by rate_download desc) num_rate_download,
                                       rank() over(partition by city_id, isp_id order by point_succ / point_total desc) num_avail
                                  from nb_m_cdn_standard_tmp)))
         where order_num < 11';
  execute immediate sqlStr;
  commit;
  --计算基线
  sqlStr:='insert into nb_m_cdn_standard(ts_dns,ts_connect,ts_first_packet,rate_download,available)
            select round(sum(ts_dns * point_dns) / sum(point_dns)) ts_dns,
               round(sum(ts_connect * point_connect) / sum(point_connect)) ts_connect,
               round(sum(ts_first_packet * point_first_packet) / sum(point_first_packet)) ts_first_packet,
               round(sum(rate_download * point_rate_download) / sum(point_rate_download)) rate_download,
               round(sum(point_succ) / sum(point_total)*100,1)
           from nb_m_cdn_standard_tmp';
  execute immediate sqlStr;
  commit;

  sqlStr:='truncate table nb_m_cdn_standard_tmp';
  execute immediate sqlStr;
  --增加上主机覆盖率
  s:=0;
  for tableName in(select t.table_name as name from user_tables t where regexp_like( t.table_name,'^NB_PAGE_[0-9]')) loop
    begin
      if s>total then exit; end if;
      s:=s+1;
      create_procedure_log('calc_cdn_standard','tableName:'||tableName.name,'run');
      sqlStr:='insert into nb_m_cdn_standard_tmp(point_succ,point_total)
           select sum(p.is_cdn_cover),sum(p.point_total)
                from '||tableName.name||' p,
                     nb_m_task t,
                     (select task_id, count(*)
                        from nb_m_task_dest
                       group by task_id
                      having count(*) > 200) td
               where p.tm_base > :st and p.tm_base < :et
                 and t.id = td.task_id
                 and t.id = p.task_id
                 and p.dest_ip is not null';
      execute immediate sqlStr using stime,etime ;
      commit;
    exception when others then
        create_procedure_log('calc_cdn_standard','tableName:'||tableName.name||','||sqlerrm,'error');
    end;
  end loop;
  create_procedure_log('calc_cdn_standard','update nb_m_cdn_standard begin','run');
  sqlStr:='update nb_m_cdn_standard set ctime=sysdate,cover_per = (select round(sum(point_succ)/sum(point_total)*100,1) from nb_m_cdn_standard_tmp)
              where ctime is null';
  execute immediate sqlStr  ;
  commit;

  create_procedure_log('calc_cdn_standard','end','run');
end calc_cdn_standard;

/

