create PROCEDURE          "IN_TOP_ERROR" (
  tableStr in number,
  taskId in number
) authid current_user
is
  sqlStr  varchar2(4000);
  s number;
  errorDesc varchar2(4000);
  startDate date;
  endDate date;
begin
  create_procedure_log('in_top_error','tableStr:' || tableStr || ' taskId:' || taskId || '  begin','run');
  select count(*) INTO s FROM user_tables where table_name = 'NB_ET_' || taskId;
  if s < 1 then
    create_procedure_log('in_top_error','tableStr:' || tableStr || ' taskId:' || taskId ||' 任务表未找到','alarm');
    return;
  end if;

  startDate := trunc(sysdate-10,'dd');
  endDate := trunc(sysdate,'dd');
  --删除指定日期内的所有生成数据，防止重复生成数据
  sqlStr:='delete nb_top_error where task_id = :tid and tm_day >= :sDate and tm_day < :eDate';
  execute immediate sqlStr using taskId,startDate,endDate;
  commit;
  sqlStr:='insert into nb_top_error(task_id,tm_day,url,url_id,url_host,domain_id,error_code,error_count,error_type,point_total,table_str)
           select '||taskId ||',s1.tm_day,e.url,s1.url_id,d.name,s1.domain_id,s1.error_code,s1.error_count,2,s1.point_total,'||tableStr||'
            from
              (
                select
                   tm_day,
                   url_id,
                   domain_id,
                   error_code,
                   sum(point_total) as error_count,
                   point_all as point_total
                from
                  (select trunc(tm_base,''dd'') as tm_day,
                         url_id,
                         domain_id,
                         error_code,
                         point_total,
                         sum(point_total)over(partition by url_id,domain_id) as point_all
                   from nb_et_'||taskId||'
                  where
                     tm_base >= :sdate  and tm_base < :edate)
                where error_code >600000
                group by
                  url_id,
                  domain_id,
                  error_code,
                  tm_day,
                  point_all
             )s1,
               nb_e_url_'||tableStr||' e,
               nb_e_domain d
             where s1.url_id = e.id and s1.domain_id = d.id
          ';
  execute immediate sqlStr using startDate,endDate;
  commit;

  create_procedure_log('in_top_error','tableStr:' || tableStr || ' taskId:' || taskId || '  end','run');
  --如果创建序列失败，则显示出失败代码
  exception when  others then
      errorDesc := 'tableStr:' || tableStr || ' taskId:' || taskId ||' Error:' || sqlerrm;
      --DBMS_OUTPUT.PUT_LINE(errorDesc);
      create_procedure_log('in_top_error',errorDesc,'error');
end in_top_error;


/

