create procedure update_mt_page_part is
type tabType is table of varchar2(32) index by BINARY_INTEGER;
tabTypeImpl tabType;
DROP_ERROR exception;
ADD_ERROR exception;
sqlStr varchar2(4000);
currDate date := trunc(sysdate,'dd');

partNameNew varchar2(64);
partValueNew varchar2(64);
partDate date;
begin
  DBMS_OUTPUT.ENABLE (1000000);
  tabTypeImpl(1):='NB_PAGE';
  tabTypeImpl(2):='MT_PAGE';
  --处理删除分区，将所有90天以前的分区均删除
  /*for s in 1..tabTypeImpl.count loop
    for tab in(select table_name tabName,partition_name partName from user_tab_partitions where table_name like tabTypeImpl(s)||'\_%'  escape '\' and to_date(substr(partition_name, -6), 'yymmdd') < currDate-90)
    loop
      begin
         partDate:=to_date(substr(tab.partName,-6),'yymmdd');
         if  partDate > currDate - 90 then  raise DROP_ERROR; end if;
         sqlStr:='alter table '||tab.tabName||' drop partition '||tab.partName;
         --dbms_output.put_line(sqlStr);
         execute immediate sqlStr;
      exception
         when DROP_ERROR then null;
         when others then
         create_procedure_log('update_mt_page_part','dropError,sql:'||sqlStr||','||sqlerrm,'error');
      end;
    end loop;*/
    --处理增加分区，一次只增加一个
    for tab in(
          select a.table_name tabName,a.partition_name partName from
           (select table_name,partition_position,partition_name from user_tab_partitions where table_name like tabTypeImpl(s)||'\_%'  escape '\')a,
           (select table_name,max(partition_position) partition_position from user_tab_partitions where table_name like tabTypeImpl(s)||'\_%'  escape '\' group by table_name)b
           where a.table_name = b.table_name and a.partition_position = b.partition_position
    )loop
      begin
        partDate:=to_date(substr(tab.partName,-6),'yymmdd');
        dbms_output.put_line(tab.partname);
        if partDate > currDate + 14 then raise ADD_ERROR; end if;
        partNameNew:=substr(tab.partName,1,length(tab.partName)-6)||to_char(partDate+7,'yymmdd');
        partValueNew :='to_date('''||to_char(partDate+7,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
        sqlStr := 'ALTER TABLE '||tab.tabName || ' ADD PARTITION '||partNameNew||' VALUES LESS THAN('||partValueNew||')';
        --dbms_output.put_line(sqlStr);
        execute immediate sqlStr;
      exception
        when ADD_ERROR then null;
        when others then
          create_procedure_log('update_mt_page_part','addError,sql:'||sqlStr||','||sqlerrm,'error');
      end;
    end loop;
  end loop;
end update_mt_page_part;


 
/

