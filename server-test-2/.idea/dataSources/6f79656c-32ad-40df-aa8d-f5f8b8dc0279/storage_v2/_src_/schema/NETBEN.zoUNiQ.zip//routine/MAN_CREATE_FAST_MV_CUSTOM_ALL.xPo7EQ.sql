create PROCEDURE          "MAN_CREATE_FAST_MV_CUSTOM_ALL" authid current_user
is
  sqlStr  varchar2(4000);
  v_name varchar2(400);
  v_error_desc varchar2(4000);
  v_s number;
  l_name varchar2(100);
  CURSOR c_emp IS SELECT substr(t.table_name,11) FROM user_tables t where t.table_name like 'NB_CUSTOM_%';
begin
OPEN c_emp;
LOOP
  begin
    --创建物化视图日志
    create_procedure_log('create_fast_mv_stream_all','create mv_custom_'||v_name,'message');
    FETCH c_emp INTO v_name;
    EXIT WHEN c_emp%NOTFOUND;
    select count(*)  INTO v_s FROM all_objects t where t.object_name = 'MLOG$_NB_CUSTOM_'||v_name;
    if v_s > 0 then
        sqlStr:=  'drop materialized view log on nb_custom_'||v_name;
        execute immediate sqlstr;
    DBMS_OUTPUT.PUT_LINE(sqlstr);
    end if;
        sqlStr:='create materialized view log on nb_custom_'||v_name||' with rowid,
         sequence (task_id,
         city_id,
         isp_id,
         net_speed_id,
         error_code,
         is_noise,
         dest_ip,
         tm_base,
         point_total,
         ts_total,
         cust_field1,
         cust_field2,
         cust_field3,
         cust_field4,
         cust_field5,
         cust_field6,
         cust_field7,
         cust_field8,
         cust_field9,
         cust_field10,
         cust_field11,
         cust_field12,
         cust_field13,
         cust_field14,
         cust_field15,
         cust_field16,
         cust_field17,
         cust_field18,
         cust_field19,
         cust_field20,
         cust_field21,
         cust_field22,
         cust_field23,
         cust_field24,
         cust_field25,
         cust_field26,
         cust_field27,
         cust_field28,
         cust_field29,
         cust_field30,
         os_ver_id,
         bs_id,
         bs_ver_id
         ) including new values';
--    execute immediate sqlStr;
 l_name := 'creating materialized view log on nb_custom_'||v_name||'..... ';
 DBMS_OUTPUT.PUT_LINE(l_name);
--  DBMS_OUTPUT.PUT_LINE(sqlStr);
      execute immediate sqlStr;
  l_name := 'materialized view log on nb_custom_'||v_name||' created!';
 DBMS_OUTPUT.PUT_LINE(l_name);
    select count(*)  INTO v_s FROM all_objects t where t.object_name = 'MV_CUSTOM_'||v_name;
    if v_s > 0 then
    --删除物化视图
    --DBMS_OUTPUT.PUT_LINE('drop mv_tran_'||v_name);
    sqlStr:='drop materialized view mv_custom_'||v_name;
    execute immediate sqlStr;
    DBMS_OUTPUT.PUT_LINE(sqlStr);
    end if;
   --custom 物化视图
    create_procedure_log('create_fast_mv_custom_all','start materialized view  mv_custom_'||v_name,'message');
    sqlStr:='create materialized view MV_CUSTOM_'||v_name||'
    refresh fast
    start with sysdate next sysdate + 4/24
    as
    (select task_id,
        city_id,
        isp_id,
        net_speed_id,
        error_code,
        is_noise,
        dest_ip,
        (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8) / 24) as tm_hour8,
        os_ver_id,
        bs_id,
        bs_ver_id,
        count(*) as c1,
        count(point_total) as c2,
        count(ts_total) as c3,
        count(cust_field1) as c4,
        count(cust_field2) as c5,
        count(cust_field3) as c6,
        count(cust_field4) as c7,
        count(cust_field5) as c8,
        count(cust_field6) as c9,
        count(cust_field7) as c10,
        count(cust_field8) as c11,
        count(cust_field9) as c12,
        count(cust_field10) as c13,
        count(cust_field11) as c14,
        count(cust_field12) as c15,
        count(cust_field13) as c16,
        count(cust_field14) as c17,
        count(cust_field15) as c18,
        count(cust_field16) as c19,
        count(cust_field17) as c20,
        count(cust_field18) as c21,
        count(cust_field19) as c22,
        count(cust_field20) as c23,
        count(cust_field21) as c24,
        count(cust_field22) as c25,
        count(cust_field23) as c26,
        count(cust_field24) as c27,
        count(cust_field25) as c28,
        count(cust_field26) as c29,
        count(cust_field27) as c30,
        count(cust_field28) as c31,
        count(cust_field29) as c32,
        count(cust_field30) as c33,
              sum(point_total) as point_total,
              avg(ts_total) as ts_total,
              avg(cust_field1) as cust_field1,
              avg(cust_field2) as cust_field2,
              avg(cust_field3) as cust_field3,
              avg(cust_field4) as cust_field4,
              avg(cust_field5) as cust_field5,
              avg(cust_field6) as cust_field6,
              avg(cust_field7) as cust_field7,
              avg(cust_field8) as cust_field8,
              avg(cust_field9) as cust_field9,
              avg(cust_field10) as cust_field10,
              avg(cust_field11) as cust_field11,
              avg(cust_field12) as cust_field12,
              avg(cust_field13) as cust_field13,
              avg(cust_field14) as cust_field14,
              avg(cust_field15) as cust_field15,
              avg(cust_field16) as cust_field16,
              avg(cust_field17) as cust_field17,
              avg(cust_field18) as cust_field18,
              avg(cust_field19) as cust_field19,
              avg(cust_field20) as cust_field20,
              avg(cust_field21) as cust_field21,
              avg(cust_field22) as cust_field22,
              avg(cust_field23) as cust_field23,
              avg(cust_field24) as cust_field24,
              avg(cust_field25) as cust_field25,
              avg(cust_field26) as cust_field26,
              avg(cust_field27) as cust_field27,
              avg(cust_field28) as cust_field28,
              avg(cust_field29) as cust_field29,
              avg(cust_field30) as cust_field30
    from nb_custom_'||v_name||'
    group by task_id,
           city_id,
           isp_id,
           net_speed_id,
           error_code,
           is_noise,
           dest_ip,
           (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8) / 24),
           os_ver_id,
           bs_id,
           bs_ver_id)';

 --   execute   immediate   sqlStr;
 
  l_name := 'creating materialized view mv_custom_'||v_name;
 DBMS_OUTPUT.PUT_LINE(l_name);
      execute immediate sqlStr;
  l_name := 'materialized view mv_custom_'||v_name||'created!';
 DBMS_OUTPUT.PUT_LINE(l_name);
 DBMS_OUTPUT.PUT_LINE('###############################################');

/*
  --索引
  --  sqlStr:='create index IN_MV_CUSTOM_ERROR_'||v_name||' on MV_CUSTOM_'||v_name||' (TASK_ID,TM_HOUR8, ERROR_CODE, CITY_ID) tableSpace NETBEN_IDX';
 --   execute   immediate   sqlStr;
    --索引
 --   sqlStr:='create index IN_MV_CUSTOM_PERF_'||v_name||' on MV_CUSTOM_'||v_name||' (TASK_ID,TM_HOUR8, CITY_ID, ISP_ID) tableSpace NETBEN_IDX';
 --   execute   immediate   sqlStr;

*/
   --如果创建失败，则显示出失败的表
   exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:' || v_name;
        DBMS_OUTPUT.PUT_LINE(v_error_desc);
        create_procedure_log('create_fast_mv_custom_all',v_error_desc,sqlcode);
        end;
END LOOP;

CLOSE c_emp;
end man_create_fast_mv_custom_all;


/

