create procedure createTracerouteTable(tableStr IN varchar2)
    authid current_user is
    sqlStr varchar2(4000);
begin
    --create trace sequence
    sqlStr := 'create sequence SEQ_NB_TRACE_ID_' || tableStr || ' minvalue 1 maxvalue 9999999999999999999999999 start with 1 increment by 1 cache 500';
    execute immediate sqlStr;

    --create TABLE of NB_TRACE
    sqlStr := 'create table NB_TRACE_' || tableStr || '
  (
    ID              NUMBER not null,
    TASK_ID         NUMBER,
    PROBE_IP        NUMBER,
    CITY_ID         NUMBER,
    ISP_ID          NUMBER,
    NET_SPEED_ID    NUMBER,
    MEMBER_ID       NUMBER,
    DNS_SERVER      VARCHAR2(128),
    TM_BASE         DATE,
    ERROR_CODE      NUMBER,
    ERROR_IP        VARCHAR2(39),
    IS_NOISE        NUMBER,
    VERSION_ID      NUMBER,
    PERCENT_CPU     NUMBER,
    DEST_IP         VARCHAR2(39),
    DEST_CITY_ID    NUMBER,
  DEST_ISP_ID     NUMBER,
    DEST_NAME       VARCHAR2(512),
    TRACERT_RESULT  VARCHAR2(512),
    NSLOOKUP_RESULT VARCHAR2(512),
    TTL_TOTAL       NUMBER,
    TS_TOTAL        NUMBER,
    POINT_TOTAL     NUMBER default 1,
      TRACE_ID            VARCHAR2(128),
      FEEDBACK            INTEGER
  ) pctfree 0
  tablespace NETBEN';
    execute immediate sqlStr;

    sqlStr := 'alter table NB_TRACE_' || tableStr || ' add constraint PK_NB_TRACE_' || tableStr || ' primary key (ID) using index tablespace NETBEN';
    execute immediate sqlStr;

    -- NB_TRACE index
    sqlStr := 'create index IN_TRACE_PERF_' || tableStr || ' on NB_TRACE_' || tableStr || ' (TM_BASE,TASK_ID) tableSpace NETBEN_IDX_NEW';
    execute immediate sqlStr;

    --create TABLE of NB_ROUTE
    sqlStr := 'create table NB_ROUTE_' || tableStr || '
  (
    TRACE_ID   NUMBER not null,
    TTL_ORDER  NUMBER,
    RTT_MAX    NUMBER,
    RTT_MIN    NUMBER,
    RTT_MEAN   NUMBER,
    DEST_IP    VARCHAR2(39),
    DEST_CITY_ID   NUMBER,
  DEST_ISP_ID    NUMBER,
    DEST_NAME  VARCHAR2(256),
    ERROR_CODE NUMBER
  )
  tablespace NETBEN';
    execute immediate sqlStr;

    sqlStr := 'create index IN_ROUTE_TRACE_ID_' || tableStr || ' on NB_ROUTE_' || tableStr || ' (TRACE_ID) tableSpace NETBEN_IDX_NEW';
    execute immediate sqlStr;

    -- Create table of NB_ROUTE_STAT
    sqlStr := 'create table NB_ROUTE_STAT_' || tableStr || '
  (
    TASK_ID     NUMBER,
    DEST_IP     VARCHAR2(39),
    TM_HOUR4    DATE,
    RTT_TOTAL   NUMBER,
    PATH_DESC   VARCHAR2(1000),
    PATH_COUNT  NUMBER,
    POINT_TOTAL NUMBER
  ) pctfree 0
  tablespace NETBEN';
    execute immediate sqlStr;

    -- Create/Recreate indexes
    sqlStr := 'create index IN_ROUTE_STAT_TASKDEST_' || tableStr || ' on NB_ROUTE_STAT_' || tableStr || ' (TM_HOUR4, TASK_ID, DEST_IP)  tablespace NETBEN_IDX_NEW';
    execute immediate sqlStr;

end createTracerouteTable;
/

