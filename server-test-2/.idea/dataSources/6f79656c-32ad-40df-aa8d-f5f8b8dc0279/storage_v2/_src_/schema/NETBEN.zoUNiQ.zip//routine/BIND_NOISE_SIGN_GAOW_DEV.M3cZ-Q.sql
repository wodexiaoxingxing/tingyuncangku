create procedure bind_noise_sign_gaow_dev authid current_user is
  sqlStr     varchar2(4000);
  error_desc varchar2(4000);
  startTime  date;
  endTime    date;
  ctime      date;
  mtime      date;
  s          number;
  hour       number;
  hourDay    number := 22;
  min_points number := 0;
  errorTable varchar2(1000);
begin
  create_procedure_log('calc_cdn_host', 'begin', 'run');
  startTime := trunc(sysdate, 'dd');
  endTime   := trunc(sysdate + 1, 'dd');
  ctime     := sysdate;
  mtime     := sysdate;
  hour      := to_number(to_char(sysdate, 'hh24'));
  sqlStr    := 'truncate table nb_m_task_dest_tmp';
  execute immediate sqlStr;

  for noise_bind in (select *
                       from nb_m_ddc_log_col t1
                      where t1.tm_base between sysdate - 1 and sysdate
                 --       and t1.is_noise != 0
                        and exists (select 1
                               from nb_m_ddc_log_col t2
                              where t2.tm_base between
                                    sysdate - 1 and sysdate
                                and t2.is_noise = 0
                                and t1.tpid = t2.tpid
                                and t1.task_id = t2.task_id
                                and t1.host_id = t2.host_id
                                and t1.rowid != t2.rowid)) loop
    begin
      DBMS_OUTPUT.PUT_LINE(noise_bind.task_id);
    end;
  end loop;

end bind_noise_sign_gaow_dev;
/

