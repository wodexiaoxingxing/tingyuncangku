create PROCEDURE PROCEDURE_23617authid current_user is     sqlStr varchar2(4000);    begin    sqlStr:='update nb_m_task set sla_probes = 1000,status = 1,mtime=sysdate where id = 23617';    execute immediate sqlStr;    commit;    create_procedure_log('PROCEDURE_23617','end','run');    for i in 59 loop     DBMS_LOCK.sleep (300);    sqlStr:='update nb_m_task set sla_probes = sla_probes + 400,status = 1,mtime=sysdate where id = 23617';    execute immediate sqlStr;    commit;    create_procedure_log('PROCEDURE_23617','end','run');    end loop;    DBMS_LOCK.sleep (300);    sqlStr:='update nb_m_task  set sla_probes = 2000,status = 0,mtime = sysdate where id = 23617';    execute immediate sqlStr;    commit;    create_procedure_log('PROCEDURE_23617','end','run');    end PROCEDURE_23617

/

