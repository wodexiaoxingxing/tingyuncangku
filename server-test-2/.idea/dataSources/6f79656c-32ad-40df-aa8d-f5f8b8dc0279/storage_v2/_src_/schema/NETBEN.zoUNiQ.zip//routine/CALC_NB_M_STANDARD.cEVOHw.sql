create procedure calc_nb_m_standard authid current_user is
sqlStr varchar2(4000);
suff number;
stime date;
etime date;
ctime date:= trunc(sysdate,'mi');
s number;
v_s number;
total number;
begin
  total := 300;
  create_procedure_log('calc_nb_m_standard','begin','run');
  stime:=trunc(sysdate-7,'dd');
  etime:=trunc(sysdate,'dd');
  -- 1 PC单文件

  sqlStr:='truncate table nb_m_standard_tmp';
  execute immediate sqlStr;
  s:=0;
  for tableName in(select t.table_name as name from user_tables t where regexp_like( t.table_name,'^NB_PAGE_[0-9]')) loop
    begin
      if s>total then exit; end if;
      select count(*)  INTO v_s from nb_m_task where status = 1 and expire > sysdate -1 and task_option ='S' and type = 1 and owner_id = substr(tableName.Name,9);
      if v_s > 0 then
        s:=s+1;
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name,'run');
        sqlStr:='insert into nb_m_standard_tmp(task_type,ts_dns,ts_connect,ts_first_packet,rate_download,point_total,point_base,point_succ,point_cover_total,point_cover)
           select ''S1'',ts_dns,ts_connect,ts_first_packet,rate_download,point_total,point_base,point_succ,point_cover_total,point_cover
            from(
               select task_id,
                   round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_dns else null end)) ts_dns,
                   round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_connect else null end)) ts_connect,
                   round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_first_packet else null end)) ts_first_packet,
                   round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then rate_download else null end)) rate_download,
                   sum(point_total) point_total,
                   sum(case when error_code < 600000 and per<0.85 and per> 0.05 then 1 else 0 end) point_base,
                   sum(case when error_code < 600000 then 1 else 0 end) point_succ,
                   sum(case when s>150 and dest_ip is not null then 1 else 0 end) point_cover_total,
                   sum(case when s>150 and dest_ip is not null then is_cdn_cover else 0 end) point_cover
                 from(
                     select p.*,td.s
                      from
                       (select p1.*,row_number()over(partition by task_id order by ts_total)/count(*) over(partition by task_id) AS per
                         from '||tableName.Name ||' p1
                         where tm_base >:st and tm_base < :et and is_noise = 0
                               and task_id in(select id from nb_m_task where owner_id = '||substr(tableName.Name,9)|| '
                               and task_option = ''S'' and type = 1))p,
                       (select t.id, count(d.task_id) s
                          from nb_m_task t, nb_m_task_dest d
                         where t.id = d.task_id
                           and t.owner_id = '||substr(tableName.Name,9)||'
                           and t.type = 1 and task_option in(''S'')
                         group by task_option , t.id) td
                      where p.task_id = td.id
                      )
                group by task_id
                )
           where point_total>100 and point_succ/point_total> 0.7';
        execute immediate sqlStr using stime,etime ;
        commit;
      end if;

    exception when others then
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name||','||sqlerrm,'error');
    end;
  end loop;
  create_procedure_log('calc_nb_m_standard','update nb_m_standard begin','run');
  sqlStr:='insert into nb_m_standard(ctime,task_type,ts_dns,ts_connect,ts_first_packet,rate_download,available,cover_per)
             select :ctime,task_type,
                    round(sum(ts_dns*point_base)/sum(point_base)) ts_dns,
                    round(sum(ts_connect*point_base)/sum(point_base)) ts_connect,
                    round(sum(ts_first_packet*point_base)/sum(point_base)) ts_first_packet,
                    round(sum(rate_download*point_base)/sum(point_base)) rate_download,
                    round(sum(point_succ)/sum(point_total)*100,1) available,
                    round(sum(point_cover)/sum(point_cover_total)*100,1) cover_per
                    from nb_m_standard_tmp
                    where task_type = ''S1''
                    group by task_type ';
  execute immediate sqlStr using ctime;
  commit;

  -- 2 真机单文件
  -- 真机还未实现覆盖率，先用假的

  sqlStr:='truncate table nb_m_standard_tmp';
  execute immediate sqlStr;
  s:=0;
  for tableName in(select t.table_name as name from user_tables t where regexp_like( t.table_name,'^NB_MOB_PAGE_[0-9]')) loop
    begin
      if s>total then exit; end if;
      select count(*)  INTO v_s from nb_m_task where status = 1 and expire > sysdate -1 and task_option ='S' and type = 102 and owner_id = substr(tableName.Name,13);
      if v_s > 0 then
       s:=s+1;
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name,'run');
        sqlStr:='insert into nb_m_standard_tmp(task_type,ts_dns,ts_connect,ts_first_packet,rate_download,point_total,point_base,point_succ,point_cover_total,point_cover)
           select ''S102'',ts_dns,ts_connect,ts_first_packet,rate_download,point_total,point_base,point_succ,point_cover_total,point_cover
            from(
               select task_id,
                   round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_dns else null end)) ts_dns,
                   round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_connect else null end)) ts_connect,
                   round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_first_packet else null end)) ts_first_packet,
                   round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then rate_download else null end)) rate_download,
                   sum(point_total) point_total,
                   sum(case when error_code < 600000 and per<0.85 and per> 0.05 then 1 else 0 end) point_base,
                   sum(case when error_code < 600000 then 1 else 0 end) point_succ,
                   sum(0) point_cover_total,
                   sum(0) point_cover
                 from(
                     select p.*,td.s
                      from
                       (select p1.*,row_number()over(partition by task_id order by ts_total)/count(*) over(partition by task_id) AS per
                         from '||tableName.Name ||' p1
                         where tm_base >:st and tm_base < :et and is_noise = 0
                               and task_id in(select id from nb_m_task where owner_id = '||substr(tableName.Name,13)|| '
                               and task_option = ''S'' and type = 102))p,
                       (select t.id, count(d.task_id) s
                          from nb_m_task t, nb_m_task_dest d
                         where t.id = d.task_id
                           and t.owner_id = '||substr(tableName.Name,13)||'
                           and t.type = 102 and task_option in(''S'')
                         group by task_option , t.id) td
                      where p.task_id = td.id
                      )
                group by task_id
                )
           where point_total>100 and point_succ/point_total> 0.7';
        execute immediate sqlStr using stime,etime ;
        commit;
      end if;
      --dbms_output.put_line(sqlStr);
    exception when others then
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name||','||sqlerrm,'error');
    end;
  end loop;

  create_procedure_log('calc_nb_m_standard','update nb_m_cdn_standard begin','run');
  sqlStr:='insert into nb_m_standard(ctime,task_type,ts_dns,ts_connect,ts_first_packet,rate_download,available,cover_per)
             select :ctime,task_type,
                    round(sum(ts_dns*point_succ)/sum(point_succ)) ts_dns,
                    round(sum(ts_connect*point_succ)/sum(point_succ)) ts_connect,
                    round(sum(ts_first_packet*point_succ)/sum(point_succ)) ts_first_packet,
                    round(sum(rate_download*point_succ)/sum(point_succ)) rate_download,
                    round(sum(point_succ)/sum(point_total)*100,1) available,
                    65.6 cover_per
                    from nb_m_standard_tmp
                    where task_type = ''S102''
                    group by task_type ';
  execute immediate sqlStr using ctime;
  commit;

  -- 3 PC页面
  sqlStr:='truncate table nb_m_standard_tmp';
  execute immediate sqlStr;
  s:=0;
  for tableName in(select t.table_name as name from user_tables t where regexp_like( t.table_name,'^NB_PAGE_[0-9]')) loop
    begin
      if s>total then exit; end if;
      select count(*)  INTO v_s from nb_m_task where status = 1 and expire > sysdate -1 and task_option in('F','B') and type = 1 and owner_id = substr(tableName.Name,9);
      if v_s > 0 then
        s:=s+1;
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name,'run');
        sqlStr:='insert into nb_m_standard_tmp(task_type,ts_first_paint,ts_user,ts_total,ts_network,ts_client,byte_total,point_total,point_base,point_succ)
           select ''F1'',ts_first_paint,ts_user,ts_total,ts_network,ts_client,byte_total,point_total,point_base,point_succ
            from(
               select task_id,
                 round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_first_paint else null end)) ts_first_paint,
                 round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_user else null end)) ts_user,
                 round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_total else null end)) ts_total,
                 round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_network else null end)) ts_network,
                 round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_client else null end)) ts_client,
                 round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then byte_total else null end)) byte_total,
                 sum(point_total) point_total,
                 sum(case when error_code < 600000 and per<0.85 and per> 0.05 then 1 else 0 end) point_base,
                 sum(case when error_code < 600000 then 1 else 0 end) point_succ
               from
                 (select p1.*,row_number()over(partition by task_id order by ts_total)/count(*) over(partition by task_id) AS per
                   from '||tableName.Name ||' p1
                   where tm_base > :st and tm_base < :et and is_noise = 0
                         and task_id in(select id from nb_m_task where owner_id = '||substr(tableName.Name,9)||'
                         and task_option in (''F'',''B'') and type = 1)
                  )p
                group by task_id
               )
           where point_total>100 and point_succ/point_total> 0.7';
        execute immediate sqlStr using stime,etime ;
        commit;
      end if;

    exception when others then
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name||','||sqlerrm,'error');
    end;
  end loop;
  create_procedure_log('calc_nb_m_standard','update nb_m_standard PC页面 begin','run');
  sqlStr:='insert into nb_m_standard(ctime,task_type,ts_first_paint,ts_user,ts_total,ts_network,ts_client,byte_total,available)
             select :ctime,task_type,
                    round(sum(ts_first_paint*point_base)/sum(point_base)) ts_first_paint,
                    round(sum(ts_user*point_base)/sum(point_base)) ts_user,
                    round(sum(ts_total*point_base)/sum(point_base)) ts_total,
                    round(sum(ts_network*point_base)/sum(point_base)) ts_network,
                    round(sum(ts_client*point_base)/sum(point_base)) ts_client,
                    round(sum(byte_total*point_base)/sum(point_base)) byte_total,
                    round(sum(point_succ)/sum(point_total)*100,1) available
                    from nb_m_standard_tmp
                    where task_type = ''F1''
                    group by task_type ';
  execute immediate sqlStr using ctime;
  commit;
  sqlStr:='insert into nb_m_standard(ctime,task_type,ts_first_paint,ts_user,ts_total,ts_network,ts_client,byte_total,available)
             select :ctime,''B1'',
                    round(sum(ts_first_paint*point_base)/sum(point_base)) ts_first_paint,
                    round(sum(ts_user*point_base)/sum(point_base)) ts_user,
                    round(sum(ts_total*point_base)/sum(point_base)) ts_total,
                    round(sum(ts_network*point_base)/sum(point_base)) ts_network,
                    round(sum(ts_client*point_base)/sum(point_base)) ts_client,
                    round(sum(byte_total*point_base)/sum(point_base)) byte_total,
                    round(sum(point_succ)/sum(point_total)*100,1) available
                    from nb_m_standard_tmp
                    where task_type = ''F1''
                    group by task_type ';
  execute immediate sqlStr using ctime;
  commit;

  -- 4 真机页面
  sqlStr:='truncate table nb_m_standard_tmp';
  execute immediate sqlStr;
  s:=0;
  for tableName in(select t.table_name as name from user_tables t where regexp_like( t.table_name,'^NB_MOB_PAGE_[0-9]')) loop
    begin
      if s>total then exit; end if;
      select count(*)  INTO v_s from nb_m_task where status = 1 and expire > sysdate -1 and task_option in('F','B') and type = 102 and owner_id = substr(tableName.Name,13);
      if v_s > 0 then
        s:=s+1;
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name,'run');
        sqlStr:='insert into nb_m_standard_tmp(task_type,ts_first_paint,ts_user,ts_total,ts_network,ts_client,byte_total,point_total,point_base,point_succ)
           select ''F102'',ts_first_paint,ts_user,ts_total,ts_network,ts_client,byte_total,point_total,point_base,point_succ
            from(
               select task_id,
                 round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_first_paint else null end)) ts_first_paint,
                 round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_user else null end)) ts_user,
                 round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_total else null end)) ts_total,
                 round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_network else null end)) ts_network,
                 round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_client else null end)) ts_client,
                 round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then byte_total else null end)) byte_total,
                 sum(point_total) point_total,
                 sum(case when error_code < 600000 and per<0.85 and per> 0.05 then 1 else 0 end) point_base,
                 sum(case when error_code < 600000 then 1 else 0 end) point_succ
               from
                 (select p1.*,row_number()over(partition by task_id order by ts_total)/count(*) over(partition by task_id) AS per
                   from '||tableName.Name ||' p1
                   where tm_base > :st and tm_base < :et and is_noise = 0
                         and task_id in(select id from nb_m_task where owner_id = '||substr(tableName.Name,13)||'
                         and task_option in (''F'',''B'') and type = 102)
                  )p
                group by task_id
               )
           where point_total>100 and point_succ/point_total> 0.7';
        execute immediate sqlStr using stime,etime ;
        commit;
      end if;
    exception when others then
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name||','||sqlerrm,'error');
    end;
  end loop;
  create_procedure_log('calc_nb_m_standard','update nb_m_standard 真机页面 begin','run');
  sqlStr:='insert into nb_m_standard(ctime,task_type,ts_first_paint,ts_user,ts_total,ts_network,ts_client,byte_total,available)
             select :ctime,task_type,
                    round(sum(ts_first_paint*point_base)/sum(point_base)) ts_first_paint,
                    round(sum(ts_user*point_base)/sum(point_base)) ts_user,
                    round(sum(ts_total*point_base)/sum(point_base)) ts_total,
                    round(sum(ts_network*point_base)/sum(point_base)) ts_network,
                    round(sum(ts_client*point_base)/sum(point_base)) ts_client,
                    round(sum(byte_total*point_base)/sum(point_base)) byte_total,
                    round(sum(point_succ)/sum(point_total)*100,1) available
                    from nb_m_standard_tmp
                    where task_type = ''F102''
                    group by task_type ';
  execute immediate sqlStr using ctime;
  commit;
  sqlStr:='insert into nb_m_standard(ctime,task_type,ts_first_paint,ts_user,ts_total,ts_network,ts_client,byte_total,available)
             select :ctime,''B102'',
                    round(sum(ts_first_paint*point_base)/sum(point_base)) ts_first_paint,
                    round(sum(ts_user*point_base)/sum(point_base)) ts_user,
                    round(sum(ts_total*point_base)/sum(point_base)) ts_total,
                    round(sum(ts_network*point_base)/sum(point_base)) ts_network,
                    round(sum(ts_client*point_base)/sum(point_base)) ts_client,
                    round(sum(byte_total*point_base)/sum(point_base)) byte_total,
                    round(sum(point_succ)/sum(point_total)*100,1) available
                    from nb_m_standard_tmp
                    where task_type = ''F102''
                    group by task_type ';
  execute immediate sqlStr using ctime;
  commit;

  -- 5 PC Ping
  sqlStr:='truncate table nb_m_standard_tmp';
  execute immediate sqlStr;
  s:=0;
  for tableName in(select t.table_name as name from user_tables t where regexp_like( t.table_name,'^NB_PING_[0-9]')) loop
    begin
      if s>total then exit; end if;
      select count(*)  INTO v_s from nb_m_task where status = 1 and expire > sysdate -1 and task_option ='P' and type = 1 and owner_id = substr(tableName.Name,9);
      if v_s > 0 then
        s:=s+1;
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name,'run');
        sqlStr:='insert into nb_m_standard_tmp(task_type,ts_total,ping_packet_lost,point_base,point_succ)
           select ''P1'',
               round(avg(case when ping_packet_lost !=10000 and per<0.85 and per> 0.05 then ts_total else null end)) ts_total,
               round(avg(case when ping_packet_lost !=10000 then ping_packet_lost/100 else null end),1) ping_packet_lost,
               sum(case when ping_packet_lost !=10000 and per<0.85 and per> 0.05 then 1 else 0 end) point_base,
               sum(case when ping_packet_lost !=10000 then 1 else 0 end) point_succ
             from
               (select p1.*,row_number()over(partition by task_id order by ts_total)/count(*) over(partition by task_id) AS per
                 from '||tableName.Name ||'  p1
                 where tm_base > :st and tm_base < :et and is_noise = 0
                       and task_id in(select id from nb_m_task where owner_id = '||substr(tableName.Name,9)||'
                       and task_option in (''P'') and type = 1))p';
        execute immediate sqlStr using stime,etime ;
        commit;
      end if;

    exception when others then
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name||','||sqlerrm,'error');
    end;
  end loop;
  create_procedure_log('calc_nb_m_standard','update nb_m_standard PC ping begin','run');
  sqlStr:='insert into nb_m_standard(ctime,task_type,ts_total,ping_packet_lost)
             select :ctime,task_type,
                    round(sum(ts_total*point_base)/sum(point_base)) ts_total,
                    round(sum(ping_packet_lost*point_succ)/sum(point_succ),1) ping_packet_lost
                    from nb_m_standard_tmp
                    where task_type = ''P1'' and point_base > 100
                    group by task_type ';
  execute immediate sqlStr using ctime;
  commit;
  -- 6 真机 Ping
  sqlStr:='truncate table nb_m_standard_tmp';
  execute immediate sqlStr;
  s:=0;
  for tableName in(select t.table_name as name from user_tables t where regexp_like( t.table_name,'^NB_PING_[0-9]')) loop
    begin
      if s>total then exit; end if;
      select count(*)  INTO v_s from nb_m_task where status = 1 and expire > sysdate -1 and task_option ='P' and type = 102 and owner_id = substr(tableName.Name,9);
      if v_s > 0 then
        s:=s+1;
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name,'run');
        sqlStr:='insert into nb_m_standard_tmp(task_type,ts_total,ping_packet_lost,point_base,point_succ)
           select ''P102'',
               round(avg(case when ping_packet_lost !=10000 and per<0.85 and per> 0.05 then ts_total else null end)) ts_total,
               round(avg(case when ping_packet_lost !=10000 then ping_packet_lost/100 else null end),1) ping_packet_lost,
               sum(case when ping_packet_lost !=10000 and per<0.85 and per> 0.05 then 1 else 0 end) point_base,
               sum(case when ping_packet_lost !=10000 then 1 else 0 end) point_succ
             from
               (select p1.*,row_number()over(partition by task_id order by ts_total)/count(*) over(partition by task_id) AS per
                 from '||tableName.Name ||'  p1
                 where tm_base > :st and tm_base < :et and is_noise = 0
                       and task_id in(select id from nb_m_task where owner_id = '||substr(tableName.Name,9)||'
                       and task_option in (''P'') and type = 102))p';
        execute immediate sqlStr using stime,etime ;
        commit;
      end if;

    exception when others then
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name||','||sqlerrm,'error');
    end;
  end loop;
  create_procedure_log('calc_nb_m_standard','update nb_m_standard 真机 ping begin','run');
  sqlStr:='insert into nb_m_standard(ctime,task_type,ts_total,ping_packet_lost)
             select :ctime,task_type,
                    round(sum(ts_total*point_base)/sum(point_base)) ts_total,
                    round(sum(ping_packet_lost*point_succ)/sum(point_succ),1) ping_packet_lost
                    from nb_m_standard_tmp
                    where task_type = ''P102'' and point_base > 100
                    group by task_type ';
  execute immediate sqlStr using ctime;
  commit;

   -- 7 流媒体
  sqlStr:='truncate table nb_m_standard_tmp';
  execute immediate sqlStr;
  s:=0;
  for tableName in(select t.table_name as name from user_tables t where regexp_like( t.table_name,'^NB_STREAM_[0-9]')) loop
    begin
      if s>total then exit; end if;
      select count(*)  INTO v_s from nb_m_task where status = 1 and expire > sysdate -1 and type = 3 and owner_id = substr(tableName.Name,11);
      if v_s > 0 then
        s:=s+1;
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name,'run');
        sqlStr:='insert into nb_m_standard_tmp(task_type,ts_total,ts_buffer,ts_rebuffer,buffer_count,fluency,point_total,point_base,point_succ)
           select ''3'',ts_total,ts_buffer,ts_rebuffer,buffer_count,fluency,point_total,point_base,point_succ
            from(
               select task_id,
               round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_total else null end)) ts_total,
               round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_buffer else null end)) ts_buffer,
               round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_rebuffer else null end)) ts_rebuffer,
               round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then buffer_count else null end),3) buffer_count,
               round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then fluency else null end),3) fluency,
               sum(point_total) point_total,
               sum(case when error_code < 600000 and per<0.85 and per> 0.05 then 1 else 0 end) point_base,
               sum(case when error_code < 600000 then 1 else 0 end) point_succ
             from
               (select p1.*,row_number()over(partition by task_id order by ts_total)/count(*) over(partition by task_id) AS per
                 from '||tableName.Name ||' p1
                 where tm_base > :st and tm_base < :et and is_noise = 0
                       and task_id in(select id from nb_m_task where owner_id = '||substr(tableName.Name,11)||'
                       and type = 3))p
                group by task_id
               )
           where point_total>100 and point_succ/point_total> 0.7';
        execute immediate sqlStr using stime,etime ;
        commit;
      end if;

    exception when others then
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name||','||sqlerrm,'error');
    end;
  end loop;
  create_procedure_log('calc_nb_m_standard','update nb_m_standard 流媒体 begin','run');
  sqlStr:='insert into nb_m_standard(ctime,task_type,ts_total,ts_buffer,ts_rebuffer,buffer_count,fluency,available)
             select :ctime,task_type,
                    round(sum(ts_total*point_base)/sum(point_base)) ts_total,
                    round(sum(ts_buffer*point_base)/sum(point_base)) ts_buffer,
                    round(sum(ts_rebuffer*point_base)/sum(point_base)) ts_rebuffer,
                    round(sum(buffer_count*point_base)/sum(point_base),2) buffer_count,
                    round(sum(fluency*point_base)/sum(point_base),3)*100 fluency,
                    round(sum(point_succ)/sum(point_total)*100,1) available
                    from nb_m_standard_tmp
                    where task_type = ''3''
                    group by task_type ';
  execute immediate sqlStr using ctime;
  commit;

     -- 7 真机流媒体
  sqlStr:='truncate table nb_m_standard_tmp';
  execute immediate sqlStr;
  s:=0;
  for tableName in(select t.table_name as name from user_tables t where regexp_like( t.table_name,'^NB_MOB_STREAM_[0-9]')) loop
    begin
      if s>total then exit; end if;
      select count(*)  INTO v_s from nb_m_task where status = 1 and expire > sysdate -1 and type = 111 and owner_id = substr(tableName.Name,11);
      if v_s > 0 then
        s:=s+1;
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name,'run');
        sqlStr:='insert into nb_m_standard_tmp(task_type,ts_total,ts_buffer,ts_rebuffer,buffer_count,fluency,point_total,point_base,point_succ)
           select ''111'',ts_total,ts_buffer,ts_rebuffer,buffer_count,fluency,point_total,point_base,point_succ
            from(
               select task_id,
               round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_total else null end)) ts_total,
               round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_buffer else null end)) ts_buffer,
               round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_rebuffer else null end)) ts_rebuffer,
               round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then buffer_count else null end),3) buffer_count,
               round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then fluency else null end),3) fluency,
               sum(point_total) point_total,
               sum(case when error_code < 600000 and per<0.85 and per> 0.05 then 1 else 0 end) point_base,
               sum(case when error_code < 600000 then 1 else 0 end) point_succ
             from
               (select p1.*,row_number()over(partition by task_id order by ts_total)/count(*) over(partition by task_id) AS per
                 from '||tableName.Name ||' p1
                 where tm_base > :st and tm_base < :et and is_noise = 0
                       and task_id in(select id from nb_m_task where owner_id = '||substr(tableName.Name,11)||'
                       and type = 111))p
                group by task_id
               )
           where point_total>100 and point_succ/point_total> 0.7';
        execute immediate sqlStr using stime,etime ;
        commit;
      end if;

    exception when others then
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name||','||sqlerrm,'error');
    end;
  end loop;
  create_procedure_log('calc_nb_m_standard','update nb_m_standard 真机流媒体 begin','run');
  sqlStr:='insert into nb_m_standard(ctime,task_type,ts_total,ts_buffer,ts_rebuffer,buffer_count,fluency,available)
             select :ctime,task_type,
                    round(sum(ts_total*point_base)/sum(point_base)) ts_total,
                    round(sum(ts_buffer*point_base)/sum(point_base)) ts_buffer,
                    round(sum(ts_rebuffer*point_base)/sum(point_base)) ts_rebuffer,
                    round(sum(buffer_count*point_base)/sum(point_base),2) buffer_count,
                    round(sum(fluency*point_base)/sum(point_base),3)*100 fluency,
                    round(sum(point_succ)/sum(point_total)*100,1) available
                    from nb_m_standard_tmp
                    where task_type = ''111''
                    group by task_type ';
  execute immediate sqlStr using ctime;
  commit;

        -- 7 真机 sms
  sqlStr:='truncate table nb_m_standard_tmp';
  execute immediate sqlStr;
  s:=0;
  for tableName in(select t.table_name as name from user_tables t where regexp_like( t.table_name,'^NB_MOB_SMS_[0-9]')) loop
    begin
      if s>total then exit; end if;
      select count(*)  INTO v_s from nb_m_task where status = 1 and expire > sysdate -1 and task_option ='N' and type = 105 and owner_id = substr(tableName.Name,12);
      if v_s > 0 then
        s:=s+1;
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name,'run');
        sqlStr:='insert into nb_m_standard_tmp(task_type,ts_total,point_base,point_succ)
           select ''N105'',
               round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then ts_total else null end)) ts_total,
               sum(case when error_code < 600000 and per<0.85 and per> 0.05 then 1 else 0 end) point_base,
               sum(case when error_code < 600000 then 1 else 0 end) point_succ
             from
               (select p1.*,row_number()over(partition by task_id order by ts_total)/count(*) over(partition by task_id) AS per
                 from '||tableName.Name ||'  p1
                 where tm_base > :st and tm_base < :et
                       and task_id in(select id from nb_m_task where owner_id = '||substr(tableName.Name,12)||'
                       and task_option in (''N'') and type = 105))p';
        execute immediate sqlStr using stime,etime ;
        commit;
      end if;

    exception when others then
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name||','||sqlerrm,'error');
    end;
  end loop;
  create_procedure_log('calc_nb_m_standard','update nb_m_standard 真机 sms begin','run');
  sqlStr:='insert into nb_m_standard(ctime,task_type,ts_total)
             select :ctime,task_type,
                    round(sum(ts_total*point_base)/sum(point_base)) ts_total
                    from nb_m_standard_tmp
                    where task_type = ''N105''
                    group by task_type ';
  execute immediate sqlStr using ctime;
  commit;
      -- 8 mtr
  sqlStr:='truncate table nb_m_standard_tmp';
  execute immediate sqlStr;
  s:=0;
  for tableName in(select t.table_name as name from user_tables t where regexp_like( t.table_name,'^NB_MTR_[0-9]')) loop
    begin
      if s>total then exit; end if;
      select count(*)  INTO v_s from nb_m_task where status = 1 and expire > sysdate -1 and task_option ='R' and type = 1 and owner_id = substr(tableName.Name,8);
      if v_s > 0 then
        s:=s+1;
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name,'run');
        sqlStr:='insert into nb_m_standard_tmp(task_type,pings_avg,packets_loss,pings_stdev,hop_number,point_base,point_succ)
           select ''R1'',
               round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then pings_avg else null end)) pings_avg,
               round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then packets_loss else null end)) packets_loss,
               round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then pings_stdev else null end),1) pings_stdev,
               round(avg(case when error_code < 600000 and per<0.85 and per> 0.05 then hop_number else null end)) hop_number,
               sum(case when error_code < 600000 and per<0.85 and per> 0.05 then 1 else 0 end) point_base,
               sum(case when error_code < 600000 then 1 else 0 end) point_succ
             from
               (select p1.*,row_number()over(partition by task_id order by pings_avg)/count(*) over(partition by task_id) AS per
                 from '||tableName.Name ||'  p1
                 where tm_base > :st and tm_base < :et
                       and task_id in(select id from nb_m_task where owner_id = '||substr(tableName.Name,8)||'
                       and task_option in (''R'') and type = 1))p';
        execute immediate sqlStr using stime,etime ;
        commit;
      end if;

    exception when others then
        create_procedure_log('calc_nb_m_standard','tableName:'||tableName.name||','||sqlerrm,'error');
    end;
  end loop;
  create_procedure_log('calc_nb_m_standard','update nb_m_standard PC MTR begin','run');
  sqlStr:='insert into nb_m_standard(ctime,task_type,pings_avg,packets_loss,pings_stdev,hop_number)
             select :ctime,task_type,
                    round(sum(pings_avg*point_base)/sum(point_base)) pings_avg,
                    round(sum(packets_loss*point_base)/sum(point_base)) packets_loss,
                    round(sum(pings_stdev*point_base)/sum(point_base),1) pings_stdev,
                    round(sum(hop_number*point_base)/sum(point_base)) hop_number
                    from nb_m_standard_tmp
                    where task_type = ''R1''
                    group by task_type ';
  execute immediate sqlStr using ctime;
  commit;

  create_procedure_log('calc_nb_m_standard','end','run');
end calc_nb_m_standard;
/

