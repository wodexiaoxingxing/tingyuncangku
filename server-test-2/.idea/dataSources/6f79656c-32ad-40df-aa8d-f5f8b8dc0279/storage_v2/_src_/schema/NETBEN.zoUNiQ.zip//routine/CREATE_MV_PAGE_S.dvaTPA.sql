create PROCEDURE          "CREATE_MV_PAGE_S" (
  v_name in varchar2
)authid current_user
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(4000);
  v_s number;
  begin
    --创建物化视图日志
    select count(*)  INTO v_s FROM all_objects t where t.object_name = 'MLOG$_NB_PAGE_'||v_name;
    if v_s > 0 then
        sqlStr:=  'drop materialized view log on nb_page_'||v_name;
        execute immediate sqlstr;
    end if;
        sqlStr:='create materialized view log on nb_page_'||v_name||' with rowid,
           sequence (task_id,page_seq,
	      	    city_id,
		          isp_id,
		          net_speed_id,
		          error_code,
              is_noise,
              dest_ip,
              tm_base,
              cont_err_total,
              cont_ele_total,
              point_total,
              byte_total,
              rate_download,
              ts_total,ts_page_base,
              ts_dns,ts_connect,
              ts_ssl,ts_redirect,
              ts_request,ts_first_packet,
              ts_client,ts_contents,ts_extra_data,
              ts_open_page,
              ts_user,
              ts_network,
              ts_close,
              byte_page_base,
              rate_download_page_base,
              num_first_elem,
              byte_first,
              num_host,
              ts_dns_total,
              num_connect,
              ts_connect_total,
              num_dom,
              num_iframe,
              num_no_compress_elem,
              num_no_expire_elem,
              num_no_etag_elem
              ) including new values';
         execute immediate sqlStr;
    select count(*)  INTO v_s FROM all_objects t where t.object_name = 'MV_PAGE_'||v_name;
    if v_s > 0 then
    --删除物化视图
    --DBMS_OUTPUT.PUT_LINE('drop mv_tran_'||v_name);
    sqlStr:='drop materialized view mv_page_'||v_name;
    execute immediate sqlStr;
    end if;


    --page物化视图
    DBMS_OUTPUT.PUT_LINE('begin create materialized view  mv_page_'||v_name);
    sqlStr:='create materialized view MV_PAGE_'||v_name||'
		refresh fast
		start with sysdate next sysdate + 4/24
		as
    (select task_id,
        page_seq,
		    city_id,
		    isp_id,
		    net_speed_id,
		    error_code,
        is_noise,
        dest_ip,
        (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8) / 24) as tm_hour8,
        count(*) as c1,
        count(cont_err_total) as c2,
        count(cont_ele_total) as c3,
        count(point_total) as c4,
        count(byte_total) as c5,
        count(rate_download) as c6,
        count(ts_total) as c7,
        count(ts_page_base) as c8,
        count(ts_dns) as c9,
		    count(ts_connect) as c10,
		    count(ts_ssl) as c11,
		    count(ts_redirect) as c12,
		    count(ts_request) as c13,
		    count(ts_first_packet) as c14,
		    count(ts_client) as c15,
		    count(ts_contents) as c16,
		    count(ts_extra_data) as c17,
		    count(ts_open_page) as c18,
		    count(ts_user) as c19,
		    count(ts_network) as c20,
		    count(ts_close) as c21,
        count(byte_page_base) as c22,
        count(rate_download_page_base) as c23,
        count(num_first_elem) as c24,
        count(byte_first) as c25,
        count(num_host) as c26,
        count(ts_dns_total) as c27,
        count(num_connect) as c28,
        count(ts_connect_total) as c29,
        count(num_dom) as c30,
        count(num_iframe) as c31,
        count(num_no_compress_elem) as c32,
        count(num_no_expire_elem) as c33,
        count(num_no_etag_elem) as c34,
              avg(cont_err_total) as cont_err_total,
              avg(cont_ele_total) as cont_ele_total,
		          sum(point_total) as point_total,
              avg(byte_total) as byte_total,
		          avg(rate_download) as rate_download,
		          avg(ts_total) as ts_total,
		          avg(ts_page_base) as ts_page_base,
		          avg(ts_dns) as ts_dns,
		          avg(ts_connect) as ts_connect,
		          avg(ts_ssl) as ts_ssl,
		          avg(ts_redirect) as ts_redirect,
		          avg(ts_request) as ts_request,
		          avg(ts_first_packet) as ts_first_packet,
		          avg(ts_client) as ts_client,
		          avg(ts_contents) as ts_contents,
		          avg(ts_extra_data) as ts_extra_data,
		          avg(ts_open_page) as ts_open_page,
		          avg(ts_user) as ts_user,
		          avg(ts_network) as ts_network,
		          avg(ts_close) as ts_close,
              avg(byte_page_base) as byte_page_base,
              avg(rate_download_page_base) as rate_download_page_base,
              avg(num_first_elem) as num_first_elem,
              avg(byte_first) as byte_first,
              avg(num_host) as num_host,
              avg(ts_dns_total) as ts_dns_total,
              avg(num_connect) as num_connect,
              avg(ts_connect_total) as ts_connect_total,
              avg(num_dom) as num_dom,
              avg(num_iframe) as num_iframe,
              avg(num_no_compress_elem) as num_no_compress_elem,
              avg(num_no_expire_elem) as num_no_expire_elem,
              avg(num_no_etag_elem) as num_no_etag_elem
	  from NB_PAGE_'||v_name||'
	  group by task_id,
           page_seq,
	         city_id,
	         isp_id,
	         net_speed_id,
		       error_code,
           is_noise,
           dest_ip,
           (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8) / 24))';

    execute   immediate   sqlStr;
  --索引
		sqlStr:='create index IN_MV_PAGE_ERROR_'||v_name||' on MV_PAGE_'||v_name||' (TASK_ID,TM_HOUR8, ERROR_CODE, CITY_ID) tableSpace NETBEN_IDX';
    execute   immediate   sqlStr;
    --索引
		--sqlStr:='create index IN_MV_PAGE_PERF_'||v_name||' on MV_PAGE_'||v_name||' (TASK_ID,TM_HOUR8, CITY_ID, ISP_ID) tableSpace NETBEN_IDX';
    --execute   immediate   sqlStr;


   --如果创建失败，则显示出失败的表
   exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:' || v_name;
        DBMS_OUTPUT.PUT_LINE(v_error_desc);
        create_procedure_log('create_fast_mv_page_all',v_error_desc,sqlcode);

end create_mv_page_s;


/

