create procedure createTRACE(tableStr IN varchar2,res OUT number) authid current_user is
  sqlStr    varchar2(4000);
  errorDesc varchar2(4000);
begin

  create_procedure_log('createTRACE',
                       'create table:NB_TRACE_' || tableStr,
                       'run');

  --create TABLE of NB_TRACE
  sqlStr := 'create table NB_TRACE_' || tableStr || '
  (
    ID              NUMBER not null,
    TASK_ID         NUMBER,
    PROBE_IP        NUMBER,
    CITY_ID         NUMBER,
    ISP_ID          NUMBER,
    NET_SPEED_ID    NUMBER,
    MEMBER_ID       NUMBER,
    DNS_SERVER      VARCHAR2(128),
    TM_BASE         DATE,
    ERROR_CODE      NUMBER,
    ERROR_IP        VARCHAR2(39),
    IS_NOISE        NUMBER,
    VERSION_ID      NUMBER,
    PERCENT_CPU     NUMBER,
    DEST_IP         VARCHAR2(39),
    DEST_NAME       VARCHAR2(512),
    TRACERT_RESULT  VARCHAR2(512),
    NSLOOKUP_RESULT VARCHAR2(512),
    TTL_TOTAL       NUMBER,
    TS_TOTAL        NUMBER,
    POINT_TOTAL     NUMBER default 1
  ) pctfree 0
  tablespace NETBEN';
  execute immediate sqlStr;

  sqlStr := 'alter table NB_TRACE_' || tableStr ||
            ' add constraint PK_NB_TRACE_' || tableStr ||
            ' primary key (ID) using index tablespace NETBEN';
  execute immediate sqlStr;

  -- NB_TRACE index
  sqlStr := 'create index IN_TRACE_PERF_' || tableStr || ' on NB_TRACE_' ||
            tableStr || ' (TM_BASE,TASK_ID) tableSpace NETBEN_IDX_NEW';
  execute immediate sqlStr;
  res:=0;
  
exception
  when others then
    errorDesc := 'Error :' || sqlerrm || '  tableStr:' || tableStr;
    --DBMS_OUTPUT.PUT_LINE(v_error_desc);
    create_procedure_log('createTRACE', errorDesc, 'error');
    res:=1;
    
end createTRACE;


/

