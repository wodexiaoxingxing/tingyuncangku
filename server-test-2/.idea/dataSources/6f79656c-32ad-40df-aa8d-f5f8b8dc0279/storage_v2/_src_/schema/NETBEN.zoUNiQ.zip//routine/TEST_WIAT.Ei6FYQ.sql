create procedure test_wiat is
begin
   for i in 1..3 loop
     dbms_lock.sleep(10);
     dbms_output.put_line(sysdate);
     end loop;
end test_wiat;


/

