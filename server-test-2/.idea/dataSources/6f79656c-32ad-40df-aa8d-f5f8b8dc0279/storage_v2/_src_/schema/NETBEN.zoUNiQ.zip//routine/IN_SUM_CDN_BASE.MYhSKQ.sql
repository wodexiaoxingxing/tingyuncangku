create PROCEDURE          "IN_SUM_CDN_BASE" authid current_user
is
  sqlStr  varchar2(4000);
  v_s number;
  v_error_desc varchar2(4000);
  v_time_start date;
  v_time_end date;

begin
  create_procedure_log('in_sum_cdn_base','in_sum_cdn_base begin','test');
  --算出统计的开始时间及结束时间
  v_time_start := trunc(sysdate - 1 - mod(to_char(sysdate, 'hh24'), 4) / 24,'hh24');
  v_time_end := trunc(sysdate - mod(to_char(sysdate, 'hh24'), 4) / 24, 'hh24');
  dbms_output.put_line(to_char(v_time_start,'yyyy-mm-dd hh24:mi'));
  --首先删除指定日期内的所有生成数据，防止重复生成数据
  sqlStr:='delete nb_sum_cdn_base where tm_hour = :delTime';
  execute immediate sqlStr using v_time_start;
  commit;
  --循环，查寻出所有的表
  for tableName in(select table_str as name from nb_top_table) loop
  begin
    --开始生成主机IP数据
    dbms_output.put_line(tableName.name);
    sqlStr:='insert into nb_sum_cdn_base 
     select seq_nb_sum_cdn_base.nextval,task_id,tm_hour,decode(dest_ip,null,''DNS is wrong'',dest_ip),point_total,
            point_succ, performence,round(decode(point_total,0,0,point_succ / point_total),2) available
     from (
       select t.task_id,
           trunc(t.tm_base-(trunc(t.tm_base,''hh24'')-trunc(sysdate-1-mod(to_char(sysdate,''hh24''),4)/24,''hh24'')),''hh24'') tm_hour,
           t.dest_ip,sum(t.point_total) point_total,
           sum(case when t.error_code in(select err_code from nb_m_error where err_type = 3) then null else t.point_total end) point_succ,
           avg(case when t.error_code in(select err_code from nb_m_error where err_type = 3) then null else t.ts_total end) performence
       from nb_page_'||tableName.name||' t
       where t.tm_base between :timeStart and :timeEnd
       group by task_id,t.dest_ip,
                trunc(t.tm_base-(trunc(t.tm_base,''hh24'') -
                trunc(sysdate-1-mod(to_char(sysdate,''hh24''), 4) / 24,''hh24'')),''hh24''))';
     execute immediate sqlStr using v_time_start,v_time_end;
     commit;
     --如果创建序列失败，则显示出失败代码
     exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:' || sqlStr;
        --DBMS_OUTPUT.PUT_LINE(v_error_desc);
        create_procedure_log('in_sum_cdn_base',v_error_desc,sqlcode);
     end;
   end loop;
   create_procedure_log('in_sum_cdn_base','in_sum_cdn_base end','test');
end in_sum_cdn_base;


/

