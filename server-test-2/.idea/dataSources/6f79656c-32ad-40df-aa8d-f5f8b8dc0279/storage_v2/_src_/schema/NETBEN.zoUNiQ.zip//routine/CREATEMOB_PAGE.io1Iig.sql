create procedure createMOB_PAGE(tableStr IN varchar2,res OUT number) authid current_user is
  sqlStr    varchar2(4000);
  errorDesc varchar2(4000);
begin
  create_procedure_log('createMOB_PAGE', 'create table:NB_MOB_PAGE_' || tableStr, 'run');
  --创建page
  sqlStr := 'create table NB_MOB_PAGE_' || tableStr || '
    (
      ID              NUMBER not null,
      TRAN_ID         NUMBER,
      TASK_ID         NUMBER,
      CITY_ID         NUMBER,
      ISP_ID          NUMBER,
      NET_SPEED_ID    NUMBER,
      TM_BASE         DATE,
      PROBE_IP        NUMBER,
      PAGE_SEQ        NUMBER,
      ERROR_CODE      NUMBER,
      ERROR_PATH      VARCHAR2(256),
      CONT_ERR_TOTAL  NUMBER,
      CONT_ELE_TOTAL  NUMBER,
      REDIRECT_TOTAL  NUMBER,
      POINT_TOTAL     NUMBER default 1,
      BYTE_TOTAL      NUMBER,  
      RATE_DOWNLOAD    NUMBER,
      BYTE_PAGE_BASE  NUMBER,
      RATE_DOWNLOAD_PAGE_BASE  NUMBER,
      DNS_SERVER   VARCHAR2(128),  
      DNS_SERVER_IP   NUMBER,
      DEST_IP         VARCHAR2(39),
      PING_RESULT     VARCHAR2(512),
      TRACERT_RESULT  VARCHAR2(512),
      NSLOOKUP_RESULT VARCHAR2(512),
      SCRIPT_ERROR_RESULT VARCHAR2(2000),
      HTTP_SERVER     VARCHAR2(256),
      HTTP_VIA        VARCHAR2(256),      
      TS_TOTAL        NUMBER,
      TS_PAGE_BASE    NUMBER,
      TS_DNS          NUMBER,
      TS_CONNECT      NUMBER,
      TS_REDIRECT     NUMBER,
      TS_REQUEST      NUMBER,
      TS_FIRST_PACKET NUMBER,
      TS_CLIENT       NUMBER,
      TS_CONTENTS     NUMBER,
      TS_EXTRA_DATA   NUMBER,
      TS_OPEN_PAGE    NUMBER,
      TS_NETWORK      NUMBER,
      TS_SSL          NUMBER,
      NUM_HOST NUMBER,
      TS_DNS_TOTAL NUMBER,
      NUM_CONNECT NUMBER,
      TS_CONNECT_TOTAL NUMBER,
      NUM_DOM NUMBER,
      NUM_IFRAME NUMBER,
      NUM_NO_COMPRESS_ELEM NUMBER,
      NUM_NO_EXPIRE_ELEM NUMBER,
      NUM_NO_ETAG_ELEM NUMBER,
      MEMBER_ID     INTEGER,
      OS_VER_ID   INTEGER,
      BS_ID      INTEGER,
      BS_VER_ID    INTEGER,
      HW_ID    INTEGER,
      LOG_MSG_RESULT VARCHAR2(512),
      NUM_ELEM_LAZY  INTEGER,
      TS_USER         INTEGER,
      TS_FIRST_PAINT  INTEGER,
      TS_FULL_SCREEN  INTEGER,
      TS_UNLOAD_START  INTEGER,
      TS_UNLOAD_END  INTEGER,
      TS_DOM_LOAD  INTEGER,
      TS_DOM_INTERACT  INTEGER,
      TS_DOM_CONT_LOAD_START  INTEGER,
      TS_DOM_CONT_LOAD_END  INTEGER,
      TS_DOM_COMPLETE  INTEGER,
      TS_LOAD_EVT_START  INTEGER,
      TS_LOAD_EVT_END    INTEGER,
      src_path      VARCHAR2(512),      -- 页面源码路径
      bitrate_trend_result    VARCHAR2(512),      -- 流量变化趋势
      ts_dns_proj      INTEGER,      -- DNS投影时间
      ts_connect_proj      INTEGER,      -- 建连投影时间
      ts_first_packet_proj    INTEGER,      -- 首包投影时间
      MOBILE_SIGNAL  INTEGER,
      SCREEN_WIDTH  INTEGER,
      SCREEN_HEIGHT  INTEGER,
      longitude  NUMBER,
      latitude  NUMBER,
      IS_NOISE      INTEGER,
      OS            VARCHAR2(128),                
    BS_VER        VARCHAR2(128),                        
    HW            VARCHAR2(128)
    ) pctfree 0';
  execute immediate sqlStr;
  --主键 
  sqlStr := 'alter table NB_MOB_PAGE_' || tableStr || '
      add constraint PK_NB_MOB_PAGE_' || tableStr ||
            ' primary key (ID)
      using index ';
  execute immediate sqlStr;
  --索引
  sqlStr := 'create index IN_MOB_PAGE_TRANID_' || tableStr ||
            ' on NB_MOB_PAGE_' || tableStr ||
            ' (TRAN_ID) tableSpace NETBEN_IDX_NEW';
  execute immediate sqlStr;
  sqlStr := 'create index IN_MOB_PAGE_PERF_' || tableStr ||
            ' on NB_MOB_PAGE_' || tableStr ||
            ' (TM_BASE,TASK_ID) tableSpace NETBEN_IDX_NEW';
  execute immediate sqlStr;
  res:=0;
  
exception
  when others then
    errorDesc := 'Error :' || sqlerrm || '  tableStr:' || tableStr;
    --DBMS_OUTPUT.PUT_LINE(v_error_desc);
    create_procedure_log('createMOB_PAGE', errorDesc, 'error');
    res:=1;
    
END createMOB_PAGE;


/

