create procedure createMobileSmsTable(tableStr IN varchar2) authid current_user is
    sqlStr varchar2(4000);
begin
    --create ping sequence
    sqlStr := 'create sequence SEQ_NB_MOB_SMS_ID_' || tableStr || ' minvalue 1 maxvalue 9999999999999999999999999 start with 1 increment by 1 cache 500';
    execute immediate sqlStr;

    sqlStr := 'create table NB_MOB_SMS_' || tableStr || '
  (
    ID                NUMBER,
    TASK_ID           NUMBER,
    PAGE_SEQ          NUMBER,
    CITY_ID           NUMBER,
    ISP_ID            NUMBER,
    NET_SPEED_ID      NUMBER,
    TM_BASE           DATE,
    PROBE_IP          NUMBER,
    MEMBER_ID         NUMBER,
    DNS_SERVER        VARCHAR2(128),
    ERROR_CODE        NUMBER,
    DEST_IP           VARCHAR2(39),
    DEST_CITY_ID      NUMBER,
    DEST_ISP_ID       NUMBER,
    TS_TOTAL          NUMBER,
    MOBILE            VARCHAR2(39),
    RECEIVE_MOBILE    VARCHAR2(20),
    SMS_CONTENT       VARCHAR2(2000),
    URL               VARCHAR2(2000),
    IS_NOISE          NUMBER,
    POINT_TOTAL       NUMBER default 1,
    CTIME             DATE ,
    client_version    varchar(128),
      TRACE_ID            VARCHAR2(128)  ,
      FEEDBACK            INTEGER
  ) pctfree 0
  tablespace NETBEN_BG';
    execute immediate sqlStr;

    sqlStr := 'create index IN_MOB_SMS_PAGEID_' || tableStr || ' on NB_MOB_SMS_' || tableStr || ' (ID) tableSpace NETBEN_IDX_NEW nologging';
    execute immediate sqlStr;

    sqlStr := 'create index IN_MOB_SMS_PERF_' || tableStr || ' on NB_MOB_SMS_' || tableStr || ' (TM_BASE,TASK_ID) tableSpace NETBEN_IDX_NEW nologging';
    execute immediate sqlStr;

end createMobileSmsTable;
/

