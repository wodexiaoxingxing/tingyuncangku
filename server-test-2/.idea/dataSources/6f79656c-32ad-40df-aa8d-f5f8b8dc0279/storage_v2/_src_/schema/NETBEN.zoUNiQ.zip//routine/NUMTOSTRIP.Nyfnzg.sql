create FUNCTION          "NUMTOSTRIP" (arg in integer) return varchar2 is
  Result varchar2(20);
p1 integer;
p2 integer ;
p3 integer ;
p4 integer ;
begin
p1:=bitand(arg, 4278190080)/16777216;
p2:=bitand(arg, 16711680)/65536;
p3:=bitand(arg, 65280)/256;
p4:=bitand(arg, 255);

result:=p1||'.'||p2||'.'||p3||'.'||p4;

return(Result);
end NUMTOSTRIP;


/

