create view NB_V_MBR_PROBE_NUMS as
select t.member_id as member_id, count(*) as probe_num from nb_m_proberuntime_log t
where t.time_stamp = (select max(time_stamp) from nb_m_proberuntime_log)
group by t.member_id
order by count(*) desc


/

