create PROCEDURE update_elemurltask_part authid current_user is
--table_name 表名 part_by分区类型 1 按天 2 按周  re_nums 保留分区数量
type ARRAY_SUB is record(table_name varchar2(64),part_by int,re_nums int);
type ARRAY_2D is table of ARRAY_SUB index by BINARY_INTEGER;
tabTypeImpl ARRAY_2D;
DROP_ERROR exception;
ADD_ERROR exception;

sqlStr varchar2(4000);
currDate date; -- 当前日期，如果是周则取本周第一天

partNameNew varchar2(64);
partValueNew varchar2(64);
partDate date;
reDays int; --删除分区时最小保留量
nextNum int; --增加分区时下一分区增加量
maxDays int; --增加分区时最大增加量

begin
  DBMS_OUTPUT.ENABLE (1000000000);
  tabTypeImpl(1).table_name:='NB_ELEM_URL_TASK_AUTO';
  tabTypeImpl(1).part_by:=1;
  tabTypeImpl(1).re_nums:=2;
  tabTypeImpl(2).table_name:='NB_ELEM_URL_TASK_MANUAL';
  tabTypeImpl(2).part_by:=2;
  tabTypeImpl(2).re_nums:=4;
  
  create_procedure_log('update_elemurltask_part','begin','run');

  for s in 1..tabTypeImpl.count loop
    if (tabTypeImpl(s).part_by=1) then
      reDays:=tabTypeImpl(s).re_nums;
      maxDays:=7;
      nextNum:=1;
      currDate := trunc(sysdate,'dd');
    elsif (tabTypeImpl(s).part_by=2) then
      reDays:=tabTypeImpl(s).re_nums*7;
      maxDays:=14;
      nextNum:=7;
      currDate := trunc(sysdate,'d');
    end if;
    
      for tab in(select tabName,partName from (
        select tabName,partName,decode(is_date(tm,'yymmdd'),0,null,1,to_date(tm,'yymmdd')) tm
          from(select table_name tabName,partition_name partName,substr(partition_name, -6) tm
            from user_tab_partitions where table_name = tabTypeImpl(s).table_name))
         where tm<= currDate - reDays)
      loop
        begin
           partDate:=to_date(substr(tab.partName,-6),'yymmdd');
           if  partDate > currDate - reDays then  raise DROP_ERROR; end if;
           sqlStr:='alter table '||tab.tabName||' drop partition '||tab.partName;
           --dbms_output.put_line(sqlStr||';');
           execute immediate sqlStr;
           create_procedure_log('update_elemurltask_part','Drop part,Table:'||tab.tabname||',partName:'||tab.partName,'run');
        exception
           when DROP_ERROR then null;
           when others then
             -- dbms_output.put_line('dropError,Table:'||tab.tabname||','||sqlerrm);
             create_procedure_log('update_elemurltask_part','dropError,Table:'||tab.tabname||','||sqlerrm,'error');
        end;
      end loop;
    --处理增加分区，一次只增加一个

    for tab in(
          select a.table_name tabName,a.partition_name partName,tablespace_name tablespaceName from
           (select table_name,partition_position,partition_name,tablespace_name from user_tab_partitions where table_name = tabTypeImpl(s).table_name)a,
           (select table_name,max(partition_position) partition_position from user_tab_partitions where table_name = tabTypeImpl(s).table_name group by table_name)b
           where a.table_name = b.table_name and a.partition_position = b.partition_position
    )loop
      begin
        partDate:=to_date(substr(tab.partName,-6),'yymmdd');
        if partDate > currDate + maxDays then raise ADD_ERROR; end if;
        partNameNew:=substr(tab.partName,1,length(tab.partName)-6)||to_char(partDate+nextNum,'yymmdd');
        partValueNew :='to_date('''||to_char(partDate+nextNum,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
        sqlStr := 'ALTER TABLE '||tab.tabName || ' ADD PARTITION '||partNameNew||' VALUES LESS THAN('||partValueNew||') tablespace '||tab.tablespacename;
        --dbms_output.put_line(sqlStr||';');
        execute immediate sqlStr;
        create_procedure_log('update_elemurltask_part','Add Part,Table:'||tab.tabname||',partName:'||partNameNew,'run');
      exception
        when ADD_ERROR then null;
        when others then
          --dbms_output.put_line('addError,Table:'||tab.tabname||','||sqlerrm);
          create_procedure_log('update_elemurltask_part','addError,Table:'||tab.tabname||','||sqlerrm,'error');
      end;
    end loop;
  end loop;
  create_procedure_log('update_ddclog_part','end','run');
  exception when others then
    --dbms_output.put_line('aa,'||sqlerrm);
    create_procedure_log('update_elemurltask_part','Outer error,'||sqlerrm,'error');
end update_elemurltask_part;


/

