create procedure        MON_PM_DROP_W_PART_ET authid current_user is
sqlStr varchar2(4000);
v_error_desc varchar2(4000);

begin


--  找出一百天前的分区号，删除过期的分区
    for tab in  (
  select table_name,
       partition_name
  from user_tab_partitions
 where table_name like 'NB_ET_%'
   AND table_name NOT LIKE 'NB_ET_URL_%'
   and to_number(substr(partition_name, instr(partition_name, '_', -1) + 1)) <
       (select max(order_num)
          from nb_part_calendar
         where sunday < sysdate - 100)
  )

    loop
        begin
           sqlStr := 'ALTER TABLE '||tab.table_name||' drop PARTITION '||tab.partition_name;
               execute immediate sqlStr;
               -- DBMS_OUTPUT.PUT_LINE(sqlStr);
        exception when  others then
 v_error_desc := 'drop table '||tab.table_name||'                   PARTITION '||tab.partition_name;
 MON_PC_ERROR_LOG('MON_PM_DROP_W_PART_ET',sqlerrm,v_error_desc);

    sqlStr := 'drop TABLE '||tab.table_name;
    execute immediate sqlStr;
  -- DBMS_OUTPUT.PUT_LINE(sqlStr);




-- DBMS_OUTPUT.PUT_LINE(v_error_desc);
         end;
    end loop;
end MON_PM_DROP_W_PART_ET;


/

