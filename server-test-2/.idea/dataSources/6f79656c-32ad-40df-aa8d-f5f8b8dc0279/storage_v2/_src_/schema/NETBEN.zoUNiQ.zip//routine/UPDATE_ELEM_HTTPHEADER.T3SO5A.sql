create PROCEDURE          "UPDATE_ELEM_HTTPHEADER" is
  sqlStr  varchar2(4000);  
  v_name varchar2(400);
  v_error_desc varchar2(400);
  CURSOR c_emp IS SELECT t.object_name FROM all_objects t where t.object_name like 'NB_ELEM_%';
begin
OPEN c_emp;
LOOP
  begin
    FETCH c_emp INTO v_name;
    EXIT WHEN c_emp%NOTFOUND;
    --修改表
    DBMS_OUTPUT.PUT_LINE('alter '||v_name);
    sqlStr:='alter table '||v_name||' add (HTTP_REQ_HEADER VARCHAR2(4000),HTTP_RESP_HEADER VARCHAR2(4000))';
    execute   immediate   sqlStr;
    commit;
  
        --如果创建失败，则显示出失败的表
    exception when  others then
        v_error_desc := 'ERROR: code: '|| sqlcode || ' '||v_name;
        DBMS_OUTPUT.PUT_LINE(v_error_desc);
    end;
END LOOP;

CLOSE c_emp;  
  
end update_elem_httpheader;


/

