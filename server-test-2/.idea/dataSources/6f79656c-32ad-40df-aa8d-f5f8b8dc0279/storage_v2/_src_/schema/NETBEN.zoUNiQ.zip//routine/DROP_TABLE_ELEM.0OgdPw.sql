create procedure drop_table_elem
is
sqlStr  varchar2(4000);
begin
  dbms_output.enable(1000000000);
  for tab in(
    select substr(table_name,7) suff from user_tables where table_name in
      (select 'NB_ET_'||id from nb_m_task where status = -1 or expire < sysdate-30 or (status = 0 and mtime < sysdate - 30))
  )loop
    begin
      sqlStr := 'drop table nb_et_'||tab.suff;
      --dbms_output.put_line(sqlStr||';');
      execute immediate  sqlStr;
      create_procedure_log('drop_table_elem','Drop table,Table:nb_et_'||tab.suff,'run');
    exception when others then
      --dbms_output.put_line('Drop table error,Table:nb_et_'||tab.suff||','||sqlerrm);
      create_procedure_log('drop_table_elem','Drop error,Table:nb_et_'||tab.suff||','||sqlerrm,'error');
    end;
    begin
      sqlStr := 'drop table nb_ett_'||tab.suff;
      --dbms_output.put_line(sqlStr||';');
      execute immediate  sqlStr;
      create_procedure_log('drop_table_elem','Drop table,Table:nb_ett_'||tab.suff,'run');
    exception when others then
      --dbms_output.put_line('Drop table error,Table:nb_et_'||tab.suff||','||sqlerrm);
      create_procedure_log('drop_table_elem','Drop error,Table:nb_ett_'||tab.suff||','||sqlerrm,'error');
    end;
    begin
      sqlStr := 'drop table nb_etd_'||tab.suff;
      --dbms_output.put_line(sqlStr||';');
      execute immediate  sqlStr;
      create_procedure_log('drop_table_elem','Drop table,Table:nb_etd_'||tab.suff,'run');
    exception when others then
      --dbms_output.put_line('Drop table error,Table:nb_et_'||tab.suff||','||sqlerrm);
      create_procedure_log('drop_table_elem','Drop error,Table:nb_etd_'||tab.suff||','||sqlerrm,'error');
    end;
  end loop;
exception when others then
  create_procedure_log('drop_table_elem','Outer error,'||sqlerrm,'error');
end drop_table_elem;


/

