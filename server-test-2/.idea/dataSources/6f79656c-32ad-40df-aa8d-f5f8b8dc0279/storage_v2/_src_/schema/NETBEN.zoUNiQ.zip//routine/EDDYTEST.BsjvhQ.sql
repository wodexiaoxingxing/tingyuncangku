create procedure eddyTest(tablestr IN varchar2, res OUT NUMBER) is
  E_EXCEPTION EXCEPTION;
begin
  RAISE E_EXCEPTION;
  res := 0;
  dbms_output.put_line(res);
exception
  when others then
    res := 1;
    dbms_output.put_line(res);
end eddyTest;


/

