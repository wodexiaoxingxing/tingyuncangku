create procedure calc_sc_intercept(memberId in number) is
  currDate date;
  sqlStr   varchar2(4000);
  accountId        int;
begin
   --此程序一天只能执行一次,在生成积分时只处理绑定过的客户端帐号
  --结转和保底计算时都记在前一天
  currDate:=sysdate;

  create_procedure_log('calc_sc_intercept','begin','run');
  -- 1 取出会员帐号ID
  select account_id  into accountId from nb_m_member where id = memberId ;
  

  -- 1 生成截转积分
 

  -- 1.2 生成客户端帐号的结转积分数据
  sqlStr:='insert into nb_sc_member_day(calc_date,calc_way,member_id,account_id,score,data_points,ctime)
            select :cd,4,m.id,m.account_id,v.score_balance,v.data_points_total,sysdate
              from nb_v_score_balance_max v,nb_m_member m
             where v.member_id = m.id and m.account_id>0 and v.reason != ''IC'' and m.id = :mid
          ';
 execute immediate sqlStr using trunc(currDate -1),memberId;
 commit;
 create_procedure_log('calc_sc_intercept','1.2 生成客户端帐号的结转积分数据完成','run');

  -- 1.3 生成会员帐号的截转积分数据
  sqlStr:='insert into nb_sc_account_day(id,calc_date,calc_way,account_id,score,data_points,score_balance,data_points_balance,note,ctime)
            select seq_nb_sc_account_day.nextval,:cd,4,p.account_id,p.sc,p.dp,
                   case when a.score_balance is null then p.sc else p.sc + a.score_balance end,
                   case when a.data_points_balance is null then p.dp else p.dp + a.data_points_balance end,
                   p.mid,sysdate
              from (select m.account_id,sum(v.score_balance) sc,sum(v.data_points_total) dp,
                    to_char(substr(wm_concat(m.username),0,3900)) mid
                      from nb_v_score_balance_max v,nb_m_member m
                      where v.member_id = m.id and m.account_id > 0 and v.reason !=''IC''
                      group by m.account_id )p,
                   (select id,account_id,score_balance,data_points_balance
                      from nb_sc_account_day
                      where id in
                        (select max(id) from nb_sc_account_day where account_id = :aid group by account_id)) a
             where p.account_id = a.account_id(+) ';
 execute immediate sqlStr using trunc(currDate -1),accountId;
 commit;
 create_procedure_log('calc_sc_intercept','1.3 生成会员帐号的截转积分数据完成','run');
 -- 1.4 最后将原积分表中的积分清空并制标记
 sqlStr:='insert into nb_m_score_balance(id,member_id,cdate,score,score_balance,data_points,data_points_total,reason)
           select score_bal_id_seq.Nextval,v.member_id,:cd,0,0,0,0,''IC''
              from nb_v_score_balance_max v,nb_m_member m
             where v.member_id = m.id and m.account_id > 0 and v.reason !=''IC'' and m.id=:mid';
 execute immediate sqlStr using trunc(currDate -1),memberId;
 commit;
 create_procedure_log('calc_sc_intercept','1.4 生成原积分表中的积分清空并制标记完成','run');

  -- 2 生成由直付会员奖金转换成的结转积分
  

  -- 2.2 生成直付会员奖金转换成的客户端帐号的结转积分数据
  sqlStr:='insert into nb_sc_member_day(calc_date,calc_way,member_id,account_id,score,data_points,ctime)
            select :cd,4,m.id,m.account_id,v.balance*600,0,sysdate
              from (select member_id,balance,reason from nb_m_dpmbr_cash_balance where id in
                        (select max(id) from nb_m_dpmbr_cash_balance group by member_id)) v,nb_m_member m
             where v.member_id = m.id and m.account_id>0 and v.reason != ''IC'' and m.id = :mid';
 execute immediate sqlStr using trunc(currDate -1),memberId;
 commit;
 create_procedure_log('calc_sc_intercept','2.2 生成用于直付会员奖金转换成结转积分的客户端帐号的数据完成','run');

  -- 2.3 生成直付会员奖金转换成的会员帐号的截转积分数据
  sqlStr:='insert into nb_sc_account_day(id,calc_date,calc_way,account_id,score,data_points,score_balance,data_points_balance,note,ctime)
            select seq_nb_sc_account_day.nextval,:cd,4,p.account_id,p.sc,0,
                   case when a.score_balance is null then p.sc else p.sc + a.score_balance end,
                   a.data_points_balance,
                   p.mid,sysdate
              from (select m.account_id,sum(v.balance * 600) sc,to_char(substr(wm_concat(m.username),0,3900)) mid
                      from (select member_id,balance,reason from nb_m_dpmbr_cash_balance where id in
                              (select max(id) from nb_m_dpmbr_cash_balance where member_id = :mid group by member_id)) v,
                            nb_m_member m
                      where v.member_id = m.id and m.account_id > 0 and v.reason !=''IC'' and m.id = :mid2
                      group by m.account_id )p,
                   (select id,account_id,score_balance,data_points_balance
                      from nb_sc_account_day
                      where id in
                        (select max(id) from nb_sc_account_day where account_id = :aid group by account_id)) a
             where p.account_id = a.account_id(+) ';
 execute immediate sqlStr using trunc(currDate -1),memberId,memberId,accountId;
 commit;
 create_procedure_log('calc_sc_intercept','2.3 生成用于直付会员奖金转换成结转积分的会员帐号的截转积分数据完成','run');
 -- 2.4 最后将原直付会员现金清空并制标记
 sqlStr:='insert into nb_m_dpmbr_cash_balance(id,member_id,ctime,money,balance,reason,creator_id,month)
           select dpmbr_cash_bal_id_seq.Nextval,v.member_id,:cd,0,0,''IC'',0,trunc(:cd,''mm'')
              from (select member_id,balance,reason from nb_m_dpmbr_cash_balance where id in
                     (select max(id) from nb_m_dpmbr_cash_balance where member_id=:mid group by member_id)) v,
                  nb_m_member m
             where v.member_id = m.id and m.account_id > 0 and v.reason !=''IC'' and m.id=:mid';
 execute immediate sqlStr using trunc(currDate -1),trunc(currDate -1),memberId,memberId;
 commit;
 create_procedure_log('calc_sc_intercept','2.4 原直付会员现金清空并制标记完成','run');

 -- 3 生成由推荐奖金转换成的结转积分
  

  -- 3.2 生成推荐奖金转换成的客户端帐号的结转积分数据
  sqlStr:='insert into nb_sc_member_day(calc_date,calc_way,member_id,account_id,score,data_points,ctime)
            select :cd,4,m.id,m.account_id,v.balance*600,0,sysdate
              from (select member_id,balance,reason from nb_m_member_cash_balance where id in
                        (select max(id) from nb_m_member_cash_balance where member_id=:mid1 group by member_id)) v,nb_m_member m
             where v.member_id = m.id and m.account_id>0 and v.reason != ''IC'' and m.id = :mid2';
 execute immediate sqlStr using trunc(currDate -1),memberId,memberId;
 commit;
 create_procedure_log('calc_sc_intercept','3.2 生成推荐奖金转换成的客户端帐号的结转积分数据完成','run');

  -- 3.3 生成推荐奖金转换成的会员帐号的截转积分数据
  sqlStr:='insert into nb_sc_account_day(id,calc_date,calc_way,account_id,score,data_points,score_balance,data_points_balance,note,ctime)
            select seq_nb_sc_account_day.nextval,:cd,4,p.account_id,p.sc,0,
                   case when a.score_balance is null then p.sc else p.sc + a.score_balance end,
                   a.data_points_balance,
                   p.mid,sysdate
              from (select m.account_id,sum(v.balance * 600) sc,
                         to_char(substr(wm_concat(m.username),0,3900)) mid
                      from (select member_id,balance,reason from nb_m_member_cash_balance where id in
                              (select max(id) from nb_m_member_cash_balance where member_id =:mid group by member_id)) v,
                            nb_m_member m
                      where v.member_id = m.id and m.account_id > 0 and v.reason !=''IC'' and m.id = :mid2
                      group by m.account_id )p,
                   (select id,account_id,score_balance,data_points_balance
                      from nb_sc_account_day
                      where id in
                        (select max(id) from nb_sc_account_day where account_id = :aid group by account_id)) a
             where p.account_id = a.account_id(+) ';
 execute immediate sqlStr using trunc(currDate -1),memberId,memberId,accountId;
 commit;
 create_procedure_log('calc_sc_intercept','3.3 生成推荐奖金转换成的会员帐号的截转积分数据完成','run');
 -- 3.4 最后将原直付会员推荐现金清空并制标记
 sqlStr:='insert into nb_m_member_cash_balance(id,member_id,ctime,money,balance,reason,creator_id,dpmbr_bal_month)
           select mbr_cash_bal_id_seq.Nextval,v.member_id,:cd,0,0,''IC'',0,trunc(sysdate,''mm'')
              from (select member_id,balance,reason from nb_m_member_cash_balance where id in
                     (select max(id) from nb_m_member_cash_balance where member_id = :mid1 group by member_id)) v,
                  nb_m_member m
             where v.member_id = m.id and m.account_id > 0 and v.reason !=''IC'' and m.id=:mid';
 execute immediate sqlStr using trunc(currDate -1),memberId,memberId;
 commit;
 create_procedure_log('calc_sc_intercept','3.4 原直付会员推荐现金清空并制标记完成','run');
 --结束
 create_procedure_log('calc_sc_intercept','end','run');
 exception when  others then
   create_procedure_log('calc_sc_intercept',sqlerrm,'error');
end calc_sc_intercept;


/

