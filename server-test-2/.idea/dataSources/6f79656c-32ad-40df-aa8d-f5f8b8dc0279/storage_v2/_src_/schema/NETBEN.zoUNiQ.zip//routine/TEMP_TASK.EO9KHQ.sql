create procedure        TEMP_TASK authid current_user is
  sqlStr    varchar2(4000);

  errorDesc varchar2(4000);

begin

  --循环，查寻出所有的表
  for tid in (select id   from netben.nb_m_task where agreement_id in (1418,29574,28914,129381,115018) and status=1 and expire > sysdate) loop
    begin
     
sqlStr := 'Insert into TEMP_ELEM_BYTES_HISTO 
select '||tid.ID||' as task_id, FLOOR(byte_total/10240) * 10240 AS bytes, COUNT(*) AS points from nb_et_'||tid.id||'
where tm_base >= to_date(''20120710'',''yyyymmdd'') and tm_base < to_date(''20120717'',''yyyymmdd'') and byte_total > 0
group by FLOOR(byte_total/10240)
order by FLOOR(byte_total/10240)';

 DBMS_OUTPUT.PUT_LINE(sqlStr);

  exception
      when others then
          DBMS_OUTPUT.PUT_LINE(sqlStr||'ERROR!!!!!!!!');
     end;
  end loop;

 
end TEMP_TASK;


/

