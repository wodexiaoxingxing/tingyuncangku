create PROCEDURE          "TESTBULKINSERT" (dataarr in TEST_USER_ARR) is
  type TEST_USER_TYPE is table of TEST_USER%ROWTYPE;
  tUser TEST_USER_TYPE := TEST_USER_TYPE();
begin
  FOR i IN dataarr.first..dataarr.last LOOP
    --if dataarr(i).id is not null then
    tUser.extend;
    tUser(i).id := 'perftest' || to_char(i);
    tUser(i).user_code := dataarr(i).USER_CODE;
    tUser(i).user_name := dataarr(i).USER_NAME;  
    tUser(i).user_pwd := dataarr(i).USER_PWD;
    --tUser(i).validity_date := dataarr(i).VALIDITY_DATE;
    --end if;
  END LOOP;
  FORALL i in tUser.first .. tUser.last
    insert into test_user
    values
           tUser(i);
end TESTBULKINSERT;


/

