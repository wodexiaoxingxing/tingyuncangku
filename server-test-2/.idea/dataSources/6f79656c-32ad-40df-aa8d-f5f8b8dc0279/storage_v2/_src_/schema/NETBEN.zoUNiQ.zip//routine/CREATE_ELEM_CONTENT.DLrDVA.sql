create PROCEDURE          "CREATE_ELEM_CONTENT" (
  tableStr in number
 ) authid current_user
is
  sqlStr  varchar2(8000);
  errorDesc varchar2(4000);
  ---------------- 主变量 ---------------------------------------------------------------------------
  createDate date := sysdate;
  orderNum   number;
  rangeDate  varchar2(128);
  partname1  varchar2(128);
  rangedate1 varchar2(128);
  partname2  varchar2(128);
  rangedate2 varchar2(128);
  partname3  varchar2(128);
  rangedate3 varchar2(128);
  --------------- 临时变量----------------------------------------------------------------------------
  s number;
begin
    create_procedure_log('create_elem_content','create table:nb_ec_'||tableStr,'run');
    --判断是否该tableStr合法
    select count(*) into s from nb_m_agreement where table_str = tableStr;
    if s=0 then
      create_procedure_log('create_elem_content','tableStr:'||tableStr||'不存在','warning');
      return;
    end if;
    --判断是否指定表已经建立
    select count(*) into s from user_tables where table_name ='NB_EC_'||tableStr;
    if s>0 then 
      create_procedure_log('create_elem_content','table:nb_ec_'||tableStr||'已经存在','warning');
      return;
    end if;
    --创建element
    --首先计算出elem的分区名称及值范围
    select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 8 - to_char( createDate,'d'),'d') from dual);
        partname1:='PART_EC_'||tableStr||'_'||orderNum;
        rangedate1:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';
         DBMS_OUTPUT.PUT_LINE(rangedate1);
    select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 15 - to_char( createDate,'d'),'d') from dual);
        partname2:='PART_EC_'||tableStr||'_'||orderNum;
        rangedate2:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';
    select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 22 - to_char( createDate,'d'),'d') from dual);
        partname3:='PART_EC_'||tableStr||'_'||orderNum;
        rangedate3:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';
        
    
    sqlStr:='create table NB_EC_'||tableStr||'
    (
      URL_ID           NUMBER,
		  PAGE_ID          NUMBER,
		  TASK_ID          NUMBER,
		  TM_BASE          DATE,
		  URL_HOST         VARCHAR2(64),
		  URL_PROTOCOL     VARCHAR2(16),
		  URL_PORT         VARCHAR2(8),
		  URL_PATH         VARCHAR2(4000),
		  DNS_SERVER	 VARCHAR2(128),
		  ELEMENT_TYPE     VARCHAR2(32),
		  HTTP_STAT_CODE   NUMBER,
		  HTTP_HEAD_SIZE   NUMBER,
		  HTTP_BODY_COMP   VARCHAR2(2),
		  HTTP_SERVER      VARCHAR2(256),
		  HTTP_VIA         VARCHAR2(256),
		  HTTP_REQ_HEADER	VARCHAR2(4000),
		  HTTP_RESP_HEADER	VARCHAR2(4000)
    ) 
    partition by range (TM_BASE)(
                  partition '||partname1||' values less than ('||rangedate1||'),
                  partition '||partname2||' values less than ('||rangedate2||'),
                  partition '||partname3||' values less than ('||rangedate3||'))';  
    execute   immediate   sqlStr;
    
   
    execute   immediate   sqlStr;
    --元素索引 tm_base,url_id,error_code
    sqlStr:='create index IDX_EC_UID_'||tableStr||' on NB_EC_'||tableStr||' (URL_ID) local 
            (partition '||partname1||',partition '||partname2||',partition '||partname3||')
            tableSpace  NETBEN_IDX';
    execute   immediate   sqlStr;
    
    exception when  others then
        errorDesc := 'Error :'|| sqlerrm || '  tableStr:' || tableStr ;
        --DBMS_OUTPUT.PUT_LINE(v_error_desc);
        create_procedure_log('create_elem_content',errorDesc,'error');
end create_elem_content;


/

