create PROCEDURE "MAN_ALTER_STREAM_ADD_FIELD"
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(400);
  v_s number;
begin
  for tableName in(select t.table_name as name from user_tables t where t.table_name like 'NB_STREAM_%') loop
  begin
      --删除指定的字段
      /*select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TS_CONNECT_STREAM';
      if v_s = 1 then
        sqlStr := 'alter table '||tableName.Name||' DROP column TS_CONNECT_STREAM';
        execute   immediate   sqlStr ;
      end if;

      */


      select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='DNS_SERVER_IP';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add   DNS_SERVER_IP number      ';
    execute   immediate   sqlStr ;
-- dbms_output.put_line(sqlStr);
      end if;

    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='CPU_TREND_RESULT';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add cpu_trend_result VARCHAR2(512)';
    execute   immediate   sqlStr ;
-- dbms_output.put_line(sqlStr);
      end if;

    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='MEM_TREND_RESULT';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add mem_trend_result VARCHAR2(512)';
        execute   immediate   sqlStr ;
-- dbms_output.put_line(sqlStr);
      end if;

    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='BITRATE_TREND_RESULT';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add bitrate_trend_result VARCHAR2(512)';
        execute   immediate   sqlStr ;
-- dbms_output.put_line(sqlStr);
      end if;
/*
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='FLASH_VER';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add FLASH_VER varchar2(64)';
        execute   immediate   sqlStr ;
 dbms_output.put_line(sqlStr);
      end if;

*/
    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlStr);
        create_procedure_log('alter_stream_add_field',v_error_desc,sqlcode);
  end;
  end loop;

end MAN_alter_stream_add_field;


/

