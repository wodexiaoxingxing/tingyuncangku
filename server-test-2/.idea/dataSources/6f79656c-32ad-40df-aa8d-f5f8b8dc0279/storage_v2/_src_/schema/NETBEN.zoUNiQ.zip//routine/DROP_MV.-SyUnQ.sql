create procedure drop_mv authid current_user is
sqlStr varchar2(4000);
begin
  -- tran
  for tableStr in  (SELECT distinct substr(t.table_name,9) suff FROM user_tables t where t.table_name like 'MV_TRAN_%')
  loop
    begin
      sqlStr:='drop materialized view log on nb_tran_'||tableStr.suff;
      execute immediate sqlStr;
      create_procedure_log('drop_mv','nb_tran_'||tableStr.suff||',drop log','run');
      --dbms_output.put_line(sqlStr||';');
    exception when  others then
      create_procedure_log('drop_mv','nb_tran_'||tableStr.suff||',drop log error,'||sqlerrm,'error');
    end;
    begin
      sqlStr:='drop materialized view mv_tran_'||tableStr.suff;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_tran_'||tableStr.suff||',drop table','run');
    exception when  others then
      create_procedure_log('drop_mv','nb_tran_'||tableStr.suff||',drop table error,'||sqlerrm,'error');
    end;
  end loop;  
  -- page
  for tableStr in  (SELECT distinct substr(t.table_name,9) suff FROM user_tables t where t.table_name like 'MV_PAGE_%')
  loop
    begin
      sqlStr:='drop materialized view log on nb_page_'||tableStr.suff;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_page_'||tableStr.suff||',drop log','run');
    exception when  others then
      create_procedure_log('drop_mv','nb_page_'||tableStr.suff||',drop log error,'||sqlerrm,'error');
    end;
    begin
      sqlStr:='drop materialized view mv_page_'||tableStr.suff;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_page_'||tableStr.suff||',drop table','run');
    exception when  others then
      create_procedure_log('drop_mv','nb_page_'||tableStr.suff||',drop table error,'||sqlerrm,'error');
    end;
  end loop;  
  --stream
  for tableStr in  (SELECT distinct substr(t.table_name,11) suff FROM user_tables t where t.table_name like 'MV_STREAM_%')
  loop
    begin
      sqlStr:='drop materialized view log on nb_stream_'||tableStr.suff;
      create_procedure_log('drop_mv','nb_stream_'||tableStr.suff||',drop log','run');
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
    exception when  others then
      dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_stream_'||tableStr.suff||',drop log error,'||sqlerrm,'error');
    end;
    begin
      sqlStr:='drop materialized view mv_stream_'||tableStr.suff;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_stream_'||tableStr.suff||',drop table','run');
    exception when  others then
      dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_stream_'||tableStr.suff||',drop table error,'||sqlerrm,'error');
    end;
  end loop;  
  --ping  
  /*
  for tableStr in  (SELECT distinct substr(t.table_name,9) suff FROM user_tables t where t.table_name like 'MV_PING_%')
  loop
    begin
      sqlStr:='drop materialized view log on nb_ping_'||tableStr.suff;
      execute immediate sqlStr;
      dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_ping_'||tableStr.suff||',drop log','run');
    exception when  others then
      create_procedure_log('drop_mv','nb_ping_'||tableStr.suff||',drop log error,'||sqlerrm,'error');
    end;
    begin
      sqlStr:='drop materialized view mv_ping_'||tableStr.suff;
      execute immediate sqlStr;
      dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_ping_'||tableStr.suff||',drop table','run');
    exception when  others then
      dbms_output.put_line(sqlStr||';');  
      create_procedure_log('drop_mv','nb_ping_'||tableStr.suff||',drop table error,'||sqlerrm,'error');
    end;
  end loop;    
  */
  --custom
  for tableStr in  (SELECT distinct substr(t.table_name,11) suff FROM user_tables t where t.table_name like 'MV_CUSTOM_%')
  loop
    begin
      sqlStr:='drop materialized view log on nb_custom_'||tableStr.suff;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_custom_'||tableStr.suff||',drop log','run');
    exception when  others then
      dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_custom_'||tableStr.suff||',drop log error,'||sqlerrm,'error');
    end;
    begin  
      sqlStr:='drop materialized view mv_custom_'||tableStr.suff;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_custom_'||tableStr.suff||',drop table','run');
    exception when  others then
      dbms_output.put_line(sqlStr||';');  
      create_procedure_log('drop_mv','nb_custom_'||tableStr.suff||',drop table error,'||sqlerrm,'error');
    end;
  end loop;    
  
  --mob_tran
  for tableStr in  (SELECT distinct substr(t.table_name,13) suff FROM user_tables t where t.table_name like 'MV_MOB_TRAN_%')
  loop
    begin
      sqlStr:='drop materialized view log on nb_mob_tran_'||tableStr.suff;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_mob_tran_'||tableStr.suff||',drop log','run');
    exception when  others then
      create_procedure_log('drop_mv','nb_mob_tran_'||tableStr.suff||',drop log error,'||sqlerrm,'error');
    end;
    begin  
      sqlStr:='drop materialized view mv_mob_tran_'||tableStr.suff;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_mob_tran_'||tableStr.suff||',drop table','run');
    exception when  others then
      create_procedure_log('drop_mv','nb_mob_tran_'||tableStr.suff||',drop table error,'||sqlerrm,'error');
    end;
  end loop;    
  --mob_page
  for tableStr in  (SELECT distinct substr(t.table_name,13) suff FROM user_tables t where t.table_name like 'MV_MOB_PAGE_%')
  loop
    begin
      sqlStr:='drop materialized view log on nb_mob_page_'||tableStr.suff;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_mob_page_'||tableStr.suff||',drop log','run');
    exception when  others then
      create_procedure_log('drop_mv','nb_mob_page_'||tableStr.suff||',drop log error,'||sqlerrm,'error');
    end;
    begin  
      sqlStr:='drop materialized view mv_mob_page_'||tableStr.suff;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_mob_page_'||tableStr.suff||',drop table','run');
    exception when  others then
      create_procedure_log('drop_mv','nb_mob_page_'||tableStr.suff||',drop table error,'||sqlerrm,'error');  
    end;
   end loop;
  --mobapp_tran
  for tableStr in  (SELECT distinct substr(t.table_name,16) suff FROM user_tables t where t.table_name like 'MV_MOBAPP_TRAN_%')
  loop
    begin
      sqlStr:='drop materialized view log on nb_mobapp_tran_'||tableStr.suff;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_mobapp_tran_'||tableStr.suff||',drop log','run');
    exception when  others then
      create_procedure_log('drop_mv','nb_mobapp_tran_'||tableStr.suff||',drop log error,'||sqlerrm,'error');
    end;
    begin  
      sqlStr:='drop materialized view mv_mobapp_tran_'||tableStr.suff;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_mobapp_tran_'||tableStr.suff||',drop table','run');
    exception when  others then
      create_procedure_log('drop_mv','nb_mobapp_tran_'||tableStr.suff||',drop table error,'||sqlerrm,'error');
    end;
  end loop;    
  --mobapp_page
  for tableStr in  (SELECT distinct substr(t.table_name,16) suff FROM user_tables t where t.table_name like 'MV_MOBAPP_PAGE_%')
  loop
    begin
      sqlStr:='drop materialized view log on nb_mobapp_page_'||tableStr.suff;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_mobapp_page_'||tableStr.suff||',drop log','run');
    exception when  others then
      create_procedure_log('drop_mv','nb_mobapp_page_'||tableStr.suff||',drop log error,'||sqlerrm,'error');
    end;
    begin  
      sqlStr:='drop materialized view mv_mobapp_page_'||tableStr.suff;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
      create_procedure_log('drop_mv','nb_mobapp_page_'||tableStr.suff||',drop table','run');
    exception when  others then
      dbms_output.put_line(sqlStr||';');  
      create_procedure_log('drop_mv','nb_mobapp_page_'||tableStr.suff||',drop table error,'||sqlerrm,'error');
    end;
  end loop;    
      
end drop_mv;


/

