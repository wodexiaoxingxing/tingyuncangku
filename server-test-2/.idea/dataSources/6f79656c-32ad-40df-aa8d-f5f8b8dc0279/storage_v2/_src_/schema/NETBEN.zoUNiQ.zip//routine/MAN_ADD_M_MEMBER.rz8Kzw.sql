create PROCEDURE          "MAN_ADD_M_MEMBER" authid current_user is
sqlStr varchar2(4000);
v_s number;

begin

    for et in  (select tname from jason.abc)
    loop
        begin
            select count(*) into v_s from nb_m_member where USERNAME = et.tname ;
            if (v_s = 0 ) then         
sqlStr := 'insert into netben.nb_m_member
 values (netben.member_id_seq.nextval,'''||et.tname||''',''9c3c98e77a9ed5e7f78c34458e5b098f'',4,1,sysdate,sysdate,null,null,1,0,0,0,''9c3c98e77a9ed5e7f78c34458e5b098f'')';
              dbms_output.put_line(sqlStr);
              execute immediate sqlStr;
sqlStr := 'insert into netben.nb_m_member_details
( ID , STATUS ,PASS_QUESTION ,PASS_ANSWER ,COUNTRY ,REGION ,CITY ,ADDRESS ,POSTALCODE ,PHONE ,MOBILE ,COMPANY ,CONTACT ,EMAIL , QQ , MSN ,CONN_TYPES ,LOC_TYPES ,ISP_TYPES ,CTIME ,MTIME ,ACTIVE_CODE ,SCORE ,SCORE_MAX ,BANK ,BANK_ACCOUNT ,BANK_ACCOUNT_NAME ,ALIPAY ,REG_EMAIL ,REG_PHONE ,ALIPAY_NAME ) values
 (netben.member_id_seq.currval, 0, null, null, 4, 401, 40101, null, null, ''021-32566001'', null, null, ''李志华'', ''cptnxiangmu@networkbench.com'', null, null, null, null, null, sysdate, sysdate, null, 0, 0, null, null, null, null, null, null, null)';
               dbms_output.put_line(sqlStr);
               execute immediate sqlStr;
               end if;
               end;
    end loop;
end man_add_m_member;


/

