create PROCEDURE          "MAN_ALTER_CUSTOM_ADD_FIELD" 
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(4000);
  v_s number;
begin
  for tableName in(select t.table_name as name from user_tables t where t.table_name like 'NB_CUSTOM_%' ) loop
  begin
    create_procedure_log('alter_custom_add_field',tableName.name,'message');

      select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='BAND_WIDTH';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' BAND_WIDTH NUMBER';
        execute   immediate   sqlStr ;
 dbms_output.put_line(sqlStr);
      end if;

    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlStr);
        create_procedure_log('alter_custom_add_field',v_error_desc,sqlcode);
  end;
  end loop;
end MAN_alter_custom_add_field;


/

