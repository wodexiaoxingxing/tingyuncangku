create PROCEDURE          "UPDATE_TRAN_DESC_IP" is
  sqlStr varchar2(4000);
  v_name varchar2(400);
  v_s    number;
  CURSOR c_emp IS
    SELECT substr(t.object_name, 8)
      FROM all_objects t
     where t.object_name like 'NB_TRAN_%';
begin
  OPEN c_emp;

  LOOP
    FETCH c_emp
      INTO v_name;
    EXIT WHEN c_emp%NOTFOUND;
    select count(*)
      INTO v_s
      FROM all_objects t
     where t.object_name = 'IN_PAGE_TRANID' || v_name;
    if v_s = 1 then
      begin
        DBMS_OUTPUT.PUT_LINE(' IN_PAGE_TRANID' || v_name ||
                             ' already exist ');
      end;
    else
      begin
        DBMS_OUTPUT.put_line('CREATE INDEX IN_PAGE_TRANID ' || v_name ||
                             '......');
        sqlStr := 'create index IN_PAGE_TRANID' || v_name || ' on NB_PAGE' ||
                  v_name || ' (TRAN_ID)  tablespace NETBEN';
        execute immediate sqlStr;
        DBMS_OUTPUT.PUT_LINE('update table NB_TRAN' || v_name || ' ... ');
        sqlStr := 'update nb_tran' || v_name ||
                  ' t set t.dest_ip = (select dest_ip from nb_page' ||
                  v_name ||
                  ' p where t.id = p.tran_id) where exists (select 1 from nb_page' ||
                  v_name || ' p where t.id = p.tran_id)';
        execute immediate sqlStr;
        commit;
      exception
        when others then
          DBMS_OUTPUT.put_line('ERROR:' || v_name || SQLCODE);
      end;
    end if;
  END LOOP;

  CLOSE c_emp;
end update_tran_desc_ip;


/

