create PROCEDURE          "UPDATE_ET_IDX" authid current_user is
sqlStr varchar2(4000);
v_error_desc varchar2(4000);
v_s number;
begin
    for et in  (SELECT distinct substr(t.table_name,7) suff FROM user_tables t where t.partitioned='YES' and t.table_name like 'NB_ET_%')
    loop
        begin
            create_procedure_log('update_et_idx',et.suff,'run');
            -- 1 DOMAIN 索引处理
            -- 判断是否索引创建
            select count(*) into v_s from user_ind_columns where index_name = 'IDX_ET_DID_'|| et.suff and column_name ='TM_BASE';
            if v_s = 0 then
               -- 创建索引
              sqlStr:='create index IDX_ET_DID_'||et.suff||'  on NB_ET_'||et.suff||' (DOMAIN_ID,TM_BASE,ERROR_CODE) local(';
              for part in(select partition_name as name from user_tab_partitions where table_name = 'NB_ET_'||et.suff) 
                loop
                  sqlStr:=sqlStr||'partition '||part.name||',';
              end loop;
                  sqlStr:=substr(sqlStr,0,length(sqlStr)-1)||')nologging tableSpace wood';
                  --dbms_output.put_line(sqlStr);
                  execute immediate sqlStr;
            else    
              -- 判断是否索引的列顺序不正确
              select column_position into v_s from user_ind_columns where index_name = 'IDX_ET_DID_'|| et.suff and column_name ='TM_BASE';
              if v_s = 1 then
                -- 先删除索引
                sqlStr:='drop index IDX_ET_DID_'||et.suff;
                --dbms_output.put_line(sqlStr);
                execute   immediate   sqlStr;
                -- 创建索引
                sqlStr:='create index IDX_ET_DID_'||et.suff||'  on NB_ET_'||et.suff||' (DOMAIN_ID,TM_BASE,ERROR_CODE) local(';
                for part in(select partition_name as name from user_tab_partitions where table_name = 'NB_ET_'||et.suff) 
                  loop
                    sqlStr:=sqlStr||'partition '||part.name||',';
                end loop;
                    sqlStr:=substr(sqlStr,0,length(sqlStr)-1)||')nologging tableSpace wood';
                    --dbms_output.put_line(sqlStr);
                    execute immediate sqlStr;    
              end if;      
            end if;
            
            -- 2 URL 索引处理
             -- 判断是否索引创建
            select count(*) into v_s from user_ind_columns where index_name = 'IDX_ET_UID_'|| et.suff and column_name ='TM_BASE';
            if v_s = 0 then
               -- 创建索引
              sqlStr:='create index IDX_ET_UID_'||et.suff||'  on NB_ET_'||et.suff||' (URL_ID,TM_BASE,ERROR_CODE) local(';
              for part in(select partition_name as name from user_tab_partitions where table_name = 'NB_ET_'||et.suff) 
                loop
                  sqlStr:=sqlStr||'partition '||part.name||',';
              end loop;
                  sqlStr:=substr(sqlStr,0,length(sqlStr)-1)||')nologging tableSpace wood';
                  --dbms_output.put_line(sqlStr);
                  execute immediate sqlStr;
            else    
              -- 判断是否索引的列顺序不正确
              select column_position into v_s from user_ind_columns where index_name = 'IDX_ET_UID_'|| et.suff and column_name ='TM_BASE';
              if v_s = 1 then
                -- 先删除索引
                sqlStr:='drop index IDX_ET_UID_'||et.suff;
                --dbms_output.put_line(sqlStr);
                execute   immediate   sqlStr;
                --创建索引
                sqlStr:='create index IDX_ET_UID_'||et.suff||'  on NB_ET_'||et.suff||' (URL_ID,TM_BASE,ERROR_CODE) local(';
                for part in(select partition_name as name from user_tab_partitions where table_name = 'NB_ET_'||et.suff) 
                  loop
                    sqlStr:=sqlStr||'partition '||part.name||',';
                end loop;
                    sqlStr:=substr(sqlStr,0,length(sqlStr)-1)||')nologging tableSpace wood';
                   -- dbms_output.put_line(sqlStr);
                    execute immediate sqlStr;    
              end if; 
            end if;      
             
            -- 3 ELEM_TYPE 索引处理
             -- 判断是否索引创建
            select count(*) into v_s from user_ind_columns where index_name = 'IDX_ET_TID_'|| et.suff and column_name ='TM_BASE';
            if v_s = 0 then
               -- 创建索引
              sqlStr:='create index IDX_ET_TID_'||et.suff||'  on NB_ET_'||et.suff||' (ELEM_TYPE_ID,TM_BASE,ERROR_CODE) local(';
              for part in(select partition_name as name from user_tab_partitions where table_name = 'NB_ET_'||et.suff) 
                loop
                  sqlStr:=sqlStr||'partition '||part.name||',';
              end loop;
                  sqlStr:=substr(sqlStr,0,length(sqlStr)-1)||')nologging tableSpace wood';
                  --dbms_output.put_line(sqlStr);
                  execute immediate sqlStr;
            else    
            --判断是否索引的列顺序不正确
              select column_position into v_s from user_ind_columns where index_name = 'IDX_ET_TID_'|| et.suff and column_name ='TM_BASE';
              if v_s = 1 then
                --先删除索引
                sqlStr:='drop index IDX_ET_TID_'||et.suff;
                --dbms_output.put_line(sqlStr);
                execute   immediate   sqlStr;
                --创建索引
                sqlStr:='create index IDX_ET_TID_'||et.suff||'  on NB_ET_'||et.suff||' (ELEM_TYPE_ID,TM_BASE,ERROR_CODE) local(';
                for part in(select partition_name as name from user_tab_partitions where table_name = 'NB_ET_'||et.suff) 
                  loop
                    sqlStr:=sqlStr||'partition '||part.name||',';
                end loop;
                    sqlStr:=substr(sqlStr,0,length(sqlStr)-1)||')nologging tableSpace wood';
                    --dbms_output.put_line(sqlStr);
                    execute immediate sqlStr;    
              end if;     
            end if;    
        exception when  others then
            v_error_desc := et.suff||' ERROR: ' || sqlerrm  || '  ' || sqlStr ;
            --dbms_output.put_line(sqlerrm);
            create_procedure_log('update_et_idx',v_error_desc,'error');
        end;
    end loop;
end update_et_idx;


/

