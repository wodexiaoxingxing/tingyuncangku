create PROCEDURE          "MAN_ADD_PART_ETD_BG" authid current_user is
sqlStr varchar2(4000);
v_error_desc varchar2(4000);
order_curr number; --本周周日对应的序号
range_date date;  --本周周日日期
v_order_curr number; --用于循环计算时的序号
v_range_date date;   --用于循环计算时的日期
v_s number;
v_partname varchar2(64); --拼出的分区命名字串
v_rangedate_desc varchar2(128);--日期的字符串
v_rangedate varchar2(128);--拼出的分区范围字符串
begin
 -- 1 计算出当前日期所对应的应该插入分区的时间范围及序号,是根据当前日期算出本周的周日，
 --   为了安全，将会提前两周处理,每周开始日期为周日
    select order_num,sunday into order_curr,range_date from nb_part_calendar t
        where t.sunday = (select trunc(sysdate + 8 - to_char( sysdate,'d'),'d') from dual);

    -- 2.取出所有已经建立分区的et表后缀，开始循环 注：无分区的表不处理
    for et in  (SELECT distinct substr(t.table_name,8) suff FROM user_tables t where t.partitioned='YES' and t.table_name like 'NB_ETD_%'  )
    loop
        begin
            -- 判断任务是否已经删除，删除的任务不需要新增加分区
            select status into v_s from nb_m_task where id = et.suff;
            if (v_s <> -1) then
              -- 3.首先增加本周的分区
              v_order_curr:=order_curr;
              v_range_date:=range_date;
              v_partname:= 'PART_ETD_'||et.suff||'_'||v_order_curr;
              v_rangedate_desc:=to_char(v_range_date,'yyyy-mm-dd');
              v_rangedate:='to_date('''||v_rangedate_desc||''',''yyyy-mm-dd'')';
              -- 判断增加的分区是否已经存在
              select count(*) into v_s from user_tab_partitions t where t.partition_name= v_partname and t.table_name = 'NB_ETD_'||et.suff;
                 --      --dbms_output.put_line(v_partname);
       --                      --dbms_output.put_line(v_s);

              -- 测试不存在则增加分区
              if v_s < 1 then
                  sqlStr := 'ALTER TABLE nb_etd_'||et.suff||' ADD PARTITION '||v_partname||' VALUES LESS THAN('||v_rangedate||') tablespace NETBEN_BG';
        --       --dbms_output.put_line(v_partname);
               --dbms_output.put_line(sqlStr);
                execute immediate sqlStr;
              else
                  -- 存在则写警告日志
                  v_error_desc:='The partition is exist,partname:'||v_partname||',rangedate:'||v_rangedate_desc;
               --dbms_output.put_line(v_error_desc);
                  create_procedure_log('add_et_part',v_error_desc,'warning');
              end if;
              -- 4.然后增加下周的分区
              v_order_curr:=order_curr+1;
              v_range_date:=range_date+7;
              v_partname:= 'PART_ETD_'||et.suff||'_'||v_order_curr;
              v_rangedate_desc:=to_char(v_range_date,'yyyy-mm-dd');
              v_rangedate:='to_date('''||v_rangedate_desc||''',''yyyy-mm-dd'')';
              -- 判断增加的分区是否已经存在
              select count(*) into v_s from user_tab_partitions t where t.partition_name= v_partname and t.table_name = 'NB_ETD_'||et.suff;
              -- 测试不存在则增加分
              if v_s < 1 then
                  sqlStr := 'ALTER TABLE nb_etd_'||et.suff||' ADD PARTITION '||v_partname||' VALUES LESS THAN('||v_rangedate||') tablespace NETBEN_BG';
              --dbms_output.put_line(sqlStr);
              execute immediate sqlStr;
              else
                  -- 存在则写警告日志
                  v_error_desc:='The partition is exist,partname:'||v_partname||',rangedate:'||v_rangedate_desc;
                  --dbms_output.put_line(v_error_desc);
                  create_procedure_log('add_etd_part',v_error_desc,'warning');
              end if;
            end if;
        exception when  others then
            v_error_desc := sqlerrm ||',partname:'||v_partname||',rangedate:'||v_rangedate_desc;
            dbms_output.PUT_LINE(sqlStr);
            create_procedure_log('add_etd_part',v_error_desc,'error');
        end;
    end loop;
end man_add_part_ETD_BG;


/

