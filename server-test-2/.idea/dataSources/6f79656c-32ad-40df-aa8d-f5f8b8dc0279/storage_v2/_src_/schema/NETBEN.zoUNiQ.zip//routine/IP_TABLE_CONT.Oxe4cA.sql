create procedure ip_table_cont(tableName varchar2) authid current_user is
TYPE cur_type IS REF CURSOR;
sqlStr varchar2(32767);
v_count int;
v_count_t int;
jc ip_201410%rowtype;
cur cur_type;
tab ip_201410%rowtype;
begin
--创建临时表
begin
   sqlStr:='drop table '||tableName||'b';
      dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
    exception when others then
      create_procedure_log('ip_table_cross',tableName||','||sqlerrm,'error');
  end;
    begin
  sqlStr:='drop table '||tableName||'bt';
      dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
    exception when others then
      create_procedure_log('ip_table_cross',tableName||','||sqlerrm,'error');
  end;
  begin
   sqlStr:='drop table '||tableName||'c';
      dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
    exception when others then
      create_procedure_log('ip_table_cross',tableName||','||sqlerrm,'error');
  end;

   sqlStr:='create table '||tableName||'b as select * from '||tableName;
       dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
         --存放被处理过的数据
   sqlStr:='create table '||tableName||'bt as select * from '||tableName||' where 1=0';
       dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      
   sqlStr:='create table '||tableName||'c as select * from '||tableName||' where 1=0';
       dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;

   sqlStr:='create index idx_sip_'||tableName||'b on '||tableName||'b (start_ip)';
          dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
   sqlStr:='create index idx_eip_'||tableName||'b on '||tableName||'b (end_ip)';
          dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
   sqlStr:='create index idx_s_e_'||tableName||'b on '||tableName||'b (start_ip, end_ip)';
          dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;

   sqlStr:='create index idx_sip_'||tableName||'c on '||tableName||'c (start_ip)';
          dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
   sqlStr:='create index idx_eip_'||tableName||'c on '||tableName||'c (end_ip)';
          dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
   sqlStr:='create index idx_s_e_'||tableName||'c on '||tableName||'c (start_ip, end_ip)';
          dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
open cur for 'select * from '||tableName||' order by start_ip,end_ip';
   loop
 fetch cur into tab;
    EXIT WHEN cur%NOTFOUND;
    --该记录如果被处理过，或者有相同的start_ip,end_ip,直接跳过

sqlStr:='select count(1) from '||tableName||'bt l where '||tab.start_ip||'=l.start_ip and '||tab.end_ip||'=l.end_ip';
          --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr into v_count_t;
if (v_count_t=0) then
   sqlStr:='select count(1) from '||tableName||'b where start_ip='||tab.start_ip||' and end_ip>'||tab.end_ip;
   execute immediate sqlStr into v_count;
if (v_count<>0) then
   sqlStr:='select * from (select * from '||tableName||'b where start_ip='||tab.start_ip||' and end_ip>'||tab.end_ip||' order by end_ip) where rownum<2';
         execute immediate sqlStr into jc;
   sqlStr:='insert into '||tableName||'c values('||jc.id||','||jc.start_ip||','||tab.end_ip||','''|| jc.PROVINCE||''','''|| jc.CITY||''','''|| jc.ISP||''','''||jc.start_ip1||''','''|| tab.end_ip1||''',nvl('''||jc.LOCATION_ID||''',NULL),'''|| jc.CITY_NAME||''',nvl('''||jc.ISP_ID||''',NULL),'''|| jc.ISP_NAME||''','''|| jc.COMMENTS||''','''|| jc.MTIME||''',nvl('''||jc.SPEED_ID||''',NULL))';
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      commit;
   sqlStr:='insert into '||tableName||'c values('||jc.id||','||tab.end_ip||'+1,'||jc.end_ip||','''|| jc.PROVINCE||''','''|| jc.CITY||''','''|| jc.ISP||''', biginttoipstr('||tab.end_ip||'+1),'''|| jc.end_ip1||''',nvl('''||jc.LOCATION_ID||''',NULL),'''|| jc.CITY_NAME||''',nvl('''||jc.ISP_ID||''',NULL),'''|| jc.ISP_NAME||''','''|| jc.COMMENTS||''','''|| jc.MTIME||''',nvl('''||jc.SPEED_ID||''',NULL))';
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      commit;
   sqlStr:='insert into '||tableName||'c values('||tab.id||','||tab.start_ip||','||tab.end_ip||','''|| tab.PROVINCE||''','''|| tab.CITY||''','''|| tab.ISP||''','''||tab.start_ip1||''','''|| tab.end_ip1||''',nvl('''||tab.LOCATION_ID||''',NULL),'''|| tab.CITY_NAME||''',nvl('''||tab.ISP_ID||''',NULL),'''|| tab.ISP_NAME||''','''|| tab.COMMENTS||''','''|| tab.MTIME||''',nvl('''||tab.SPEED_ID||''',NULL))';
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      commit;
      --处理过的数据插入bt表，
     sqlStr:='insert into '||tableName||'bt values('||tab.id||','||tab.start_ip||','||tab.end_ip||','''||tab.PROVINCE||''','''||tab.CITY||''','''||tab.ISP||''','''||tab.START_IP1||''','''||tab.end_ip1||''',nvl('''||tab.LOCATION_ID||''',NULL),'''||tab.CITY_NAME||''',nvl('''||tab.ISP_ID||''',NULL),'''||tab.ISP_NAME||''','''||tab.COMMENTS||''','''||tab.MTIME||''',nvl('''||tab.SPEED_ID||''',NULL))';
      execute immediate sqlStr;
      commit;  
      sqlStr:='insert into '||tableName||'bt values('||jc.id||','||jc.start_ip||','||jc.end_ip||','''|| jc.PROVINCE||''','''|| jc.CITY||''','''|| jc.ISP||''', '''||jc.start_ip1||''','''|| jc.end_ip1||''',nvl('''||jc.LOCATION_ID||''',NULL),'''|| jc.CITY_NAME||''',nvl('''||jc.ISP_ID||''',NULL),'''|| jc.ISP_NAME||''','''|| jc.COMMENTS||''','''|| jc.MTIME||''',nvl('''||jc.SPEED_ID||''',NULL))';
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      commit;   
   sqlStr:='delete from '||tableName||'b where start_ip='||tab.start_ip||' and end_ip='||tab.end_ip;
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      commit;
    sqlStr:='delete from '||tableName||'b where start_ip='||jc.start_ip||' and end_ip='||jc.end_ip;
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      commit;
  else
    sqlStr:='select count(1) from '||tableName||'b where start_ip<'||tab.start_ip||' and end_ip='||tab.end_ip;
   execute immediate sqlStr into v_count;
  
  if (v_count<>0) then
      sqlStr:='select * from (select * from'||tableName||'b where start_ip<'||tab.start_ip||' and end_ip='||tab.end_ip||' order by start_ip desc) where rownum<2';
         execute immediate sqlStr into jc; 
   sqlStr:='insert into '||tableName||'c values('||jc.id||','||jc.start_ip||','||tab.start_ip||'-1,'''|| jc.PROVINCE||''','''|| jc.CITY||''','''|| jc.ISP||''','''||jc.start_ip1||''',biginttoipstr('|| tab.start_ip||'-1),nvl('''||jc.LOCATION_ID||''',NULL),'''|| jc.CITY_NAME||''',nvl('''||jc.ISP_ID||''',NULL),'''|| jc.ISP_NAME||''','''|| jc.COMMENTS||''','''|| jc.MTIME||''',nvl('''||jc.SPEED_ID||''',NULL))';
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      commit;
   sqlStr:='insert into '||tableName||'c values('||jc.id||','||tab.start_ip||','||jc.end_ip||','''|| jc.PROVINCE||''','''|| jc.CITY||''','''|| jc.ISP||''','''||tab.start_ip1||''','''|| jc.end_ip1||''',nvl('''||jc.LOCATION_ID||''',NULL),'''|| jc.CITY_NAME||''',nvl('''||jc.ISP_ID||''',NULL),'''|| jc.ISP_NAME||''','''|| jc.COMMENTS||''','''|| jc.MTIME||''',nvl('''||jc.SPEED_ID||''',NULL))';
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      commit;
    sqlStr:='insert into '||tableName||'c values('||tab.id||','||tab.start_ip||','||tab.end_ip||','''|| tab.PROVINCE||''','''|| tab.CITY||''','''|| tab.ISP||''','''||tab.start_ip1||''','''|| tab.end_ip1||''',nvl('''||tab.LOCATION_ID||''',NULL),'''|| tab.CITY_NAME||''',nvl('''||tab.ISP_ID||''',NULL),'''|| tab.ISP_NAME||''','''|| tab.COMMENTS||''','''|| tab.MTIME||''',nvl('''||tab.SPEED_ID||''',NULL))';
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      commit;
            --处理过的数据插入bt表，
     sqlStr:='insert into '||tableName||'bt values('||tab.id||','||tab.start_ip||','||tab.end_ip||','''||tab.PROVINCE||''','''||tab.CITY||''','''||tab.ISP||''','''||tab.START_IP1||''','''||tab.end_ip1||''',nvl('''||tab.LOCATION_ID||''',NULL),'''||tab.CITY_NAME||''',nvl('''||tab.ISP_ID||''',NULL),'''||tab.ISP_NAME||''','''||tab.COMMENTS||''','''||tab.MTIME||''',nvl('''||tab.SPEED_ID||''',NULL))';
      execute immediate sqlStr;
      commit;  
      sqlStr:='insert into '||tableName||'bt values('||jc.id||','||jc.start_ip||','||jc.end_ip||','''|| jc.PROVINCE||''','''|| jc.CITY||''','''|| jc.ISP||''', '''||jc.start_ip1||''','''|| jc.end_ip1||''',nvl('''||jc.LOCATION_ID||''',NULL),'''|| jc.CITY_NAME||''',nvl('''||jc.ISP_ID||''',NULL),'''|| jc.ISP_NAME||''','''|| jc.COMMENTS||''','''|| jc.MTIME||''',nvl('''||jc.SPEED_ID||''',NULL))';
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      commit;  
   sqlStr:='delete from '||tableName||'b where start_ip='||tab.start_ip||' and end_ip='||tab.end_ip;
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      commit;
    sqlStr:='delete from '||tableName||'b where start_ip='||jc.start_ip||' and end_ip='||jc.end_ip;
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      commit; 
   else
     sqlStr:='select count(1) from '||tableName||'b where start_ip<'||tab.start_ip||' and end_ip>'||tab.end_ip;
   execute immediate sqlStr into v_count;
   
    if (v_count<>0) then
      sqlStr:='select * from (select * from'||tableName||'b where start_ip<'||tab.start_ip||' and end_ip>'||tab.end_ip||' order by start_ip desc) where rownum<2';
         execute immediate sqlStr into jc; 
   sqlStr:='insert into '||tableName||'c values('||jc.id||','||jc.start_ip||','||tab.start_ip||'-1,'''|| jc.PROVINCE||''','''|| jc.CITY||''','''|| jc.ISP||''','''||jc.start_ip1||''',biginttoipstr('|| tab.start_ip||'-1),nvl('''||jc.LOCATION_ID||''',NULL),'''|| jc.CITY_NAME||''',nvl('''||jc.ISP_ID||''',NULL),'''|| jc.ISP_NAME||''','''|| jc.COMMENTS||''','''|| jc.MTIME||''',nvl('''||jc.SPEED_ID||''',NULL))';
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      commit;
   sqlStr:='insert into '||tableName||'c values('||jc.id||','||tab.start_ip||','||tab.end_ip||','''|| jc.PROVINCE||''','''|| jc.CITY||''','''|| jc.ISP||''','''||tab.start_ip1||''','''|| tab.end_ip1||''',nvl('''||jc.LOCATION_ID||''',NULL),'''|| jc.CITY_NAME||''',nvl('''||jc.ISP_ID||''',NULL),'''|| jc.ISP_NAME||''','''|| jc.COMMENTS||''','''|| jc.MTIME||''',nvl('''||jc.SPEED_ID||''',NULL))';
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      commit;
   sqlStr:='insert into '||tableName||'c values('||jc.id||','||tab.end_ip||'+1,'||jc.end_ip||','''|| jc.PROVINCE||''','''|| jc.CITY||''','''|| jc.ISP||''',biginttoipstr('||tab.end_ip||'+1),'''||jc.end_ip1||''',nvl('''||jc.LOCATION_ID||''',NULL),'''|| jc.CITY_NAME||''',nvl('''||jc.ISP_ID||''',NULL),'''|| jc.ISP_NAME||''','''|| jc.COMMENTS||''','''|| jc.MTIME||''',nvl('''||jc.SPEED_ID||''',NULL))';
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      commit;
      --处理过的数据插入bt表，
     sqlStr:='insert into '||tableName||'bt values('||tab.id||','||tab.start_ip||','||tab.end_ip||','''||tab.PROVINCE||''','''||tab.CITY||''','''||tab.ISP||''','''||tab.START_IP1||''','''||tab.end_ip1||''',nvl('''||tab.LOCATION_ID||''',NULL),'''||tab.CITY_NAME||''',nvl('''||tab.ISP_ID||''',NULL),'''||tab.ISP_NAME||''','''||tab.COMMENTS||''','''||tab.MTIME||''',nvl('''||tab.SPEED_ID||''',NULL))';
      execute immediate sqlStr;
      commit;  
      sqlStr:='insert into '||tableName||'bt values('||jc.id||','||jc.start_ip||','||jc.end_ip||','''|| jc.PROVINCE||''','''|| jc.CITY||''','''|| jc.ISP||''', '''||jc.start_ip1||''','''|| jc.end_ip1||''',nvl('''||jc.LOCATION_ID||''',NULL),'''|| jc.CITY_NAME||''',nvl('''||jc.ISP_ID||''',NULL),'''|| jc.ISP_NAME||''','''|| jc.COMMENTS||''','''|| jc.MTIME||''',nvl('''||jc.SPEED_ID||''',NULL))';
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      commit;  
      
    sqlStr:='delete from '||tableName||'b where start_ip='||jc.start_ip||' and end_ip='||jc.end_ip;
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      commit; 
    sqlStr:='insert into '||tableName||'c values('||tab.id||','||tab.start_ip||','||tab.end_ip||','''|| tab.PROVINCE||''','''|| tab.CITY||''','''|| tab.ISP||''','''||tab.start_ip1||''','''|| tab.end_ip1||''',nvl('''||tab.LOCATION_ID||''',NULL),'''|| tab.CITY_NAME||''',nvl('''||tab.ISP_ID||''',NULL),'''|| tab.ISP_NAME||''','''|| tab.COMMENTS||''','''|| tab.MTIME||''',nvl('''||tab.SPEED_ID||''',NULL))';
        --dbms_output.put_line(sqlStr||';');
        execute immediate sqlStr;
        commit;
    sqlStr:='delete from '||tableName||'b where start_ip='||tab.start_ip||' and end_ip='||tab.end_ip;
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      commit;
      else
        sqlStr:='insert into '||tableName||'c values('||tab.id||','||tab.start_ip||','||tab.end_ip||','''|| tab.PROVINCE||''','''|| tab.CITY||''','''|| tab.ISP||''','''||tab.start_ip1||''','''|| tab.end_ip1||''',nvl('''||tab.LOCATION_ID||''',NULL),'''|| tab.CITY_NAME||''',nvl('''||tab.ISP_ID||''',NULL),'''|| tab.ISP_NAME||''','''|| tab.COMMENTS||''','''|| tab.MTIME||''',nvl('''||tab.SPEED_ID||''',NULL))';
        --dbms_output.put_line(sqlStr||';');
        execute immediate sqlStr;
        commit;
       sqlStr:='delete from '||tableName||'b where start_ip='||tab.start_ip||' and end_ip='||tab.end_ip;
       --dbms_output.put_line(sqlStr||';');
       execute immediate sqlStr;
       commit; 
    end if;
  end if;
end if;
--else
--dbms_output.put_line('此条数据已被处理过');
end if;
end loop;
end;


/

