create PROCEDURE          "UPDATE_PAGE_RATE_DOWNLOAD" authid current_user
is
  sqlStr  varchar2(4000);  
  v_name varchar2(400);
  v_error_desc varchar2(400);
  CURSOR c_emp IS SELECT substr(t.object_name,8) FROM all_objects t where t.object_name like 'NB_PAGE_%';
begin
OPEN c_emp;
LOOP
  begin
    FETCH c_emp INTO v_name;
    EXIT WHEN c_emp%NOTFOUND;
    --修改表
    DBMS_OUTPUT.PUT_LINE('start alter table  NB_PAGE'||v_name);
    sqlStr:='alter table NB_PAGE'||v_name||' add RATE_DOWNLOAD NUMBER';
    execute   immediate   sqlStr;
    --加工数据
    DBMS_OUTPUT.PUT_LINE('add data to  NB_PAGE'||v_name);
    sqlStr:='update nb_page'||v_name||' t set t.rate_download = (case when t.ts_total=0 then 0 else round((t.byte_total/t.ts_total)*1000,0) end)';
    DBMS_OUTPUT.PUT_LINE(sqlStr);
    execute immediate sqlStr;
    commit;
  
        --如果创建失败，则显示出失败的表
    exception when  others then
        v_error_desc := 'ERROR:  code: '|| sqlcode || '   NB_PAGE'||v_name;
        DBMS_OUTPUT.PUT_LINE(v_error_desc);
    end;
END LOOP;

CLOSE c_emp;  
end update_page_rate_download;


/

