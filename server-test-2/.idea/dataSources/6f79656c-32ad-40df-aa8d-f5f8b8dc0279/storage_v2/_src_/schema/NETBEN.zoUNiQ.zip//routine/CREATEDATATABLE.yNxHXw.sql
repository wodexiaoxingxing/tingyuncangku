create PROCEDURE createDataTable(tableStr IN varchar2) authid current_user is
    sqlStr     varchar2(8000);
    createDate date := sysdate;
    rangeDate  date;
    rangeDesc  varchar2(8);
    partName1  varchar2(64);
    rangeName1 varchar2(64);
    partName2  varchar2(64);
    rangeName2 varchar2(64);
    partName3  varchar2(64);
    rangeName3 varchar2(64);
BEGIN

    --创建Tran sequence
    sqlStr := 'create sequence SEQ_NB_TRAN_ID_' || tableStr || ' minvalue 1 maxvalue 9999999999999999999999999 start with 1 increment by 1 cache 500';
    execute immediate sqlStr;

    --创建Page sequence
    sqlStr := 'create sequence SEQ_NB_PAGE_ID_' || tableStr || ' minvalue 1 maxvalue 9999999999999999999999999 start with 1 increment by 1 cache 500';
    execute immediate sqlStr;

    --创建Tran
    sqlStr := 'create table NB_TRAN_' || tableStr || '
    (
      ID                  NUMBER not null,
      TASK_ID             NUMBER,
      CITY_ID             NUMBER,
      ISP_ID              NUMBER,
      NET_SPEED_ID        NUMBER,
      TM_BASE             DATE,
      TM_HOUR             DATE,
      TM_DAY              DATE,
      TM_HALF_HOUR        DATE,
      PROBE_IP            NUMBER,
      ERROR_CODE          NUMBER,
      CONT_ERR_TOTAL      NUMBER,
      ERROR_PAGE_SEQ      NUMBER,
      PAGE_TOTAL          NUMBER,
      BYTE_TOTAL          NUMBER,
      TS_TOTAL            NUMBER,
      TS_NETWORK          NUMBER,
      TS_PING_AVG         NUMBER,
      TS_PING_START       NUMBER,
      PING_ERROR          NUMBER,
      TS_PING_MAX         NUMBER,
      TS_PING_MIN         NUMBER,
      PING_PACKET_LOST    NUMBER,
      POINT_TOTAL         NUMBER default 1,
      DNS_SERVER          VARCHAR2(128),
      DNS_SERVER_IP       NUMBER,
      DEST_IP             VARCHAR2(39),
      DEST_CITY_ID        NUMBER,
      DEST_ISP_ID         NUMBER,
      PING_DEST_IP        VARCHAR2(39),
      MEMBER_ID           INTEGER,
      VERSION_ID          INTEGER,
      OS_VER_ID           INTEGER,
      BS_ID               INTEGER,
      BS_VER_ID           INTEGER,
      FLASH_VER           VARCHAR2(32),
      PERCENT_CPU         NUMBER,
      PERCENT_CPU_TASK    NUMBER,
      PERCENT_MEM         NUMBER,
      PERCENT_MEM_TASK    NUMBER,
      RATE_AVG            NUMBER,
      BAND_WIDTH          NUMBER,
      CPU_TYPE            VARCHAR2(128),
      MEM_SIZE            INTEGER,
      IS_NOISE            INTEGER,
      PCAP_PATH           VARCHAR2(512),
      COUNTRY_ID          INTEGER,
      REGION_ID           INTEGER,
      DISTINCT_ID         INTEGER,
      DEST_COUNTRY_ID     INTEGER,
      DEST_REGION_ID      INTEGER,
      IS_CDN_COVER        INTEGER,
      IS_ISP_COVER        INTEGER,
      DEST_IP_VERSION     INTEGER,
      TRACE_ID            VARCHAR2(128),
      FEEDBACK            INTEGER
    ) pctfree 0';
    execute immediate sqlStr;

    --主键
    sqlStr := 'alter table NB_TRAN_' || tableStr || ' add constraint PK_NB_TRAN_' || tableStr || ' primary key (ID) using index';
    execute immediate sqlStr;

    --索引
    sqlStr := 'create index IN_TRAN_PERF_' || tableStr || ' on NB_TRAN_' || tableStr || ' (TM_BASE, TASK_ID) tableSpace NETBEN_idx_new nologging';
    execute immediate sqlStr;

    --创建page
    rangeDate  := trunc(createDate + 7, 'd');
    rangeDesc  := to_char(rangeDate, 'yymmdd');
    partName1  := 'part_page_' || tableStr || '_' || rangeDesc;
    rangeName1 := 'to_date(''' || to_char(rangeDate, 'yyyy-mm-dd') || ''',''yyyy-mm-dd'')';
    rangeDate  := trunc(rangeDate + 7, 'd');
    rangeDesc  := to_char(rangeDate, 'yymmdd');
    partName2  := 'part_page_' || tableStr || '_' || rangeDesc;
    rangeName2 := 'to_date(''' || to_char(rangeDate, 'yyyy-mm-dd') || ''',''yyyy-mm-dd'')';
    rangeDate  := trunc(rangeDate + 7, 'd');
    rangeDesc  := to_char(rangeDate, 'yymmdd');
    partName3  := 'part_page_' || tableStr || '_' || rangeDesc;
    rangeName3 := 'to_date(''' || to_char(rangeDate, 'yyyy-mm-dd') || ''',''yyyy-mm-dd'')';
    sqlStr     := 'create table NB_PAGE_' || tableStr || '
  (
    ID                              NUMBER NOT NULL,
    TRAN_ID                         NUMBER,
    TASK_ID                         NUMBER,
    CITY_ID                         NUMBER,
    ISP_ID                          NUMBER,
    NET_SPEED_ID                    NUMBER,
    TM_BASE                         DATE,
    TM_DAY                          DATE,
    TM_HOUR                         DATE,
    TM_HALF_HOUR                    DATE,
    PROBE_IP                        NUMBER,
    PAGE_SEQ                        NUMBER,
    ERROR_CODE                      NUMBER,
    ERROR_PATH                      VARCHAR2(256),
    CONT_ERR_TOTAL                  NUMBER,
    CONT_ELE_TOTAL                  NUMBER,
    REDIRECT_TOTAL                  NUMBER,
    POINT_TOTAL                     NUMBER DEFAULT 1,
    BYTE_TOTAL                      NUMBER,
    RATE_DOWNLOAD                   NUMBER,
    BYTE_PAGE_BASE                  NUMBER,
    RATE_DOWNLOAD_PAGE_BASE         NUMBER,
    DNS_SERVER                      VARCHAR2(128),
    DNS_SERVER_IP                   NUMBER,
    DEST_IP                         VARCHAR2(39),
    DEST_CITY_ID                    NUMBER,
    DEST_ISP_ID                     NUMBER,
    IS_CDN_COVER                    INTEGER,
    PING_RESULT                     VARCHAR2(512),
    TRACERT_RESULT                  VARCHAR2(512),
    NSLOOKUP_RESULT                 VARCHAR2(512),
    SCRIPT_ERROR_RESULT             VARCHAR2(2000),
    PCAP_PATH                       VARCHAR2(512),
    HTTP_SERVER                     VARCHAR2(256),
    HTTP_VIA                        VARCHAR2(256),
    TS_TOTAL                        NUMBER,
    TS_PAGE_BASE                    NUMBER,
    TS_DNS                          NUMBER,
    TS_CONNECT                      NUMBER,
    TS_SSL                          NUMBER,
    TS_REDIRECT                     NUMBER,
    TS_REQUEST                      NUMBER,
    TS_FIRST_PACKET                 NUMBER,
    TS_CLIENT                       NUMBER,
    TS_CONTENTS                     NUMBER,
    TS_EXTRA_DATA                   NUMBER,
    TS_OPEN_PAGE                    NUMBER,
    TS_USER                         NUMBER,
    TS_NETWORK                      NUMBER,
    TS_CLOSE                        NUMBER,
    NUM_FIRST_ELEM                  NUMBER,
    BYTE_FIRST                      NUMBER,
    NUM_HOST                        NUMBER,
    TS_DNS_TOTAL                    NUMBER,
    NUM_CONNECT                     NUMBER,
    TS_CONNECT_TOTAL                NUMBER,
    NUM_DOM                         NUMBER,
    NUM_IFRAME                      NUMBER,
    NUM_NO_COMPRESS_ELEM            NUMBER,
    NUM_NO_EXPIRE_ELEM              NUMBER,
    NUM_NO_ETAG_ELEM                NUMBER,
    PERCENT_CPU                     NUMBER,
    PERCENT_CPU_TASK                NUMBER,
    PERCENT_MEM                     NUMBER,
    PERCENT_MEM_TASK                NUMBER,
    RATE_AVG                        NUMBER,
    BAND_WIDTH                      NUMBER,
    MEMBER_ID                       INTEGER,
    VERSION_ID                      INTEGER,
    OS_VER_ID                       INTEGER,
    BS_ID                           INTEGER,
    BS_VER_ID                       INTEGER,
    FLASH_VER                       VARCHAR2(32),
    LOG_MSG_RESULT                  VARCHAR2(512),
    NUM_ELEM_LAZY                   INTEGER,
    TS_FIRST_PAINT                  INTEGER,
    TS_FULL_SCREEN                  INTEGER,
    TS_UNLOAD_START                 INTEGER,
    TS_UNLOAD_END                   INTEGER,
    TS_DOM_LOAD                     INTEGER,
    TS_DOM_INTERACT                 INTEGER,
    TS_DOM_CONT_LOAD_START          INTEGER,
    TS_DOM_CONT_LOAD_END            INTEGER,
    TS_DOM_COMPLETE                 INTEGER,
    TS_LOAD_EVT_START               INTEGER,
    TS_LOAD_EVT_END                 INTEGER,
    SRC_PATH                        VARCHAR2(512),   --页面源码路径
    CPU_TREND_RESULT                VARCHAR2(512),   --CPU变化趋势
    MEM_TREND_RESULT                VARCHAR2(512),   --内存变化趋势
    BITRATE_TREND_RESULT            VARCHAR2(512),   --流量变化趋势
    SCRIPT_EXEC_SEGMENTS_RESULT     VARCHAR2(512),   --JS执行过程
    TS_SCRIPT_TOTAL                 INTEGER,         --脚本执行总时间
    TS_DNS_PROJ                     INTEGER,         --DNS投影时间
    TS_CONNECT_PROJ                 INTEGER,         --建联投影时间
    TS_FIRST_PACKET_PROJ            INTEGER,         --首包投影时间
    QUEUE_TIME                      NUMBER,
    APPLICATION_SERVER_TIME         NUMBER,
    APPLICATION_ID                  NUMBER,
    APPLICATION_INSTANCE_ID         NUMBER,
    TRACE_GUID                      VARCHAR2(512),
    ACTION_NAME                     VARCHAR2(512),
    IS_NOISE                        INTEGER,
    CTIME                           DATE,
  QUIC_VERSION                    VARCHAR2(10),
    PROTOCOL_VERSION                VARCHAR2(10),
    NUM_QUIC_HANDSHAKE              NUMBER,
    NUM_QUIC_CONNECTION             NUMBER,
    TS_QUIC_FIRST_100               NUMBER,
    QUIC_PACKET_LOST                NUMBER,
  COUNTRY_ID                      INTEGER,
  REGION_ID                       INTEGER,
  DISTINCT_ID                     INTEGER,
  DEST_COUNTRY_ID                 INTEGER,
  DEST_REGION_ID                  INTEGER,
  IS_ISP_COVER                    INTEGER,
  DEST_IP_VERSION                 INTEGER,
  SPEED_INDEX                 INTEGER,
  HTTP_PORT                    VARCHAR2(8),
  HTTP_LOCAL_PORT                VARCHAR2(8),
      TRACE_ID            VARCHAR2(128),
      FEEDBACK            INTEGER
  ) partition by range (TM_BASE)(
              partition ' || partName1 || ' values less than (' || rangeName1 || '),
              partition ' || partName2 || ' values less than (' || rangeName2 || '),
              partition ' || partName3 || ' values less than (' || rangeName3 || '))
          tableSpace netben_bg';
    execute immediate sqlStr;

    -- 创建索引
    sqlStr := 'create index in_page_perf_' || tableStr || ' on nb_page_' || tableStr || ' (task_id,tm_base) LOCAL compress 1 tableSpace NETBEN_idx_new nologging';
    execute immediate sqlStr;
    sqlStr := 'create index in_page_ctime_' || tableStr || ' on nb_page_' || tableStr || ' (tm_base,ctime) LOCAL tableSpace NETBEN_idx_new nologging';
    execute immediate sqlStr;
    sqlStr := 'create index in_page_tranid_' || tableStr || ' on nb_page_' || tableStr || ' (tran_id) local tableSpace NETBEN_idx_new nologging';
    execute immediate sqlStr;
    sqlStr := 'create index in_page_id_' || tableStr || ' on nb_page_' || tableStr || ' (id) local tableSpace NETBEN_idx_new nologging';
    execute immediate sqlStr;

    -- 创建mt
    rangeDate  := trunc(createDate + 7, 'd');
    rangeDesc  := to_char(rangeDate, 'yymmdd');
    partName1  := 'p_mt_page_' || tableStr || '_' || rangeDesc;
    rangeName1 := 'to_date(''' || to_char(rangeDate, 'yyyy-mm-dd') || ''',''yyyy-mm-dd'')';
    rangeDate  := trunc(rangeDate + 7, 'd');
    rangeDesc  := to_char(rangeDate, 'yymmdd');
    partName2  := 'p_mt_page_' || tableStr || '_' || rangeDesc;
    rangeName2 := 'to_date(''' || to_char(rangeDate, 'yyyy-mm-dd') || ''',''yyyy-mm-dd'')';
    rangeDate  := trunc(rangeDate + 7, 'd');
    rangeDesc  := to_char(rangeDate, 'yymmdd');
    partName3  := 'p_mt_page_' || tableStr || '_' || rangeDesc;
    rangeName3 := 'to_date(''' || to_char(rangeDate, 'yyyy-mm-dd') || ''',''yyyy-mm-dd'')';
    sqlStr     := 'create table mt_page_' || tableStr || '
    (
      task_id                 NUMBER,
      page_seq                NUMBER,
      city_id                 NUMBER,
      isp_id                  NUMBER,
      net_speed_id            NUMBER,
      error_code              NUMBER,
      is_noise                INTEGER,
      dest_ip                 VARCHAR2(39),
      tm_base                 DATE,
      os_ver_id               INTEGER,
      bs_id                   INTEGER,
      bs_ver_id               INTEGER,
      cont_err_total          NUMBER,
      cont_ele_total          NUMBER,
      point_total             NUMBER,
      byte_total              NUMBER,
      rate_download           NUMBER,
      ts_total                NUMBER,
      ts_page_base            NUMBER,
      ts_dns                  NUMBER,
      ts_connect              NUMBER,
      ts_ssl                  NUMBER,
      ts_redirect             NUMBER,
      ts_request              NUMBER,
      ts_first_packet         NUMBER,
      ts_client               NUMBER,
      ts_contents             NUMBER,
      ts_user                 NUMBER,
      ts_network              NUMBER,
      byte_page_base          NUMBER,
      rate_download_page_base NUMBER,
      num_first_elem          NUMBER,
      byte_first              NUMBER,
      num_host                NUMBER,
      ts_dns_total            NUMBER,
      num_connect             NUMBER,
      ts_connect_total        NUMBER,
      num_dom                 NUMBER,
      num_elem_lazy           NUMBER,
      ts_first_paint          NUMBER,
      ts_full_screen          NUMBER,
      ts_unload_start         NUMBER,
      ts_unload_end           NUMBER,
      ts_dom_load             NUMBER,
      ts_dom_interact         NUMBER,
      ts_dom_cont_load_start  NUMBER,
      ts_dom_cont_load_end    NUMBER,
      ts_dom_complete         NUMBER,
      ts_load_evt_start       NUMBER,
      ts_load_evt_end         NUMBER,
      queue_time              NUMBER,
      application_server_time NUMBER,
      dest_city_id            NUMBER,
      dest_isp_id             NUMBER,
      is_cdn_cover            INTEGER
    ) partition by range (TM_BASE)(
          partition ' || partName1 || ' values less than (' || rangeName1 || '),
          partition ' || partName2 || ' values less than (' || rangeName2 || '),
          partition ' || partName3 || ' values less than (' || rangeName3 || '))
      tableSpace netben_bg';
    execute immediate sqlStr;

    -- 创建索引
    sqlStr := 'create index IDX_MT_PAGE_PERF_' || tableStr || ' on MT_PAGE_' || tableStr || ' (task_id,tm_base) LOCAL compress 2 tableSpace NETBEN_idx_new nologging';
    execute immediate sqlStr;

END createDataTable;
/

