create procedure rename_mt_page_part is

begin
  
  --处理删除分区，将所有90天以前的分区均删除
  for str in(select 'alter table '|| table_name ||' rename partition ' || partition_name || ' to p_'|| table_name ||'_'||substr(partition_name,-6) sqls from user_tab_partitions where table_name like 'MT_PAGE_%')
  loop
    begin
       create_procedure_log('rename_mt_page_part','sql:'||str.sqls,'run');
       --dbms_output.put_line(sqlStr);
       execute immediate str.sqls;
       commit;
    exception
       when others then
       create_procedure_log('rename_mt_page_part','sql:'||str.sqls||','||sqlerrm,'error');
    end;
  end loop;
  
end rename_mt_page_part;


/

