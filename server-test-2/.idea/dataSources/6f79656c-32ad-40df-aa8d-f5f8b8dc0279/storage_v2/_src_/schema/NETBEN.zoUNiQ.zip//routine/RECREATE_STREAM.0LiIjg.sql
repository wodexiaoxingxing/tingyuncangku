create PROCEDURE          "RECREATE_STREAM" (
       tableStr IN varchar2
) authid current_user
is
sqlStr  varchar2(4000);
begin
   sqlStr:='drop materialized view log on nb_stream_'||tableStr;
   execute immediate sqlStr;
   
   sqlStr:='drop materialized view mv_stream_'||tableStr;
   execute immediate sqlStr;
  
  --创建Stream物化视图日志
  sqlStr:='create materialized view log on NB_STREAM_'||tableStr||' with rowid,
		sequence (task_id,
			city_id,
			isp_id,
			net_speed_id,
			error_code,
			is_noise,
			dest_ip,
			tm_hour,
			point_total,
			rate_download,
      buffer_count,
			ts_total,
			ts_dns,
      ts_connect,
			ts_buffer,
			ts_rebuffer,
      ts_first_play,
			ts_play,
			ts_full,
      ts_user,
      rece_package,
      lose_package
			) including new values';
	 execute immediate sqlStr;
   
   --创建Stream物化视图 
    sqlStr:='create materialized view MV_STREAM_'||tableStr||'
		refresh fast
		start with sysdate next sysdate + 4/24 
		as
		(select task_id,
		city_id,
		isp_id,
		net_speed_id,
		error_code,
		is_noise,
		dest_ip,
		(tm_hour - mod(to_number(to_char(tm_hour, '||chr(39)||'hh24'||chr(39)||')) + 8, 8) / 24) as tm_hour8,
		(tm_hour - mod(to_number(to_char(tm_hour, '||chr(39)||'hh24'||chr(39)||')) + 12, 12) / 24) as tm_hour12,
		trunc(tm_hour, '||chr(39)||'dd'||chr(39)||') as tm_day,
		count(*) as c1,
		count(point_total) as c2,
		count(rate_download) as c3,
		count(ts_total) as c4,
		count(ts_dns) as c5,
		count(ts_connect) as c6,
		count(ts_buffer) as c7,
		count(ts_rebuffer) as c8,
    count(ts_first_play) as c9,
		count(ts_play) as c10,
		count(ts_full) as c11,
    count(ts_user) as c12,
    count(rece_package) as c13,
    count(lose_package) as c14,
    count(buffer_count) as c15,
    avg(buffer_count) as buffer_count,
		sum(point_total) as point_total,
		avg(rate_download) as rate_download,
		avg(ts_total) as ts_total,
		avg(ts_dns) as ts_dns,
		avg(ts_connect) as ts_connect,
		avg(ts_buffer) as ts_buffer,
		avg(ts_rebuffer) as ts_rebuffer,
    avg(ts_first_play) as ts_first_play,
		avg(ts_play) as ts_play,
		avg(ts_full) as ts_full,
    avg(ts_user) as ts_user,
		avg(rece_package) as rece_package,
		avg(lose_package) as lose_package
		from NB_STREAM_'||tableStr||' 
		group by task_id,
			city_id,
			isp_id,
			net_speed_id,
			error_code,
			is_noise,
			dest_ip,
			(tm_hour - mod(to_number(to_char(tm_hour, '||chr(39)||'hh24'||chr(39)||')) + 8, 8) / 24),
			(tm_hour - mod(to_number(to_char(tm_hour, '||chr(39)||'hh24'||chr(39)||')) + 12, 12) / 24),
			trunc(tm_hour, '||chr(39)||'dd'||chr(39)||'))';
    execute   immediate   sqlStr;    

   -- MV_STREAM 索引	              
	  sqlStr:='create index IN_MV_STREAM_PERF_'||tableStr||' on MV_STREAM_'||tableStr||' (TASK_ID,TM_HOUR8, CITY_ID,ISP_ID) tableSpace NETBEN_IDX';  
    execute   immediate   sqlStr;	
     sqlStr:='create index IN_MV_STREAM_ERROR_'||tableStr||' on MV_STREAM_'||tableStr||' (TASK_ID,TM_HOUR8, ERROR_CODE,CITY_ID) tableSpace NETBEN_IDX';  
    execute   immediate   sqlStr;		   
   
end recreate_stream;


/

