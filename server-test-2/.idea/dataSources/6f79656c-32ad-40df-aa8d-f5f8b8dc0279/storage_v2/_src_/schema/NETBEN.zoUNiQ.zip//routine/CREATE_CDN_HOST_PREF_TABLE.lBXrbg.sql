create procedure create_cdn_host_pref_table(tablestr IN varchar2) authid current_user is
  sqlStr     varchar2(32767);
  rangeDate  date;
  rangeDesc  varchar2(8);
  partName1  varchar2(64);
  rangeName1 varchar2(64);
  partName2  varchar2(64);
  rangeName2 varchar2(64);
  partName3  varchar2(64);
  rangeName3 varchar2(64);

  createDate date;
begin
  createDate := sysdate;
  
  -- cteate nb_cdn_host_perf
  rangeDate  := trunc(createDate + 7, 'd');
  rangeDesc  := to_char(rangeDate, 'yymmdd');
  partName1  := 'p_cdn_host_' || tableStr || '_' || rangeDesc;
  rangeName1 := 'to_date(''' || to_char(rangeDate, 'yyyy-mm-dd') || ''',''yyyy-mm-dd'')';
  rangeDate  := trunc(rangeDate + 7, 'd');
  rangeDesc  := to_char(rangeDate, 'yymmdd');
  partName2  := 'p_cdn_host_' || tableStr || '_' || rangeDesc;
  rangeName2 := 'to_date(''' || to_char(rangeDate, 'yyyy-mm-dd') || ''',''yyyy-mm-dd'')';
  rangeDate  := trunc(rangeDate + 7, 'd');
  rangeDesc  := to_char(rangeDate, 'yymmdd');
  partName3  := 'p_cdn_host_' || tableStr || '_' || rangeDesc;
  rangeName3 := 'to_date(''' || to_char(rangeDate, 'yyyy-mm-dd') || ''',''yyyy-mm-dd'')';
  sqlStr     := 'create table NB_CDN_HOST_PERF_' || tablestr || ' 
             (
                tm_base           DATE,
                domain_id         INTEGER,
                cdn_id            INTEGER,
                cdn_host_id       INTEGER,
                region_id         INTEGER,
                isp_id            INTEGER,
                ts_dns            INTEGER,
                ts_connect        INTEGER,
                ts_first_packet   INTEGER,
                speed_dl          INTEGER,
                availability      NUMBER,
                hits              INTEGER,
                hits_dns          INTEGER,
                hits_connect      INTEGER,
                hits_first_packet INTEGER
              ) partition by range (TM_BASE)(
              partition ' || partName1 || ' values less than (' || rangeName1 || '),
              partition ' || partName2 || ' values less than (' || rangeName2 || '),
              partition ' || partName3 || ' values less than (' || rangeName3 || '))tablespace netben_bg';
  execute immediate sqlStr;

  sqlStr := 'create index idx_cdn_host_' || tableStr || ' on NB_CDN_HOST_PERF_' || tableStr || ' (tm_base,cdn_id,cdn_host_id) compress 3 LOCAL tableSpace  NETBEN_IND nologging';
  execute immediate sqlStr;

end create_cdn_host_pref_table;

/

