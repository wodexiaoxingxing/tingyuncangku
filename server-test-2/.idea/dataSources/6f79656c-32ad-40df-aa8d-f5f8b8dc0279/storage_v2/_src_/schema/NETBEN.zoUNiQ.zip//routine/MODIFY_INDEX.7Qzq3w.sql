create PROCEDURE          "MODIFY_INDEX" authid current_user
is
  sqlStr  varchar2(4000);  
  v_name varchar2(400);
  v_error_desc varchar2(4000);
  v_s number;
  CURSOR c_emp IS SELECT substr(t.object_name,9) FROM all_objects t where t.object_name like 'NB_PAGE_%';
begin
OPEN c_emp;
LOOP
  begin
    FETCH c_emp INTO v_name;
    EXIT WHEN c_emp%NOTFOUND;
   
   
    sqlStr:= 'drop index IN_PAGE_ERROR_'||v_name;
    execute immediate sqlStr;
    sqlStr:= 'drop index IN_PAGE_PERF_'||v_name;
    execute immediate sqlStr;
     sqlStr:= 'drop index IN_TRAN_ERROR_'||v_name;
    execute immediate sqlStr;
    sqlStr:= 'drop index IN_TRAN_PERF_'||v_name;
    execute immediate sqlStr;
    sqlStr:= 'drop index IN_LT_TRAN_PERF_'||v_name;
    execute immediate sqlStr;
    

     --sqlStr:='create index IN_TRAN_ERROR_'||v_name||' on NB_TRAN_'||v_name||' (TASK_ID,TM_BASE, ERROR_CODE, CITY_ID) tableSpace NETBEN_IDX';
     --execute   immediate   sqlStr;
	   sqlStr:='create index IN_TRAN_PERF_'||v_name||' on NB_TRAN_'||v_name||' (TASK_ID,TM_BASE, CITY_ID,  ISP_ID) tableSpace NETBEN_IDX';
  	 execute   immediate   sqlStr;
     
     sqlStr:='create index IN_PAGE_ERROR_'||v_name||' on NB_PAGE_'||v_name||' (TASK_ID,TM_BASE, ERROR_CODE, CITY_ID) tableSpace NETBEN_IDX';
     execute   immediate   sqlStr;
	   sqlStr:='create index IN_PAGE_PERF_'||v_name||' on NB_PAGE_'||v_name||' (TASK_ID,TM_BASE, CITY_ID,  ISP_ID) tableSpace NETBEN_IDX';
  	 execute   immediate   sqlStr;
     
     sqlStr:='create index IN_LT_TRAN_PERF_'||v_name||' on LT_TRAN_'||v_name||' (TASK_ID, TM_DAY, CITY_ID, ISP_ID) tableSpace NETBEN_IDX';
	   execute   immediate   sqlStr;

  
   --如果创建失败，则显示出失败的表
   exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:' || sqlStr;
        DBMS_OUTPUT.PUT_LINE(v_error_desc);
        create_procedure_log('modify_index',v_error_desc,sqlcode);
    end;
END LOOP;

CLOSE c_emp;  
  
end modify_index;


/

