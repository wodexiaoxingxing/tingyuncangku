create PROCEDURE update_other_part_e authid current_user is
DROP_ERROR exception;
ADD_ERROR exception;

sqlStr varchar2(4000);
currDate date; -- ??？？？??？??？？？？??？?？?？,？??？？？??？?？?？

partNameNew varchar2(64);
partValueNew varchar2(64);
partDate date;
reDays int; --？???？?？？С??????
nextNum int; --？?？？?？？？?？?？?？?
maxDays int; --？?？？?？？??？?？?

begin
  for listtab in(select * from other_parttab_list)loop
  --create_procedure_log('update_other_part_e','begin','run');

  if (listtab.part_by=1) then
      reDays:=listtab.re_nums;
      maxDays:=7;
      nextNum:=1;
      currDate := trunc(sysdate,'dd');
    elsif (listtab.part_by=2) then
      reDays:=listtab.re_nums*7;
      maxDays:=14;
      nextNum:=7;
      currDate := trunc(sysdate,'d');
  elsif (listtab.part_by=3) then
      reDays:=sysdate-add_months(sysdate,-listtab.re_nums);
      maxDays:=trunc(add_months(sysdate,3),'mm')-trunc(sysdate,'mm')-1;
      currDate := trunc(sysdate,'mm');
    end if;

      for tab in(select tabName,partName from (
        select tabName,partName,decode(is_date(tm,'yymmdd'),0,null,1,to_date(tm,'yymmdd')) tm
          from(select table_name tabName,partition_name partName,substr(partition_name, -6) tm
            from user_tab_partitions where table_name = listtab.table_name))
         where tm<= currDate - reDays)
      loop
        begin
           partDate:=to_date(substr(tab.partName,-6),'yymmdd');
           if  partDate > currDate - reDays then  raise DROP_ERROR; end if;
           sqlStr:='alter table '||tab.tabName||' drop partition '||tab.partName;
           --dbms_output.put_line(sqlStr||';');
           execute immediate sqlStr;
           create_procedure_log('update_other_part_e','Drop part,Table:'||tab.tabname||',partName:'||tab.partName,'run');
        exception
           when DROP_ERROR then null;
           when others then
             --dbms_output.put_line('dropError,Table:'||tab.tabname||','||sqlerrm);
             create_procedure_log('update_other_part_e','dropError,Table:'||tab.tabname||','||sqlerrm,'error');
        end;
      end loop;
    --???？?？？???？?？?？?？???

    for tab in(
          select a.table_name tabName,a.partition_name partName,tablespace_name tablespaceName from
           (select table_name,partition_position,partition_name,tablespace_name from user_tab_partitions where table_name = listtab.table_name)a,
           (select table_name,max(partition_position) partition_position from user_tab_partitions where table_name = listtab.table_name group by table_name)b
           where a.table_name = b.table_name and a.partition_position = b.partition_position
    )loop
      begin
        partDate:=to_date(substr(tab.partName,-6),'yymmdd');
        if partDate > currDate + maxDays then raise ADD_ERROR; end if;
        if  (listtab.part_by=3) then
         partNameNew:=substr(tab.partName,1,length(tab.partName)-6)||to_char(add_months(partDate,1),'yymmdd');
         partValueNew :='to_date('''||to_char(add_months(partDate,1),'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
         sqlStr := 'ALTER TABLE '||tab.tabName || ' ADD PARTITION '||partNameNew||' VALUES LESS THAN('||partValueNew||') tablespace '||tab.tablespacename;
        --dbms_output.put_line(sqlStr||';');
         execute immediate sqlStr;
         create_procedure_log('update_other_part_e','Add Part,Table:'||tab.tabname||',partName:'||partNameNew,'run');
        else
         partNameNew:=substr(tab.partName,1,length(tab.partName)-6)||to_char(partDate+nextNum,'yymmdd');
         partValueNew :='to_date('''||to_char(partDate+nextNum,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
         sqlStr := 'ALTER TABLE '||tab.tabName || ' ADD PARTITION '||partNameNew||' VALUES LESS THAN('||partValueNew||') tablespace '||tab.tablespacename;
        --dbms_output.put_line(sqlStr||';');
        execute immediate sqlStr;
         create_procedure_log('update_other_part_e','Add Part,Table:'||tab.tabname||',partName:'||partNameNew,'run');
        end if;
      exception
        when ADD_ERROR then null;
        when others then
          --dbms_output.put_line('addError,Table:'||tab.tabname||','||sqlerrm);
          create_procedure_log('update_other_part_e','addError,Table:'||tab.tabname||','||sqlerrm,'error');

      end;
    end loop;
  end loop;
  create_procedure_log('update_ddclog_part_e','end','run');
  exception when others then
    --dbms_output.put_line('aa,'||sqlerrm);
    create_procedure_log('update_other_part_e','Outer error,'||sqlerrm,'error');
end update_other_part_e;

/

