create procedure del_cdn_u_perf authid current_user is
sqlStr     varchar2(4000);
tab   varchar2(32);
curDays number;
begin
   DBMS_OUTPUT.ENABLE(999999999999999999999);
    create_procedure_log('del_cdn_u_perf','begin','run');
    for tab in(SELECT t.table_name as name FROM user_tables t where t.table_name like 'NB_CDN_USAGE_PERF%')loop
       if tab.name != 'NB_CDN_USAGE_PERF_73864' then goto next; end if;
       for i in 1..330 loop
         begin
          curDays:=400-i;
          sqlStr:='delete from '||tab.name||' where tm_base < :tm';
          dbms_output.put_line(sqlstr);
          execute immediate sqlStr using trunc(sysdate,'dd')-0.5-curDays;
          commit;
          /*
          sqlStr:='delete from '||tab.name||' where tm_base < trunc(sysdate,''dd'')-'||curDays;
          dbms_output.put_line(sqlstr);
          execute immediate sqlStr;
          commit;
          */
          create_procedure_log('del_cdn_u_perf',sqlStr,'run');
        exception when others then
           dbms_output.put_line('error:'||sqlStr||sqlerrm);
          --create_procedure_log('del_cdn_u_perf','tableName:'||tab.name||sqlerrm||','||sqlstr,'error');
        end;
    end loop;
    <<next>>
      null;
  end loop;
  create_procedure_log('del_cdn_u_perf','end','run');
end del_cdn_u_perf;


/

