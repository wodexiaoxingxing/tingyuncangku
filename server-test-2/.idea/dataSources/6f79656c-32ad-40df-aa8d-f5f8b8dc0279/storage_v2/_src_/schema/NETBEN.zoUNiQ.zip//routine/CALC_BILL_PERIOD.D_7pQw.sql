create procedure calc_bill_period(sd Date,days number) authid current_user is
/**
  * HISTORY:   用于数据修复，重新计算某天数据
*/
  sqlStr       varchar2(4000);
  errorDesc varchar2(4000);
  s int;
  startDate date;
  endDate date;
begin
  -- 用于测试增加输出缓存
  --dbms_output.enable(buffer_size=>null) ;
  startDate := trunc(sd,'dd');
  endDate := startDate + days;
  create_procedure_log('calc_bill_period', 'calc_bill_period begin', 'run');
  --首先删除可能已经生成的数据
      sqlStr := 'delete from nb_bill_task_day where calc_date >= :sDate and  calc_date < :eDate';
      execute immediate sqlStr using startDate,endDate;
      commit;

  --循环，查寻出所有的表
  for tableName in (select distinct table_str as name from nb_m_agreement) loop
  begin
      create_procedure_log('calc_bill_period','tableStr:'|| tableName.Name, 'run');  
      --从page表中生成每日的数据，页面包括普通ping及事务的数据
      begin
        sqlStr := 'insert into nb_bill_task_day value
                     select task_id,trunc(tm_base,''dd''),sum(point_total),sysdate
                        from nb_page_'||tableName.name||'
                         where tm_base >= :sDate and tm_base < :eDate
                            and is_noise = 0
                         group by task_id,trunc(tm_base,''dd'')';
        execute immediate sqlStr using startDate,endDate;
        commit;
      exception when others then
        errorDesc := sqlerrm||',tableName:nb_page_' || tableName.name ;
        --DBMS_OUTPUT.PUT_LINE(errorDesc);
        create_procedure_log('calc_bill_period',errorDesc,'warning');
      end;

      --从stream表中生成每日的数据
      select count(*)  INTO s FROM nb_m_task where type=3 and agreement_id in (select id from nb_m_agreement where table_str =tableName.name);
      if s > 0 then
        begin
          sqlStr := 'insert into nb_bill_task_day value
                       select task_id,trunc(tm_base,''dd''),sum(point_total),sysdate
                          from nb_stream_'||tableName.name||'
                           where tm_base >= :sDate and tm_base < :eDate
                              and is_noise = 0
                           group by task_id,trunc(tm_base,''dd'')';
          execute immediate sqlStr using startDate,endDate;
          commit;
        exception when  others then
          errorDesc := sqlerrm||',tableName:nb_stream_' || tableName.name ;
          --DBMS_OUTPUT.PUT_LINE(errorDesc);
          create_procedure_log('calc_bill_period',errorDesc,'warning');
        end;
      end if;
      --从custom表中生成每日的数据
      select count(*)  INTO s FROM nb_m_task where type=255 and agreement_id in (select id from nb_m_agreement where table_str =tableName.name);
      if s > 0 then
        begin
          sqlStr := 'insert into nb_bill_task_day value
                       select task_id,trunc(tm_base,''dd''),sum(point_total),sysdate
                          from nb_custom_'||tableName.name||'
                           where tm_base >= :sDate and tm_base < :eDate
                              and is_noise = 0
                           group by task_id,trunc(tm_base,''dd'')';
          execute immediate sqlStr using startDate,endDate;
          commit;
        exception when  others then
          errorDesc := sqlerrm||',tableName:nb_custom_' || tableName.name ;
          --DBMS_OUTPUT.PUT_LINE(errorDesc);
          create_procedure_log('calc_bill_period',errorDesc,'warning');
        end;
      end if;
      --从trace表中生成每日的数据
      select count(*)  INTO s FROM nb_m_task where task_option='T' and type=1 and agreement_id in (select id from nb_m_agreement where table_str =tableName.name);
      if s > 0 then
        begin
          sqlStr := 'insert into nb_bill_task_day value
                       select task_id,trunc(tm_base,''dd''),sum(point_total),sysdate
                          from nb_trace_'||tableName.name||'
                           where tm_base >= :sDate and tm_base < :eDate
                              and is_noise = 0
                           group by task_id,trunc(tm_base,''dd'')';
          execute immediate sqlStr using startDate,endDate;
          commit;
        exception when  others then
          errorDesc := sqlerrm||',tableName:nb_trace_' || tableName.name ;
          --DBMS_OUTPUT.PUT_LINE(errorDesc);
          create_procedure_log('calc_bill_period',errorDesc,'warning');
        end;
      end if;
      --从手机页面监测表中生成每日的数据
      select count(*)  INTO s FROM nb_m_task where type=102 and agreement_id in (select id from nb_m_agreement where table_str =tableName.name);
      if s > 0 then
        begin
          sqlStr := 'insert into nb_bill_task_day value
                       select task_id,trunc(tm_base,''dd''),sum(point_total),sysdate
                          from nb_mob_page_'||tableName.name||'
                           where tm_base >= :sDate and tm_base < :eDate
                              and is_noise = 0
                           group by task_id,trunc(tm_base,''dd'')';
          execute immediate sqlStr using startDate,endDate;
          commit;
        exception when  others then
          errorDesc := sqlerrm||',tableName:nb_mob_page_' || tableName.name ;
          --DBMS_OUTPUT.PUT_LINE(errorDesc);
          create_procedure_log('calc_bill_period',errorDesc,'warning');
        end;
      end if;
      --从ping监测表中生成每日的数据,暂时只取手机页面PING的数据，普通页面ping从page表中取
      select count(*)  INTO s FROM nb_m_task where task_option='P' and type=102 and agreement_id in (select id from nb_m_agreement where table_str =tableName.name);
      if s > 0 then
      begin
        sqlStr := 'insert into nb_bill_task_day value
                     select p.task_id, trunc(p.tm_base, ''dd''), sum(p.point_total), sysdate
                        from nb_ping_'||tableName.name||' p,nb_m_task t
                       where p.tm_base >= :sDate and p.tm_base < :eDate
                         and p.is_noise = 0
                         and t.agreement_id in(select id from nb_m_agreement where table_str = '||tableName.name||')
                         and t.task_option = ''P''
                         and t.type = 102
                         and p.task_id = t.id
                       group by p.task_id, trunc(p.tm_base, ''dd'')';
        execute immediate sqlStr using startDate,endDate;
        commit;
      exception when  others then
        errorDesc := sqlerrm||',tableName:nb_ping_' || tableName.name ;
        --DBMS_OUTPUT.PUT_LINE(errorDesc);
        create_procedure_log('calc_bill_period',errorDesc,'warning');
      end;
      end if;
  end;
  end loop;
  create_procedure_log('calc_bill_period', 'calc_bill_period end', 'run');
end calc_bill_period;


/

