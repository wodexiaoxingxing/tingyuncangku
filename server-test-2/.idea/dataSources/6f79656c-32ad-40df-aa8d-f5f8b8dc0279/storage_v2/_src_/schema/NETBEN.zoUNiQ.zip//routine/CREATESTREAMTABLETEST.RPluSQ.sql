create PROCEDURE          "CREATESTREAMTABLETEST" (
tableStr IN varchar2
) authid current_user
is
sqlStr varchar2(4000);
begin
	sqlStr := 'create table TEST_UTG_STREAM_' || tableStr || '(id integer) tablespace NETBEN';
	execute immediate sqlStr;
end createStreamTableTest;


/

