create PROCEDURE alter_mob_tran_add_field
is 
  sqlStr  varchar2(4000);  
  v_error_desc varchar2(4000);
  v_s number;
begin
  for tableName in(select t.table_name as name from user_tables t where regexp_like( t.table_name,'^NB_MOB_TRAN_[0-9]')) loop
    begin
      create_procedure_log('alter_mob_tran_add_field',tableName.name,'message');
      select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='DEST_CITY_ID';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add dest_city_id number';
        execute   immediate   sqlStr ;
      end if;
      create_procedure_log('alter_mob_tran_add_field',tableName.name,'message');
      select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='DEST_ISP_ID';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add dest_isp_id number';
        execute   immediate   sqlStr ;
      end if;
      exception when  others then
          v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
          create_procedure_log('alter_mob_tran_add_field',v_error_desc,sqlcode);
    end;
  end loop;
end alter_mob_tran_add_field;


/

