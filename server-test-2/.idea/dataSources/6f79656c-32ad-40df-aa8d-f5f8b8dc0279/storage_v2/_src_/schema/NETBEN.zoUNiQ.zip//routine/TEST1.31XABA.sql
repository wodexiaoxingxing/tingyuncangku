create procedure test1(s number) is
ss number :=s;
begin
  for s in 1..ss loop
    create_procedure_log('test1',ss,'run');
    end loop;
end test1;


/

