create PROCEDURE "INSERT_MBR_SCORE" authid current_user is
   
   -- 定义一个数组变量
  type id_member is table of number;
  memberId id_member := id_member();
   --定义变量 
  i  NUMBER;
  score NUMBER;
  netid NUMBER;
 
   -- 定义一个数组变量
  type id_memberZ is table of number;
  memberIdZ id_memberZ := id_memberZ();
  
  type id_impci is table of number;
  impciId id_impci := id_impci();
   --定义变量 
  j  NUMBER;
  k  NUMBER;
  points NUMBER;
  netidZ NUMBER;
  
  
begin
 
 i:=1;
    -- 初始化数组
    -- 数组扩展到5个元素
    memberId.extend(5); 
    memberId(1) := 1868;
    memberId(2) := 11;
    memberId(3) := 7;
    memberId(4) := 767;
    memberId(5) := 766;
  ----循环开始
   WHILE (i<=5)  
     LOOP
        BEGIN 
              score:= ceil(dbms_random.value(1500,2000));
              netid:= ceil(dbms_random.value(0,2));
              insert into NB_MBR_SCORE (id,MEMBER_ID,CDATE,SCORE,DATA_POINTS,NET_ID) 
              values(m_score_id_seq.nextval, memberId(i),sysdate-1,score,score*2,netid);
              commit;
              i:=i+1;
         END;
     ----循环结束
     END LOOP;
   
  j:=1;
  k:=1;
    -- 初始化数组
    -- 数组扩展到5个元素
    memberIdZ.extend(5); 
    memberIdZ(1) := 1867;
    memberIdZ(2) := 5;
    memberIdZ(3) := 8;
    memberIdZ(4) := 9;
    memberIdZ(5) := 10;
    ----循环开始得到impciId数组
    impciId.extend(5);
    
   WHILE (j<=5)  
     LOOP
        BEGIN 
              select distinct IMPCI_ID into impciId(j) from NB_M_DPMBR_IMPCI mImpci where mImpci.Member_Id = memberIdZ(j);
              j:=j+1;
         END;
     ----循环结束
     END LOOP;
    
   ----循环开始
   WHILE (k<=5)  
     LOOP
        BEGIN 
              points:= ceil(dbms_random.value(1500,2000));
              netidZ:= ceil(dbms_random.value(0,2));
              insert into NB_DPMBR_DP (MEMBER_ID,IMPCI_ID,NET_ID,CDATE,DATA_POINTS) 
              values(memberIdZ(k),impciId(k),netidZ,sysdate-1,points);
              commit;
              k:=k+1;
         END;
     ----循环结束
     END LOOP;
    
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
   
end INSERT_MBR_SCORE;


/

