create trigger NB_M_IPDB_TG
    before insert
    on NB_M_IPDB
    for each row
    when (new.id is null)
begin
  select NB_M_IPDB_SQUENCE.nextval into :new.id from dual;
end;


/

