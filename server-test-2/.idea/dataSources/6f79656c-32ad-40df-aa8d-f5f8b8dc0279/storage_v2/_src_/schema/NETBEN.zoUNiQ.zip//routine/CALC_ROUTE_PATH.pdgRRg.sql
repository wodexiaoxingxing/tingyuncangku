create PROCEDURE          "CALC_ROUTE_PATH" authid current_user is

--存放从Trace表中取出的记录的 记录类型
type Trace is record(id number,task_id number,dest_ip varchar2(39));
--用于生成任务对就的主机IP
type TaskDestType is record(task_id number,dest_ip varchar2(39));
--存放从Route表中取出的记录的 记录类型
type Route is record(dest_ip varchar2(39),rtt_mean number);

type TraceCursorType is table of Trace;
type RouteCursorType is table of Route;
type TaskDestCursorType is table of TaskDestType;
tCur TraceCursorType;
rCur RouteCursorType;
tmpTaskDest TaskDestType;
taskDest TaskDestCursorType;
rtt number;
pathDesc varchar2(4000);
sqlStr       varchar2(4000);
currDate date;
calcHour Date;
v_error_desc varchar2(4000);
v_order number;
ifExist boolean;
begin
  create_procedure_log('calc_route_path', 'calc_route_path begin', 'message');
  currDate := sysdate ;
  --现在用2小时间隔来计算
  calcHour := trunc(currDate,'hh24') - mod(to_number(to_char(trunc(currDate,'hh24'), 'hh24')) + 4, 4) / 24 -4/24;
  --循环，查寻出所有的表
  for tab in (select substr(t.table_name,10) as suff from user_tables t where t.table_name like '%NB_TRACE_%') loop
  begin
      
      --清空临时表
      sqlStr:='truncate table nb_route_temp';
      execute immediate sqlStr;
      --从Trace表中循环，查出2或4小时内所有的有效记录
      execute immediate 'select id,task_id,dest_ip from nb_trace_'||tab.suff||' where tm_base >=:sDate and tm_base < :eDate' 
           bulk collect into tCur using calcHour ,calcHour + 2/24;
      for i in 1..tCur.count loop
         --准备处理任务对应多主机地址表
         ifExist:=false;
         --如果集合taskDest已经初始化了
          if (taskDest is not null) then
            if (tCur(i).dest_ip is not null) then
              for z in 1..taskDest.count loop
                  if (taskDest(z).task_id = tCur(i).task_id and taskDest(z).dest_ip = tCur(i).dest_ip) then
                      ifExist:=true;
                  end if;
              end loop;
              if (not ifExist) then
                  v_order := taskDest.count + 1;
                  taskDest.extend;
                  taskDest(v_order).task_id := tCur(i).task_id;
                  taskDest(v_order).dest_ip := tCur(i).dest_ip;
              end if;
            end if;
          --如果集合没有初始化，将其初始化(给值即完成初始化)    
          else
              tmpTaskDest.task_id := tCur(i).task_id;
              tmpTaskDest.dest_ip := tCur(i).dest_ip;
              taskDest:=TaskDestCursorType(tmpTaskDest);
          end if;
          rtt := 0;
          pathDesc := '';
          --从Route表中循环，查出指定Trace_id的路径记录，倒排序
          execute immediate 'select dest_ip,rtt_mean from nb_route_'||tab.suff||' where trace_id = :id order by ttl_order desc ' bulk collect into rCur using tCur(i).id;
          for j in 1..rCur.count loop
              --处理rtt时间及路径描述
              rtt := rCur(j).rtt_mean;
              pathDesc := rCur(j).dest_ip || '-' || pathDesc;
              --pathDesc := substr(pathDesc,1,length(pathDesc)-1);
              --将生成的数据插入到临时表中，用临时表是为了提高插入的效率
              sqlStr:='merge into nb_route_temp t using
                      (select :taskId task_id,:destIp dest_ip,:tmHour4 tm_hour4,:rttTotal rtt_total,:pathDesc path_desc,:pathCount path_count from dual) g
                      on(g.task_id = t.task_id and g.path_desc = t.path_desc) 
                      when matched then update set t.point_total = t.point_total + 1,t.rtt_total = (t.rtt_total * t.point_total +'|| rtt ||')/(t.point_total + 1)
                      when not matched then insert values(g.task_id,g.dest_ip,g.tm_hour4,g.rtt_total,g.path_desc,g.path_count,1,'''')';
              execute immediate sqlStr using tCur(i).task_id,tCur(i).dest_ip,calcHour,rtt,substr(pathDesc,1,length(pathDesc)-1),j;
              commit;
          end loop;
      end loop;
      --将临时数据插入到统计表中
      sqlStr:='delete from nb_route_stat_'||tab.suff||' where tm_hour4 = :hour';
      execute immediate sqlStr using calcHour;
      commit;
      sqlStr:='insert into nb_route_stat_'||tab.suff||' value select task_id,dest_ip,tm_hour4,rtt_total,path_desc,path_count,point_total from nb_route_temp';
      execute immediate sqlStr;
      commit;
      ---将任务对应多主机地址信息存放到nb_m_task_dest字典表中
      for y in 1..taskDest.count loop
       DBMS_OUTPUT.PUT_LINE('taskDest:' || taskDest.count || taskDest(y).task_id || '   ' || taskDest(y).dest_ip);
          sqlStr:='merge into nb_m_task_dest t using
                   (select :taskId task_id,:destIp dest_ip from dual) g
                   on(g.task_id = t.task_id and g.dest_ip = t.dest_ip)
                   when not matched then insert values(g.task_id,g.dest_ip)';
          execute immediate sqlStr using taskDest(y).task_id,taskDest(y).dest_ip;
          commit;          
      end loop;
      --清除taskDest内的数据
      taskDest.delete;
     
      exception when  others then
        v_error_desc := 'Error Message:'|| sqlerrm || '  tab:' || tab.suff;
        DBMS_OUTPUT.PUT_LINE(v_error_desc);
        --create_procedure_log('in_top_host',v_error_desc,sqlcode);
    end;
  end loop;
  create_procedure_log('calc_point_alarm_day', 'calc_point_alarm_day end', 'test');
end calc_route_path;


/

