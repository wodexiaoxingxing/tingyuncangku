create trigger TR_M_PROBE_HOST
    before insert or update or delete
    on NB_M_PROBE_HOST
begin
  RAISE_APPLICATION_ERROR(-20001, 'TR_M_PROBE_HOST');
end TR_M_PROBE_HOST;


/

