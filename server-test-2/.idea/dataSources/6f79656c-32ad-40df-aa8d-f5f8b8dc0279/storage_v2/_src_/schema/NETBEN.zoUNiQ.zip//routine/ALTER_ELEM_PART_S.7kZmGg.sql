create PROCEDURE          "ALTER_ELEM_PART_S" 
(tableStr IN varchar2) authid current_user
is
  sqlStr  varchar2(4000);
  v_is_part varchar2(32); 
  v_s number;
begin
  -- 判断是否该表已经做过分区
  select t.partitioned into v_is_part from user_tables t where t.table_name = 'NB_ELEM_'||tableStr;
  dbms_output.put_line(v_is_part);
  if v_is_part = 'YES' then return; end if;
  
  -- 1.首先创建一个新表
  dbms_output.put_line('begin create table');
  sqlStr:='create table NB_ELEM_'||tableStr||'_TEMP
  (
  id               number not null,
  PAGE_ID          NUMBER,
  TASK_ID          NUMBER,
  CITY_ID          NUMBER,
  ISP_ID           NUMBER,
  NET_SPEED_ID     NUMBER,
  TM_BASE          DATE,
  PROBE_IP         NUMBER,
  ELEMENT_SEQ      NUMBER,
  RECORD_TYPE      VARCHAR2(2),
  ERROR_CODE       NUMBER,
  REDIRECT_TOTAL   NUMBER,
  URL_HOST         VARCHAR2(64),
  URL_PROTOCOL     VARCHAR2(16),
  URL_PORT         VARCHAR2(8),
  URL_PATH         VARCHAR2(512),
  URL_IP           VARCHAR2(32),
  ELEMENT_TYPE     VARCHAR2(32),
  BYTE_TOTAL       NUMBER,
  HTTP_STAT_CODE   NUMBER,
  HTTP_HEAD_SIZE   NUMBER,
  HTTP_BODY_COMP   VARCHAR2(2),
  HTTP_SERVER      VARCHAR2(256),
  HTTP_VIA         VARCHAR2(256),
  TS_START_OFFSET  NUMBER,
  TS_DNS           NUMBER,
  TS_CONNECT       NUMBER,
  TS_SSL           NUMBER,
  TS_REDIRECT      NUMBER,
  TS_REQUEST       NUMBER,
  TS_FIRST_PACKET  NUMBER,
  TS_REMAIN_PACKET NUMBER,
  TS_ELEMENT       NUMBER,
  TS_CLOSE         NUMBER
  )
  partition by range (TM_BASE)
  (
  partition PART_ELEM_'||tableStr||'_9 values less than (TO_DATE(''2007-12-30'', ''YYYY-MM-DD'')),
  partition PART_ELEM_'||tableStr||'_10 values less than (TO_DATE(''2008-01-06'', ''YYYY-MM-DD'')),
  partition PART_ELEM_'||tableStr||'_11 values less than (TO_DATE(''2008-01-13'', ''YYYY-MM-DD'')),
  partition PART_ELEM_'||tableStr||'_12 values less than (TO_DATE(''2008-01-20'', ''YYYY-MM-DD'')),
  partition PART_ELEM_'||tableStr||'_13 values less than (TO_DATE(''2008-01-27'', ''YYYY-MM-DD''))
  )';
  execute immediate sqlStr;
  

  --2.检查原始表能否在线重定义,采用rowid方式  用系统管理员执行
  dbms_output.put_line('DBMS_REDEFINITION.CAN_REDEF_TABLE');
  DBMS_REDEFINITION.CAN_REDEF_TABLE('NETBEN', 'NB_ELEM_'||tableStr, DBMS_REDEFINITION.cons_use_rowid); 
  
  --3.执行在线重新定义 系统管理员执行
  dbms_output.put_line('DBMS_REDEFINITION.START_REDEF_TABLE');
  DBMS_REDEFINITION.START_REDEF_TABLE('NETBEN', 'NB_ELEM_'||tableStr, 'NB_ELEM_'||tableStr||'_TEMP', '', DBMS_REDEFINITION.cons_use_rowid); 
  
  
  --4.执行数据同步 系统管理员执行
  dbms_output.put_line('DBMS_REDEFINITION.sync_interim_table');
  DBMS_REDEFINITION.sync_interim_table('NETBEN', 'NB_ELEM_'||tableStr, 'NB_ELEM_'||tableStr||'_TEMP');
  --执行两次
  DBMS_REDEFINITION.sync_interim_table('NETBEN', 'NB_ELEM_'||tableStr, 'NB_ELEM_'||tableStr||'_TEMP');
  
  --5.完成在线重新定义 系统管理员执行
  dbms_output.put_line('DBMS_REDEFINITION.FINISH_REDEF_TABLE');
  DBMS_REDEFINITION.FINISH_REDEF_TABLE('NETBEN', 'NB_ELEM_'||tableStr, 'NB_ELEM_'||tableStr||'_TEMP');

  --6.创建一个local 索引
  --先判断是否同名索引存在，如果存在，则删除
  select count(*) into v_s from user_indexes t where t.index_name='IN_ELEM_PAGEID_'||tableStr;
  if v_s > 0 then 
      sqlStr:='drop index IN_ELEM_PAGEID_'||tableStr;
      execute immediate sqlStr;
  end if;
  sqlStr:='create index in_elem_pageid_'||tableStr||' on nb_elem_'||tableStr||'(page_id) local
      (partition PART_ELEM_'||tableStr||'_9,
       partition PART_ELEM_'||tableStr||'_10,
       partition PART_ELEM_'||tableStr||'_11,
       partition PART_ELEM_'||tableStr||'_12,
       partition PART_ELEM_'||tableStr||'_13)
       tablespace netben_idx';
  execute immediate sqlStr;
end alter_elem_part_s;


/

