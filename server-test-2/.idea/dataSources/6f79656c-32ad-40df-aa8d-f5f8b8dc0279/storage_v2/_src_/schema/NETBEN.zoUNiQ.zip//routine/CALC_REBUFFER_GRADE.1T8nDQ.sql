create FUNCTION          "CALC_REBUFFER_GRADE" (ts_rebuffer in number)
  return number is
  result number;
begin
  result := -2 * power(ts_rebuffer, 2) + 100;
  result := case
              when result < 0 then
               0
              else
               result
            end;
  return(Result);
end calc_rebuffer_grade;


/

