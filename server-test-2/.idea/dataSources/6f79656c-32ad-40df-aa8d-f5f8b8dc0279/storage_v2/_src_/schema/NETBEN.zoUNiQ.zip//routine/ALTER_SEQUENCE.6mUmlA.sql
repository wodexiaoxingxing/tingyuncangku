create PROCEDURE alter_sequence (
   tableStr in number
)authid current_user is
   sqlStr varchar2(4000);
   errorDesc varchar2(4000);
   minId number;
   v_s int;
begin
   -- tran 表
   select count(*) into v_s from user_sequences where sequence_name = 'SEQ_NB_TRAN_ID_'||tableStr;
   if v_s > 0 then
     sqlStr:='select min(id) from nb_tran_'||tableStr;
     execute immediate sqlStr into minId;
     dbms_output.put_line('-- tran:minId='||to_char(minId,'999,999,999,999,999,999,999,999'));
     if (minId> 10000000) then 
       sqlStr := 'create sequence seq_nb_tran_id_'||tableStr||'_tmp minvalue 1 maxvalue 9999999999999999999999999 start with 1 increment by 1 cache 1000';
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
       sqlStr := 'rename seq_nb_tran_id_'||tableStr||' to seq_nb_tran_id_'||tableStr||'_bak';
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
       sqlStr := 'rename seq_nb_tran_id_'||tableStr||'_tmp to seq_nb_tran_id_'||tableStr;
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
     end if;
   end if;    
   -- page 表
   select count(*) into v_s from user_sequences where sequence_name = 'SEQ_NB_PAGE_ID_'||tableStr;
   if v_s > 0 then
     sqlStr:='select min(id) from nb_page_'||tableStr;
     execute immediate sqlStr into minId;
     dbms_output.put_line('-- page:minId='||to_char(minId,'999,999,999,999,999,999,999,999'));
     if (minId> 10000000) then 
       sqlStr := 'create sequence seq_nb_page_id_'||tableStr||'_tmp minvalue 1 maxvalue 9999999999999999999999999 start with 1 increment by 1 cache 1000';
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
       sqlStr := 'rename seq_nb_page_id_'||tableStr||' to seq_nb_page_id_'||tableStr||'_bak';
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
       sqlStr := 'rename seq_nb_page_id_'||tableStr||'_tmp to seq_nb_page_id_'||tableStr;
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
     end if;
   end if;    
   -- stream表
   select count(*) into v_s from user_sequences where sequence_name = 'SEQ_NB_STREAM_ID_'||tableStr;
   if v_s > 0 then
     sqlStr:='select min(id) from nb_stream_'||tableStr;
     execute immediate sqlStr into minId;
     dbms_output.put_line('-- stream:minId='||to_char(minId,'999,999,999,999,999,999,999,999'));
     if (minId> 10000000) then 
       sqlStr := 'create sequence seq_nb_stream_id_'||tableStr||'_tmp minvalue 1 maxvalue 9999999999999999999999999 start with 1 increment by 1 cache 500';
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
       sqlStr := 'rename seq_nb_stream_id_'||tableStr||' to seq_nb_stream_id_'||tableStr||'_bak';
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
       sqlStr := 'rename seq_nb_stream_id_'||tableStr||'_tmp to seq_nb_stream_id_'||tableStr;
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
     end if;
   end if;    
   -- ping 表
   select count(*) into v_s from user_sequences where sequence_name = 'SEQ_NB_PING_ID_'||tableStr;
   if v_s > 0 then
     sqlStr:='select min(id) from nb_ping_'||tableStr||' where id > 0';
     execute immediate sqlStr into minId;
     dbms_output.put_line('-- ping:minId='||to_char(minId,'999,999,999,999,999,999,999,999'));
     if (minId> 10000000) then 
       sqlStr := 'create sequence seq_nb_ping_id_'||tableStr||'_tmp minvalue 1 maxvalue 9999999999999999999999999 start with 1 increment by 1 cache 1000';
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
       sqlStr := 'rename seq_nb_ping_id_'||tableStr||' to seq_nb_ping_id_'||tableStr||'_bak';
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
       sqlStr := 'rename seq_nb_ping_id_'||tableStr||'_tmp to seq_nb_ping_id_'||tableStr;
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
     end if;
   end if;    
   -- trace 表
   select count(*) into v_s from user_sequences where sequence_name = 'SEQ_NB_TRACE_ID_'||tableStr;
   if v_s > 0 then
     sqlStr:='select min(id) from nb_trace_'||tableStr||' where id > 0';
     execute immediate sqlStr into minId;
     dbms_output.put_line('-- trace:minId='||to_char(minId,'999,999,999,999,999,999,999,999'));
     if (minId> 10000000) then 
       sqlStr := 'create sequence seq_nb_trace_id_'||tableStr||'_tmp minvalue 1 maxvalue 9999999999999999999999999 start with 1 increment by 1 cache 500';
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
       sqlStr := 'rename seq_nb_trace_id_'||tableStr||' to seq_nb_trace_id_'||tableStr||'_bak';
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
       sqlStr := 'rename seq_nb_trace_id_'||tableStr||'_tmp to seq_nb_trace_id_'||tableStr;
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
     end if;
   end if;    
   -- custom 表
   select count(*) into v_s from user_sequences where sequence_name = 'SEQ_NB_CUSTOM_ID_'||tableStr;
   if v_s > 0 then
     sqlStr:='select min(id) from nb_custom_'||tableStr||' where id > 0';
     execute immediate sqlStr into minId;
     dbms_output.put_line('-- custom:minId='||to_char(minId,'999,999,999,999,999,999,999,999'));
     if (minId> 10000000) then 
       sqlStr := 'create sequence seq_nb_custom_id_'||tableStr||'_tmp minvalue 1 maxvalue 9999999999999999999999999 start with 1 increment by 1 cache 500';
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
       sqlStr := 'rename seq_nb_custom_id_'||tableStr||' to seq_nb_custom_id_'||tableStr||'_bak';
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
       sqlStr := 'rename seq_nb_custom_id_'||tableStr||'_tmp to seq_nb_custom_id_'||tableStr;
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
     end if;
   end if;    
   -- mobTran 表                                                       
   select count(*) into v_s from user_sequences where sequence_name = 'SEQ_NB_MOB_TRAN_ID_'||tableStr;
   if v_s > 0 then
     sqlStr:='select min(id) from nb_mob_tran_'||tableStr||' where id > 0';
     execute immediate sqlStr into minId;
     dbms_output.put_line('-- mob_tran:minId='||to_char(minId,'999,999,999,999,999,999,999,999'));
     if (minId> 10000000) then  
       sqlStr := 'create sequence seq_nb_mob_tran_id_'||tableStr||'_tmp minvalue 1 maxvalue 9999999999999999999999999 start with 1 increment by 1 cache 500';
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
       sqlStr := 'rename seq_nb_mob_tran_id_'||tableStr||' to seq_nb_mob_tran_id_'||tableStr||'_bak';
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
       sqlStr := 'rename seq_nb_mob_tran_id_'||tableStr||'_tmp to seq_nb_mob_tran_id_'||tableStr;
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
     end if;
   end if;    
    -- mobPage 表
   select count(*) into v_s from user_sequences where sequence_name = 'SEQ_NB_MOB_PAGE_ID_'||tableStr;
   if v_s > 0 then
     sqlStr:='select min(id) from nb_mob_page_'||tableStr||' where id > 0';
     execute immediate sqlStr into minId;
     dbms_output.put_line('-- mob_page:minId='||to_char(minId,'999,999,999,999,999,999,999,999'));
     if (minId> 10000000) then 
       sqlStr := 'create sequence seq_nb_mob_page_id_'||tableStr||'_tmp minvalue 1 maxvalue 9999999999999999999999999 start with 1 increment by 1 cache 500';
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
       sqlStr := 'rename seq_nb_mob_page_id_'||tableStr||' to seq_nb_mob_page_id_'||tableStr||'_bak';
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
       sqlStr := 'rename seq_nb_mob_page_id_'||tableStr||'_tmp to seq_nb_mob_page_id_'||tableStr;
       dbms_output.put_line(sqlStr ||';');
       --execute immediate sqlStr;
     end if;
   end if;    
   
   create_procedure_log('alter_sequence','修改sequence完成：tableStr：'|| tableStr,'run');
exception when  others then
   errorDesc := 'End error,' || sqlerrm  ;
   create_procedure_log('alter_sequence',errorDesc|| ',sql:'||sqlStr,'error');
   dbms_output.put_line(errorDesc);
end alter_sequence;


/

