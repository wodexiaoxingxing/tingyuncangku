create PROCEDURE          "UPDATE_RPT_ASSISTANT_DETAIL" 
is
  sqlStr  varchar2(4000);
begin
  for detailId in(select t.id from NB_REPORT_ASSISTANT_DETAIL t where t.task_id is null) loop
  begin
      sqlStr := 'update NB_REPORT_ASSISTANT_DETAIL set task_id = (select ra.task_id from NB_REPORT_ASSISTANT_DETAIL rad inner join NB_REPORT_ASSISTANT ra on rad.report_assistant_id = ra.id where rad.id = ' || detailId.id || ') where id = ' || detailId.id;
      execute   immediate   sqlStr ;
  end;
  end loop;
  commit;
  
  for detailId in(select t.id from NB_REPORT_ASSISTANT_DETAIL t where t.relative_time_range = 0 or t.relative_time_range is null) loop
  begin
      sqlStr := 'update NB_REPORT_ASSISTANT_DETAIL set relative_time_range = (select ra.relative_time_range from NB_REPORT_ASSISTANT_DETAIL rad inner join NB_REPORT_ASSISTANT ra on rad.report_assistant_id = ra.id where rad.id = ' || detailId.id || ') where id = ' || detailId.id;
      execute   immediate   sqlStr ;
  end;
  end loop;
  commit;
end update_rpt_assistant_detail;


/

