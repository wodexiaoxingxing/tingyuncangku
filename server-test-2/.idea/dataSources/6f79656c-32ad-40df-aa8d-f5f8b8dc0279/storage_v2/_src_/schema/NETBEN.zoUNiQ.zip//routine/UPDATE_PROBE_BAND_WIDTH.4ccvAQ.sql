create procedure update_probe_band_width is
begin
  -- 对过去一小时的记录添加城市
  update NB_M_PROBE_BANDWIDTH_HISTORY his
     set his.city =
         (select log.city_id
            from nb_m_proberuntime_log log
           where log.time_stamp =
                 (select max(time_stamp) from nb_m_proberuntime_log)
             and log.host_id = his.host_id)
   where his.host_id in
         (select log.host_id
            from nb_m_proberuntime_log log
           where log.time_stamp =
                 (select max(time_stamp) from nb_m_proberuntime_log))
     and his.mtime > sysdate - 1 / 24;
     
  -- 国内点只保留6分钟内的数据   
  delete from NB_M_PROBE_BANDWIDTH_HISTORY where MTIME > SYSDATE - 6 / 1440 AND CITY LIKE '48%';
  commit;
end update_probe_band_width;
/

