create PROCEDURE "selMembers"(out mycs) is
begin
  open mycs for
    select * into mycs from nb_m_member where username like 'test%';
end selMembers;


/

