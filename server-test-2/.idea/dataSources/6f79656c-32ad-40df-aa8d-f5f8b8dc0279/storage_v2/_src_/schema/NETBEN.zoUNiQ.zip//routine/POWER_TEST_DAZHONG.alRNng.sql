create procedure power_test_dazhong authid current_user is
sqlStr varchar2(4000);
begin
  -- 压测注意事项
  -- 1 检查task_id是否配置正确，主要看有效期及频率
  -- 2 检查sql数量，分三条，最初一条，循环一条，最后恢复一条;检查每条语句后要跟着commit;
  -- 3 每条sql三个字段，sla_probes,status,mtime,检查sla_probes初始值及循环时是否按指定数量增加,
  --   检查最后一条sql的status=0,且sla_probes等于初始值
  -- 4 检查循环次数是否与需求相符，这个要重点检查，容易多或少循环
  -- 5 dbms_lock.sleep()是以秒为单位，5分钟=300

  -- 初始100，每5分钟增加100节点
  sqlStr:='update nb_m_task set sla_probes = 1000,status = 1,mtime=sysdate where id = 2041950';
    execute immediate sqlStr;
    commit;
  for i in 1..19 loop
    DBMS_LOCK.sleep (300);
    sqlStr:='update nb_m_task set sla_probes = sla_probes + 200,status = 1,mtime=sysdate where id = 2041950';
    execute immediate sqlStr;
    commit;
  end loop;
    DBMS_LOCK.sleep (300);
    sqlStr:='update nb_m_task  set sla_probes = 1000,status = 0,mtime = sysdate where id = 2041950';
    execute immediate sqlStr;
    commit;
end power_test_dazhong;


/

