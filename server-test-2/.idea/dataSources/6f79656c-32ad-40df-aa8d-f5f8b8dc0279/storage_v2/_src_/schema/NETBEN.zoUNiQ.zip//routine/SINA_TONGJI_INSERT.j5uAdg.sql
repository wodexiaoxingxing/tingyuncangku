create PROCEDURE          "SINA_TONGJI_INSERT" IS
  v_city         varchar2(100);
  V_ISP_NAME     varchar2(100);
  V_FIELD_NAME   varchar2(100);
  V_VALUE        NUMBER;
  V_TASK_NAME    varchar2(100);
  V_PERCENT_SUCC NUMBER;
  v_task_id      number;
  v_city_id      number;
  v_exist        number;
  sqltext        varchar2(1000);
  v_seq          number;
  cursor c is
    select task.id,
           mid.city_id      as city,
           task.name        as task_name,
           loc.name,
           isp.name,
           mid.field_name,
           mid.field_value,
           mid.percent_succ,
           mid.page_seq
      from tmp_sina_task  task,
           tmp_sina_mid   mid,
           nb_m_location  loc,
           nb_m_option    isp,
           tmp_sina_field field
     where mid.task_id = task.task_id
       and mid.city_id = loc.id
       and mid.isp_id = isp.id
       and mid.field_name = field.name;
  calc_time date;
  errorDesc varchar2(100);
begin
  open c;
  calc_time := trunc(sysdate, 'dd');
  sqltext   := 'truncate table tmp_sina_value';
  execute immediate sqltext;

  loop
    fetch c
      into v_task_id,
           v_city_id,
           V_TASK_NAME,
           v_city,
           V_ISP_NAME,
           V_FIELD_NAME,
           V_VALUE,
           V_PERCENT_SUCC,
           v_seq;
    exit when c%notfound;
    select count(*)
      into v_exist
      from tmp_sina_value t
     where t.task_id = v_task_id and t.city=v_city and t.isp=V_ISP_NAME and page_seq=v_seq;

    if (v_exist = 0) then
      if (v_field_name = '首屏时间') then
        sqltext := 'insert into tmp_sina_value values(:a,:b,:c,:d,:e,:f,null,null,null,null,null ,null,null,null ,null,null,null,:g,:v_seq)';
         --dbms_output.put_line('1');
        execute immediate sqltext
          using v_task_id, v_task_name, v_city, V_ISP_NAME, calc_time, V_VALUE, V_PERCENT_SUCC,v_seq;
      end if;

      if (v_field_name = '总下载时间') then
        sqltext := 'insert into tmp_sina_value values(:v_task_id,:v_task_name,:v_city,:V_ISP_NAME,:CALC_DATE,null,:V_VALUE,null,null,null,null ,null,null,null ,null,null,null,:V_PERCENT_SUCC,:v_seq)';
         --dbms_output.put_line('2');
        execute immediate sqltext
          using v_task_id, v_task_name, v_city, V_ISP_NAME, calc_time, V_VALUE, V_PERCENT_SUCC,v_seq;
      end if;
     if (v_field_name = '页面大小') then
         --dbms_output.put_line(sqltext);
        sqltext := 'insert into tmp_sina_value values(:v_task_id,:v_task_name,:v_city,:V_ISP_NAME,:CALC_DATE,null,null,:V_VALUE,null,null,null ,null,null,null ,null,null,null,:V_PERCENT_SUCC,:v_seq)';
        execute immediate sqltext
          using v_task_id, v_task_name, v_city, V_ISP_NAME, calc_time, V_VALUE, V_PERCENT_SUCC,v_seq;
      end if;
      if (v_field_name = '首屏元素') then
        sqltext := 'insert into tmp_sina_value values(:v_task_id,:v_task_name,:v_city,:V_ISP_NAME,:CALC_DATE,null,null,null,:V_VALUE,null,null ,null,null,null ,null,null,null,:V_PERCENT_SUCC,:v_seq)';
         --dbms_output.put_line(sqltext);
        execute immediate sqltext
          using v_task_id, v_task_name, v_city, V_ISP_NAME, calc_time, V_VALUE, V_PERCENT_SUCC,v_seq;
      end if;
     if (v_field_name = '基础页面下载速度') then
        sqltext := 'insert into tmp_sina_value values(:v_task_id,:v_task_name,:v_city,:V_ISP_NAME,:CALC_DATE,null,null,null,null,:V_VALUE,null ,null,null,null ,null,null,null,:V_PERCENT_SUCC,:v_seq)';
        --dbms_output.put_line(sqltext);
        execute immediate sqltext
          using v_task_id, v_task_name, v_city, V_ISP_NAME, calc_time, V_VALUE, V_PERCENT_SUCC,v_seq;
      end if;
       if (v_field_name = '下载速度') then
        sqltext := 'insert into tmp_sina_value values(:v_task_id,:v_task_name,:v_city,:V_ISP_NAME,:CALC_DATE,null,null,null,null,null ,:V_VALUE,null,null,null ,null,null,null,:V_PERCENT_SUCC,:v_seq)';
         --dbms_output.put_line(sqltext);
        execute immediate sqltext
          using v_task_id, v_task_name, v_city, V_ISP_NAME, calc_time, V_VALUE, V_PERCENT_SUCC,v_seq;
      end if;
      if (v_field_name = '建立连接时间') then
        sqltext := 'insert into tmp_sina_value values(:v_task_id,:v_task_name,:v_city,:V_ISP_NAME,:CALC_DATE,null,null,null,null,null ,null,:V_VALUE,null,null ,null,null,null,:V_PERCENT_SUCC,:v_seq)';
        -- dbms_output.put_line(sqltext);
        execute immediate sqltext
          using v_task_id, v_task_name, v_city, V_ISP_NAME, calc_time, V_VALUE, V_PERCENT_SUCC,v_seq;
      end if;
      if (v_field_name = 'dns时间') then
        sqltext := 'insert into tmp_sina_value values(:v_task_id,:v_task_name,:v_city,:V_ISP_NAME,:CALC_DATE,null,null,null,null,null ,null,null,:V_VALUE,null ,null,null,null,:V_PERCENT_SUCC,:v_seq)';
         --dbms_output.put_line(sqltext);
        execute immediate sqltext
          using v_task_id, v_task_name, v_city, V_ISP_NAME, calc_time, V_VALUE, V_PERCENT_SUCC,v_seq;
      end if;
      if (v_field_name = '收到第一个包时间') then
        sqltext := 'insert into tmp_sina_value values(:v_task_id,:v_task_name,:v_city,:V_ISP_NAME,:CALC_DATE,null,null,null,null,null ,null,null,null ,:V_VALUE,null,null,null,:V_PERCENT_SUCC,:v_seq)';
        -- dbms_output.put_line(sqltext);
        execute immediate sqltext
          using v_task_id, v_task_name, v_city, V_ISP_NAME, calc_time, V_VALUE, V_PERCENT_SUCC,v_seq;
      end if;
      if (v_field_name = '缓冲时间') then
        sqltext := 'insert into tmp_sina_value values(:v_task_id,:v_task_name,:v_city,:V_ISP_NAME,:CALC_DATE,null,null,null,null,null ,null,null,null ,null,:V_VALUE,null,null,:V_PERCENT_SUCC,:v_seq)';
        -- dbms_output.put_line(sqltext);
        execute immediate sqltext
          using v_task_id, v_task_name, v_city, V_ISP_NAME, calc_time, V_VALUE, V_PERCENT_SUCC,v_seq;
      end if;
      if (v_field_name = '再次缓冲时间') then
        sqltext := 'insert into tmp_sina_value values(:v_task_id,:v_task_name,:v_city,:V_ISP_NAME,:CALC_DATE,null,null,null,null,null ,null,null,null ,null,null,:V_VALUE,null,:V_PERCENT_SUCC,:v_seq)';
        -- dbms_output.put_line(sqltext);
        execute immediate sqltext
          using v_task_id, v_task_name, v_city, V_ISP_NAME, calc_time, V_VALUE, V_PERCENT_SUCC,v_seq;
      end if;
      if (v_field_name = '再次缓冲次数') then
        sqltext := 'insert into tmp_sina_value values(:v_task_id,:v_task_name,:v_city,:V_ISP_NAME,:CALC_DATE,null,null,null,null,null ,null,null,null ,null,null,null,:V_VALUE,:V_PERCENT_SUCC,:v_seq)';
        -- dbms_output.put_line(sqltext);
        execute immediate sqltext
          using v_task_id, v_task_name, v_city, V_ISP_NAME, calc_time, V_VALUE, V_PERCENT_SUCC,v_seq;
      end if;
      if (v_field_name = '比特率') then
        sqltext := 'insert into tmp_sina_value values(:v_task_id,:v_task_name,:v_city,:V_ISP_NAME,:CALC_DATE,null,null,null,null,null ,:V_VALUE,null,null,null ,null,null,null,:V_PERCENT_SUCC,:v_seq)';
         --dbms_output.put_line(sqltext);
        execute immediate sqltext
          using v_task_id, v_task_name, v_city, V_ISP_NAME, calc_time, V_VALUE, V_PERCENT_SUCC,v_seq;
      end if;

    end if;

    --

    if (v_exist > 0) then
      if (v_field_name = '首屏时间') then
        sqltext := 'update tmp_sina_value set TS_USER=:V_VALUE where task_id=:v_task_id and city=:v_city and isp=:v_isp and page_seq=:v_seq';
        --dbms_output.put_line(sqltext);
        execute immediate sqltext
          using v_value, v_task_id,v_city,v_isp_name,v_seq;
      end if;
      if (v_field_name = '总下载时间') then
        sqltext := 'update tmp_sina_value set TS_TOTAL=:V_VALUE where task_id=:v_task_id and city=:v_city and isp=:v_isp and page_seq=:v_seq';
        execute immediate sqltext
          using v_value, v_task_id,v_city,v_isp_name,v_seq;
      end if;
      if (v_field_name = '页面大小') then
        sqltext := 'update tmp_sina_value set BYTE_TOTAL=:V_VALUE where task_id=:v_task_id and city=:v_city and isp=:v_isp and page_seq=:v_seq';
        execute immediate sqltext
          using v_value, v_task_id,v_city,v_isp_name,v_seq;
      end if;
      if (v_field_name = '首屏元素') then
        sqltext := 'update tmp_sina_value set NUM_FIRST_ELEM=:V_VALUE where task_id=:v_task_id and city=:v_city and isp=:v_isp and page_seq=:v_seq';
        execute immediate sqltext
          using v_value, v_task_id,v_city,v_isp_name,v_seq;
      end if;
      if (v_field_name = '基础页面下载速度') then
        sqltext := 'update tmp_sina_value set RATE_DOWNLOAD_PAGE_BASE=:V_VALUE where task_id=:v_task_id and city=:v_city and isp=:v_isp and page_seq=:v_seq';
        execute immediate sqltext
          using v_value, v_task_id,v_city,v_isp_name,v_seq;
      end if;
      if (v_field_name = '下载速度') then
        sqltext := 'update tmp_sina_value set RATE_DOWNLOAD=:V_VALUE where task_id=:v_task_id and city=:v_city and isp=:v_isp and page_seq=:v_seq';
        execute immediate sqltext
          using v_value, v_task_id,v_city,v_isp_name,v_seq;
      end if;
      if (v_field_name = '建立连接时间') then
        sqltext := 'update tmp_sina_value set TS_CONNECT=:V_VALUE where task_id=:v_task_id and city=:v_city and isp=:v_isp and page_seq=:v_seq';
        execute immediate sqltext
          using v_value, v_task_id,v_city,v_isp_name,v_seq;
      end if;
      if (v_field_name = 'dns时间') then
        sqltext := 'update tmp_sina_value set TS_DNS=:V_VALUE where task_id=:v_task_id and city=:v_city and isp=:v_isp and page_seq=:v_seq';
        execute immediate sqltext
          using v_value, v_task_id,v_city,v_isp_name,v_seq;
      end if;
      if (v_field_name = '收到第一个包时间') then
        sqltext := 'update tmp_sina_value set TS_FIRST_PACKET=:V_VALUE where task_id=:v_task_id and city=:v_city and isp=:v_isp and page_seq=:v_seq';
        execute immediate sqltext
          using v_value, v_task_id,v_city,v_isp_name,v_seq;
      end if;
      if (v_field_name = '缓冲时间') then
        sqltext := 'update tmp_sina_value set TS_BUFFER=:V_VALUE where task_id=:v_task_id and city=:v_city and isp=:v_isp and page_seq=:v_seq';
        execute immediate sqltext
          using v_value, v_task_id,v_city,v_isp_name,v_seq;
      end if;
      if (v_field_name = '再次缓冲时间') then
        sqltext := 'update tmp_sina_value set TS_REBUFFER=:V_VALUE where task_id=:v_task_id and city=:v_city and isp=:v_isp and page_seq=:v_seq';
        execute immediate sqltext
          using v_value, v_task_id,v_city,v_isp_name,v_seq;
      end if;
      if (v_field_name = '再次缓冲次数') then
        sqltext := 'update tmp_sina_value set BUFFER_COUNT=:V_VALUE where task_id=:v_task_id and city=:v_city and isp=:v_isp and page_seq=:v_seq';
        execute immediate sqltext
          using v_value, v_task_id,v_city,v_isp_name,v_seq;
      end if;
      if (v_field_name = '比特率') then
        sqltext := 'update tmp_sina_value set RATE_DOWNLOAD=:V_VALUE where task_id=:v_task_id and city=:v_city and isp=:v_isp and page_seq=:v_seq';
        execute immediate sqltext
          using v_value, v_task_id,v_city,v_isp_name,v_seq;
      end if;
    end if;

    commit;
  end loop;
  exception   when others then
   errorDesc := ' Error Code:' || sqlcode;
    DBMS_OUTPUT.PUT_LINE(errorDesc);
end;


/

