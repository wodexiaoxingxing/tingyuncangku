create procedure in_noc_alarm_task authid current_user
is
  sqlStr  varchar2(4000);
  tableStr varchar2(32);
  timeCurr date;
  timeStart date;
  timeEnd date;
  timeLast date;
  errorDesc varchar2(4000);
begin
  create_procedure_log('in_noc_alarm_task',' begin','run');
  timeCurr := sysdate ;
  timeStart := trunc(timeCurr - 1/24,'hh24');
  timeEnd := trunc(timeCurr,'hh24');
  timeLast := trunc(timeCurr - 2/24,'hh24');

  --首先删除指定日期内的所有生成数据，防止重复生成数据
  sqlStr:='delete from noc_alarm_task where tm_base =:st';
  execute immediate sqlStr using timeStart;
  sqlStr:='delete from noc_alarm_avail_base where tm_base =:st';
  execute immediate sqlStr using timeStart;
  sqlStr:='delete from noc_alarm_avail_do where tm_base =:st';
  execute immediate sqlStr using timeStart;
  commit;

  --页面监测(真机wap监测=6),排除行业及网上试用
  for tableName in(SELECT t.table_name as name FROM user_tables t where t.table_name like 'NB_PAGE_%'
     and t.table_name not in(select 'NB_PAGE_'||table_str from nb_trade_list)
     and t.table_name not in(select 'NB_PAGE_'||id from nb_m_user where type in(1,9)) ) loop
    begin
    tableStr:=substr(tableName.Name,9);
    sqlStr:='insert into noc_alarm_task
         (id,task_id,tm_base,ctime,point_total,point_error,point_base,ts_total,ts_user,ts_dns,ts_first_packet,ts_connect,percent_succ)
         select seq_noc_alarm_task.nextval,task_id,tm_base,sysdate,
                point_total,point_error,point_base,ts_total,ts_user,ts_dns,ts_first_packet,ts_connect,
                round((point_total-point_error)/point_total*100,2)
          from (
             select task_id,trunc(tm_base,''hh24'') as tm_base,
                  sum(point_total) as point_total,
                  sum(case when error_code > 600000 then 1 else 0 end) as point_error,
                  sum(case when error_code < 600000 then 1 else 0 end) as point_base,
                  round(avg(case when error_code < 600000 then ts_total else null end),0) as ts_total,
                  round(avg(case when error_code < 600000 then ts_user else null end),0) as ts_user,
                  round(avg(case when error_code < 600000 then ts_dns else null end),0) as ts_dns,
                  round(avg(case when error_code < 600000 then ts_first_packet else null end),0) as ts_first_packet,
                  round(avg(case when error_code < 600000 then ts_connect else null end),0) as ts_connect
             from '|| tableName.Name ||'
             where  tm_base >= :st and tm_base < :st and is_noise = 0
                    and task_id in(
                       select id from nb_m_task where (type = 1 or type=6) and agreement_id
                           in(select id from nb_m_agreement where table_str = :ts))
             group by task_id, trunc(tm_base,''hh24'')
         )';
      execute immediate sqlStr using timeStart,timeEnd,tableStr;
      commit;
      exception when  others then
        errorDesc := 'tableName:'||tableName.name||' '||sqlerrm;
        create_procedure_log('in_noc_alarm_task',errorDesc,'error');
    end;
  end loop;
  create_procedure_log('in_noc_alarm_task','page end','run');
  --流媒体监测
  for tableName in(SELECT t.table_name as name FROM user_tables t where t.table_name like 'NB_STREAM_%') loop
    begin
    sqlStr:='insert into noc_alarm_task
         (id,task_id,tm_base,ctime,point_total,point_error,point_base,ts_total,ts_user,ts_dns,ts_first_packet,ts_connect,percent_succ)
         select seq_noc_alarm_task.nextval,task_id,tm_base,sysdate,
                point_total,point_error,point_base,ts_total,ts_user,ts_dns,ts_first_packet,ts_connect,
                round((point_total-point_error)/point_total*100,2)
          from (
             select task_id,trunc(tm_base,''hh24'') as tm_base,
                  sum(point_total) as point_total,
                  sum(case when error_code > 600000 then 1 else 0 end) as point_error,
                  sum(case when error_code < 600000 then 1 else 0 end) as point_base,
                  round(avg(case when error_code < 600000 then ts_total else null end),0) as ts_total,
                  round(avg(case when error_code < 600000 then ts_user else null end),0) as ts_user,
                  round(avg(case when error_code < 600000 then ts_dns else null end),0) as ts_dns,
                  round(avg(case when error_code < 600000 then ts_first_packet else null end),0) as ts_first_packet,
                  round(avg(case when error_code < 600000 then ts_connect else null end),0) as ts_connect
             from '|| tableName.Name ||'
             where  tm_base >= :st and tm_base < :st and is_noise = 0
             group by task_id,trunc(tm_base,''hh24'')
         )';
      execute immediate sqlStr using timeStart,timeEnd;
      commit;
      exception when  others then
        errorDesc := 'tableName:'||tableName.name||' '||sqlerrm;
        create_procedure_log('in_noc_alarm_task',errorDesc,'error');
    end;
  end loop;
    create_procedure_log('in_noc_alarm_task','stream end','run');
  --私有协议监测
  for tableName in(SELECT t.table_name as name FROM user_tables t where t.table_name like 'NB_CUSTOM_%') loop
    begin
    sqlStr:='insert into noc_alarm_task
         (id,task_id,tm_base,ctime,point_total,point_error,point_base,ts_total,percent_succ)
         select seq_noc_alarm_task.nextval,task_id,tm_base,sysdate,
                point_total,point_error,point_base,ts_total,
                round((point_total-point_error)/point_total*100,2)
          from (
             select task_id,trunc(tm_base,''hh24'') as tm_base,
                  sum(point_total) as point_total,
                  sum(case when error_code > 600000 then 1 else 0 end) as point_error,
                  sum(case when error_code < 600000 then 1 else 0 end) as point_base,
                  round(avg(case when error_code < 600000 then ts_total else null end),0) as ts_total
             from '|| tableName.Name ||'
             where  tm_base >= :st and tm_base < :st and is_noise = 0
             group by task_id, trunc(tm_base,''hh24'')
         )';
      execute immediate sqlStr using timeStart,timeEnd;
      commit;
      exception when  others then
        errorDesc := 'tableName:'||tableName.name||' '||sqlerrm;
        create_procedure_log('in_noc_alarm_task',errorDesc,'error');
    end;
  end loop;
  --事务主记录
  for tableName in(SELECT t.table_name as name FROM user_tables t where t.table_name like 'NB_TRAN_%') loop
    begin
    tableStr:=substr(tableName.Name,9);
    sqlStr:='insert into noc_alarm_task
         (id,task_id,tm_base,ctime,point_total,point_error,point_base,ts_total,percent_succ)
         select seq_noc_alarm_task.nextval,task_id,tm_base,sysdate,
                point_total,point_error,point_base,ts_total,
                round((point_total-point_error)/point_total*100,2)
          from (
             select task_id,trunc(tm_base,''hh24'') as tm_base,
                  sum(point_total) as point_total,
                  sum(case when error_code > 600000 then 1 else 0 end) as point_error,
                  sum(case when error_code < 600000 then 1 else 0 end) as point_base,
                  round(avg(case when error_code < 600000 then ts_total else null end),0) as ts_total
             from '|| tableName.Name ||'
             where  tm_base >= :st and tm_base < :st and is_noise = 0
                   and task_id in(select id from nb_m_task where type = 2 and agreement_id
                       in(select id from nb_m_agreement where table_str = :ts))
             group by task_id, trunc(tm_base,''hh24'')
         )';
      execute immediate sqlStr using timeStart,timeEnd,tableStr;
      commit;
      exception when  others then
        errorDesc := 'tableName:'||tableName.name||' '||sqlerrm;
        create_procedure_log('in_noc_alarm_task',errorDesc,'error');
    end;
  end loop;
    create_procedure_log('in_noc_alarm_task','tran end','run');
  --ping任务
  for tableName in(SELECT t.table_name as name FROM user_tables t where t.table_name like 'NB_PING_%') loop
    begin
    tableStr:=substr(tableName.Name,9);
    sqlStr:='insert into noc_alarm_task
         (id,task_id,tm_base,ctime,point_total,point_error,point_base,ts_total,ping_packet_lost)
         select seq_noc_alarm_task.nextval,task_id,tm_base,sysdate,
                point_total,point_error,point_base,ts_total,ping_packet_lost
          from (
             select task_id,trunc(tm_base,''hh24'') as tm_base,
                  sum(point_total) as point_total,
                  sum(case when error_code = 10 and ping_packet_lost = 10000  then 1 else 0 end) as point_error,
                  sum(case when error_code = 10 then 0 else 1 end) as point_base,
                  round(avg(case when error_code = 10 and ping_packet_lost = 10000  then ts_total else null end),0) as ts_total,
                  round(avg(case when error_code = 10 then null else ping_packet_lost/100 end),2) as ping_packet_lost
             from '|| tableName.Name ||'
             where  tm_base >= :st and tm_base < :st and is_noise = 0
                   and task_id in(select id from nb_m_task where task_option = ''P'' and agreement_id
                       in(select id from nb_m_agreement where table_str = :ts))
             group by task_id, trunc(tm_base,''hh24'')
         )';
      execute immediate sqlStr using timeStart,timeEnd,tableStr;
      commit;
      exception when  others then
        errorDesc := 'tableName:'||tableName.name||' '||sqlerrm;
        create_procedure_log('in_noc_alarm_task',errorDesc,'error');
    end;
  end loop;
  --手机页面监测
  for tableName in(SELECT t.table_name as name FROM user_tables t where t.table_name like 'NB_MOB_PAGE_%') loop
    begin
    sqlStr:='insert into noc_alarm_task
         (id,task_id,tm_base,ctime,point_total,point_error,point_base,ts_total,ts_user,ts_dns,ts_first_packet,ts_connect,percent_succ)
         select seq_noc_alarm_task.nextval,task_id,tm_base,sysdate,
                point_total,point_error,point_base,ts_total,0,ts_dns,ts_first_packet,ts_connect,
                round((point_total-point_error)/point_total*100,2)
          from (
             select task_id,trunc(tm_base,''hh24'') as tm_base,
                  sum(point_total) as point_total,
                  sum(case when error_code > 600000 then 1 else 0 end) as point_error,
                  sum(case when error_code < 600000 then 1 else 0 end) as point_base,
                  round(avg(case when error_code < 600000 then ts_total else null end),0) as ts_total,
                  
                  round(avg(case when error_code < 600000 then ts_dns else null end),0) as ts_dns,
                  round(avg(case when error_code < 600000 then ts_first_packet else null end),0) as ts_first_packet,
                  round(avg(case when error_code < 600000 then ts_connect else null end),0) as ts_connect
             from '|| tableName.Name ||'
             where  tm_base >= :st and tm_base < :st and is_noise = 0
             group by task_id, trunc(tm_base,''hh24'')
         )';
      execute immediate sqlStr using timeStart,timeEnd;
      commit;
      exception when  others then
        errorDesc := 'tableName:'||tableName.name||' '||sqlerrm;
        create_procedure_log('in_noc_alarm_task',errorDesc,'error');
    end;
  end loop;
  create_procedure_log('in_noc_alarm_task','page end','run');
  
  create_procedure_log('in_noc_alarm_task','ping end','run');
  begin
    sqlStr:='insert into noc_alarm_avail_base(task_id,tm_base,point_total,ts_total,percent_succ,ctime)
        select task_id,tm_base,point_total,ts_total,percent_succ,sysdate
          from noc_alarm_task
         where tm_base = :st
             and ((percent_succ = 0 and point_total > 1) or (percent_succ <101 and point_total>1))
               ';
               --and ((percent_succ = 0 and point_total > 1) or (percent_succ <60 and point_total>10))
     execute immediate sqlStr using timeStart;
     commit;
   exception when  others then
        errorDesc := 'insert noc_alarm_avail_base' ||sqlerrm;
        create_procedure_log('in_noc_alarm_task',errorDesc,'error');
  end;

  begin
    sqlStr:='insert into noc_alarm_avail_do(task_id,tm_base,point_total,ts_total,percent_succ,ctime)
        select task_id,tm_base,point_total,ts_total,percent_succ,sysdate from
            (select * from noc_alarm_avail_base where tm_base = :st)t1
            where  not exists
              (select 1 from (select task_id from noc_alarm_avail_base where tm_base = :sl) t2 where t1.task_id = t2.task_id)';
     execute immediate sqlStr using timeStart,timeLast;
     commit;
   exception when  others then
        errorDesc := 'insert noc_alarm_avail_do ' ||sqlerrm;
        create_procedure_log('in_noc_alarm_task',errorDesc,'error');
  end;



  create_procedure_log('in_noc_alarm_task','all end','run');
end in_noc_alarm_task;


/

