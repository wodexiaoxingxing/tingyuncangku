create FUNCTION          "CALC_BUFFER_GRADE" (ts_buffer in number)
  return number is
  result number;
begin
  result := -0.0000017358 * power(ts_buffer, 6) +
            0.0001769247 * power(ts_buffer, 5) +
            -0.0072133241 * power(ts_buffer, 4) +
            0.1455708133 * power(ts_buffer, 3) +
            -1.3036484049 * power(ts_buffer, 2) + -1.4954291458 * ts_buffer +
            101.1914181458;

  result := case
              when result > 100 then
               100
              when result < 0 then
               0
              else
               result
            end;
  return(Result);
end calc_buffer_grade;


/

