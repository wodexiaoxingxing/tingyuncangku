create FUNCTION          "CALC_TRADE_GRADE_S" (v0 in number, v1 in number) return number is
  Result number;
  vBad number;
begin
  --v0要计算分数的值
  --v1最差值
  --vBad当v1大于120000时，取120000，小于时取本值
  vBad:=case when v1>120000 then 120000 else v1 end;
  Result:=round((100-100*sin(v0*acos(-1)/(vBad*2))),2);
  return(Result);
end calc_trade_grade_s;


/

