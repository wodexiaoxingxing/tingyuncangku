create materialized view MV_ZC_ID
            (ID, COUNT(*))
    refresh fast on demand
as
select id, count(*) from zc group by id
/

