create procedure MAN_CREATE_INDEX_TRAN authid current_user is
  sqlStr  varchar2(8000);
  ---------------- 主变量 ---------------------------------------------------------------------------

  sub_str  varchar2(128);
  c int;
begin
     -- 2.取出所有已经建立分区的et表后缀，开始循环 注：无分区的表不处理
   for et in  (
 select name,substr(name,9) sub_str1
             from (   select DISTINCT (table_name) name
          from user_indexes
         where table_name like 'NB_TRAN%')
           )
     loop
 begin
        sub_str := et.sub_str1;
   --  DBMS_OUTPUT.PUT_LINE(sub_str);

SELECT COUNT(*) INTO C FROM USER_INDEXES WHERE INDEX_NAME= 'IN_TRAN_PERF_'||sub_str ;
 --DBMS_OUTPUT.PUT_LINE(C);
IF C<1 THEN
       DBMS_OUTPUT.PUT_LINE(C);
    --创建索引
    sqlStr:='create INDEX IN_TRAN_PERF_'||sub_str||' on NB_TRAN_'||sub_str||' ( TASK_ID ,  TM_BASE ,  CITY_ID ,  ISP_ID )  TABLESPACE  NETBEN_IND   nologging';

--DBMS_OUTPUT.PUT_LINE(sqlStr);
execute   immediate   sqlStr;
END IF;


SELECT COUNT(*) INTO C FROM USER_INDEXES WHERE INDEX_NAME= 'PK_NB_TRAN_'||sub_str ;
IF C<1 THEN
    --创建索引
sqlStr:='ALTER TABLE NB_TRAN_'||sub_str||' ADD CONSTRAINT  PK_NB_TRAN_'||sub_str||' PRIMARY KEY ( ID )  ENABLE';

--DBMS_OUTPUT.PUT_LINE(sqlStr);
execute   immediate   sqlStr;
END IF;



    exception when  others then
      MON_PC_ERROR_LOG('MAN_CREATE_INDEX_TRAN',sqlerrm,sub_str);
    -- DBMS_OUTPUT.PUT_LINE(sub_str||' ERROR!');
     DBMS_OUTPUT.PUT_LINE(sqlStr);
  end;
      end loop;

end MAN_CREATE_INDEX_TRAN;


/

