create procedure calc_cdn_host authid current_user
is
  sqlStr  varchar2(4000);
  error_desc varchar2(4000);
  startTime date;
  endTime date;
  ctime date;
  mtime date;
  s number;
  hour number;
  hourDay number := 8;
  min_points number := 0;
  errorTable varchar2(1000);
begin
  create_procedure_log('calc_cdn_host','begin','run');
  startTime := trunc(sysdate,'dd');
  endTime := trunc(sysdate+1,'dd');
  ctime := sysdate;
  mtime := sysdate;
  hour := to_number(to_char(sysdate,'hh24'));
  sqlStr:='truncate table nb_m_task_dest_tmp';
  execute immediate sqlStr;

  -- hour==22时对所有任务进行处理,即每天晚上22点执行一次
  if hour = hourDay then
      --循环，查寻出所有的表
      for agree in(select distinct id,table_str as tableSuff from nb_m_agreement where id in(select  agreement_id from nb_m_agree_detail where status = 1 and expire > sysdate -1)) loop
          begin
         --page 表中能够统计出主机的任务为 事务 页面
          select count(*)  into s from  user_tables t where t.table_name = 'NB_PAGE_'||agree.tableSuff;
          if s > 0 then
            sqlStr := 'insert into nb_m_task_dest_tmp(agreement_id,task_id,dest_ip,point_total,ctime,mtime)
                       select :aid,task_id,dest_ip,point_total,:ctime,:mtime
                         from(
                              select task_id,dest_ip,sum(point_total) point_total
                              from nb_page_'||agree.tableSuff||'
                              where is_noise = 0 and dest_ip is not null
                                 and tm_base>=:st and tm_base <= :et
                                 and task_id in(select id from nb_m_task where (type = 1 or type=2) and task_option !=''P'' and status =1 and expire > sysdate -1 and agreement_id =:aid)
                              group by task_id,dest_ip
                              )
                         where point_total > '||min_points;

            execute immediate sqlStr using agree.id,ctime,mtime,startTime,endTime,agree.id;
            commit;
          end if;
          --ping表中能够统计出主机的任务为 Ping监测
            select count(*) into s from  user_tables t where t.table_name = 'NB_PING_'||agree.tableSuff;
            if s > 0 then
              sqlStr := 'insert into nb_m_task_dest_tmp(agreement_id,task_id,dest_ip,point_total,ctime,mtime)
                         select :aid,task_id,dest_ip,point_total,:ctime,:mtime
                           from(
                                select task_id,dest_ip,sum(point_total) point_total
                                from nb_ping_'||agree.tableSuff||'
                                where is_noise = 0 and dest_ip is not null
                                   and tm_base>=:st and tm_base <= :et
                                   and task_id in(select id from nb_m_task where task_option=''P'' and status =1 and expire > sysdate -1 and agreement_id =:aid)
                                group by task_id,dest_ip
                                )
                           where point_total > '||min_points;
              execute immediate sqlStr using agree.id,ctime,mtime,startTime,endTime,agree.id;
              commit;
            end if;
          --Stream 表中能够统计出主机的任务为 流媒体
          select count(*)  into s from  user_tables t where t.table_name = 'NB_STREAM_'||agree.tableSuff;
          if s > 0 then
            sqlStr := 'insert into nb_m_task_dest_tmp(agreement_id,task_id,dest_ip,point_total,ctime,mtime)
                       select :aid,task_id,dest_ip,point_total,:ctime,:mtime
                         from(
                              select task_id,dest_ip,sum(point_total) point_total
                              from nb_stream_'||agree.tableSuff||'
                              where is_noise = 0 and dest_ip is not null
                                 and tm_base>=:st and tm_base <= :et
                                 and task_id in(select id from nb_m_task where type = 3 and status =1 and expire > sysdate -1 and agreement_id =:aid)
                              group by task_id,dest_ip
                              )
                         where point_total > '||min_points;
            execute immediate sqlStr using agree.id,ctime,mtime,startTime,endTime,agree.id;
            commit;
          end if;
          --Custom 表中能够统计出主机的任务为 私有协议
          select count(*)  into s from  user_tables t where t.table_name = 'NB_CUSTOM_'||agree.tableSuff;
          if s > 0 then
            sqlStr := 'insert into nb_m_task_dest_tmp(agreement_id,task_id,dest_ip,point_total,ctime,mtime)
                       select :aid,task_id,dest_ip,point_total,:ctime,:mtime
                         from(
                              select task_id,dest_ip,sum(point_total) point_total
                              from nb_custom_'||agree.tableSuff||'
                              where is_noise = 0 and dest_ip is not null
                                 and tm_base>=:st and tm_base <= :et
                                 and task_id in(select id from nb_m_task where type = 255 and status =1 and expire > sysdate -1 and agreement_id =:aid)
                              group by task_id,dest_ip
                              )
                         where point_total > '||min_points;
            execute immediate sqlStr using agree.id,ctime,mtime,startTime,endTime,agree.id;
            commit;
          end if;
          --Trace 表中能够统计出主机的任务为 路由任务
          select count(*)  into s from  user_tables t where t.table_name = 'NB_TRACE_'||agree.tableSuff;
          if s > 0 then
            sqlStr := 'insert into nb_m_task_dest_tmp(agreement_id,task_id,dest_ip,point_total,ctime,mtime)
                       select :aid,task_id,dest_ip,point_total,:ctime,:mtime
                         from(
                              select task_id,dest_ip,sum(point_total) point_total
                              from nb_trace_'||agree.tableSuff||'
                              where is_noise = 0 and dest_ip is not null
                                 and tm_base>=:st and tm_base <= :et
                                 and task_id in(select id from nb_m_task where type = 1 and task_option=''T'' and status =1 and expire > sysdate -1 and agreement_id =:aid)
                              group by task_id,dest_ip
                              )
                         where point_total > '||min_points;
            execute immediate sqlStr using agree.id,ctime,mtime,startTime,endTime,agree.id;
            commit;
          end if;
          --mob page 表中能够统计出主机的任务为 手机页面,手机事务
          select count(*)  into s from  user_tables t where t.table_name = 'NB_MOB_PAGE_'||agree.tableSuff;
          if s > 0 then
            sqlStr := 'insert into nb_m_task_dest_tmp(agreement_id,task_id,dest_ip,point_total,ctime,mtime)
                       select :aid,task_id,dest_ip,point_total,:ctime,:mtime
                         from(
                              select task_id,dest_ip,sum(point_total) point_total
                              from nb_mob_page_'||agree.tableSuff||'
                              where is_noise = 0 and dest_ip is not null
                                 and tm_base>=:st and tm_base <= :et
                                 and task_id in(select id from nb_m_task where (type = 102 or type=103) and task_option !=''P'' and status =1 and expire > sysdate -1 and agreement_id =:aid)
                              group by task_id,dest_ip
                              )
                         where point_total > '||min_points;
            execute immediate sqlStr using agree.id,ctime,mtime,startTime,endTime,agree.id;
            commit;
          end if;
          --mob strean 表中能够统计出主机的任务为 手机流媒体
          select count(*)  into s from  user_tables t where t.table_name = 'NB_MOB_STREAM_'||agree.tableSuff;
          if s > 0 then
            sqlStr := 'insert into nb_m_task_dest_tmp(agreement_id,task_id,dest_ip,point_total,ctime,mtime)
                       select :aid,task_id,dest_ip,point_total,:ctime,:mtime
                         from(
                              select task_id,dest_ip,sum(point_total) point_total
                              from nb_mob_stream_'||agree.tableSuff||'
                              where is_noise = 0 and dest_ip is not null
                                 and tm_base>=:st and tm_base <= :et
                                 and task_id in(select id from nb_m_task where type = 111 and status =1 and expire > sysdate-1 and agreement_id =:aid)
                              group by task_id,dest_ip
                              )
                         where point_total > '||min_points;
            execute immediate sqlStr using agree.id,ctime,mtime,startTime,endTime,agree.id;
            commit;
          end if;

        --如果创建序列失败，则显示出失败代码
        exception when  others then
            error_desc := 'Day Table1:'|| agree.tableSuff || ' Error Message:'||sqlerrm;
            DBMS_OUTPUT.PUT_LINE(error_desc);
            create_procedure_log('calc_cdn_host',error_desc,'error');
        end;
        end loop;
    else
      -- hour!=20时对仅对所有新增任务进行处理，为了确保数据足够多，对新建任务的条件为本天新建的任务
      --循环，查寻出所有的表
      for agree in(select id,table_str as tableSuff from nb_m_agreement where id in
        (select distinct agreement_id from nb_m_task where status = 1 and expire > sysdate -1 and mtime >= trunc(sysdate,'dd')))
        loop
          begin
           
         --page 表中能够统计出主机的任务为 事务 页面
         errorTable:='NB_PAGE_'||agree.tableSuff;
          select count(*)  into s from  user_tables t where t.table_name = 'NB_PAGE_'||agree.tableSuff;
          if s > 0 then
            sqlStr := 'insert into nb_m_task_dest_tmp(agreement_id,task_id,dest_ip,point_total,ctime,mtime)
                       select :aid,task_id,dest_ip,point_total,:ctime,:mtime
                         from(
                              select task_id,dest_ip,sum(point_total) point_total
                              from nb_page_'||agree.tableSuff||'
                              where is_noise = 0 and dest_ip is not null
                                 and tm_base>=:st and tm_base <= :et
                                 and task_id in(select id from nb_m_task where (type = 1 or type=2) and task_option !=''P'' and status =1 and expire > sysdate -1 and agreement_id =:aid and mtime >= trunc(sysdate,''dd''))
                              group by task_id,dest_ip
                              )
                         where point_total > '||min_points;

            execute immediate sqlStr using agree.id,ctime,mtime,startTime,endTime,agree.id;
            commit;
          end if;
          errorTable:='NB_PING_'||agree.tableSuff;
          --ping表中能够统计出主机的任务为 Ping监测
            select count(*) into s from  user_tables t where t.table_name = 'NB_PING_'||agree.tableSuff;
            if s > 0 then
              sqlStr := 'insert into nb_m_task_dest_tmp(agreement_id,task_id,dest_ip,point_total,ctime,mtime)
                         select :aid,task_id,dest_ip,point_total,:ctime,:mtime
                           from(
                                select task_id,dest_ip,sum(point_total) point_total
                                from nb_ping_'||agree.tableSuff||'
                                where is_noise = 0 and dest_ip is not null
                                   and tm_base>=:st and tm_base <= :et
                                   and task_id in(select id from nb_m_task where task_option=''P'' and status =1 and expire > sysdate -1 and agreement_id =:aid and mtime >= trunc(sysdate,''dd''))
                                group by task_id,dest_ip
                                )
                           where point_total > '||min_points;
              execute immediate sqlStr using agree.id,ctime,mtime,startTime,endTime,agree.id;
              commit;
            end if;
          --Stream 表中能够统计出主机的任务为 流媒体
          errorTable:='NB_STREAM_'||agree.tableSuff;
          select count(*)  into s from  user_tables t where t.table_name = 'NB_STREAM_'||agree.tableSuff;
          if s > 0 then
            sqlStr := 'insert into nb_m_task_dest_tmp(agreement_id,task_id,dest_ip,point_total,ctime,mtime)
                       select :aid,task_id,dest_ip,point_total,:ctime,:mtime
                         from(
                              select task_id,dest_ip,sum(point_total) point_total
                              from nb_stream_'||agree.tableSuff||'
                              where is_noise = 0 and dest_ip is not null
                                 and tm_base>=:st and tm_base <= :et
                                 and task_id in(select id from nb_m_task where type = 3 and status =1 and expire > sysdate -1 and agreement_id =:aid and mtime >= trunc(sysdate,''dd''))
                              group by task_id,dest_ip
                              )
                         where point_total > '||min_points;
            execute immediate sqlStr using agree.id,ctime,mtime,startTime,endTime,agree.id;
            commit;
          end if;
          --Custom 表中能够统计出主机的任务为 私有协议
          errorTable:='NB_CUSTOM_'||agree.tableSuff;
          select count(*)  into s from  user_tables t where t.table_name = 'NB_CUSTOM_'||agree.tableSuff;
          if s > 0 then
            sqlStr := 'insert into nb_m_task_dest_tmp(agreement_id,task_id,dest_ip,point_total,ctime,mtime)
                       select :aid,task_id,dest_ip,point_total,:ctime,:mtime
                         from(
                              select task_id,dest_ip,sum(point_total) point_total
                              from nb_custom_'||agree.tableSuff||'
                              where is_noise = 0 and dest_ip is not null
                                 and tm_base>=:st and tm_base <= :et
                                 and task_id in(select id from nb_m_task where type = 255 and status =1 and expire > sysdate -1 and agreement_id =:aid and mtime >= trunc(sysdate,''dd''))
                              group by task_id,dest_ip
                              )
                         where point_total > '||min_points;
            execute immediate sqlStr using agree.id,ctime,mtime,startTime,endTime,agree.id;
            commit;
          end if;
          --Trace 表中能够统计出主机的任务为 路由任务
          errorTable:='NB_TRACE_'||agree.tableSuff;
          select count(*)  into s from  user_tables t where t.table_name = 'NB_TRACE_'||agree.tableSuff;
          if s > 0 then
            sqlStr := 'insert into nb_m_task_dest_tmp(agreement_id,task_id,dest_ip,point_total,ctime,mtime)
                       select :aid,task_id,dest_ip,point_total,:ctime,:mtime
                         from(
                              select task_id,dest_ip,sum(point_total) point_total
                              from nb_trace_'||agree.tableSuff||'
                              where is_noise = 0 and dest_ip is not null
                                 and tm_base>=:st and tm_base <= :et
                                 and task_id in(select id from nb_m_task where type = 1 and task_option=''T'' and status =1 and expire > sysdate -1 and agreement_id =:aid and mtime >= trunc(sysdate,''dd''))
                              group by task_id,dest_ip
                              )
                         where point_total > '||min_points;
            execute immediate sqlStr using agree.id,ctime,mtime,startTime,endTime,agree.id;
            commit;
          end if;
          --mob page 表中能够统计出主机的任务为 手机页面,手机事务
          errorTable:='NB_MOB_PAGE_'||agree.tableSuff;
          select count(*)  into s from  user_tables t where t.table_name = 'NB_MOB_PAGE_'||agree.tableSuff;
          if s > 0 then
            sqlStr := 'insert into nb_m_task_dest_tmp(agreement_id,task_id,dest_ip,point_total,ctime,mtime)
                       select :aid,task_id,dest_ip,point_total,:ctime,:mtime
                         from(
                              select task_id,dest_ip,sum(point_total) point_total
                              from nb_mob_page_'||agree.tableSuff||'
                              where is_noise = 0 and dest_ip is not null
                                 and tm_base>=:st and tm_base <= :et
                                 and task_id in(select id from nb_m_task where (type = 102 or type=103) and task_option !=''P'' and status =1 and expire > sysdate -1 and agreement_id =:aid and mtime >= trunc(sysdate,''dd''))
                              group by task_id,dest_ip
                              )
                         where point_total > '||min_points;
            execute immediate sqlStr using agree.id,ctime,mtime,startTime,endTime,agree.id;
            commit;
          end if;
          
          --mob stream 表中能够统计出主机的任务为 真机流媒体
          errorTable:='NB_MOB_STREAM_'||agree.tableSuff;
          select count(*)  into s from  user_tables t where t.table_name = 'NB_MOB_STREAM_'||agree.tableSuff;
          if s > 0 then
            sqlStr := 'insert into nba_m_task_dest_tmp(agreement_id,task_id,dest_ip,point_total,ctime,mtime)
                       select :aid,task_id,dest_ip,point_total,:ctime,:mtime
                         from(
                              select task_id,dest_ip,sum(point_total) point_total
                              from nb_mob_stream_'||agree.tableSuff||'
                              where is_noise = 0 and dest_ip is not null
                                 and tm_base>=:st and tm_base <= :et
                                 and task_id in(select id from nb_m_task where type = 111 and status =1 and expire > sysdate -1 and agreement_id =:aid and mtime >= trunc(sysdate,''dd''))
                              group by task_id,dest_ip
                              )
                         where point_total > '||min_points;
            execute immediate sqlStr using agree.id,ctime,mtime,startTime,endTime,agree.id;
            commit;
          end if;

        --如果创建序列失败，则显示出失败代码
        exception when  others then
            error_desc := 'Hour Table2:'|| errorTable || ' Error Message:'||sqlerrm;
            create_procedure_log('calc_cdn_host',error_desc,'error');
        end;
        end loop;
    end if;
     if hour = hourDay then
        --将数据从临时表copy到正式表
        sqlStr:='merge into nb_m_task_dest t using
                  (select agreement_id,task_id,dest_ip,point_total,ctime,mtime from nb_m_task_dest_tmp) g
                  on(t.task_id = g.task_id and t.dest_ip = g.dest_ip)
                  when matched then update set t.mtime = g.ctime,t.point_total = t.point_total + g.point_total
                  when not matched then insert values(g.agreement_id,g.task_id,g.dest_ip,g.point_total,g.ctime,g.mtime, ''oracle'')';
        execute immediate sqlStr;
        commit;
        --将过期的数据删除,只是每天更新时才用删除
        sqlStr:='delete from nb_m_task_dest where mtime < :dtime';
        execute immediate sqlStr using sysdate - 50;
        commit;
    else
        --每小时算时，不做点数累计
        sqlStr:='merge into nb_m_task_dest t using
                  (select agreement_id,task_id,dest_ip,point_total,ctime,mtime from nb_m_task_dest_tmp) g
                  on(t.task_id = g.task_id and t.dest_ip = g.dest_ip)
                  when matched then update set t.mtime = g.ctime
                  when not matched then insert values(g.agreement_id,g.task_id,g.dest_ip,g.point_total,g.ctime,g.mtime, ''oracle'')';
        execute immediate sqlStr;
        commit;
    end if;
    create_procedure_log('calc_cdn_host','end','run');
end calc_cdn_host;
/

