create PROCEDURE          "CREATE_LT_TABLE_ALL" authid current_user
is
  sqlStr  varchar2(4000);  
  v_name varchar2(400);
  v_s number;
  v_error_desc varchar2(400);
  CURSOR c_emp IS SELECT substr(t.object_name,8) FROM all_objects t where t.object_name like 'NB_TRAN_%';
begin
OPEN c_emp;
LOOP
    FETCH c_emp INTO v_name;
    EXIT WHEN c_emp%NOTFOUND;
    --判断是否已经建立该表
    select count(*)  INTO v_s FROM all_objects t where t.object_name = 'LT_TRAN'||v_name;
    if v_s = 1 then 
      begin
         DBMS_OUTPUT.PUT_LINE(' Table LT_TRAN'|| v_name||' already exist ');
      end;
    else 
      begin
         DBMS_OUTPUT.PUT_LINE(' start create seq  SEQ_LT_TRAN_ID'||v_name);
         --创建序列
        sqlStr:='create sequence SEQ_LT_TRAN_ID'||v_name||'
			    minvalue 1
		    	maxvalue 9999999999999999999999999
			    start with 1
    			increment by 1
		    	cache 20';  
        execute   immediate   sqlStr;	
        
       
       
        sqlStr:='create table LT_TRAN'||v_name||'
		    (
    		  ID             NUMBER not null,
		      TASK_ID        NUMBER,
    		  CITY_ID        NUMBER,
		      ISP_ID         NUMBER,
    		  NET_SPEED_ID   NUMBER,
		      TM_DAY         DATE,
    		  TM_DAY2        DATE,
    		  TM_DAY4        DATE,
    		  TM_DAY8        DATE,
    		  TM_DAY16       DATE,
		      ERROR_CODE     NUMBER,
    		  PING_ERROR	   NUMBER,
          POINT_TOTAL    NUMBER,
    		  TS_TOTAL       NUMBER,
		      TS_PING_AVG    NUMBER		  
    		)';  
        execute   immediate   sqlStr;
        --主键  
        sqlStr:='alter table LT_TRAN'||v_name||'
		      add constraint PK_LT_TRAN'||v_name||' primary key (ID)
    		  using index ';
        execute   immediate   sqlStr;
        --索引
	      sqlStr:='create index IN_LT_TRAN_PERF'||v_name||' on LT_TRAN'||v_name||' (TM_DAY, CITY_ID, TASK_ID, ISP_ID) tableSpace NETBEN_IDX';
    	  execute   immediate   sqlStr;
        --如果创建序列失败，则显示出失败的序列
         exception when  others then
             v_error_desc := ' create seq exception  error code: '|| sqlcode || ' SEQ:SEQ_LT_TRAN_ID'||v_name;
             DBMS_OUTPUT.PUT_LINE(v_error_desc);
             create_procedure_log('create_lt_table_all',v_error_desc,sqlcode);
        
      end;
    end if;
    
END LOOP;

CLOSE c_emp;
 
end create_lt_table_all;


/

