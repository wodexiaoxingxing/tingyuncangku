create FUNCTION          "CALC_TRADE_GRADE_A" (
t0 in number,t1 in number,
u0 in number,u1 in number,
a0 in number,
s0 in number,s1 in number,
rd0 in number,rd1 in number
) return number is
--t 总下载 u 首屏 a 可用性 s 方差
--0 计算值 1 最差值
--权重 t:0.3 u:0.4 a:0.2 s:0.1
  Result number;
  tGrade number;
  uGrade number;
  aGrade number;
  sGrade number;
  rdGrade number;
begin
  tGrade:=calc_trade_grade_s(t0,t1);
  uGrade:=calc_trade_grade_s(u0,u1);
  aGrade:=(a0-80)/20*40+60;
  sGrade:=calc_trade_grade_s(s0,s1);
  rdGrade:=round(100*sin(rd0*acos(-1)/(rd1*2)),2);
  Result:=round(tGrade*0.1+uGrade*0.3+sGrade*0.1+aGrade*0.2+rdGrade*0.3,2);
  return(Result);
end calc_trade_grade_a;


/

