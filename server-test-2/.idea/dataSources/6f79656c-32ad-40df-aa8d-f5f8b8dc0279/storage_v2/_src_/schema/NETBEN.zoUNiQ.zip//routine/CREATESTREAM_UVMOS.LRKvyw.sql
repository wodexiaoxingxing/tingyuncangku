create procedure createSTREAM_UVMOS(tableStr IN varchar2,res OUT number) authid current_user is
  sqlStr varchar2(4000);
  errorDesc varchar2(4000);
begin
 
create_procedure_log('createSTREAM_UVMOS', 'create table:NB_STREAM_UVMOS_' || tableStr, 'run');

  --创建NB_STREAM_UVMOS表
  sqlStr := 'create table NB_STREAM_UVMOS_' || tableStr || '
  (
      STREAM_ID                NUMBER not null,
      UVMOS                    VARCHAR2(4000),  -- U-vMOS即时得分
      VIDEO_QUALITY            VARCHAR2(4000),  -- 视频质量即时得分
      VIEWING_EXPERIENCE       VARCHAR2(4000),  -- 观看体验即时得分
      INTERACTIVE_EXPERIENCE   VARCHAR2(4000)   -- 交互体验即时得分 
  ) pctfree 0
  tablespace NETBEN';
  execute immediate sqlStr;

  sqlStr := 'create index PK_NB_STREAM_UVMOS_' || tableStr || ' on NB_STREAM_UVMOS_' ||
            tableStr || ' (STREAM_ID) tablespace NETBEN_IDX_NEW';
  execute immediate sqlStr;
  res:=0;
  
exception
  when others then
    errorDesc := 'Error :' || sqlerrm || '  tableStr:' || tableStr;
    --DBMS_OUTPUT.PUT_LINE(v_error_desc);
    create_procedure_log('createSTREAM_UVMOS', errorDesc, 'error');
    res:=1;
    
end createSTREAM_UVMOS;


/

