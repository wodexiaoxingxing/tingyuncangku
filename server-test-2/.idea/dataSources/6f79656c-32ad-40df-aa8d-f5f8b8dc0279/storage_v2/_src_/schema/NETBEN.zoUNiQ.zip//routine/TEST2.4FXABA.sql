create procedure test2(s number) is
ss number :=s;
sqlStr varchar2(1000);
begin
  for s in 1..ss loop
    create_procedure_log('test2',ss,'run');
    sqlStr:='drop table nb_page_aaa';
    execute immediate sqlStr;
    end loop;
end test2;


/

