create procedure createMobilePageTable2(
       tableStr IN varchar2
) authid current_user
is
sqlStr  varchar2(4000);
begin
    --创建Tran sequence
    sqlStr:='create sequence SEQ_NB_MOB_TRAN_ID_'||tableStr||'
      minvalue 1
      maxvalue 9999999999999999999999999
      start with 1
      increment by 1
      cache 500';
    -- execute   immediate   sqlStr;

        --创建TRAN
    sqlStr:='create table NB_MOB_TRAN_'||tableStr||'
    (
      ID              NUMBER not null,
      TASK_ID         NUMBER,
      CITY_ID         NUMBER,
      ISP_ID          NUMBER,
      NET_SPEED_ID    NUMBER,
      TM_BASE         DATE,
      PROBE_IP        NUMBER,
      ERROR_CODE      NUMBER,
      CONT_ERR_TOTAL  NUMBER,
      POINT_TOTAL     NUMBER default 1,
      ERROR_PAGE_SEQ  NUMBER,
      PAGE_TOTAL      NUMBER,
      BYTE_TOTAL      NUMBER,
      DNS_SERVER   VARCHAR2(128),
      DNS_SERVER_IP   NUMBER,
      DEST_IP         VARCHAR2(39),
      TS_TOTAL        NUMBER,
      TS_NETWORK      NUMBER,
      MEMBER_ID     INTEGER,
      OS_VER_ID   INTEGER,
      BS_ID      INTEGER,
      BS_VER_ID    INTEGER,
      HW_ID    INTEGER,
      MOBILE_SIGNAL  INTEGER,
      SCREEN_WIDTH  INTEGER,
      SCREEN_HEIGHT  INTEGER,
      longitude  NUMBER,
      latitude  NUMBER,
      IS_NOISE      INTEGER
    ) pctfree 0';
    execute   immediate   sqlStr;
    --主键
    sqlStr:='alter table NB_MOB_TRAN_'||tableStr||'
      add constraint PK_NB_MOB_TRAN_'||tableStr||' primary key (ID)
      using index ';
    execute   immediate   sqlStr;
    --索引
  sqlStr:='create index IN_MOB_TRAN_PERF_'||tableStr||' on NB_MOB_TRAN_'||tableStr||' (TASK_ID,TM_BASE, CITY_ID,  ISP_ID) tableSpace NETBEN_IND';
  execute   immediate   sqlStr;

    --创建Page sequence
    sqlStr:='create sequence SEQ_NB_MOB_PAGE_ID_'||tableStr||'
      minvalue 1
      maxvalue 9999999999999999999999999
      start with 1
      increment by 1
      cache 500';
    execute   immediate   sqlStr;


        --创建page
    sqlStr:='create table NB_MOB_PAGE_'||tableStr||'
    (
      ID              NUMBER not null,
      TRAN_ID         NUMBER,
      TASK_ID         NUMBER,
      CITY_ID         NUMBER,
      ISP_ID          NUMBER,
      NET_SPEED_ID    NUMBER,
      TM_BASE         DATE,
      PROBE_IP        NUMBER,
      PAGE_SEQ        NUMBER,
      ERROR_CODE      NUMBER,
      ERROR_PATH      VARCHAR2(256),
      CONT_ERR_TOTAL  NUMBER,
      CONT_ELE_TOTAL  NUMBER,
      REDIRECT_TOTAL  NUMBER,
      POINT_TOTAL     NUMBER default 1,
      BYTE_TOTAL      NUMBER,
      RATE_DOWNLOAD    NUMBER,
      BYTE_PAGE_BASE  NUMBER,
      RATE_DOWNLOAD_PAGE_BASE  NUMBER,
      DNS_SERVER   VARCHAR2(128),
      DNS_SERVER_IP   NUMBER,
      DEST_IP         VARCHAR2(39),
      PING_RESULT     VARCHAR2(512),
      TRACERT_RESULT  VARCHAR2(512),
      NSLOOKUP_RESULT VARCHAR2(512),
      SCRIPT_ERROR_RESULT VARCHAR2(2000),
      HTTP_SERVER     VARCHAR2(256),
      HTTP_VIA        VARCHAR2(256),
      TS_TOTAL        NUMBER,
      TS_PAGE_BASE    NUMBER,
      TS_DNS          NUMBER,
      TS_CONNECT      NUMBER,
      TS_REDIRECT     NUMBER,
      TS_REQUEST      NUMBER,
      TS_FIRST_PACKET NUMBER,
      TS_CLIENT       NUMBER,
      TS_CONTENTS     NUMBER,
      TS_EXTRA_DATA   NUMBER,
      TS_OPEN_PAGE    NUMBER,
      TS_NETWORK      NUMBER,
      NUM_HOST NUMBER,
      TS_DNS_TOTAL NUMBER,
      NUM_CONNECT NUMBER,
      TS_CONNECT_TOTAL NUMBER,
      NUM_DOM NUMBER,
      NUM_IFRAME NUMBER,
      NUM_NO_COMPRESS_ELEM NUMBER,
      NUM_NO_EXPIRE_ELEM NUMBER,
      NUM_NO_ETAG_ELEM NUMBER,
      MEMBER_ID     INTEGER,
      OS_VER_ID   INTEGER,
      BS_ID      INTEGER,
      BS_VER_ID    INTEGER,
      HW_ID    INTEGER,
      LOG_MSG_RESULT VARCHAR2(512),
        NUM_ELEM_LAZY  INTEGER,
      TS_FIRST_PAINT  INTEGER,
      TS_FULL_SCREEN  INTEGER,
      TS_UNLOAD_START  INTEGER,
      TS_UNLOAD_END  INTEGER,
      TS_DOM_LOAD  INTEGER,
      TS_DOM_INTERACT  INTEGER,
      TS_DOM_CONT_LOAD_START  INTEGER,
      TS_DOM_CONT_LOAD_END  INTEGER,
      TS_DOM_COMPLETE  INTEGER,
      TS_LOAD_EVT_START  INTEGER,
      TS_LOAD_EVT_END    INTEGER,
      src_path      VARCHAR2(512),      -- 页面源码路径
      bitrate_trend_result    VARCHAR2(512),      -- 流量变化趋势
      ts_dns_proj      INTEGER,      -- DNS投影时间
      ts_connect_proj      INTEGER,      -- 建连投影时间
      ts_first_packet_proj    INTEGER,      -- 首包投影时间
      MOBILE_SIGNAL  INTEGER,
      SCREEN_WIDTH  INTEGER,
      SCREEN_HEIGHT  INTEGER,
      longitude  NUMBER,
      latitude  NUMBER,
      IS_NOISE      INTEGER
    ) pctfree 0';
    execute   immediate   sqlStr;
    --主键
    sqlStr:='alter table NB_MOB_PAGE_'||tableStr||'
      add constraint PK_NB_MOB_PAGE_'||tableStr||' primary key (ID)
      using index ';
    execute   immediate   sqlStr;
    --索引
   sqlStr:='create index IN_MOB_PAGE_TRANID_'||tableStr||' on NB_MOB_PAGE_'||tableStr||' (TRAN_ID) tableSpace NETBEN_IND';
   execute   immediate   sqlStr;
  sqlStr:='create index IN_MOB_PAGE_ERROR_'||tableStr||' on NB_MOB_PAGE_'||tableStr||' (TASK_ID,TM_BASE, ERROR_CODE, CITY_ID) tableSpace NETBEN_IND';
  execute   immediate   sqlStr;
  sqlStr:='create index IN_MOB_PAGE_PERF_'||tableStr||' on NB_MOB_PAGE_'||tableStr||' (TASK_ID,TM_BASE, CITY_ID,  ISP_ID) tableSpace NETBEN_IND';
  execute   immediate   sqlStr;

    --Tran log
    sqlStr:='create materialized view log on NB_MOB_TRAN_'||tableStr||' with rowid,
      sequence (task_id,
          city_id,
          isp_id,
          net_speed_id,
          error_code,
          is_noise,
          tm_base,
          point_total,
          ts_total,
          os_ver_id,
          bs_id,
          bs_ver_id,
          hw_id) including new values';
    execute   immediate   sqlStr;

    --Tran物化视图 '' => '||chr(39)||'
    sqlStr:='create materialized view MV_MOB_TRAN_'||tableStr||'
    refresh fast
    start with sysdate next sysdate + 4/24
    as
      (select task_id,
        city_id,
        isp_id,
        net_speed_id,
        error_code,
          is_noise,
          (tm_base - mod(to_number(to_char(tm_base, '||chr(39)||'hh24'||chr(39)||')) + 8, 8) / 24) as tm_hour8,
          os_ver_id,
          bs_id,
          bs_ver_id,
      hw_id,
          count(*) as c1,
          count(point_total) as c2,
          count(ts_total) as c3,
        sum(point_total) as point_total,
        avg(ts_total) as ts_tota
    from NB_MOB_TRAN_'||tableStr||'
    group by task_id,
      city_id,
      isp_id,
      net_speed_id,
      error_code,
      is_noise,
      (tm_base - mod(to_number(to_char(tm_base, '||chr(39)||'hh24'||chr(39)||')) + 8, 8) / 24),
            os_ver_id,
            bs_id,
            bs_ver_id,
      hw_id)';

    execute   immediate   sqlStr;
    --索引
  sqlStr:='create index IN_MV_MOB_TRAN_PERF_'||tableStr||' on MV_MOB_TRAN_'||tableStr||' (TASK_ID,TM_HOUR8, CITY_ID, ISP_ID) tableSpace NETBEN_IND';
    execute   immediate   sqlStr;

  --Page log
  sqlStr:='create materialized view log on NB_MOB_PAGE_'||tableStr||' with rowid,
          sequence (task_id,page_seq,
              city_id,
              isp_id,
              net_speed_id,
              error_code,
              is_noise,
              dest_ip,
              tm_base,
              cont_err_total,
              cont_ele_total,
              point_total,
              byte_total,
              rate_download,
              ts_total,ts_page_base,
              ts_dns,ts_connect,
              ts_redirect,
              ts_request,ts_first_packet,
              ts_client,ts_contents,
              ts_network,
              byte_page_base,
              rate_download_page_base,
              num_host,
              ts_dns_total,
              num_connect,
              ts_connect_total,
              num_dom,
              OS_VER_ID,
              BS_ID,
              BS_VER_ID,
        HW_ID,
              NUM_ELEM_LAZY,
        TS_FIRST_PAINT,
    --    TS_FULL_SCREEN,
        TS_UNLOAD_END,
        TS_DOM_LOAD,
        TS_DOM_INTERACT,
        TS_DOM_CONT_LOAD_END,
        TS_DOM_COMPLETE,
        TS_LOAD_EVT_END,
        ts_dns_proj,ts_connect_proj,ts_first_packet_proj
              ) including new values';
  execute immediate sqlStr;
    --Page物化视图  '' => '||chr(39)||'
  sqlStr:='create materialized view MV_MOB_PAGE_'||tableStr||'
    refresh fast
    start with sysdate next sysdate + 4/24
    as
    (select task_id,
        page_seq,
        city_id,
        isp_id,
        net_speed_id,
        error_code,
        is_noise,
        dest_ip,
        (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8) / 24) as tm_hour8,
        os_ver_id,
        bs_id,
        bs_ver_id,
  hw_id,
        count(*) as c1,
        count(cont_err_total) as c2,
        count(cont_ele_total) as c3,
        count(point_total) as c4,
        count(byte_total) as c5,
        count(rate_download) as c6,
        count(ts_total) as c7,
        count(ts_page_base) as c8,
        count(ts_dns) as c9,
        count(ts_connect) as c10,
        count(ts_redirect) as c11,
        count(ts_request) as c12,
        count(ts_first_packet) as c13,
        count(ts_client) as c14,
        count(ts_contents) as c15,
        count(ts_network) as c16,
        count(byte_page_base) as c17,
        count(rate_download_page_base) as c18,
        count(num_host) as c19,
        count(ts_dns_total) as c20,
        count(num_connect) as c21,
        count(ts_connect_total) as c22,
        count(num_dom) as c23,
        count(NUM_ELEM_LAZY) as c24,
    count(TS_FIRST_PAINT) as c25,
  --  count(TS_FULL_SCREEN) as c26,
    count(TS_UNLOAD_END) as c28,
    count(TS_DOM_LOAD) as c29,
    count(TS_DOM_INTERACT) as c30,
    count(TS_DOM_CONT_LOAD_END) as c32,
    count(TS_DOM_COMPLETE) as c33,
    count(TS_LOAD_EVT_END) as c35,
    count(ts_dns_proj) as c36,
    count(ts_connect_proj) as c37,
    count(ts_first_packet_proj) as c38,
              avg(cont_err_total) as cont_err_total,
              avg(cont_ele_total) as cont_ele_total,
              sum(point_total) as point_total,
              avg(byte_total) as byte_total,
              avg(rate_download) as rate_download,
              avg(ts_total) as ts_total,
              avg(ts_page_base) as ts_page_base,
              avg(ts_dns) as ts_dns,
              avg(ts_connect) as ts_connect,
              avg(ts_redirect) as ts_redirect,
              avg(ts_request) as ts_request,
              avg(ts_first_packet) as ts_first_packet,
              avg(ts_client) as ts_client,
              avg(ts_contents) as ts_contents,
              avg(ts_network) as ts_network,
              avg(byte_page_base) as byte_page_base,
              avg(rate_download_page_base) as rate_download_page_base,
              avg(num_host) as num_host,
              avg(ts_dns_total) as ts_dns_total,
              avg(num_connect) as num_connect,
              avg(ts_connect_total) as ts_connect_total,
              avg(num_dom) as num_dom,
                avg(NUM_ELEM_LAZY) as NUM_ELEM_LAZY,
        avg(TS_FIRST_PAINT) as TS_FIRST_PAINT,
    --    avg(TS_FULL_SCREEN) as TS_FULL_SCREEN,
        avg(TS_UNLOAD_END) as TS_UNLOAD_END,
        avg(TS_DOM_LOAD) as TS_DOM_LOAD,
        avg(TS_DOM_INTERACT) as TS_DOM_INTERACT,
        avg(TS_DOM_CONT_LOAD_END) as TS_DOM_CONT_LOAD_END,
        avg(TS_DOM_COMPLETE) as TS_DOM_COMPLETE,
        avg(TS_LOAD_EVT_END) as TS_LOAD_EVT_END,
        avg(ts_dns_proj) as ts_dns_proj,
        avg(ts_connect_proj) as ts_connect_proj,
        avg(ts_first_packet_proj) as ts_first_packet_proj
    from NB_MOB_PAGE_'||tableStr||'
    group by task_id,
           page_seq,
         city_id,
         isp_id,
         net_speed_id,
       error_code,
           is_noise,
           dest_ip,
           (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8) / 24),
        os_ver_id,
        bs_id,
        bs_ver_id,
  hw_id)';

    execute   immediate   sqlStr;

  --索引
  sqlStr:='create index IN_MV_MOB_PAGE_ERROR_'||tableStr||' on MV_MOB_PAGE_'||tableStr||' (TASK_ID,TM_HOUR8, ERROR_CODE, CITY_ID) tableSpace NETBEN_IND';
    execute   immediate   sqlStr;
    --索引
  sqlStr:='create index IN_MV_MOB_PAGE_PERF_'||tableStr||' on MV_MOB_PAGE_'||tableStr||' (TASK_ID,TM_HOUR8, CITY_ID,ISP_ID) tableSpace NETBEN_IND';
    execute   immediate   sqlStr;
END createMobilePageTable2;


/

