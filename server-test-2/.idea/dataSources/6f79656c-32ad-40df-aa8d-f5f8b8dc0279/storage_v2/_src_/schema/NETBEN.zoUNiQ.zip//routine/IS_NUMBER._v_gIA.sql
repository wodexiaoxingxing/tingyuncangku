create function is_number(num varchar2) return integer is
  val   number;
  inFt  varchar2(32);
begin
  val := to_number(num);
  return 1;
exception
  when others then
    return 0;
end is_number;


/

