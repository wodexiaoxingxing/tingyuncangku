create PROCEDURE network_check_job AS
  -- 查询状态为失败, 或者上次执行距当前时间超过DURATION * 1.5的记录
  CURSOR err_jobs IS
    SELECT * FROM NB_M_SCHEDULER_MONITOR WHERE (BEGIN_TIME < SYSDATE - (DURATION * 1.5 / 3600 / 24) OR STATUS = 2);
  err_job err_jobs%ROWTYPE;
  mail_content varchar(1024);
BEGIN
  mail_content := '';
  FOR err_job IN err_jobs LOOP
    mail_content := mail_content || '应用【' || err_job.application || '】在机器【' || err_job.host || '】执行job【' || err_job.service_name || '】';
    IF err_job.status=2 THEN
      mail_content := mail_content || '失败';
    ELSE
      mail_content := mail_content || ', 时间为' || to_char(err_job.begin_time, 'mm-dd hh24:mi') || ', 超过执行周期:'|| err_job.duration || 's';
    END IF;
    mail_content := mail_content || '\n\r';
  END LOOP;
  DBMS_OUTPUT.PUT_LINE(mail_content);
  network_sendmail('gaowei@tingyun.com', 'Network定时JOB执行失败', mail_content);
END network_check_job;
/

