create PROCEDURE alter_stream_add_table
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(400);
  v_s number;
  tabName varchar2(100);
begin
  dbms_output.enable(1000000);      
  for tableName in(select substr(t.table_name,11) as name from user_tables t where regexp_like( t.table_name,'^NB_STREAM_[0-9]')) loop
  begin
    
      --删除指定的字段
      /*select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TS_CONNECT_STREAM';
      if v_s = 1 then
        sqlStr := 'alter table '||tableName.Name||' DROP column TS_CONNECT_STREAM';
        execute   immediate   sqlStr ;
      end if;
      */
      tabName := 'NB_STREAM_RATE_'|| tableName.Name;
      
      select count(*)  INTO v_s FROM user_tables t where t.table_name = tabName;
      if v_s < 1 then
        
        -- 创建NB_STREAM_RATE表
          sqlStr := 'create table '||tabName||'
          (
            STREAM_ID                     NUMBER not null,
            BIT_RATE_FLOW_STR             VARCHAR2(4000), -- 比特率
            FRAME_LOSS_RATE_FLOW_STR      VARCHAR2(4000)  -- 丢帧率
          ) ';
          execute immediate sqlStr;

          sqlStr:='create index IDX_STREAM_RATE_'||tableName.Name||' on '|| tabName ||' (STREAM_ID)
                   tablespace NETBEN_IDX_NEW';
          execute immediate sqlStr;
      end if;
      
     exception when  others then
        --v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlStr);
        --create_procedure_log('alter_stream_add_table',v_error_desc,sqlcode);
  end;
  end loop;
end alter_stream_add_table;


/

