create view NB_V_PROBE_REQ_IDC_CUSTOM as
select  city.name AS CITY, isp.name AS ISP, s.location_id AS CITY_ID, s.isp_id AS ISP_ID, sum(86400/t.interval*s.sla_probe)/24/30 AS PROBE_REQ
from nb_m_task t, nb_m_grp_subgrp s, nb_m_location city, nb_m_option_ext isp
where  t.probgrp_id=s.grp_id and s.location_id=city.id and s.isp_id=isp.id
and s.conn_id<>8
and t.status=1 and t.expire>sysdate
and t.interval>0
group by city.name, s.location_id, s.isp_id, isp.name
order by PROBE_REQ desc-- s.location_id, s.isp_id


/

