create procedure calc_cctv_task_3227137
sqlStr varchar2(4000);
begin
    sqlStr:='update nb_stream_1046209 set ts_user=60000,error_code=500404 where task_id =3227137 and error_code =600404';
  execute immediate sqlStr;
  commit;
end calc_cctv_task_3227137;
/

