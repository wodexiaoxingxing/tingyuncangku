create procedure NB_P_NODE_SCORE_NEW is
  currDate date := sysdate;
  sqlStr   varchar2(4000);
begin
  --此程序一天只能执行一次
  create_procedure_log('nb_p_node_score_new','begin','run');
  --首先删除可能重复的数据
  /*sqlStr := 'delete from nb_m_score_balance where cdate = :cdate and (reason = ''DP'' or reason =''SP'')';
  execute immediate sqlStr  using trunc(currDate - 1);
  commit;
  */
  --开始生成数据
  -- 首先生成临时数据
  sqlStr:='truncate table nb_m_score_balance_max';
  execute immediate sqlStr;
  sqlStr:='insert into nb_m_score_balance_max
              select * from nb_v_score_balance_max 
           ';
  execute immediate sqlStr;
  -- 此处删除是为了减少数据量，前面在插入因视图原因无法优化         
  /*sqlStr:='delete from nb_m_score_balance_max t
            where not exists (select 1
              from (select member_id
                      from nb_mbr_score
                     where cdate >= :cd1
                       and cdate < :cd2
                       and net_id = 0
                     group by member_id) s
             where t.member_id = s.member_id)
   ';         
  execute immediate sqlStr using trunc(currDate - 1), trunc(currDate);           
  create_procedure_log('nb_p_node_score_new','生成1临时数据完成','run');   */    

  sqlStr := '
      insert into nb_m_score_balance(id,member_id,cdate,score,score_balance,data_points,data_points_total,reason)
        select score_bal_id_seq.Nextval,member_id,dd,score,score_balance,dp,dp_total,''DP''
            from 
              (select member_id, dd, score, score + score_bal score_balance, dp, dp + dp_to dp_total
                from (select t.member_id,
                             trunc(t.cdate) dd,
                             sum(t.score) score,
                             sum(t.data_points) dp,
                             case when t1.score_balance is null then 0 else t1.score_balance end score_bal,
                             case when t1.data_points_total is null then 0 else t1.data_points_total end dp_to
                        from (select * from nb_mbr_score 
                               where cdate >= :cd and cdate < :ld
                                    and net_id = 0
                                    and member_id not in(select id from nb_m_member where account_id >0)
                                    and member_id not in
                                     (select member_id from nb_m_score_balance where cdate = :cd1 and reason=''DP'')) t, 
                        nb_m_score_balance_max t1
                       where t.member_id = t1.member_id(+)
                       group by t.member_id,
                                trunc(t.cdate),
                                t1.score_balance,
                                t1.data_points_total)
               )      
          ';
    execute immediate sqlStr  using trunc(currDate - 1), trunc(currDate),trunc(currDate - 1);
    commit;
    create_procedure_log('nb_p_node_score_new','生成积分数据完成','run');
    --生成推荐数据
    -- 再次生成临时数据
  sqlStr:='truncate table nb_m_score_balance_max';
  execute immediate sqlStr;
  sqlStr:='insert into nb_m_score_balance_max
              select * from nb_v_score_balance_max 
           ';
  execute immediate sqlStr;
  -- 此处删除是为了减少数据量，前面在插入因视图原因无法优化         
 /* sqlStr:='delete from nb_m_score_balance_max t
            where not exists (select 1
              from (select m.recomm_id
                       from (select member_id, sum(score)
                          from nb_mbr_score
                         where cdate >= :cd1
                           and cdate < :cd2
                           and net_id = 0
                           and score > 0
                         group by member_id) s,
                       (select id, recomm_id from nb_m_member where recomm_id > 0 and recomm_id in(select id from nb_m_member where account_id < 1 or account_id is null)) m
                 where s.member_id = m.id
                ) r
             where t.member_id = r.recomm_id)
   ';         
  execute immediate sqlStr using trunc(currDate - 1), trunc(currDate); 
  
  create_procedure_log('nb_p_node_score_new','生成2临时数据完成','run');  */       
    sqlStr := '
      insert into nb_m_score_balance(id,member_id,cdate,score,score_balance,data_points,data_points_total,reason)
      select score_bal_id_seq.Nextval,ma.member_id,tmp.dd,tmp.score,tmp.score + ma.score_balance,
             0,ma.data_points_total,''SP''
      from (select round(sum(s.score) * 0.1) score,
                 m.recomm_id,
                 trunc(s.cdate) dd
            from nb_mbr_score s,
                 (select id, recomm_id from nb_m_member where recomm_id > 0 and recomm_id not in(select id from nb_m_member where account_id >0)) m
           where s.cdate >= :cd
             and s.cdate < :ld
             and s.net_id = 0
             and s.member_id = m.id
             and s.score > 0
             and m.recomm_id not in(select member_id from nb_m_score_balance where cdate = :cd1 and reason=''SP'')
           group by m.recomm_id, trunc(s.cdate)) tmp,
          nb_m_score_balance_max ma
       where tmp.score > 0
         and tmp.recomm_id = ma.member_id';
  execute immediate sqlStr  using trunc(currDate - 1), trunc(currDate),trunc(currDate - 1);
  commit;
  
  create_procedure_log('nb_p_node_score_new','end','run');
  exception when  others then
    create_procedure_log('nb_p_node_score_new',sqlerrm,'error');
end NB_P_NODE_SCORE_NEW;


/

