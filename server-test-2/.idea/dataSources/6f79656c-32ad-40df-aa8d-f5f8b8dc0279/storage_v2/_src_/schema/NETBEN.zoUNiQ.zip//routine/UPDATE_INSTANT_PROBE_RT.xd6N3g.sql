create procedure UPDATE_INSTANT_PROBE_RT is
sqlStr varchar2(4000);
begin
  
  create_procedure_log('update_instant_probe_rt','begin','run');
  sqlStr:='truncate table nb_m_instant_probe_rt';
  execute immediate sqlStr;
insert into nb_m_instant_probe_rt
(
  select mobiType,
         mobiOs,
         mobiHw,
         connId,
         ispId,
         cityId,
         supWap,
         supMobi,
         supType,
         ipv6
    from (select p.MOBILE_NODE mobiType,
                 0 as mobiOs,
                 0 as mobiHw,
                 decode(p.SPEED_ID, 5, 9, 6, 9, 7, 9, p.speed_id) connId,
                 p.ISP_ID ispId,
                 p.city_id cityId,
                 decode(mobile_node, 1, 1, 0) supWap,
                 decode(mobile_node, 11, 1, 12, 1, 0) supMobi,
                 decode(mobile_node, 1, 11, 11, 6, 12, 6, 2, 5, 0) supType,
                 max(p.ipver) as ipv6,
                 count(*) probNum
            from nb_v_proberuntime p
           where p.TEMP_DISABLED = 0
             and p.ACL_DISABLED = 0
             and p.os is not null
             and p.bs is not null
             and p.city_id >0
             and p.isp_id >0 
             and p.speed_id >0
           group by p.MOBILE_NODE,
                    decode(regexp_instr(p.OS, '^[[:digit:]]+$'), 1, p.OS, 0),
                    decode(regexp_instr(p.bS, '^[[:digit:]]+$'), 1, p.BS, 0),
                    decode(p.SPEED_ID, 5, 9, 6, 9, 7, 9, p.speed_id),
                    p.ISP_ID,
                    p.city_id,
                    decode(mobile_node, 1, 1, 0),
                    decode(mobile_node, 11, 1, 12, 1, 0),
                    decode(mobile_node, 1, 11, 11, 6, 12, 6, 2, 5, 0)
          having count(*) >= 1)
)
union all
(
    select mobile_type,0,0,speed_id,isp_id,city_id,0,1,6,ipv6 from(
         select mobile_type,speed_id,isp_id,city_id,max(ipv6) as ipv6
               from (
                     select distinct pm.mobile_type as mobile_type, 
                                pm.speed_id as speed_id,
                                pm.isp_id as isp_id,
                                pm.city_id as city_id,
                                pm.ipv6 as ipv6
                      from nb_m_proberuntime_log_mobile pm,nb_m_location l
                       where pm.time_stamp > sysdate - 1 / 48
                             and pm.time_stamp <
                                 (select max(time_stamp) from nb_m_proberuntime_log_mobile)
                             and pm.member_type != 4 and pm.city_id = l.id and l.location_level=2
                     )
                group by mobile_type,speed_id,isp_id,city_id
       )
);
commit;
-- 删除城市ID不在我们字典表的记录
delete from nb_m_instant_probe_rt where city_id not in(select id from nb_m_location);
commit;
create_procedure_log('update_instant_probe_rt','end','run');
exception when  others then
    create_procedure_log('update_instant_probe_rt',sqlerrm,'error');

end UPDATE_INSTANT_PROBE_RT;
/

