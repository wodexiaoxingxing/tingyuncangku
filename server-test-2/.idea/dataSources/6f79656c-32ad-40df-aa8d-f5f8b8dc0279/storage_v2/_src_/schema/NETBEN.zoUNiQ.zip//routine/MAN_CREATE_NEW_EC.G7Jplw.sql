create PROCEDURE          "MAN_CREATE_NEW_EC" 
is
  createDate date := sysdate;
  orderNum   number;
  rangeDate  varchar2(128);
  partname1  varchar2(128);
  ee_partname1  varchar2(128);
  rangedate1 varchar2(128);
  partname2  varchar2(128);
  ee_partname2  varchar2(128);
  rangedate2 varchar2(128);
  partname3  varchar2(128);
  ee_partname3  varchar2(128);
  rangedate3 varchar2(128);
  --new
  sqlStr  varchar2(4000);
  v_error_desc varchar2(4000);
  t number;
   tableStr varchar2(50);
   cursor cur_tab is SELECT substr(table_name,7)  from user_tables where table_name like 'NB_EC_%';


   begin
OPEN cur_tab;
LOOP
  begin
    FETCH cur_tab INTO tableStr;
    EXIT WHEN cur_tab%NOTFOUND;

    --创建element
    --首先计算出elem的分区名称及值范围
    select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 8 - to_char( createDate,'d'),'d') from dual);
        partname1:='PART_EC_'||tableStr||'_'||orderNum;
        rangedate1:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';
         DBMS_OUTPUT.PUT_LINE(rangedate1);
    select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 15 - to_char( createDate,'d'),'d') from dual);
        partname2:='PART_EC_'||tableStr||'_'||orderNum;
        rangedate2:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';
    select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 22 - to_char( createDate,'d'),'d') from dual);
        partname3:='PART_EC_'||tableStr||'_'||orderNum;
        rangedate3:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';

--建表

        sqlStr:='create table NB_EE_'||tableStr||'
    (
      URL_ID           NUMBER,
      PAGE_ID          NUMBER,
      TASK_ID          NUMBER,
      CITY_ID          NUMBER,
      ISP_ID           NUMBER,
      NET_SPEED_ID     NUMBER,
      TM_BASE          DATE,
      DOMAIN_ID        NUMBER,
      ELEM_TYPE_ID     NUMBER,
      PROBE_IP         NUMBER,
      ELEMENT_SEQ      NUMBER,
      RECORD_TYPE      CHAR(1),
      ERROR_CODE       NUMBER,
      REDIRECT_TOTAL   NUMBER,
      URL_IP           NUMBER,
      BYTE_TOTAL       NUMBER,
      TS_START_OFFSET  NUMBER,
      TS_DNS           NUMBER,
      TS_CONNECT       NUMBER,
      TS_SSL           NUMBER,
      TS_REDIRECT      NUMBER,
      TS_REQUEST       NUMBER,
      TS_FIRST_PACKET  NUMBER,
      TS_REMAIN_PACKET NUMBER,
      TS_ELEMENT       NUMBER,
      TS_CLOSE         NUMBER,
      TS_BLOCK         NUMBER,
      BYTE_SENT        NUMBER,
      RATE_DOWNLOAD     NUMBER,
      RATE_UPLOAD     NUMBER,
      POINT_TOTAL     NUMBER
    ) pctfree 0
    partition by range (TM_BASE)(
                  partition '||ee_partname1||' values less than ('||rangedate1||'),
                  partition '||ee_partname2||' values less than ('||rangedate2||'),
                  partition '||ee_partname3||' values less than ('||rangedate3||'))';
    execute   immediate   sqlStr;

    --元素索引 tm_base,url_id,error_code
    sqlStr:='create index IDX_EE_UID_'||tableStr||' on NB_EE_'||tableStr||' (URL_ID,TM_BASE,ERROR_CODE) local
            (partition '||ee_partname1||',partition '||ee_partname2||',partition '||ee_partname3||') compress 1 PCTFREE 0
            tableSpace  NETBEN_IDX nologging';
    execute   immediate   sqlStr;
    --域名索引 tm_base,domain_id,error_code
    sqlStr:='create index IDX_EE_DID_'||tableStr||' on NB_EE_'||tableStr||' (DOMAIN_ID,TM_BASE,ERROR_CODE) local
            (partition '||ee_partname1||',partition '||ee_partname2||',partition '||ee_partname3||') compress 2 PCTFREE 0
            tableSpace  NETBEN_IDX';
    execute   immediate   sqlStr;
    --类型索引 tm_base,type_id,error_code
    sqlStr:='create index IDX_EE_TID_'||tableStr||' on NB_EE_'||tableStr||' (ELEM_TYPE_ID,TM_BASE,ERROR_CODE) local
            (partition '||ee_partname1||',partition '||ee_partname2||',partition '||ee_partname3||') compress 2 PCTFREE 0
            tableSpace  NETBEN_IDX';
    execute   immediate   sqlStr;
    
    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
      --  raise_application_error ();
        dbms_output.PUT_LINE(sqlStr);
      MON_PC_ERROR_LOG('create_table_EC',sqlerrm,tableStr);
end;
  end loop;
end MAN_CREATE_NEW_EC;


/

