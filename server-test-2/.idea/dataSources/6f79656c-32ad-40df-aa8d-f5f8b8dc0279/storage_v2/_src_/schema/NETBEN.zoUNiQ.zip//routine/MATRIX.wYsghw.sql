create PROCEDURE          "MATRIX" (p_cursor out sys_refcursor) is
  OWNERID integer := 1759;           -- ownerId
  SAMPLINGTIME integer := 5000;      -- 取样时间（分钟）：查询矩阵数据的时间长度。
  sqlstr varchar2(20480);
  errorcodes varchar2(4000);
begin
  errorcodes := getpageerrorcodes();
    sqlstr := 'SELECT * FROM (SELECT matx.col0perf/1000 AS col0perf, (CASE WHEN matx.col0total = 0 THEN NULL ELSE matx.col0succ/matx.col0total END) AS col0avail,
                    matx.col1perf/1000 AS col1perf, (CASE WHEN matx.col1total = 0 THEN NULL ELSE matx.col1succ/matx.col1total END) AS col1avail,
                    matx.col2perf/1000 AS col2perf, (CASE WHEN matx.col2total = 0 THEN NULL ELSE matx.col2succ/matx.col2total END) AS col2avail,
                    matx.col3perf/1000 AS col3perf, (CASE WHEN matx.col3total = 0 THEN NULL ELSE matx.col3succ/matx.col3total END) AS col3avail,
                    matx.col4perf/1000 AS col4perf, (CASE WHEN matx.col4total = 0 THEN NULL ELSE matx.col4succ/matx.col4total END) AS col4avail,
                    matx.col5perf/1000 AS col5perf, (CASE WHEN matx.col5total = 0 THEN NULL ELSE matx.col5succ/matx.col5total END) AS col5avail,
                    matx.col6perf/1000 AS col6perf, (CASE WHEN matx.col6total = 0 THEN NULL ELSE matx.col6succ/matx.col6total END) AS col6avail,
                    matx.col7perf/1000 AS col7perf, (CASE WHEN matx.col7total = 0 THEN NULL ELSE matx.col7succ/matx.col7total END) AS col7avail,
                    matx.col8perf/1000 AS col8perf, (CASE WHEN matx.col8total = 0 THEN NULL ELSE matx.col8succ/matx.col8total END) AS col8avail
             FROM nb_m_task task LEFT JOIN
                (SELECT tran.task_id,
                        AVG(CASE WHEN tran.city_id = 481101 THEN tran.ts_total ELSE NULL END) AS col0perf,
                        COUNT(CASE WHEN tran.city_id <> 481101 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col0succ,
                        COUNT(CASE WHEN tran.city_id = 481101 THEN 1 ELSE NULL END) AS col0total,
                		    AVG(CASE WHEN tran.city_id = 483101 THEN tran.ts_total ELSE NULL END) AS col1perf,
                                    COUNT(CASE WHEN tran.city_id <> 483101 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col1succ,
                                    COUNT(CASE WHEN tran.city_id = 483101 THEN 1 ELSE NULL END) AS col1total,
                		    AVG(CASE WHEN tran.city_id = 484401 THEN tran.ts_total ELSE NULL END) AS col2perf,
                        COUNT(CASE WHEN tran.city_id <> 484401 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col2succ,
                        COUNT(CASE WHEN tran.city_id = 484401 THEN 1 ELSE NULL END) AS col2total,
                		    AVG(CASE WHEN tran.city_id = 486501 THEN tran.ts_total ELSE NULL END) AS col3perf,
                        COUNT(CASE WHEN tran.city_id <> 486501 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col3succ,
                        COUNT(CASE WHEN tran.city_id = 486501 THEN 1 ELSE NULL END) AS col3total,
                		    AVG(CASE WHEN tran.city_id = 481301 THEN tran.ts_total ELSE NULL END) AS col4perf,
                        COUNT(CASE WHEN tran.city_id <> 481301 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col4succ,
                        COUNT(CASE WHEN tran.city_id = 481301 THEN 1 ELSE NULL END) AS col4total,
                		    AVG(CASE WHEN tran.city_id = 483502 THEN tran.ts_total ELSE NULL END) AS col5perf,
                        COUNT(CASE WHEN tran.city_id <> 483502 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col5succ,
                        COUNT(CASE WHEN tran.city_id = 483502 THEN 1 ELSE NULL END) AS col5total,
                		    AVG(CASE WHEN tran.city_id = 486101 THEN tran.ts_total ELSE NULL END) AS col6perf,
                        COUNT(CASE WHEN tran.city_id <> 486101 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col6succ,
                        COUNT(CASE WHEN tran.city_id = 486101 THEN 1 ELSE NULL END) AS col6total,
                		    AVG(CASE WHEN tran.city_id = 483701 THEN tran.ts_total ELSE NULL END) AS col7perf,
                        COUNT(CASE WHEN tran.city_id <> 483701 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col7succ,
                        COUNT(CASE WHEN tran.city_id = 483701 THEN 1 ELSE NULL END) AS col7total,
                		    AVG(tran.ts_total) AS col8perf,
                        COUNT(CASE WHEN tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col8succ,
                        COUNT(1) AS col8total
                FROM nb_tran_' || OWNERID || ' tran
                WHERE tran.task_id IN (SELECT id from nb_m_task t where t.owner_id = ' || OWNERID || ')
                      AND tran.tm_base > sysdate - interval ''' || SAMPLINGTIME || ''' MINUTE
                GROUP BY tran.task_id) matx ON task.id = matx.task_id
            WHERE task.owner_id = ' || OWNERID || ' ORDER BY task.id)';
            
    -- union with tasks avg
    sqlstr := sqlstr || ' UNION ALL (SELECT matx.col0perf/1000 AS col0perf, (CASE WHEN matx.col0total = 0 THEN NULL ELSE matx.col0succ/matx.col0total END) AS col0avail,
                    matx.col1perf/1000 AS col1perf, (CASE WHEN matx.col1total = 0 THEN NULL ELSE matx.col1succ/matx.col1total END) AS col1avail,
                    matx.col2perf/1000 AS col2perf, (CASE WHEN matx.col2total = 0 THEN NULL ELSE matx.col2succ/matx.col2total END) AS col2avail,
                    matx.col3perf/1000 AS col3perf, (CASE WHEN matx.col3total = 0 THEN NULL ELSE matx.col3succ/matx.col3total END) AS col3avail,
                    matx.col4perf/1000 AS col4perf, (CASE WHEN matx.col4total = 0 THEN NULL ELSE matx.col4succ/matx.col4total END) AS col4avail,
                    matx.col5perf/1000 AS col5perf, (CASE WHEN matx.col5total = 0 THEN NULL ELSE matx.col5succ/matx.col5total END) AS col5avail,
                    matx.col6perf/1000 AS col6perf, (CASE WHEN matx.col6total = 0 THEN NULL ELSE matx.col6succ/matx.col6total END) AS col6avail,
                    matx.col7perf/1000 AS col7perf, (CASE WHEN matx.col7total = 0 THEN NULL ELSE matx.col7succ/matx.col7total END) AS col7avail,
                    matx.col8perf/1000 AS col8perf, (CASE WHEN matx.col8total = 0 THEN NULL ELSE matx.col8succ/matx.col8total END) AS col8avail
             FROM (SELECT AVG(CASE WHEN tran.city_id = 481101 THEN tran.ts_total ELSE NULL END) AS col0perf,
                        COUNT(CASE WHEN tran.city_id <> 481101 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col0succ,
                        COUNT(CASE WHEN tran.city_id = 481101 THEN 1 ELSE NULL END) AS col0total,
                		    AVG(CASE WHEN tran.city_id = 483101 THEN tran.ts_total ELSE NULL END) AS col1perf,
                                    COUNT(CASE WHEN tran.city_id <> 483101 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col1succ,
                                    COUNT(CASE WHEN tran.city_id = 483101 THEN 1 ELSE NULL END) AS col1total,
                		    AVG(CASE WHEN tran.city_id = 484401 THEN tran.ts_total ELSE NULL END) AS col2perf,
                        COUNT(CASE WHEN tran.city_id <> 484401 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col2succ,
                        COUNT(CASE WHEN tran.city_id = 484401 THEN 1 ELSE NULL END) AS col2total,
                		    AVG(CASE WHEN tran.city_id = 486501 THEN tran.ts_total ELSE NULL END) AS col3perf,
                        COUNT(CASE WHEN tran.city_id <> 486501 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col3succ,
                        COUNT(CASE WHEN tran.city_id = 486501 THEN 1 ELSE NULL END) AS col3total,
                		    AVG(CASE WHEN tran.city_id = 481301 THEN tran.ts_total ELSE NULL END) AS col4perf,
                        COUNT(CASE WHEN tran.city_id <> 481301 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col4succ,
                        COUNT(CASE WHEN tran.city_id = 481301 THEN 1 ELSE NULL END) AS col4total,
                		    AVG(CASE WHEN tran.city_id = 483502 THEN tran.ts_total ELSE NULL END) AS col5perf,
                        COUNT(CASE WHEN tran.city_id <> 483502 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col5succ,
                        COUNT(CASE WHEN tran.city_id = 483502 THEN 1 ELSE NULL END) AS col5total,
                		    AVG(CASE WHEN tran.city_id = 486101 THEN tran.ts_total ELSE NULL END) AS col6perf,
                        COUNT(CASE WHEN tran.city_id <> 486101 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col6succ,
                        COUNT(CASE WHEN tran.city_id = 486101 THEN 1 ELSE NULL END) AS col6total,
                		    AVG(CASE WHEN tran.city_id = 483701 THEN tran.ts_total ELSE NULL END) AS col7perf,
                        COUNT(CASE WHEN tran.city_id <> 483701 OR tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col7succ,
                        COUNT(CASE WHEN tran.city_id = 483701 THEN 1 ELSE NULL END) AS col7total,
                		    AVG(tran.ts_total) AS col8perf,
                        COUNT(CASE WHEN tran.error_code IN (' || errorcodes || ') THEN NULL ELSE 1 END) AS col8succ,
                        COUNT(1) AS col8total
                FROM nb_tran_' || OWNERID || ' tran
                WHERE tran.task_id IN (SELECT id from nb_m_task t where t.owner_id = ' || OWNERID || ')
                      AND tran.tm_base > sysdate - interval ''' || SAMPLINGTIME || ''' MINUTE) matx)';
  open p_cursor for sqlstr;
end matrix;


/

