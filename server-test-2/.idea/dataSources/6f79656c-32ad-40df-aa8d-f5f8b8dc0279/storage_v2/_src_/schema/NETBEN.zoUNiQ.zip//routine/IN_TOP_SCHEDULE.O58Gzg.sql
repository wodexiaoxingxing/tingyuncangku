create PROCEDURE "IN_TOP_SCHEDULE" (num in number) authid current_user is
  sqlStr    varchar2(4000);
  errorDesc varchar2(4000);

begin
  create_procedure_log('in_top_schedule', 'in_top_schedule begin', 'run');

  --循环，查寻出所有的表
  for task in (select t.id, a.table_str
                 from nb_m_task t, nb_m_agreement a
                where t.agreement_id = a.id
                  and t.expire > sysdate - 1
                  and t.status != -1
                  and t.task_option = 'F'
                  and t.id like '%' || num)  loop
    begin
      --DBMS_OUTPUT.PUT_LINE('tableStr:' || task.table_str || ' taskId:' || task.id);
      in_top_elem_perf(task.table_str,task.id);
      in_top_error(task.table_str,task.id);
      in_top_host(task.table_str,task.id);
    exception
      when others then
        errorDesc := 'tableStr:' || task.table_str || ' taskId:' || task.id ||'Error:' || sqlerrm;
        --DBMS_OUTPUT.PUT_LINE(errorDesc);
        create_procedure_log('in_top_schedule', errorDesc, 'error');
    end;
  end loop;

end in_top_schedule;


/

