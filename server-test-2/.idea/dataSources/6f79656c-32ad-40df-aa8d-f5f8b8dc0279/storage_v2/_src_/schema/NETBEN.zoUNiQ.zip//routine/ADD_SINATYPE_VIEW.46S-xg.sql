create PROCEDURE          "ADD_SINATYPE_VIEW" authid current_user is
    sqlStr varchar2(2000);
    viewCode varchar2(64);
    errorDesc varchar2(4000);
    v_s number;
    v_viewId number;
    v_agreementId number;
    
    
begin
    for sinaType in(select id,name,code,passwd,email from nb_m_user where type = 8 and status = 1) loop
    begin
        viewCode:=sinaType.code || '_view';
        dbms_output.put_line(viewCode);
        --判断是否view用户已经建立
        sqlStr:='select count(*) from nb_m_user where code = :code';
        execute immediate sqlStr into v_s using viewCode;
        dbms_output.put_line(v_s);
        if (v_s<1) then
            --如果没有建，则新建该用户，用户的code为管理用户code + _view
            sqlStr:='select id from nb_m_agreement where agent_id = :agentId and rownum=1 order by create_date desc';
            execute immediate sqlStr into v_agreementId using sinaType.id;
            
            sqlStr:='insert into nb_m_user(id,code,name,passwd,email,type,status,agree_id)
                select seq_nb_ops_user.nextval,:code,:name,:passwd,:email,4,1,:agreeId from dual';
            execute immediate sqlStr using viewCode,sinaType.name,sinaType.Passwd,sinaType.email,v_agreementId;
            commit;
        end if;
        --取出该用户的ID
        sqlStr:='select id from nb_m_user where code=:code';
        execute immediate sqlStr into v_viewId using viewCode;
        dbms_output.put_line(v_viewId);
               
        --将所属管理用户下的所有任务给到view用户
        sqlStr:='insert into nb_m_user_task(user_id,task_id) 
            select :viewId,id from nb_m_task where agreement_id in(select id from nb_m_agreement where agent_id =:agentId)
            and id not in(select task_id from nb_m_user_task where user_id =:viewId)';
        execute immediate sqlStr using v_viewId,sinaType.id,v_viewId;
        commit;
        exception when  others then
        errorDesc := 'Error Code:'|| sqlcode || '  Sql:' ;
        dbms_output.put_line(errorDesc);
        create_procedure_log('add_sinatype_view',errorDesc,sqlcode);
    end;
    end loop;
end add_sinatype_view;


/

