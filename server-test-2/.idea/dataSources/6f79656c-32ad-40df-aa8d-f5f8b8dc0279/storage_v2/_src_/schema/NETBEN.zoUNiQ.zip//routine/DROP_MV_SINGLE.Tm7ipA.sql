create procedure drop_mv_single(tableStr number) authid current_user is
sqlStr varchar2(4000);
begin
  -- tran
    begin
      sqlStr:='drop materialized view log on nb_tran_'||tableStr;
      execute immediate sqlStr;
    exception when  others then
      dbms_output.put_line(sqlStr||';');
    end;
    begin
      sqlStr:='drop materialized view mv_tran_'||tableStr;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
    exception when  others then
      dbms_output.put_line(sqlStr||';');
    end;
  -- page
    begin
      sqlStr:='drop materialized view log on nb_page_'||tableStr;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
    exception when  others then
      dbms_output.put_line(sqlStr||';');
    end;
    begin
      sqlStr:='drop materialized view mv_page_'||tableStr;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
    exception when  others then
      dbms_output.put_line(sqlStr||';');
    end;
  --stream
    begin
      sqlStr:='drop materialized view log on nb_stream_'||tableStr;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
    exception when  others then
      dbms_output.put_line(sqlStr||';');
    end;
    begin
      sqlStr:='drop materialized view mv_stream_'||tableStr;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
    exception when  others then
      dbms_output.put_line(sqlStr||';');
    end;
  --ping  
  /*
  for tableStr in  (SELECT distinct substr(t.table_name,9) suff FROM user_tables t where t.table_name like 'MV_PING_%')
  loop
    begin
      sqlStr:='drop materialized view log on nb_ping_'||tableStr.suff;
      execute immediate sqlStr;
      dbms_output.put_line(sqlStr||';');
    exception when  others then
      dbms_output.put_line(sqlStr||';');
    end;
    begin
      sqlStr:='drop materialized view mv_ping_'||tableStr.suff;
      execute immediate sqlStr;
      dbms_output.put_line(sqlStr||';');
    exception when  others then
      dbms_output.put_line(sqlStr||';');  
    end;
  end loop;    
  */
  --custom
    begin
      sqlStr:='drop materialized view log on nb_custom_'||tableStr;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
    exception when  others then
      dbms_output.put_line(sqlStr||';');
    end;
    begin  
      sqlStr:='drop materialized view mv_custom_'||tableStr;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
    exception when  others then
      dbms_output.put_line(sqlStr||';');  
    end;
  --mob_tran
    begin
      sqlStr:='drop materialized view log on nb_mob_tran_'||tableStr;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
    exception when  others then
      dbms_output.put_line(sqlStr||';');
    end;
    begin  
      sqlStr:='drop materialized view mv_mob_tran_'||tableStr;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
    exception when  others then
      dbms_output.put_line(sqlStr||';');  
    end;
  --mob_page
    begin
      sqlStr:='drop materialized view log on nb_mob_page_'||tableStr;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
    exception when  others then
      dbms_output.put_line(sqlStr||';');
    end;
    begin  
      sqlStr:='drop materialized view mv_mob_page_'||tableStr;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
    exception when  others then
      dbms_output.put_line(sqlStr||';');  
    end;
  --mobapp_tran
    begin
      sqlStr:='drop materialized view log on nb_mobapp_tran_'||tableStr;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
    exception when  others then
      dbms_output.put_line(sqlStr||';');
    end;
    begin  
      sqlStr:='drop materialized view mv_mobapp_tran_'||tableStr;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
    exception when  others then
      dbms_output.put_line(sqlStr||';');  
    end;
  --mobapp_page
    begin
      sqlStr:='drop materialized view log on nb_mobapp_page_'||tableStr;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
    exception when  others then
      dbms_output.put_line(sqlStr||';');
    end;
    begin  
      sqlStr:='drop materialized view mv_mobapp_page_'||tableStr;
      execute immediate sqlStr;
      --dbms_output.put_line(sqlStr||';');
    exception when  others then
      dbms_output.put_line(sqlStr||';');  
    end;
  
      
end drop_mv_single;


/

