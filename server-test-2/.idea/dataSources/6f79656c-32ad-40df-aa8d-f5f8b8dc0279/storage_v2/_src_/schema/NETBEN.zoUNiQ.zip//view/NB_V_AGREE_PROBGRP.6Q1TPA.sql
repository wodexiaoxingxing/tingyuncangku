create view NB_V_AGREE_PROBGRP as
select distinct ad.agreement_id as agreement_id, grp.column_value as grp_id from nb_m_agree_detail ad, table (split(ad.probgrp_id, ',')) grp
order by ad.agreement_id, grp.column_value


/

