create PROCEDURE PROCEDURE_45673 authid current_user is     sqlStr varchar2(4000);    begin    sqlStr:='update nb_m_task set sla_probes = 2000,status = 1,mtime=sysdate where id = 45673';    execute immediate sqlStr;    commit;    create_procedure_log('PROCEDURE_45673','end','run');    for i in 1..3 loop     DBMS_LOCK.sleep (300);    sqlStr:='update nb_m_task set sla_probes = sla_probes + 400,status = 1,mtime=sysdate where id = 45673';    execute immediate sqlStr;    commit;    create_procedure_log('PROCEDURE_45673','end','run');    end loop;    DBMS_LOCK.sleep (300);    sqlStr:='update nb_m_task  set sla_probes = 2000,status = 0,mtime = sysdate where id = 45673';    execute immediate sqlStr;    commit;    create_procedure_log('PROCEDURE_45673','end','run');    end PROCEDURE_45673;

/

