create PROCEDURE update_el_part_and_ind authid current_user is
type tabType is table of varchar2(32) index by BINARY_INTEGER;
tabTypeImpl tabType;
/*维护分区时同时维护索引*/
type v_ind is table of user_indexes%rowtype index by binary_integer;
ind_arr v_ind;
indStr varchar2(4000);
i int :=0;
c int :=0;
DROP_ERROR exception;
ADD_ERROR exception;

sqlStr varchar2(4000);
currDate date := trunc(sysdate,'d');

partNameNew varchar2(64);
partValueNew varchar2(64);
partDate date;
begin
  DBMS_OUTPUT.ENABLE (1000000000);
  tabTypeImpl(1):='NB_EL';
  tabTypeImpl(2):='NB_ELT';
  create_procedure_log('update_el_part_and_ind','begin','run');
  for s in 1..tabTypeImpl.count loop
    for tab in  (select t.partition_name partName,t.num partNum,t.table_name tabName from
      (select partition_name,decode(is_number(num),0,0,1,num) num,table_name from (select partition_name,substr(partition_name, instr(partition_name,'_',-1,1)+1) num, table_name from user_tab_partitions where table_name like tabTypeImpl(s)||'\_%'  escape '\')) t,
      (select order_num from nb_part_calendar where sunday <= currDate - 21) c
        where t.num = c.order_num) loop
        begin
          select sunday into partDate from nb_part_calendar where order_num = tab.partNum;
          if partDate > currDate - 21 then
            raise DROP_ERROR;
          end if;
          sqlStr:='alter table '||tab.tabName||' drop partition '||tab.partName;
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
          --create_procedure_log('update_el_part_and_ind','Drop part,Table:'||tab.tabname||',partName:'||tab.partName,'run');
        exception
           when DROP_ERROR then null;
           when others then
           dbms_output.put_line('dropError,Table:'||tab.tabname||','||sqlerrm);
           --create_procedure_log('update_el_part_and_ind','dropError,Table:'||tab.tabname||','||sqlerrm,'error');
        end;
     end loop;
     for tab in(
          select a.table_name tabName,a.partition_name partName,decode(is_number(a.num),0,0,1,num) partNum,tablespace_name tablespaceName from
           (select table_name,partition_position,partition_name,substr(partition_name, instr(partition_name,'_',-1,1)+1) num,tablespace_name from user_tab_partitions where table_name like tabTypeImpl(s)||'\_%'  escape '\')a,
           (select table_name,max(partition_position) partition_position from user_tab_partitions where table_name like tabTypeImpl(s)||'\_%'  escape '\' group by table_name)b
           where a.table_name = b.table_name and a.partition_position = b.partition_position
     )loop
       begin
         select sunday into partDate from nb_part_calendar where order_num = tab.partNum;
          if partDate > currDate + 14 then
            raise ADD_ERROR;
          end if;
          partNameNew:=substr(tab.partName,1,instr(tab.partName,'_',-1,1))||(tab.partNum+1);
          partValueNew :='to_date('''||to_char(partDate+7,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';

          select count(1) into c from user_indexes where partitioned='YES' and table_name=tab.tabName;
          if c=0 then
              sqlStr := 'alter table '||tab.tabName || ' add partition '||partNameNew||' values less than('||partValueNew||') tablespace '||tab.tablespacename||';';
             dbms_output.put_line(sqlStr||';');
             else
             i :=0;
             ind_arr(i).index_name :=NULL;
            for ind in(select index_name from user_indexes where partitioned='YES' and table_name=tab.tabName) loop
             i :=i+1;
             ind_arr(i).index_name :=ind.index_name;
             if i=1 then
              indStr :=ind_arr(i).index_name||'(partition '||partNameNew||' tablespace netben_idx_new)';
             dbms_output.put_line(indStr||';');
             else
             indStr :=indStr||','||ind_arr(i).index_name||'(partition '||partNameNew||' tablespace netben_idx_new)';
              dbms_output.put_line(indStr||';');
             end if;
             end loop;
           sqlStr := 'alter table '||tab.tabName || ' add partition '||partNameNew||' values less than('||partValueNew||') tablespace '||tab.tablespacename||' update indexes('||indStr||')';
          dbms_output.put_line(sqlStr||';');
          end if;
          --execute immediate sqlStr;
          --create_procedure_log('update_el_part_and_ind','Add Part,Table:'||tab.tabname||',partName:'||partNameNew,'run');
      exception
        when ADD_ERROR then null;
        when others then
          dbms_output.put_line('addError,Table:'||tab.tabname||','||sqlerrm);
          --create_procedure_log('update_el_part_and_ind','addError,Table:'||tab.tabname||','||sqlerrm,'error');
      end;
    end loop;
  end loop;
  --create_procedure_log('update_el_part_and_ind','end','run');
  exception when others then
    dbms_output.put_line('Outer error,'||sqlerrm);
    --create_procedure_log('update_el_part_and_ind','Outer error,'||sqlerrm,'error');
end update_el_part_and_ind;


/

