create PROCEDURE CALC_NODE_LONGIN_AGAIN
  AS
   task_counts int; --白名单配置有效任务数
   error_counts int; --错误代码连续出现 （612271或612007或612029）的次数,当次数大于5次时，需要将当前的节点重新登录
   relogin_nodes int; --当前的节点是否存在要更新
   max_error_counts number :=5;
    Cursor temp_disabled_cur is
            select host_id,ipaddress,time_stamp+numtodsinterval(-10,'minute') start_time,time_stamp end_time
             from nb_m_proberuntime_log
              where time_stamp = (select max(time_stamp) from nb_m_proberuntime_log) and  temp_disabled = 1;
  BEGIN
    create_procedure_log('calc_node_longin_again', 'begin', 'run');
    select count(1) into task_counts from nb_m_node_task_white_list where expire > sysdate -1;
     if task_counts > 0 then
    begin
     for temp_disabled in temp_disabled_cur Loop
         begin
           error_counts:=0;
        for ddc_col in
           (select task_id,host_id,error_code,tm_base
              from nb_m_ddc_log_col where task_id in(select task_id from nb_m_node_task_white_list
                where expire > sysdate -1) and host_id =temp_disabled.host_id and ctime >=temp_disabled.start_time and ctime <=temp_disabled.end_time order by ctime desc)
             loop
               begin
                if ddc_col.error_code in (612271,612007,612029) then
                  begin
                      error_counts:= error_counts + 1;
                          if error_counts >= max_error_counts then
                              begin
                                error_counts:=0;
                              select count(1) into relogin_nodes from nb_m_relogin_node where ctime > sysdate - 0.5/24 and ipaddress = temp_disabled.ipaddress and status = 1;
                               if relogin_nodes = 0 then
                                 begin
                                  -- 将其设置到表中，需要进行重新登录操作
                                  insert into nb_m_relogin_node (id,task_id,host_id,ipaddress,status,mtime,ctime) values(seq_relogin_node.nextval,ddc_col.task_id,ddc_col.host_id,temp_disabled.ipaddress,1,sysdate,sysdate);
                                  commit;
                                   exception when others then
                                     create_procedure_log('calc_node_longin_again','task_id:'||ddc_col.task_id||',host_id:'||ddc_col.host_id || 'ipaddress:'||temp_disabled.ipaddress||'tm_base:'||to_char(ddc_col.tm_base,'yyyy-mm-dd hh24:mi:ss') ,'error');
                                    exit;
                                  end;
                                end if;
                             end;
                         end if;
                    end;
                   else error_counts:=0;
                  end if;
                 end;
               end loop;
         end;
         end Loop;
     end;
  end if;
    create_procedure_log('calc_node_longin_again', 'end', 'run');
  END CALC_NODE_LONGIN_AGAIN;
/

