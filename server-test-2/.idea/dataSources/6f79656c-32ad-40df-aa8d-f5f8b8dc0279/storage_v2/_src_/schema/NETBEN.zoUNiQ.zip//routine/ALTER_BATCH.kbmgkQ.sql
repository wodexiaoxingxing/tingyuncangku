create PROCEDURE alter_batch authid current_user is
  table_name user_tables.table_name%type;
  sys_cur    sys_refcursor;
  sql_str    varchar2(4096);
begin
  OPEN sys_cur FOR
    select table_name
      from user_tables where table_name like 'NB_CROSS_APP_TOPOLOGY%';
  LOOP
    FETCH sys_cur INTO table_name;
    EXIT WHEN sys_cur%NOTFOUND;
    BEGIN
      sql_str := 'alter table ' || table_name || ' add tm_base date';
      execute immediate sql_str;
    EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE(sqlerrm);
    END;
  END LOOP;
  CLOSE sys_cur;
END alter_batch;


/

