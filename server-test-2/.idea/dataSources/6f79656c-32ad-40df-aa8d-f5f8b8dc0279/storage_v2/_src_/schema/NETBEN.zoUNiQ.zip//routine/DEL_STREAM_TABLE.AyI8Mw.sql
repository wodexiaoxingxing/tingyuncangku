create PROCEDURE          "DEL_STREAM_TABLE" (
       tableStr IN varchar2
) authid current_user
is
sqlStr varchar2(4000);
begin
   sqlStr:='drop sequence seq_nb_stream_id_'||tableStr;
   execute immediate sqlStr;	
   
   sqlStr:='drop materialized view log on nb_stream_'||tableStr;
   execute immediate sqlStr;
   
   sqlStr:='drop materialized view mv_stream_'||tableStr;
   execute immediate sqlStr;
   
   sqlStr:='drop table nb_stream_'||tableStr;
   execute immediate sqlStr;
end del_stream_table;


/

