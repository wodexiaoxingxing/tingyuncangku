create PROCEDURE mob_dns_stat
(
  start_dt IN DATE default to_date('2019-01-19 15:00:00', 'yyyy-mm-dd hh24:mi:ss'),
  end_dt IN DATE default to_date('2019-01-22 15:00:00', 'yyyy-mm-dd hh24:mi:ss'),
  start_dt2 IN DATE default to_date('2019-01-22 15:00:00', 'yyyy-mm-dd hh24:mi:ss'),
  end_dt2 IN DATE default to_date('2019-01-25 15:00:00', 'yyyy-mm-dd hh24:mi:ss')
) AS 
table_str varchar2(3000);
source_table varchar2(3000);
ts_dns1 number;
ts_dns2 number;
sql_str1 varchar2(3000);
sql_str2 varchar2(3000);
mark varchar2(10);
username varchar2(3000);


--声明游标，查询所有的真机任务
Cursor mob_tasks is  
select id,owner_id,name,type,TASK_OPTION opt,ctime 
from nb_m_task 
where type in (102,103) and status = 1 and EXPIRE > sysdate;

BEGIN
  for task_one in mob_tasks LOOP
  begin
    -- 拼接数据表名称
    select table_str,b.name into table_str,username
    from nb_m_agreement a,nb_m_user b
    where a.id=b.agree_id and b.id= task_one.owner_id;
--    select table_str into table_str from nb_m_agreement where id=(select agree_id from nb_m_user where id= task_one.owner_id);
    source_table := 'nb_mob_page_' || table_str;
    
    -- 计算第一个时间段内的平均dns 
    sql_str1:='select round(avg(TS_DNS)/1000.0,3) from ' || source_table || ' where task_id = :tid and tm_base between :start_dt and :end_dt';
    -- 计算第二个时间段内的平均dns 
    sql_str2:='select round(avg(TS_DNS)/1000.0,3) from ' || source_table || ' where task_id = :tid and tm_base between :start_dt2 and :end_dt2';
    execute immediate sql_str1 into ts_dns1 using task_one.id, start_dt, end_dt;
    execute immediate sql_str2 into ts_dns2 using task_one.id, start_dt2, end_dt2;

--    if ts_dns1 > 0 and ts_dns2 > 0 then
      mark := null;
      if ts_dns2 < ts_dns1 then
        mark := '-';
      end if;
      insert into TMP_NB_MOB_DNS_STAT values(task_one.id, task_one.owner_id, task_one.name, username, ts_dns1, ts_dns2, source_table, sysdate, mark, task_one.type, task_one.opt);
--    end if;
  end;
  end LOOP;
  commit;
END mob_dns_stat;
/

