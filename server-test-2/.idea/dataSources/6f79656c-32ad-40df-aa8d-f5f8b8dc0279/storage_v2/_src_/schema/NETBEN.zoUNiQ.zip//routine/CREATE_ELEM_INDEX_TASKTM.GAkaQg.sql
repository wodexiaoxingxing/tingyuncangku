create PROCEDURE          "CREATE_ELEM_INDEX_TASKTM" 
   (tableStr in varchar2) authid current_user is
  sqlStr  varchar2(4000);
  partStr varchar2(4000);
  v_s number;
  v_error_desc varchar2(4000);

begin
  
  --循环，查寻出所有的表
 
  for partName in(select partition_name as name from user_tab_partitions where table_name ='NB_ELEM_'||tableStr) loop
     partStr := partStr||'partition '||partName.name||',';
  end loop;
  partStr:=substr(partStr,1,length(partStr)-1);
  DBMS_OUTPUT.PUT_LINE(partStr);
     sqlStr :=  'create index in_elem_pageid_'||tableStr||' on nb_elem_'||tableStr||'(page_id) local('||partStr||')';
     execute immediate sqlStr ;
     --  DBMS_OUTPUT.PUT_LINE(sqlStr);
end CREATE_ELEM_INDEX_TASKTM;


/

