create procedure in_cdn_by_old(sd date,days number) authid current_user is
   SUFF_ERROR EXCEPTION;
   sqlStr varchar2(4000);
   startDate date;
   calcDate date;
   suff number;
   inDays number;
begin
if sd is null or days is null then
  startDate:=trunc(sysdate-1,'dd');
  inDays := 1;
else
  startDate:=trunc(sd,'dd');
  inDays:=days;
end if;
  create_procedure_log('in_mt_page_by_mv','begin','run');
  -- nb_cdn_usage_summary
  for tab in(SELECT t.table_name as name FROM user_tables t where t.table_name like 'NB_CDN_USAGE_SUMMARY%') loop
    begin
      calcDate:=startDate;
      begin
        suff:=substr(tab.name,22);
        -- if suff!=22 then raise SUFF_ERROR; end if;
      exception when others then
        --如果后缀不是数字则不是正式表，不处理直接exit
        --dbms_output.put_line(tab.name);
        raise SUFF_ERROR;
      end;
      for i in 1..inDays loop
        begin
          --先删除数据
          sqlStr:='delete from nb_cdn_u_summ_'||suff||' where tm_base >= :sm and tm_base < :em' ;
          execute immediate sqlStr using calcDate,calcDate+1;
          commit;
          
          sqlStr:='insert into nb_cdn_u_summ_'||suff||' select * from nb_cdn_usage_summary_'||suff||
                ' where tm_base >= :sm and tm_base < :em' ;
          execute immediate sqlStr using calcDate,calcDate+0.5;
          commit;
          create_procedure_log('in_cdn_by_old','tableName:'||tab.name||',calcDate:'||to_char(calcDate,'yyyy-mm-dd hh24:mi'),'run');
          
          sqlStr:='insert into nb_cdn_u_summ_'||suff||' select * from nb_cdn_usage_summary_'||suff||
                ' where tm_base >= :sm and tm_base < :em' ;
          execute immediate sqlStr using calcDate+0.5,calcDate+1;
          commit;
          
          create_procedure_log('in_cdn_by_old','tableName:'||tab.name||',calcDate:'||to_char(calcDate+0.5,'yyyy-mm-dd hh24:mi'),'run');
          calcDate:=calcDate+1;
        exception when others then
          create_procedure_log('in_cdn_by_old','tableName:'||tab.name||',calcDate:'||to_char(calcDate,'yyyy-mm-dd hh24:mi')||','||sqlerrm,'error');
        end;
       end loop;
     exception when SUFF_ERROR then
      --如果是后缀不正确则不处理
      null;
    when others then
      create_procedure_log('in_cdn_by_old','tableName:'||tab.name||',calcDate:'||to_char(calcDate,'yyyy-mm-dd hh24:mi')||','||sqlerrm,'error');
    end;
  end loop;   
   
  -- nb_cdn_usage_perf
  for tab in(SELECT t.table_name as name FROM user_tables t where t.table_name like 'NB_CDN_USAGE_PERF%') loop
    begin
      calcDate:=startDate;
      begin
        suff:=substr(tab.name,19);
        -- if suff!=22 then raise SUFF_ERROR; end if;
      exception when others then
        --如果后缀不是数字则不是正式表，不处理直接exit
        --dbms_output.put_line(tab.name);
        raise SUFF_ERROR;
      end;
      for i in 1..inDays loop
        begin
          --先删除数据
          sqlStr:='delete from nb_cdn_u_perf_'||suff||' where tm_base >= :sm and tm_base < :em' ;
          execute immediate sqlStr using calcDate,calcDate+1;
          commit;
          
          sqlStr:='insert into nb_cdn_u_perf_'||suff||' select * from nb_cdn_usage_perf_'||suff||
                ' where tm_base >= :sm and tm_base < :em' ;
          execute immediate sqlStr using calcDate,calcDate+0.5;
          commit;
          create_procedure_log('in_cdn_by_old','tableName:'||tab.name||',calcDate:'||to_char(calcDate,'yyyy-mm-dd hh24:mi'),'run');
          sqlStr:='insert into nb_cdn_u_perf_'||suff||' select * from nb_cdn_usage_perf_'||suff||
                ' where tm_base >= :sm and tm_base < :em' ;
          execute immediate sqlStr using calcDate,calcDate+0.5;
          commit;
          --dbms_output.put_line(sqlStr);
          create_procedure_log('in_cdn_by_old','tableName:'||tab.name||',calcDate:'||to_char(calcDate+0.5,'yyyy-mm-dd hh24:mi'),'run');
          calcDate:=calcDate+1;
        exception when others then
          create_procedure_log('in_cdn_by_old','tableName:'||tab.name||',calcDate:'||to_char(calcDate,'yyyy-mm-dd hh24:mi')||','||sqlerrm,'error');
        end;
       end loop;
     exception when SUFF_ERROR then
      --如果是后缀不正确则不处理
      null;
    when others then
      create_procedure_log('in_cdn_by_old','tableName:'||tab.name||',calcDate:'||to_char(calcDate,'yyyy-mm-dd hh24:mi')||','||sqlerrm,'error');
    end;
  end loop;
  
   -- nb_cdn_host_perf
  for tab in(SELECT t.table_name as name FROM user_tables t where t.table_name like 'NB_CDN_HOST_PERF%') loop
    begin
      calcDate:=startDate;
      begin
        suff:=substr(tab.name,18);
        -- if suff!=22 then raise SUFF_ERROR; end if;
      exception when others then
        --如果后缀不是数字则不是正式表，不处理直接exit
        --dbms_output.put_line(tab.name);
        raise SUFF_ERROR;
      end;
      for i in 1..inDays loop
        begin
          --先删除数据
          sqlStr:='delete from nb_cdn_h_perf_'||suff||' where tm_base >= :sm and tm_base < :em' ;
          execute immediate sqlStr using calcDate,calcDate+0.5;
          commit;
          
          sqlStr:='insert into nb_cdn_h_perf_'||suff||' select * from nb_cdn_host_perf_'||suff||
                ' where tm_base >= :sm and tm_base < :em' ;
          execute immediate sqlStr using calcDate,calcDate+0.5;
          commit;
          create_procedure_log('in_cdn_by_old','tableName:'||tab.name||',calcDate:'||to_char(calcDate,'yyyy-mm-dd hh24:mi'),'run');
          sqlStr:='insert into nb_cdn_h_perf_'||suff||' select * from nb_cdn_host_perf_'||suff||
                ' where tm_base >= :sm and tm_base < :em' ;
          execute immediate sqlStr using calcDate+0.5,calcDate+1;
          commit;
          --dbms_output.put_line(sqlStr);
          create_procedure_log('in_cdn_by_old','tableName:'||tab.name||',calcDate:'||to_char(calcDate,'yyyy-mm-dd hh24:mi'),'run');
          calcDate:=calcDate+1;
        exception when others then
          create_procedure_log('in_cdn_by_old','tableName:'||tab.name||',calcDate:'||to_char(calcDate,'yyyy-mm-dd hh24:mi')||','||sqlerrm,'error');
        end;
       end loop;
     exception when SUFF_ERROR then
      --如果是后缀不正确则不处理
      null;
    when others then
      create_procedure_log('in_cdn_by_old','tableName:'||tab.name||',calcDate:'||to_char(calcDate,'yyyy-mm-dd hh24:mi')||','||sqlerrm,'error');
    end;
  end loop;
   
  create_procedure_log('in_cdn_by_old','end','run');
end in_cdn_by_old;


/

