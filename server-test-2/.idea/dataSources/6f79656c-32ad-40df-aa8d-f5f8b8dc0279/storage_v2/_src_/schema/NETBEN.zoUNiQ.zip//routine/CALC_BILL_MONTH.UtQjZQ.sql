create procedure calc_bill_month(num in number) authid current_user is
  sqlStr       varchar2(4000);
  s number;
  errorDesc varchar2(4000);
  startDate date;
  endDate date;
begin
  startDate := add_months(trunc(sysdate,'mm'),-1);
  endDate := trunc(sysdate,'mm');

  create_procedure_log('calc_bill_month'||num, 'calc_bill_month begin', 'run');
  
  --开始生成每个月的汇总数据
  --首先删除可能已经生成的数据
    sqlStr := 'delete from nb_bill_task_month m where m.calc_date = :calcDate  and exists (select 1 from nb_m_task t where t.id = m.task_id and t.agreement_id in(select id from nb_m_agreement where table_str like ''%'||num||'''))';
    execute immediate sqlStr using trunc(startDate,'mm');
    commit;

  --循环，查寻出所有的表
  for tableName in (select distinct table_str as name from nb_m_agreement where table_str like '%'||num) loop
  begin
      create_procedure_log('calc_bill_month'||num, tableName.name, 'run');
      
      
      --从page表中生成每月的数据，页面包括普通ping及事务的数据
      begin
        sqlStr := 'insert into nb_bill_task_month value
                     select task_id,trunc(tm_base,''mm''),sum(point_total),sysdate
                        from nb_page_'||tableName.name||'
                         where tm_base >= :sDate and tm_base < :eDate
                            and is_noise = 0
                         group by task_id,trunc(tm_base,''mm'')';
        execute immediate sqlStr using startDate,endDate;
        commit;
      exception when  others then
        errorDesc := sqlerrm||',tableName:nb_page_' || tableName.name ;
        --DBMS_OUTPUT.PUT_LINE(errorDesc);
        create_procedure_log('calc_bill_month'||num,errorDesc,'warning');
      end;
      
      --从stream表中生成每月的数据
      select count(*)  INTO s FROM nb_m_task where type=3 and agreement_id in (select id from nb_m_agreement where table_str =tableName.name);
      if s > 0 then
        begin     
          sqlStr := 'insert into nb_bill_task_month value
                       select task_id,trunc(tm_base,''mm''),sum(point_total),sysdate
                          from nb_stream_'||tableName.name||'
                           where tm_base >= :sDate and tm_base < :eDate
                              and is_noise = 0
                           group by task_id,trunc(tm_base,''mm'')';
          execute immediate sqlStr using startDate,endDate;
          commit;
        exception when  others then
          errorDesc := sqlerrm||',tableName:nb_stream_' || tableName.name ;
          --DBMS_OUTPUT.PUT_LINE(errorDesc);
          create_procedure_log('calc_bill_month'||num,errorDesc,'warning');
        end;
      end if;
      --从custom表中生成每日的数据
      select count(*)  INTO s FROM nb_m_task where type=255 and agreement_id in (select id from nb_m_agreement where table_str =tableName.name);
      if s > 0 then
        begin
          sqlStr := 'insert into nb_bill_task_month value
                       select task_id,trunc(tm_base,''mm''),sum(point_total),sysdate
                          from nb_custom_'||tableName.name||'
                           where tm_base >= :sDate and tm_base < :eDate
                              and is_noise = 0
                           group by task_id,trunc(tm_base,''mm'')';
          execute immediate sqlStr using startDate,endDate;
          commit;
        exception when  others then
          errorDesc := sqlerrm||',tableName:nb_custom_' || tableName.name ;
          --DBMS_OUTPUT.PUT_LINE(errorDesc);
          create_procedure_log('calc_bill_month'||num,errorDesc,'warning');
        end;
      end if;
      --从trace表中生成每日的数据
      select count(*)  INTO s FROM nb_m_task where task_option='T' and type=1 and agreement_id in (select id from nb_m_agreement where table_str =tableName.name);
        if s > 0 then
        begin
          sqlStr := 'insert into nb_bill_task_month value
                       select task_id,trunc(tm_base,''mm''),sum(point_total),sysdate
                          from nb_trace_'||tableName.name||'
                           where tm_base >= :sDate and tm_base < :eDate
                              and is_noise = 0
                           group by task_id,trunc(tm_base,''mm'')';
          execute immediate sqlStr using startDate,endDate;
          commit;
        exception when  others then
          errorDesc := sqlerrm||',tableName:nb_trace_' || tableName.name ;
          --DBMS_OUTPUT.PUT_LINE(errorDesc);
          create_procedure_log('calc_bill_month'||num,errorDesc,'warning');
        end;
      end if;
      --从手机页面监测表中生成每日的数据
      select count(*)  INTO s FROM nb_m_task where type=102 and agreement_id in (select id from nb_m_agreement where table_str =tableName.name);
        if s > 0 then
        begin
          sqlStr := 'insert into nb_bill_task_month value
                       select task_id,trunc(tm_base,''mm''),sum(point_total),sysdate
                          from nb_mob_page_'||tableName.name||'
                           where tm_base >= :sDate and tm_base < :eDate
                              and is_noise = 0
                           group by task_id,trunc(tm_base,''mm'')';
          execute immediate sqlStr using startDate,endDate;
          commit;
        exception when  others then
          errorDesc := sqlerrm||',tableName:nb_mob_page_' || tableName.name ;
          --DBMS_OUTPUT.PUT_LINE(errorDesc);
          create_procedure_log('calc_bill_month'||num,errorDesc,'warning');
        end;
      end if;
      --从ping监测表中生成每日的数据,暂时只取手机页面PING的数据，普通页面ping从page表中取
      select count(*)  INTO s FROM nb_m_task where task_option='P' and type=102 and agreement_id in (select id from nb_m_agreement where table_str =tableName.name);
      if s > 0 then
      begin
        sqlStr := 'insert into nb_bill_task_month value
                     select p.task_id, trunc(p.tm_base, ''mm''), sum(p.point_total), sysdate
                        from nb_ping_'||tableName.name||' p,nb_m_task t
                       where p.tm_base >= :sDate and p.tm_base < :eDate
                         and p.is_noise = 0
                         and t.agreement_id in(select id from nb_m_agreement where table_str = '||tableName.name||')
                         and t.task_option = ''P''
                         and t.type = 102
                         and p.task_id = t.id
                       group by p.task_id, trunc(p.tm_base, ''mm'')';
        execute immediate sqlStr using startDate,endDate;
        commit;
      exception when  others then
        errorDesc := sqlerrm||',tableName:nb_ping_' || tableName.name ;
        --DBMS_OUTPUT.PUT_LINE(errorDesc);
        create_procedure_log('calc_bill_month'||num,errorDesc,'warning');
      end;
      end if;
  end;    
  end loop;

     
  -- 生成对比数据,从每日汇总数据中生成数据在calc_bill_day中实现，每月2号生成
  sqlStr := 'delete from nb_bill_task_confirm m where calc_date = :calcDate and exists (select 1 from nb_m_task t where t.id = m.task_id and t.agreement_id in(select id from nb_m_agreement where table_str like ''%'||num||'''))';
  execute immediate sqlStr using trunc(startDate,'mm');
  commit;

  sqlStr := 'insert into nb_bill_task_confirm value
               select c.task_id,c.calc_date,c.count_day,c.count_month,sysdate
               from(
                 select s.task_id,s.calc_date,d.count as count_day,s.count as count_month,case when s.count = d.count then 1 else 0 end as same
                   from 
                   (select * from nb_bill_task_month m where m.calc_date = :cd and exists (select 1 from nb_m_task t where t.id = m.task_id and t.agreement_id in(select id from nb_m_agreement where table_str like ''%'||num||'''))) s,
                   (select * from nb_bill_task_tmp where calc_date = :cd) d
                  where s.task_id = d.task_id and s.calc_date = d.calc_date 
               ) c
               where c.same=0';
  execute immediate sqlStr using trunc(startDate,'mm'),trunc(startDate,'mm');
  commit;
  create_procedure_log('calc_bill_month'||num, 'calc_bill_month end', 'run');
  
end calc_bill_month;


/

