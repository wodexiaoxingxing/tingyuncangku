create PROCEDURE "ADD_ET_LIST_BY_TABLESTR" (tablestr in number)
  authid current_user is
  type task_cursor is ref cursor;
  tasks task_cursor;
  sqlStr varchar2(4000);
  taskId number;
  v_s int;
begin
  select count(*) into v_s from user_tables where table_name ='NB_ET_URL_'||tableStr;
  IF (v_s = 0) then create_procedure_log('add_et_list_by_tablestr','该合同无元素表,tableStr：'||tablestr,'error'); return; end if;
  sqlStr := 'select id
                 from nb_m_task
                where agreement_id in
                      (select id from nb_m_agreement where table_str = '||tablestr||')
                  and status = 1
                  and expire > sysdate - 1
                  and task_option = ''F'' 
                  and id not in(select distinct task_id from nb_et_url_'||tablestr||')';
  open tasks for sqlStr;
  loop
    begin
       fetch tasks into taskId;
       exit when tasks%notfound;
       sqlStr :='insert into nb_et_url_'||tablestr||'
                    select url_id as id, task_id, domain_id,elem_type_id, (max(tm_base) - to_date(''2007-01-01'',''yyyy-mm-dd'')) * 86400 as mtime, count(*)+50 as point 
                      from nb_et_'||taskId||'
                      group by task_id, url_id, domain_id, elem_type_id';
       --dbms_output.put_line(sqlStr);
       execute immediate sqlStr;
       execute immediate 'commit';
    exception when  others then
       --DBMS_OUTPUT.PUT_LINE(v_error_desc);
       create_procedure_log('add_et_list_by_tablestr',sqlerrm ||',taskId:'||taskId,'error');
    end;
  end loop;
  close tasks;
 end add_et_list_by_tablestr;


/

