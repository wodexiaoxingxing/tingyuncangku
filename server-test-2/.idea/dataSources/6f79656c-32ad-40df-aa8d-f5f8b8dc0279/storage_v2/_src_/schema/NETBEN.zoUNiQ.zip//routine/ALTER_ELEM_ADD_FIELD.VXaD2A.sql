create PROCEDURE          "ALTER_ELEM_ADD_FIELD" 
is 
  sqlStr  varchar2(4000);  
  v_error_desc varchar2(4000);
  v_s number;
begin
  for tableName in(select t.table_name as name from user_tables t where t.table_name like 'NB_ELEM_%') loop
  begin
   
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TS_BLOCK';
      if v_s < 1 then
        DBMS_OUTPUT.PUT_LINE('alter ' ||tableName.Name);
        sqlStr := 'alter table '||tableName.Name||' add TS_BLOCK NUMBER';
        execute   immediate   sqlStr ;
      end if;
    
     select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='SOCKET_ID';
      if v_s < 1 then
        DBMS_OUTPUT.PUT_LINE('alter ' ||tableName.Name);
        sqlStr := 'alter table '||tableName.Name||' add SOCKET_ID NUMBER';
        execute   immediate   sqlStr ;
      end if;
      
     select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='BYTE_SENT';
      if v_s < 1 then
        DBMS_OUTPUT.PUT_LINE('alter ' ||tableName.Name);
        sqlStr := 'alter table '||tableName.Name||' add BYTE_SENT NUMBER';
        execute   immediate   sqlStr ;
      end if;  
      
           
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='DNS_RESOLVED';
      if v_s < 1 then
        DBMS_OUTPUT.PUT_LINE('alter ' ||tableName.Name);
        sqlStr := 'alter table '||tableName.Name||' add DNS_RESOLVED NUMBER';
        execute   immediate   sqlStr ;
      end if;
    
     select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='CONN_ESTABLISHED';
      if v_s < 1 then
        DBMS_OUTPUT.PUT_LINE('alter ' ||tableName.Name);
        sqlStr := 'alter table '||tableName.Name||' add CONN_ESTABLISHED NUMBER';
        execute   immediate   sqlStr ;
      end if;
      
     select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='REQUESTED';
      if v_s < 1 then
        DBMS_OUTPUT.PUT_LINE('alter ' ||tableName.Name);
        sqlStr := 'alter table '||tableName.Name||' add REQUESTED NUMBER';
        execute   immediate   sqlStr ;
      end if;  
    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlStr);
        create_procedure_log('alter_elem_add_field',v_error_desc,sqlcode);
  end;
  end loop;
end alter_elem_add_field;


/

