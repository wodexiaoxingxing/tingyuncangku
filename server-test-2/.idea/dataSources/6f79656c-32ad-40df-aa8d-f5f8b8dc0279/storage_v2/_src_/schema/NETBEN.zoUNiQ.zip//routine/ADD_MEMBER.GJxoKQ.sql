create procedure "ADD_MEMBER" (new_username in varchar2,
                                       new_password in varchar2,
                                       new_mbr_type in number,
                                       new_email    in varchar2) is
begin
  declare
    sid         integer;
    webPassHash varchar2(32);
    musername   varchar2(32);
    mpassword   varchar2(32);
    email       varchar2(32);
    mbrType     integer;
    mbrExist    integer;
  begin
    select MEMBER_ID_SEQ.nextval into sid from dual;
    -- 需要修改的地方 -- 开始
    -- 会员类型
    mbrType := new_mbr_type;
    -- 会员名
    musername := new_username;
    -- 密码
    mpassword := new_password;
    -- 需要修改的地方 -- 结束

    select NVL(count(*), 0)
      into mbrExist
      from nb_m_member m
     where m.username = musername;

    -- 判断用户名是否存在,存在不保存
    if mbrExist > 0 then
      SYS.dbms_output.put_line(concat('count: ', mbrExist));
      SYS.dbms_output.put_line(concat(concat('username : "', musername),
                                      '" is exists.'));
    else
      SYS.dbms_output.put_line(concat('new member username : "', musername));
      -- 保存
      -- MD5加密
      webPassHash := Utl_Raw.Cast_To_Raw(sys.dbms_obfuscation_toolkit.md5(input_string => concat(mpassword,
                                                                                                 musername)));
      webPassHash := lower(webPassHash);

      -- 下面的不用管
      insert into nb_m_member
        (PASS_LEVEL2_HASH,
         MBR_LEVEL,
         CTIME,
         MTIME,
         LAST_LOGIN,
         LAST_LOGIN_IP,
         STATUS,
         IF_BIND_CUSTOMER,
         CUSTOMER_ID,
         RECOMM_ID,
         WEBPASS_HASH,
         ID,
         USERNAME,
         PASSWORD_HASH,
         MBR_TYPE)
      values
        (null,
         1,
         sysdate,
         sysdate,
         null,
         0,
         1,
         0,
         0,
         0,
         webPassHash,
         sid,
         musername,
         webPasshash,
         mbrType);

      insert into nb_m_member_details
        (ID,
         STATUS,
         PASS_QUESTION,
         PASS_ANSWER,
         COUNTRY,
         REGION,
         CITY,
         ADDRESS,
         POSTALCODE,
         PHONE,
         MOBILE,
         EMAIL,
         QQ,
         MSN,
         CONN_TYPES,
         LOC_TYPES,
         ISP_TYPES,
         CTIME,
         MTIME,
         ACTIVE_CODE,
         SCORE,
         SCORE_MAX,
         COMPANY,
         CONTACT,
         BANK,
         BANK_ACCOUNT,
         BANK_ACCOUNT_NAME,
         ALIPAY,
         REG_EMAIL,
         REG_PHONE,
         ALIPAY_NAME,
         BOUND,
         LAST_MOBILE,
         ID_NUMBER)
      values
        (sid,
         0,
         null,
         null,
         0,
         0,
         0,
         null,
         null,
         null,
         null,
         new_email,
         null,
         null,
         null,
         null,
         null,
         sysdate,
         sysdate,
         null,
         0,
         0,
         null,
         null,
         null,
         null,
         null,
         null,
         new_email,
         null,
         null,
         0,
         null,
         null);

      insert into nb_m_score_balance
        (ID,
         MEMBER_ID,
         CDATE,
         SCORE,
         SCORE_BALANCE,
         DATA_POINTS,
         DATA_POINTS_TOTAL,
         REASON,
         CUSTOMER_ID,
         MONTH_NUM)
      values
        (SCORE_BAL_ID_SEQ.nextval,
         sid,
         sysdate,
         0,
         0,
         0,
         0,
         'BAT ADD',
         0,
         null);
    end if;
  end;
end;


/

