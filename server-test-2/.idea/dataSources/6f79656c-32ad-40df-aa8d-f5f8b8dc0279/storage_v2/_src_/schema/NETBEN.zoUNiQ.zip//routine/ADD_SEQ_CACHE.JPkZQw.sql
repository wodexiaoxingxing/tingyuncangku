create PROCEDURE          "ADD_SEQ_CACHE" authid current_user
is
  sqlStr  varchar2(4000);  
  v_name varchar2(400);
  v_error_desc varchar2(4000);
  CURSOR c_emp IS SELECT substr(t.object_name,9) FROM all_objects t where t.object_name like 'NB_ELEM_%';
begin
OPEN c_emp;
LOOP
  begin
    FETCH c_emp INTO v_name;
    EXIT WHEN c_emp%NOTFOUND;
    
    sqlStr:='alter sequence seq_nb_elem_id_'||v_name||' cache 500 noorder';
    DBMS_OUTPUT.PUT_LINE(sqlStr);
    execute immediate sqlStr;
   --如果创建失败，则显示出失败的表
   exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:' || sqlStr;
        DBMS_OUTPUT.PUT_LINE(v_error_desc);
        create_procedure_log('add_seq_cache',v_error_desc,sqlcode);
    end;
END LOOP;
CLOSE c_emp;  
end add_seq_cache;


/

