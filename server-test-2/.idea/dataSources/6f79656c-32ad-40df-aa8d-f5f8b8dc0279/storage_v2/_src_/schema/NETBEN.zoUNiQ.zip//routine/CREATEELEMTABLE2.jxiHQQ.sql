create PROCEDURE          "CREATEELEMTABLE2" (
  taskId in number
 ) authid current_user
is
  sqlStr  varchar2(8000);
  errorDesc varchar2(4000);
  ---------------- 主变量 ---------------------------------------------------------------------------
  createDate date := sysdate;
  orderNum   number;
  rangeDate  varchar2(128);
  partname1  varchar2(128);
  etd_partname1  varchar2(128);
  ett_partname1  varchar2(128);
  rangedate1 varchar2(128);
  partname2  varchar2(128);
  etd_partname2  varchar2(128);
  ett_partname2  varchar2(128);
  rangedate2 varchar2(128);
  partname3  varchar2(128);
  etd_partname3  varchar2(128);
  ett_partname3  varchar2(128);
  rangedate3 varchar2(128);
  --------------- 临时变量----------------------------------------------------------------------------
  s number;
begin
    create_procedure_log('createElemTable','create table:nb_et_'||taskId,'run');
    --判断是否该任务ID合法
    select count(*) into s from nb_m_task where id = taskId;
    if s=0 then
      create_procedure_log('createElemTable','task:'||taskId||'不存在','warning');
      --return;
    end if;
    --判断是否指定表已经建立
    select count(*) into s from user_tables where table_name ='NB_ET_'||taskId;
    if s>0 then
      create_procedure_log('createElemTable','table:nb_et_'||taskId||'已经存在','warning');
      --return;
    end if;
    --创建element
    --首先计算出elem的分区名称及值范围
     select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 8 - to_char( createDate,'d'),'d') from dual);
        partname1:='PART_ET_'||taskId||'_'||orderNum;
  etd_partname1:='PART_ETD_'||taskId||'_'||orderNum;
  ett_partname1:='PART_ETT_'||taskId||'_'||orderNum;
        rangedate1:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';
    select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 15 - to_char( createDate,'d'),'d') from dual);
        partname2:='PART_ET_'||taskId||'_'||orderNum;
  etd_partname2:='PART_ETD_'||taskId||'_'||orderNum;
  ett_partname2:='PART_ETT_'||taskId||'_'||orderNum;
        rangedate2:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';
    select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 22 - to_char( createDate,'d'),'d') from dual);
        partname3:='PART_ET_'||taskId||'_'||orderNum;
  etd_partname3:='PART_ETD_'||taskId||'_'||orderNum;
  ett_partname3:='PART_ETT_'||taskId||'_'||orderNum;
        rangedate3:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';


    --创建域名表
    sqlStr:='create table NB_ETD_'||taskId||'
    (
      PAGE_ID          NUMBER,
      TASK_ID          NUMBER,
      CITY_ID          NUMBER,
      ISP_ID           NUMBER,
      NET_SPEED_ID     NUMBER,
      TM_BASE          DATE,
      DOMAIN_ID        NUMBER,
    OS_VER_ID   INTEGER,
    BS_ID      INTEGER,
    BS_VER_ID    INTEGER,
      PROBE_IP         NUMBER,
      URL_IP           NUMBER,
      BYTE_TOTAL       NUMBER,
      TS_DNS           NUMBER,
      TS_CONNECT       NUMBER,
      TS_SSL           NUMBER,
      TS_REDIRECT      NUMBER,
      TS_REQUEST       NUMBER,
      TS_FIRST_PACKET  NUMBER,
      TS_REMAIN_PACKET NUMBER,
      TS_ELEMENT       NUMBER,
      TS_CLOSE         NUMBER,
      TS_BLOCK         NUMBER,
      BYTE_SENT        NUMBER,
      RATE_DOWNLOAD     NUMBER,
      RATE_UPLOAD     NUMBER,
      POINT_TOTAL     NUMBER,
      POINT_SUCC     NUMBER,
      POINT_DNS       NUMBER,
      POINT_CONN     NUMBER,
      POINT_SSL       NUMBER
    ) pctfree 0
    tablespace NETBEN_BG
    partition by range (TM_BASE)(
                  partition '||etd_partname1||' values less than ('||rangedate1||'),
                  partition '||etd_partname2||' values less than ('||rangedate2||'),
                  partition '||etd_partname3||' values less than ('||rangedate3||'))';
    execute   immediate   sqlStr;
    --域名索引 tm_base,domain_id
    sqlStr:='create index IDX_ETD_DID_'||taskId||' on NB_ETD_'||taskId||' (DOMAIN_ID,TM_BASE) local
            (partition '||etd_partname1||',partition '||etd_partname2||',partition '||etd_partname3||') compress 2 PCTFREE 0
            tableSpace  NETBEN_IND nologging';
    execute   immediate   sqlStr;

    --创建元素类型表
    sqlStr:='create table NB_ETT_'||taskId||'
    (
      PAGE_ID          NUMBER,
      TASK_ID          NUMBER,
      CITY_ID          NUMBER,
      ISP_ID           NUMBER,
      NET_SPEED_ID     NUMBER,
      TM_BASE          DATE,
      ELEM_TYPE_ID     NUMBER,
    OS_VER_ID   INTEGER,
    BS_ID      INTEGER,
    BS_VER_ID    INTEGER,
      PROBE_IP         NUMBER,
      BYTE_TOTAL       NUMBER,
      TS_DNS           NUMBER,
      TS_CONNECT       NUMBER,
      TS_SSL           NUMBER,
      TS_REDIRECT      NUMBER,
      TS_REQUEST       NUMBER,
      TS_FIRST_PACKET  NUMBER,
      TS_REMAIN_PACKET NUMBER,
      TS_ELEMENT       NUMBER,
      TS_CLOSE         NUMBER,
      TS_BLOCK         NUMBER,
      BYTE_SENT        NUMBER,
      RATE_DOWNLOAD     NUMBER,
      RATE_UPLOAD     NUMBER,
      POINT_TOTAL     NUMBER,
      POINT_SUCC     NUMBER,
      POINT_DNS       NUMBER,
      POINT_CONN     NUMBER,
      POINT_SSL       NUMBER
    ) pctfree 0
    tablespace NETBEN_BG
    partition by range (TM_BASE)(
                  partition '||ett_partname1||' values less than ('||rangedate1||'),
                  partition '||ett_partname2||' values less than ('||rangedate2||'),
                  partition '||ett_partname3||' values less than ('||rangedate3||'))';
    execute   immediate   sqlStr;

    --类型索引 tm_base,type_id
    sqlStr:='create index IDX_ETT_TID_'||taskId||' on NB_ETT_'||taskId||' (ELEM_TYPE_ID,TM_BASE) local
            (partition '||ett_partname1||',partition '||ett_partname2||',partition '||ett_partname3||') compress 2 PCTFREE 0
            tableSpace  NETBEN_IND nologging';
    execute   immediate   sqlStr;

    exception when  others then
        errorDesc := 'Error :'|| sqlerrm || '  taskId:' || taskId ;
        --DBMS_OUTPUT.PUT_LINE(v_error_desc);
        create_procedure_log('create_elem_task',errorDesc,'error');
end createElemTable2;


/

