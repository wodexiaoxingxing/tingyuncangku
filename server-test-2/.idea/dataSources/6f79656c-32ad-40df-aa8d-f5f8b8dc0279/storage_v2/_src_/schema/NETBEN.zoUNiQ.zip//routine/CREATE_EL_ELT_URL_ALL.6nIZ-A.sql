create procedure create_el_elt_url_all authid current_user is
sqlStr varchar2(4000);
errorDesc varchar2(4000);
c int;
begin
     for str in  (
        select substr(table_name,7) as table_str from user_tables where table_name like 'NB_EC_%')
     loop
        begin
            select count(*) into c from user_tables where table_name='NB_EL_URL_'||str.table_str;
              if c<1 then
                 -- sqlStr := 'drop table nb_el_url_'||str.table_str;
                 -- execute immediate sqlStr ;
                 test_create_el(str.table_str);
                 -- dbms_output.put_line('test_create_el('||str.table_str||')');
                 create_procedure_log('create_el_elt_url_all','test_create_el('||str.table_str||')','str.table_str');
              end if;
            select count(*) into c from user_tables where table_name='NB_ELT_URL_'||str.table_str;
              if c<1 then
                 -- sqlStr := 'drop table nb_elt_url_'||str.table_str;
                 -- execute immediate sqlStr ;
                 test_create_elt(str.table_str);
                 -- dbms_output.put_line('test_create_elt('||str.table_str||')');
                 create_procedure_log('create_el_elt_url_all','test_create_elt('||str.table_str||')','str.table_str');
               end if;
        exception when  others then
            errorDesc := sqlerrm || ',' || sqlStr;
            -- DBMS_OUTPUT.PUT_LINE(errorDesc);
            create_procedure_log('create_el_elt_url_all',errorDesc,'error');
        end;
    end loop;
end create_el_elt_url_all;


/

