create PROCEDURE          "CREATE_MV_INDEX" authid current_user
is
  sqlStr  varchar2(4000);
  v_name varchar2(400);
  v_error_desc varchar2(4000);
  v_s number;
  CURSOR c_emp IS SELECT substr(t.object_name,9) FROM all_objects t where t.object_name like 'NB_TRAN_%';
begin
OPEN c_emp;
LOOP
  begin
    FETCH c_emp INTO v_name;
    EXIT WHEN c_emp%NOTFOUND;
   
    --索引
	sqlStr:='create index IN_MV_TRAN_PERF_'||v_name||' on MV_TRAN_'||v_name||' (TASK_ID,TM_HOUR8, CITY_ID,  ISP_ID) tableSpace NETBEN_IDX';
    execute   immediate   sqlStr;


   --如果创建失败，则显示出失败的表
   exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:' || v_name;
        --DBMS_OUTPUT.PUT_LINE(v_error_desc);
        create_procedure_log('create_fast_mv_tran_all',v_error_desc,sqlcode);
    end;
END LOOP;

CLOSE c_emp;

end create_mv_index;


/

