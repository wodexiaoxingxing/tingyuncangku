create procedure incr_sequence(
  sequence_name in varchar2,
  incr in number
 ) authid current_user
is
  sqlStr  varchar2(8000);
  s number;
  curr_value number;
  incr_value number;
begin
    -- 创建临时表tmp_sequence_value
    select count(*) into s from user_tables where table_name = 'TMP_SEQUENCE_CHANGELOG';
    if s = 0 then
      sqlStr := 'create table TMP_SEQUENCE_CHANGELOG (seq_name varchar2(64), old_value number, new_value number, ctime date)';
      execute   immediate   sqlStr;
    end if;

    sqlStr := 'select ' || sequence_name || '.nextval - 1 from dual';
        execute   immediate   sqlStr into curr_value;
        -- dbms_output.put_line('execute: ' || sqlStr);
        commit;

    if incr < 1 then
      incr_value := ceil(curr_value * incr);
    else
      incr_value := incr - curr_value;
    end if;

    sqlStr := 'alter sequence ' || sequence_name || ' increment by ' || to_char(incr_value) || ' nocache';
        execute   immediate   sqlStr;
        -- dbms_output.put_line('execute: ' || sqlStr);

        sqlStr := 'select ' || sequence_name || '.nextval from dual';
        execute   immediate   sqlStr into s;
        -- dbms_output.put_line('execute: ' || sqlStr || ', result: ' || s);
        commit;

        sqlStr := 'alter sequence ' || sequence_name || ' increment by 1 cache 20';
        execute   immediate   sqlStr;
        -- dbms_output.put_line('execute: ' || sqlStr);
        commit;

        sqlStr := 'insert into TMP_SEQUENCE_CHANGELOG (seq_name, old_value, new_value, ctime) values (''' || sequence_name || ''', ' || to_char(curr_value) || ', ' || to_char(curr_value + incr_value) || ' , sysdate)';
        execute   immediate   sqlStr;
        -- dbms_output.put_line('execute: ' || sqlStr);
        commit;
end incr_sequence;


/

