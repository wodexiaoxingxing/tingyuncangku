create PROCEDURE "DEL_AGREEMENT" (
   aId in number
)authid current_user is
   sqlStr varchar2(4000);
   tableStr number;
   v_s int;
   type tmp_cursor is ref cursor;
   tasks tmp_cursor;
   taskId number;
   columnArr tmp_cursor;
   columnName varchar2(100);
   columnStr varchar2(4000);
   errorDesc varchar2(4000);
begin
   -- 合同ID找不到，直接返回
   select count(*) into v_s from nb_m_agreement where id = aId;
   if (v_s = 0) then create_procedure_log('del_agreement','合同ID未找到','error'); return; end if;
   -- 取出合同ID对的tableStr,可能会多个合同指向同一个tableStr,比如网上申请的，sina等

   select table_str into tableStr from nb_m_agreement where id = aId;
   if (tableStr is null) then tableStr := 0; end if;
   create_procedure_log('del_agreement','开始删除合同,合同ID：'||aId||',tableStr：'|| tableStr,'run');
   dbms_output.put_line('agreementId：'||aId||',table_str:'||tableStr);

   -- 首先判断合同是否可以删除（是否在crm表，是否有按点付费，套餐中最后过期日期在一年以内的
   -- 过期日期在一年内的不能删除
   select max(round(expire - (sysdate-365)))into v_s from nb_m_agree_detail where agreement_id = aId;
   if (v_s > 0) then create_procedure_log('del_agreement','合同过期后未过一年内不能删除,合同ID：'||aId,'error'); return; end if;
   -- 在crm系统中的，不能删除
   select count(*) into v_s from crm_agreement where id = aId;
   if (v_s > 0) then create_procedure_log('del_agreement','crm系统中的合同不能删除,合同ID：'||aId,'error'); return; end if;
   -- 有按点付费的不能删除
   select count(*) into v_s from nb_m_agree_detail where pay_way =1 and agreement_id = aId;
   if (v_s > 0) then create_procedure_log('del_agreement','有按点付费的套餐不能删除,合同ID：'||aId,'error'); return; end if;

   -- 一个tableStr对应多个合同的(试用合同)，不能删除表，只删除数据
   select count(*) into v_s from nb_m_agreement where table_str = tableStr and type = 4;
   if (v_s >1) then tableStr :=0; end if;

   -- 一个tableStr对应多个合同的(正式合同，新浪)，不能删除
   select count(*) into v_s from nb_m_agreement where table_str = tableStr and type != 4;
   if (v_s > 1) then create_procedure_log('del_agreement','多个合同且不是网上申请的，对应相同tableStr不能删除,合同ID：'||aId,'error'); return; end if;

   -- 在行业列表中的合同也不能删除
   select count(*) into v_s from nb_trade_list where table_str = tableStr;
   if (v_s > 0) then create_procedure_log('del_agreement','行业列表中的合同不能删除,合同ID：'||aId,'error'); return; end if;

   -- 为了安全，特殊指明新浪合同不能删除
   if (tableStr = 23771) then create_procedure_log('del_agreement','新浪的合同，不能删除,合同ID：'||aId,'error'); return; end if;

   -- 删除数据表
   -- 删除权限，元素及insight
   sqlStr:='delete from nb_m_agreement_right where agreement_id = :id';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 删除权限，cdn分析
   sqlStr:='delete from nb_m_cdn_config where agreement_id = :id';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 删除权限，api权限
   sqlStr:='delete from nb_m_chartapi_verify where user_id in(select id from nb_m_user where agree_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 删除权限，即时监测
   sqlStr:='delete from nb_m_instant_config where agreement_id = :id';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_instant_usage where agreement_id = :id';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 删除权限，自定义角色
   sqlStr:='delete from nb_m_role_user where user_id in(select id from nb_m_user where agree_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 删除权限，自定义私有协议
   sqlStr:='delete from nb_m_prot_user where user_id in(select id from nb_m_user where agree_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 删除权限，私有节点
   sqlStr:='delete from nb_m_member_agreement where agreement_id = :id';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);

   -- 业务相关表删除
   -- 警报
   sqlStr:='delete from nb_alarm_static where agreement_id = :id';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_alarm_log_static where task_id in(select id from nb_m_task where agreement_id =:id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_alarm_threshold where task_id in(select id from nb_m_task where agreement_id =:id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 报告
   sqlStr:='delete from nb_report_assistant_mail_log where report_id in(select id from nb_report_assistant where user_id in(select id from nb_m_user where agree_id = :id))';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_report_assistant_detail where report_assistant_id in(select id from nb_report_assistant where user_id in(select id from nb_m_user where agree_id = :id))';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_report_assistant where user_id in(select id from nb_m_user where agree_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- sqlStr:='delete from nb_report_assistant_favorites where user_id in(select id from nb_m_user where agree_id = :id)';
   -- execute immediate sqlStr using aId;
   -- dbms_output.put_line(sqlStr);
   --矩阵图
   sqlStr:='delete from nb_m_matrix_threshold where matrix_id in(select id from nb_m_matrix where user_id in(select id from nb_m_user where agree_id = :id))';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_matrix_isp_id where matrix_id in(select id from nb_m_matrix where user_id in(select id from nb_m_user where agree_id = :id))';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_matrix_city_id where matrix_id in(select id from nb_m_matrix where user_id in(select id from nb_m_user where agree_id = :id))';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_matrix where user_id in(select id from nb_m_user where agree_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 报表收藏
   sqlStr:='delete from nb_favorites where user_id in(select id from nb_m_user where agree_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);

   -- 配置数据相关
   -- 地图参数
   sqlStr:='delete from nb_map_option where user_id in(select id from nb_m_user where agree_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 汇总权重参数
   sqlStr:='delete from nb_rpc_weight_main where agreement_id = :id';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_rpc_weight_detail where main_id in(select id from nb_rpc_weight_main where agreement_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 首页性能图
   sqlStr:='delete from nb_user_24perf where user_id in(select id from nb_m_user where agree_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 过滤条件设置
   sqlStr:='delete from nb_trim_option where user_id in(select id from nb_m_user where agree_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);

   -- 节点组相关
   -- 节点组关联表(先删除)
   sqlStr:='delete from nb_m_grp_subgrp where grp_id in(select id from nb_m_probgrp where grp_type = 1 and id in(select probgrp_id from nb_m_task where id in(select id from nb_m_task where agreement_id = :id)))';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_grp_isp where grp_id in(select id from nb_m_probgrp where grp_type = 1 and id in(select probgrp_id from nb_m_task where id in(select id from nb_m_task where agreement_id = :id)))';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_grp_conn where grp_id in(select id from nb_m_probgrp where grp_type = 1 and id in(select probgrp_id from nb_m_task where id in(select id from nb_m_task where agreement_id = :id)))';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_grp_loc where grp_id in(select id from nb_m_probgrp where grp_type = 1 and id in(select probgrp_id from nb_m_task where id in(select id from nb_m_task where agreement_id = :id)))';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_grp_mbr where grp_id in(select id from nb_m_probgrp where grp_type = 1 and id in(select probgrp_id from nb_m_task where id in(select id from nb_m_task where agreement_id = :id)))';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_grp_mbt where grp_id in(select id from nb_m_probgrp where grp_type = 1 and id in(select probgrp_id from nb_m_task where id in(select id from nb_m_task where agreement_id = :id)))';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_grp_probeip where grp_id in(select id from nb_m_probgrp where grp_type = 1 and id in(select probgrp_id from nb_m_task where id in(select id from nb_m_task where agreement_id = :id)))';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 私有节点组
   sqlStr:='delete from nb_m_grp_pid where grp_id in(select id from nb_m_probgrp where grp_type in(1,4) and id in(select probgrp_id from nb_m_task where id in(select id from nb_m_task where agreement_id = :id)))';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_probe_alias where agreement_id = :id';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);


   -- 用户及权限相关
   -- 用户对应的角色
   sqlStr:='delete from nb_m_user_role where user_id in(select id from nb_m_user where agree_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 任务管理员对应套餐
   sqlStr:='delete from nb_m_user_detail where user_id in(select id from nb_m_user where agree_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 权限组
   sqlStr:='delete from nb_m_usergroup_user where user_id in(select id from nb_m_user where agree_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_usergroup_task where group_id in(select id from nb_m_usergroup where agreement_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_usergroup where agreement_id = :id';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 用户对应任务(以任务ID来删除，可能会有试用客户的任务指给其它人)
   sqlStr:='delete from nb_m_user_task where task_id in(select id from nb_m_task where agreement_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);


   -- 任务表相关的表
   -- 任务分类表
   sqlStr:='delete from nb_m_category_task where category_id in(select id from nb_m_category where agreement_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_category where agreement_id = :id';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 任务绑定表
   sqlStr:='delete from nb_m_task_bind_detail where bind_id in(select id from nb_m_task_bind where agreement_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_task_bind where agreement_id = :id';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 任务相关表
   -- 执行计划
   sqlStr:='delete from nb_m_task_schedule where task_id in(select id from nb_m_task where agreement_id = :id)
                                                 or agree_detail_id in(select id from nb_m_agree_detail where agreement_id = :id)';
   execute immediate sqlStr using aId,aId;
   dbms_output.put_line(sqlStr);
   -- 步骤
   sqlStr:='delete from nb_m_task_page_seq where task_id in(select id from nb_m_task where agreement_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 任务(排除相关)
   sqlStr:='delete from nb_m_task_ignore_hostid where task_id in(select id from nb_m_task where agreement_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_task_ignore_probe where task_id in(select id from nb_m_task where agreement_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_os_bs_filter where task_id in(select id from nb_m_task where agreement_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 任务（数据服务器)
   sqlStr:='delete from nb_m_task_datasvr where task_id in(select id from nb_m_task where agreement_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 任务对应的目标主机
   sqlStr:='delete from nb_m_task_dest where task_id in(select id from nb_m_task where agreement_id = :id)';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);

   -- 删除表
   -- tableStr = 0 时，不用删除表
   if (tableStr >0) then
     --tran
     select count(*) into v_s from user_tables where table_name ='NB_TRAN_'||tableStr;
     if (v_s > 0) then
       begin
         sqlStr:='drop materialized view log on nb_tran_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop materialized view mv_tran_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop table nb_tran_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop sequence seq_nb_tran_id_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop table lt_tran_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
       exception when  others then
         create_procedure_log('del_agreement',sqlerrm|| ',sql:'||sqlStr,'error');
       end;
     end if;
     -- page
     select count(*) into v_s from user_tables where table_name ='NB_PAGE_'||tableStr;
     if (v_s > 0) then
       begin
         sqlStr:='drop materialized view log on nb_page_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop materialized view mv_page_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop table nb_page_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop sequence seq_nb_page_id_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop table lt_page_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
       exception when  others then
         create_procedure_log('del_agreement',sqlerrm|| ',sql:'||sqlStr,'error');
       end;
     end if;

     -- Stream
     select count(*) into v_s from user_tables where table_name ='NB_STREAM_'||tableStr;
     if (v_s > 0) then
       begin
         sqlStr:='drop materialized view log on nb_stream_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop materialized view mv_stream_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop table nb_stream_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop sequence seq_nb_stream_id_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop table lt_stream_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         -- 播放速率
         select count(*) into v_s from user_tables where table_name ='NB_RATE_'||tableStr;
         if (v_s > 0) then
             sqlStr:='drop table nb_rate_'||tableStr;
             execute immediate sqlStr;
             dbms_output.put_line(sqlStr);
         end if;
       exception when  others then
         create_procedure_log('del_agreement',sqlerrm|| ',sql:'||sqlStr,'error');
       end;
     end if;
     -- Ping
     select count(*) into v_s from user_tables where table_name ='NB_PING_'||tableStr;
     if (v_s > 0) then
       begin
         sqlStr:='drop materialized view log on nb_ping_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop materialized view mv_ping_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop table nb_ping_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop sequence seq_nb_ping_id_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop table lt_ping_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
       exception when  others then
         create_procedure_log('del_agreement',sqlerrm|| ',sql:'||sqlStr,'error');
       end;
     end if;
     -- TraceRoute
     select count(*) into v_s from user_tables where table_name ='NB_TRACE_'||tableStr;
     if (v_s > 0) then
       begin
         sqlStr:='drop sequence seq_nb_trace_id_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop table nb_trace_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop table nb_route_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop table nb_route_stat_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
       exception when  others then
         create_procedure_log('del_agreement',sqlerrm|| ',sql:'||sqlStr,'error');
       end;
     end if;
     -- 私有协议
     select count(*) into v_s from user_tables where table_name ='NB_CUSTOM_'||tableStr;
     if (v_s > 0) then
       begin
         sqlStr:='drop sequence seq_nb_custom_id_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop materialized view log on nb_custom_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop materialized view mv_custom_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop table nb_custom_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop table lt_custom_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
       exception when  others then
         create_procedure_log('del_agreement',sqlerrm|| ',sql:'||sqlStr,'error');
       end;
     end if;
     -- 手机页面监测
     select count(*) into v_s from user_tables where table_name ='NB_MOB_TRAN_'||tableStr;
     if (v_s > 0) then
       begin
         -- mob tran
         sqlStr:='drop materialized view log on nb_mob_tran_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop materialized view mv_mob_tran_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop table nb_mob_tran_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop sequence seq_nb_mob_tran_id_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop table lt_mob_tran_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
       exception when  others then
         create_procedure_log('del_agreement',sqlerrm|| ',sql:'||sqlStr,'error');
       end;
     end if;
     select count(*) into v_s from user_tables where table_name ='NB_MOB_PAGE_'||tableStr;
     if (v_s > 0) then
       begin
         -- mob page
         sqlStr:='drop materialized view log on nb_mob_page_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop materialized view mv_mob_page_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop table nb_mob_page_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop sequence seq_nb_mob_page_id_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         sqlStr:='drop table lt_mob_page_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
       exception when  others then
         create_procedure_log('del_agreement',sqlerrm|| ',sql:'||sqlStr,'error');
       end;
     end if;


     -- 元素相关
     -- elem(兼容)
     select count(*) into v_s from user_tables where table_name ='NB_ELEM_'||tableStr;
     if (v_s > 0) then
         sqlStr:='drop table nb_elem_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         -- sqlStr:='drop sequence seq_nb_elem_id_'||tableStr;
         -- execute immediate sqlStr;
         -- dbms_output.put_line(sqlStr);
     end if;
     -- 后缀是tableStr的
     select count(*) into v_s from user_tables where table_name ='NB_EC_'||tableStr;
     if (v_s > 0) then
         sqlStr:='drop table nb_ec_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
     end if;
     select count(*) into v_s from user_tables where table_name ='NB_EE_'||tableStr;
     if (v_s > 0) then
         sqlStr:='drop table nb_ee_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
     end if;
     select count(*) into v_s from user_tables where table_name ='NB_ET_URL_'||tableStr;
     if (v_s > 0) then
         sqlStr:='drop table nb_et_url_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
     end if;
     select count(*) into v_s from user_tables where table_name ='NB_E_URL_'||tableStr;
     if (v_s > 0) then
         sqlStr:='drop table nb_e_url_'||tableStr;
         execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
     end if;
     -- 所有元素表
     sqlStr := 'select id from nb_m_task where agreement_id = '|| aId;
     open tasks for sqlStr;
     loop
       begin
         fetch tasks into taskId;
         exit when tasks%notfound;
         select count(*) into v_s from user_tables where table_name ='NB_ET_'||taskId;
         if (v_s > 0) then
            sqlStr:='drop table nb_et_'||taskId;
            execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         end if;
         select count(*) into v_s from user_tables where table_name ='NB_ETT_'||taskId;
         if (v_s > 0) then
            sqlStr:='drop table nb_ett_'||taskId;
            execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         end if;
         select count(*) into v_s from user_tables where table_name ='NB_ETD_'||taskId;
         if (v_s > 0) then
            sqlStr:='drop table nb_etd_'||taskId;
            execute immediate sqlStr;
         dbms_output.put_line(sqlStr);
         end if;
       exception when  others then
         errorDesc := sqlerrm ||',taskId:'||taskId;
         create_procedure_log('del_agreement',errorDesc|| ',sql:'||sqlStr,'error');
       end;
     end loop;
     close tasks;
    end if;
    -- 备份数据
    -- 用户表
    begin
      sqlStr := 'select column_name from user_tab_columns where table_name = ''NB_M_USER_HIS''';
      open columnArr for sqlStr;
      loop
           fetch columnArr into columnName;
           exit when columnArr%notfound;
           columnStr:=columnName||','||columnStr;
      end loop;
      columnStr:=substr(columnStr,1,length(columnStr)-1);
      sqlStr:='insert into nb_m_user_his('||columnStr||') select '||columnStr||' from nb_m_user where agree_id = :id';
      -- dbms_output.put_line(sqlStr);
      execute immediate sqlStr using aId;
      close columnArr;
      -- 任务表
      columnName:='';
      columnStr:='';
      sqlStr := 'select column_name from user_tab_columns where table_name = ''NB_M_TASK_HIS''';
      open columnArr for sqlStr;
      loop
           fetch columnArr into columnName;
           exit when columnArr%notfound;
           columnStr:=columnName||','||columnStr;
      end loop;
      columnStr:=substr(columnStr,1,length(columnStr)-1);
      sqlStr:='insert into nb_m_task_his('||columnStr||') select '||columnStr||' from nb_m_task where agreement_id = :id';
      -- dbms_output.put_line(sqlStr);
      execute immediate sqlStr using aId;
      close columnArr;
      -- 套餐表
      columnName:='';
      columnStr:='';
      sqlStr := 'select column_name from user_tab_columns where table_name = ''NB_M_AGREE_DETAIL_HIS''';
      open columnArr for sqlStr;
      loop
           fetch columnArr into columnName;
           exit when columnArr%notfound;
           columnStr:=columnName||','||columnStr;
      end loop;
      columnStr:=substr(columnStr,1,length(columnStr)-1);
      sqlStr:='insert into nb_m_agree_detail_his('||columnStr||') select '||columnStr||' from nb_m_agree_detail where agreement_id = :id';
      -- dbms_output.put_line(sqlStr);
      execute immediate sqlStr using aId;
      close columnArr;
      -- 合同表
      columnName:='';
      columnStr:='';
      sqlStr := 'select column_name from user_tab_columns where table_name = ''NB_M_AGREEMENT_HIS''';
      open columnArr for sqlStr;
      loop
           fetch columnArr into columnName;
           exit when columnArr%notfound;
           columnStr:=columnName||','||columnStr;
      end loop;
      columnStr:=substr(columnStr,1,length(columnStr)-1);
      sqlStr:='insert into nb_m_agreement_his('||columnStr||') select '||columnStr||' from nb_m_agreement where id = :id';
      -- dbms_output.put_line(sqlStr);
      execute immediate sqlStr using aId;
      close columnArr;
      -- 节点组表
      columnName:='';
      columnStr:='';
      sqlStr := 'select column_name from user_tab_columns where table_name = ''NB_M_PROBGRP_HIS''';
      open columnArr for sqlStr;
      loop
           fetch columnArr into columnName;
           exit when columnArr%notfound;
           columnStr:=columnName||','||columnStr;
      end loop;
      columnStr:=substr(columnStr,1,length(columnStr)-1);
      sqlStr:='insert into nb_m_probgrp_his('||columnStr||') select '||columnStr||' from nb_m_probgrp where grp_type in(1,4) and id in(select probgrp_id from nb_m_task where id in(select id from nb_m_task where agreement_id = :id))';
      -- dbms_output.put_line(sqlStr);
      execute immediate sqlStr using aId;
      close columnArr;
    exception when  others then
         create_procedure_log('del_agreement',sqlerrm|| ',sql:'||sqlStr,'error');
    end;
   -- 关键表最后删除
   -- 节点组主表(只删除自定义节点组)
   sqlStr:='delete from nb_m_probgrp where grp_type in(1,4) and id in(select probgrp_id from nb_m_task where id in(select id from nb_m_task where agreement_id = :id))';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   -- 用户表
   sqlStr:='delete from nb_m_user where agree_id = :id';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);

   -- 任务主表
   sqlStr:='delete from nb_m_task where agreement_id = :id';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);

   --删除套餐
   sqlStr:='delete from nb_m_agree_change where agreement_id = :id';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   sqlStr:='delete from nb_m_agree_detail where agreement_id = :id';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   --删除合同
   sqlStr:='delete from nb_m_agreement where id = :id';
   execute immediate sqlStr using aId;
   dbms_output.put_line(sqlStr);
   commit;
   create_procedure_log('del_agreement','删除合同完成,合同ID：'||aId||',tableStr：'|| tableStr,'run');
exception when  others then
   errorDesc := 'End error,' || sqlerrm  ;
   create_procedure_log('del_agreement',errorDesc|| ',sql:'||sqlStr,'error');
   rollback;
end del_agreement;


/

