create PACKAGE          "PKG_IBRTEST1" as
  type rc_cursor is ref cursor;

procedure MY_GET_MBR_PROC(cc out rc_cursor);
end PKG_IBRTEST1;


/

