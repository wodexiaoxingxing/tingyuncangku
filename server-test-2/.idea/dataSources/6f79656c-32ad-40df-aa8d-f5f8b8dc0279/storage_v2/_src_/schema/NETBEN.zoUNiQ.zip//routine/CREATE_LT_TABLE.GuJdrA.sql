create PROCEDURE          "CREATE_LT_TABLE" authid current_user
is
   sqlStr varchar2(4000);
   v_s number;
begin
create_procedure_log('create_lt_table','begin','message');
for item in (select substr(t.table_name, 9) as name from user_tables t where t.table_name like 'NB_TRAN_%') loop
   --判断是否该表已经创建
   select count(*) into v_s from user_tables t where t.table_name = 'LT_TRAN_'||item.name;
   if v_s < 1 then
       --表不存在，创建新表
        sqlStr:='create table LT_TRAN_'||item.name||'
		     (
		        TASK_ID        NUMBER NOT NULL,
		        CITY_ID        NUMBER NOT NULL,
		        ISP_ID         NUMBER NOT NULL,
		        NET_SPEED_ID   NUMBER NOT NULL,
            TM_DAY         DATE,
		        ERROR_CODE     NUMBER DEFAULT 0,
            PING_ERROR	   NUMBER DEFAULT 0,
            POINT_TOTAL    NUMBER DEFAULT 1,
    		    TS_TOTAL       NUMBER DEFAULT 0,
		        TS_PING_AVG    NUMBER DEFAULT 0,
            PING_PACKET_LOST NUMBER DEFAULT 0
		      )';
         execute   immediate   sqlStr;
         --创建索引
	       sqlStr:='create index IN_LT_TRAN_PERF_'||item.name||' on LT_TRAN_'||item.name||' (task_id,tm_day,city_id,isp_id,error_code) tableSpace NETBEN_IDX';
	       execute   immediate   sqlStr;
         create_procedure_log('create_lt_table','Create lt_tran'||item.name,'message');
     end if;
end loop;

for item in (select substr(t.table_name, 9) as name from user_tables t where t.table_name like 'NB_PAGE_%') loop
   --判断是否该表已经创建
   select count(*) into v_s from user_tables t where t.table_name = 'LT_PAGE_'||item.name;
   if v_s < 1 then
       --表不存在，创建新表
       sqlStr:='create table LT_PAGE_'||item.name||'
		       (
      		 TASK_ID        NUMBER NOT NULL,
		       CITY_ID        NUMBER NOT NULL,
		       ISP_ID         NUMBER NOT NULL,
		       NET_SPEED_ID   NUMBER NOT NULL,
		       TM_DAY         DATE,
           PAGE_SEQ       NUMBER DEFAULT 1,
           ERROR_CODE     NUMBER DEFAULT 0,
           POINT_TOTAL    NUMBER DEFAULT 1,
           BYTE_TOTAL     NUMBER DEFAULT 0,
           RATE_DOWNLOAD  NUMBER DEFAULT 0,
           TS_TOTAL       NUMBER DEFAULT 0,
           TS_DNS         NUMBER DEFAULT 0,
           TS_CONNECT     NUMBER DEFAULT 0,
           TS_FIRST_PACKET NUMBER DEFAULT 0,
           TS_USER        NUMBER,
           BYTE_PAGE_BASE NUMBER,
           RATE_DOWNLOAD_PAGE_BASE NUMBER,
           NUM_FIRST_ELEM NUMBER,
           BYTE_FIRST NUMBER,
           NUM_DOM NUMBER
		       )';
         execute   immediate   sqlStr;
         --创建索引
         sqlStr:='create index IN_LT_PAGE_PERF_'||item.name||' on LT_PAGE_'||item.name||' (task_id,tm_day,city_id,isp_id,error_code) tableSpace netben_idx';
	       execute   immediate   sqlStr;
         create_procedure_log('create_lt_table','Create lt_page'||item.name,'message');
     end if;
end loop;

for item in (select substr(t.table_name, 11) as name from user_tables t where t.table_name like 'NB_STREAM_%') loop
   --判断是否该表已经创建
   select count(*) into v_s from user_tables t where t.table_name = 'LT_STREAM_'||item.name;
   if (v_s<1) then
       --表不存在，创建新表
       sqlStr:='create table LT_STREAM_'||item.name||'
		       (
      		 TASK_ID        NUMBER NOT NULL,
		       CITY_ID        NUMBER NOT NULL,
		       ISP_ID         NUMBER NOT NULL,
		       NET_SPEED_ID   NUMBER NOT NULL,
		       TM_DAY         DATE,
           ERROR_CODE     NUMBER DEFAULT 0,
           POINT_TOTAL    NUMBER DEFAULT 1,
           TS_TOTAL       NUMBER DEFAULT 0,
           TS_CONNECT     NUMBER DEFAULT 0,
           TS_BUFFER      NUMBER DEFAULT 0,
           TS_REBUFFER    NUMBER DEFAULT 0,
           BUFFER_COUNT   NUMBER DEFAULT 0
		       )';
         execute   immediate   sqlStr;
         --创建索引
         sqlStr:='create index IN_LT_STREAM_PERF_'||item.name||' on LT_STREAM_'||item.name||' (task_id,tm_day,city_id,isp_id,error_code) tableSpace netben_idx';
	       execute   immediate   sqlStr;
         create_procedure_log('create_lt_table','Create lt_stream'||item.name,'message');
     end if;
end loop;
create_procedure_log('create_lt_table','end','message');
end create_lt_table;


/

