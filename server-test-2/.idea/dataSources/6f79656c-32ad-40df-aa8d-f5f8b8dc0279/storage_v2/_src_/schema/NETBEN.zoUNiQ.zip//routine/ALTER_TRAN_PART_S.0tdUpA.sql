create PROCEDURE          "ALTER_TRAN_PART_S" 
(tableStr IN varchar2) authid current_user
is
  sqlStr  varchar2(4000);
  v_is_part varchar2(32); 
  v_s number;
begin
  -- 判断是否该表已经做过分区
  select t.partitioned into v_is_part from user_tables t where t.table_name = 'NB_TRAN_'||tableStr;
  dbms_output.put_line(v_is_part);
  if v_is_part = 'YES' then return; end if;
  dbms_output.put_line('begin create table');
  sqlStr:='create table NB_TRAN_'||tableStr||'_temp
		(
		  ID             NUMBER not null,
		  TASK_ID        NUMBER,
		  CITY_ID        NUMBER,
		  ISP_ID         NUMBER,
		  NET_SPEED_ID   NUMBER,
		  TM_BASE        DATE,
		  TM_HOUR        DATE,
		  TM_DAY         DATE,
		  TM_HALF_HOUR   DATE,
		  PROBE_IP       NUMBER,
		  ERROR_CODE     NUMBER,
		  CONT_ERR_TOTAL NUMBER,
		  ERROR_PAGE_SEQ NUMBER,
		  PAGE_TOTAL     NUMBER,
		  BYTE_TOTAL     NUMBER,
		  TS_TOTAL       NUMBER,
		  TS_NETWORK     NUMBER,
		  TS_PING_AVG    NUMBER,		  
		  TS_PING_START  NUMBER,
		  PING_ERROR	 NUMBER,
		  POINT_TOTAL    NUMBER default 1,
		  DNS_SERVER	 VARCHAR2(39),
		  DEST_IP        VARCHAR2(39),
		  MEMBER_ID		 NUMBER,
		  IS_NOISE		 NUMBER
		)
		partition by range (TM_BASE)
 (
  partition part_tran_'||tableStr||'_25 values less than (TO_DATE(''2008-04-20'', ''YYYY-MM-DD'')),
  partition part_tran_'||tableStr||'_26 values less than (TO_DATE(''2008-04-27'', ''YYYY-MM-DD'')),
  partition part_tran_'||tableStr||'_27 values less than (TO_DATE(''2008-05-04'', ''YYYY-MM-DD'')),
  partition part_tran_'||tableStr||'_28 values less than (TO_DATE(''2008-05-11'', ''YYYY-MM-DD'')),
  partition part_tran_'||tableStr||'_29 values less than (TO_DATE(''2008-05-18'', ''YYYY-MM-DD'')),
  partition part_tran_'||tableStr||'_30 values less than (TO_DATE(''2008-05-25'', ''YYYY-MM-DD'')),
  partition part_tran_'||tableStr||'_31 values less than (TO_DATE(''2008-06-01'', ''YYYY-MM-DD'')),
  partition part_tran_'||tableStr||'_32 values less than (TO_DATE(''2008-06-08'', ''YYYY-MM-DD'')),
  partition part_tran_'||tableStr||'_33 values less than (TO_DATE(''2008-06-15'', ''YYYY-MM-DD'')),
  partition part_tran_'||tableStr||'_34 values less than (TO_DATE(''2008-06-22'', ''YYYY-MM-DD'')),
  partition part_tran_'||tableStr||'_35 values less than (TO_DATE(''2008-06-29'', ''YYYY-MM-DD''))
 )';
  execute immediate sqlStr;
  
  -- 2.删除原表的物化视图
    --先删除日志
    sqlStr := 'drop materialized view log on nb_tran_'||tableStr;
    execute immediate sqlStr;
    --再删除物化视图
    sqlStr := 'drop materialized view mv_tran_'||tableStr;
    execute immediate sqlStr;
    
  --3.检查原始表能否在线重定义,采用rowid方式  用系统管理员执行
  dbms_output.put_line('DBMS_REDEFINITION.CAN_REDEF_TABLE');
  DBMS_REDEFINITION.CAN_REDEF_TABLE('NETBEN', 'NB_TRAN_'||tableStr, DBMS_REDEFINITION.cons_use_rowid); 
  
  --4.执行在线重新定义 系统管理员执行
  dbms_output.put_line('DBMS_REDEFINITION.START_REDEF_TABLE');
  DBMS_REDEFINITION.START_REDEF_TABLE('NETBEN', 'NB_TRAN_'||tableStr, 'NB_TRAN_'||tableStr||'_TEMP', '', DBMS_REDEFINITION.cons_use_rowid); 
  
  
  --5.执行数据同步 系统管理员执行
  dbms_output.put_line('DBMS_REDEFINITION.sync_interim_table');
  DBMS_REDEFINITION.sync_interim_table('NETBEN', 'NB_TRAN_'||tableStr, 'NB_TRAN_'||tableStr||'_TEMP');
  --执行两次
  DBMS_REDEFINITION.sync_interim_table('NETBEN', 'NB_TRAN_'||tableStr, 'NB_TRAN_'||tableStr||'_TEMP');
  
  --6.完成在线重新定义 系统管理员执行
  dbms_output.put_line('DBMS_REDEFINITION.FINISH_REDEF_TABLE');
  DBMS_REDEFINITION.FINISH_REDEF_TABLE('NETBEN', 'NB_TRAN_'||tableStr, 'NB_TRAN_'||tableStr||'_TEMP');
  
  
  --删除临时表
  sqlStr:='drop table nb_tran_'||tableStr||'_temp';
  execute immediate sqlStr;
  
  --7.创建一个local 索引 及主键
  --先判断是否同名索引存在，如果存在，则删除
  
  sqlStr:='alter table NB_TRAN_'||tableStr||'  add constraint PK_NB_TRAN_'||tableStr||' primary key (ID) using index';
  execute immediate sqlStr;
  
  select count(*) into v_s from user_indexes t where t.index_name='IN_TRAN_PERF_'||tableStr;
  if v_s > 0 then 
      sqlStr:='drop index IN_TRAN_PERF_'||tableStr;
      execute immediate sqlStr;
  end if;
  sqlStr:='create index in_tran_perf_'||tableStr||' on nb_tran_'||tableStr||'(task_id,tm_base,city_id,isp_id) local
   (partition part_tran_'||tableStr||'_25,
    partition part_tran_'||tableStr||'_26,
    partition part_tran_'||tableStr||'_27,
    partition part_tran_'||tableStr||'_28,
    partition part_tran_'||tableStr||'_29,
    partition part_tran_'||tableStr||'_30,
    partition part_tran_'||tableStr||'_31,
    partition part_tran_'||tableStr||'_32,
    partition part_tran_'||tableStr||'_33,
    partition part_tran_'||tableStr||'_34,
    partition part_tran_'||tableStr||'_35
    )tablespace netben_idx'; 
  execute immediate sqlStr;
  
  
    
  --8.创建物化视图日志
  sqlStr:='create materialized view log on NB_TRAN_'||tableStr||' with rowid,
		sequence (task_id,
				city_id,
				isp_id,
				net_speed_id,
				error_code,
				ping_error,
				is_noise,
				tm_hour,
				point_total,
				ts_total,
				ts_ping_avg) including new values';
    execute immediate sqlStr;  
    
     --9.创建物化视图			
sqlStr:='create materialized view MV_TRAN_'||tableStr||'
		refresh fast
		start with sysdate next sysdate + 4/24 
		as
		(select task_id,
		    city_id,
		    isp_id,
		    net_speed_id,
		    error_code,
		    ping_error,
        	is_noise,
	        (tm_hour - mod(to_number(to_char(tm_hour, ''hh24'')) + 8, 8) / 24) as tm_hour8,
    	    (tm_hour - mod(to_number(to_char(tm_hour, ''hh24'')) + 12, 12) / 24) as tm_hour12,
        	trunc(tm_hour, ''dd'') as tm_day,
	        count(*) as c1,
    	    count(point_total) as c2,
        	count(ts_total) as c3,
	        count(ts_ping_avg) as c4,
		    sum(point_total) as point_total,
		    avg(ts_total) as ts_total,
			avg(ts_ping_avg) as ts_ping_avg
		from NB_TRAN_'||tableStr||' 
		group by task_id,
			city_id,
			isp_id,
			net_speed_id,
			error_code,
			ping_error,
			is_noise,
			(tm_hour - mod(to_number(to_char(tm_hour, ''hh24'')) + 8, 8) / 24),
			(tm_hour - mod(to_number(to_char(tm_hour, ''hh24'')) + 12, 12) / 24),
			trunc(tm_hour, ''dd''))';
      execute immediate sqlStr;  
      
--10.创建物化视图索引
	sqlStr:='create index IN_MV_TRAN_PERF_'||tableStr||' on MV_TRAN_'||tableStr||' (TASK_ID,TM_HOUR8, CITY_ID,ISP_ID) tableSpace NETBEN_IDX';       
  execute immediate sqlStr;  
        
end alter_tran_part_s;


/

