create trigger UPDATE_A_COUNT_ONHAND
    after insert
    on NB_A_COUNT_TRAN
    for each row
declare
  -- local variables here
  sqlStr varchar2(4000);
begin
  --1 设置追加 2设置减少 3使用减少 4删除使用增加 5执行失败增加
  if (:new.tran_type = 1) then
      merge into nb_a_count_onhand s using 
         (select :new.agreement_id as agreement_id from dual) g 
         on (g.agreement_id = s.agreement_id) 
         when matched then update set count_total=count_total+:new.count,count_remain=count_remain+:new.count 
         when not matched then insert values(:new.agreement_id,:new.count,0,:new.count,:new.ctime);
  elsif(:new.tran_type = 2) then
     update nb_a_count_onhand set count_total=count_total-:new.count,count_remain=count_remain-:new.count 
     where  agreement_id = :new.agreement_id;
  elsif(:new.tran_type = 3) then
     update nb_a_count_onhand set count_used=count_used+:new.count,count_remain=count_remain-:new.count 
     where  agreement_id = :new.agreement_id;
  elsif(:new.tran_type = 4) then
     update nb_a_count_onhand set count_used=count_used-:new.count,count_remain=count_remain+:new.count 
     where  agreement_id = :new.agreement_id;  
  elsif(:new.tran_type = 5) then
     update nb_a_count_onhand set count_used=count_used-:new.count,count_remain=count_remain+:new.count 
     where  agreement_id = :new.agreement_id; 
  end if;
end update_a_count_onhand;


/

