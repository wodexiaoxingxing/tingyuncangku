create procedure in_lt_tran_period(sd date,days number) authid current_user
is
   sqlStr varchar2(4000);
   startDate date;
   endDate date;
   errorDesc varchar2(4000);
   v_s number;
begin
if sd is null or days is null then
  startDate:=trunc(sysdate-1,'dd');
  endDate:=startDate+1;
else
  startDate:=trunc(sd,'dd');
  endDate:=startDate+days;
end if;
dbms_output.put_line(startDate||','||days);
create_procedure_log('in_lt_tran_period','begin','run');
for item in (select substr(t.table_name, 9) as name from user_tables t where t.table_name like 'NB_TRAN_%') loop
begin
   create_procedure_log('in_lt_tran_period','tableStr:'||item.name,'run');
   --判断是否该表已经创建
   select count(*) into v_s from user_tables t where t.table_name = 'LT_TRAN_'||item.name;
   if (v_s<1) then
       --表不存在，创建新表
        sqlStr:='create table LT_TRAN_'||item.name||'
		     (
		        TASK_ID        NUMBER NOT NULL,
		        CITY_ID        NUMBER NOT NULL,
		        ISP_ID         NUMBER NOT NULL,
		        NET_SPEED_ID   NUMBER NOT NULL,
						dest_city_id   number,
						dest_isp_id    number,
						dest_ip        VARCHAR2(39),
            TM_DAY         DATE,
		        ERROR_CODE     NUMBER DEFAULT 0,
            PING_ERROR	   NUMBER DEFAULT 0,
            POINT_TOTAL    NUMBER DEFAULT 1,
    		    TS_TOTAL       NUMBER DEFAULT 0,
		        TS_PING_AVG    NUMBER DEFAULT 0,
            PING_PACKET_LOST NUMBER DEFAULT 0,
						byte_total     number DEFAULT 0
		      )';
         execute   immediate   sqlStr;
         --创建索引
	       sqlStr:='create index IN_LT_TRAN_PERF_'||item.name||' on LT_TRAN_'||item.name||' (task_id,tm_day,city_id,isp_id,error_code) tableSpace netben_ind';
	       execute   immediate   sqlStr;
     end if;

  --删除指定日期的长期库中的数据,防止重复数据
  sqlStr := 'delete from lt_tran_'||item.name||' where tm_day  >=:sDate and tm_day < :eDate';
  execute immediate sqlStr using startDate,endDate;
  commit;

  --从实时库中插入指定日期的数据
  sqlStr:='insert into lt_tran_'||item.name||'
           (task_id,city_id,isp_id,	dest_city_id,dest_isp_id,dest_ip,net_speed_id,tm_day,error_code,
            ping_error,point_total,ts_total,ts_ping_avg,ping_packet_lost,byte_total)
        select
		       task_id,
		       city_id,
		       isp_id,
					 dest_city_id,
					 dest_isp_id,
					 dest_ip,
		       net_speed_id,
		       trunc(tm_base,''dd'') as tm_day,
           error_code,
           (case when ping_error=0 then 0 else -1 end) as ping_error,
		       sum(point_total),
           round(avg(ts_total),0) as ts_total,
           round(avg(ts_ping_avg),0) as ts_ping_avg,
           round(avg(ping_packet_lost),0) as ping_packet_lost,
					 round(avg(byte_total),0) as byte_total
		    from NB_TRAN_'||item.name||'
           where tm_base >= :sDate and  tm_base < :eDate and is_noise = 0
		       group by task_id,
		                city_id,
		                isp_id,
										dest_city_id,
										dest_isp_id,
										dest_ip,
		                net_speed_id,
                    trunc(tm_base,''dd''),
		                error_code,
                    ping_error
		    ';
       execute immediate sqlStr using startDate,endDate;
       commit;
     exception when  others then
        errorDesc := 'Tabel Str ' || item.name || ' Error Code:'|| sqlcode || '  Sql:' ;
        create_procedure_log('in_lt_tran_period',errorDesc,'error');
  end;
end loop;
create_procedure_log('in_lt_tran_period','end','run');
end in_lt_tran_period;
/

