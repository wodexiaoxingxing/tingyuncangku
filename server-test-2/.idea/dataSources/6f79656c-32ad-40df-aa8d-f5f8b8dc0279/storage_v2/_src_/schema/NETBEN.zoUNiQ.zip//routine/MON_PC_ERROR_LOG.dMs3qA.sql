create PROCEDURE "MON_PC_ERROR_LOG"
( procName IN varchar2,
  descr IN varchar2,
  errorCode IN varchar2
)
 authid current_user
 is
   sqlStr varchar2(4000);
begin
   sqlStr:='insert into MON_ERROR_LOG values(SEQ_ERROR_LOG.Nextval,
                '''||procName||''','''||descr||''','''||errorCode||''',sysdate)';
    execute   immediate  sqlStr;
    commit;
end MON_PC_ERROR_LOG;


/

