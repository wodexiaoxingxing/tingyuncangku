create PROCEDURE "IN_TOP_EL_ERROR_SCHEDULE"  authid current_user is
  errorDesc varchar2(4000);
  calcDate date;
begin
  create_procedure_log('in_top_el_error_schedule', 'begin', 'run');
  calcDate := sysdate -1;
  --循环，查寻出所有的表
  for task in (select distinct task_id from nb_top_hit where ctime >sysdate -7)  loop
    begin
      --DBMS_OUTPUT.PUT_LINE('tableStr:' || task.table_str || ' taskId:' || task.id);
      in_top_el_error(calcDate,task.task_id);
    exception
      when others then
        errorDesc := 'taskId:' || task.task_id ||'Error:' || sqlerrm;
        --DBMS_OUTPUT.PUT_LINE(errorDesc);
        create_procedure_log('in_top_el_error_schedule', errorDesc, 'error');
    end;
  end loop;
end in_top_el_error_schedule;


/

