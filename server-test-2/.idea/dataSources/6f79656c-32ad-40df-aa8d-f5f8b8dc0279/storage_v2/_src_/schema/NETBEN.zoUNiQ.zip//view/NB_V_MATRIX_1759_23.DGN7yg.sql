create view NB_V_MATRIX_1759_23 as
SELECT t.task_id, t.isp_id,
	SUM(CASE WHEN e.err_type = 3 THEN 0 ELSE t.ts_total END) AS perf,
	COUNT(CASE WHEN e.err_type = 3 THEN NULL ELSE 1 END) AS succ,
	COUNT(1) AS total
FROM NB_TRAN_1759 t
	 LEFT JOIN NB_M_ERROR e ON t.error_code = e.err_code
WHERE t.task_id IN (1109,1128) AND t.tm_base > sysdate - interval '15' MINUTE AND t.isp_id IN (16,17,18,19,20,21,22,23) AND t.is_noise = 0
GROUP BY t.task_id, t.isp_id
ORDER BY t.task_id, t.isp_id


/

