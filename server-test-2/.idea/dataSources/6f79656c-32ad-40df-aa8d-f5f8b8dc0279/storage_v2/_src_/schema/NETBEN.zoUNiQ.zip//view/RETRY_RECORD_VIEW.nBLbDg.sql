create view RETRY_RECORD_VIEW as
select r0."ID",r0."MEASUREMENT_ID",r0."TASK_TYPE",r0."VERSION_ID",r0."RETRIES",r0."RETRY_DATE",r0."RESULT",r0."TOPIC",r0."PARTITION",r0."OFFSET",r0."CTIME",r0."MTIME" , 0 as table_index from Retry_Record_0 r0
 union all
 select r1."ID",r1."MEASUREMENT_ID",r1."TASK_TYPE",r1."VERSION_ID",r1."RETRIES",r1."RETRY_DATE",r1."RESULT",r1."TOPIC",r1."PARTITION",r1."OFFSET",r1."CTIME",r1."MTIME" , 1 as table_index from Retry_Record_1 r1
 union all
 select r2."ID",r2."MEASUREMENT_ID",r2."TASK_TYPE",r2."VERSION_ID",r2."RETRIES",r2."RETRY_DATE",r2."RESULT",r2."TOPIC",r2."PARTITION",r2."OFFSET",r2."CTIME",r2."MTIME" , 2 as table_index from Retry_Record_2 r2
 union all
 select r3."ID",r3."MEASUREMENT_ID",r3."TASK_TYPE",r3."VERSION_ID",r3."RETRIES",r3."RETRY_DATE",r3."RESULT",r3."TOPIC",r3."PARTITION",r3."OFFSET",r3."CTIME",r3."MTIME" , 3 as table_index from Retry_Record_3 r3
 union all
 select r4."ID",r4."MEASUREMENT_ID",r4."TASK_TYPE",r4."VERSION_ID",r4."RETRIES",r4."RETRY_DATE",r4."RESULT",r4."TOPIC",r4."PARTITION",r4."OFFSET",r4."CTIME",r4."MTIME" , 4 as table_index from Retry_Record_4 r4
 union all
 select r5."ID",r5."MEASUREMENT_ID",r5."TASK_TYPE",r5."VERSION_ID",r5."RETRIES",r5."RETRY_DATE",r5."RESULT",r5."TOPIC",r5."PARTITION",r5."OFFSET",r5."CTIME",r5."MTIME" , 5 as table_index from Retry_Record_5 r5
 union all
 select r6."ID",r6."MEASUREMENT_ID",r6."TASK_TYPE",r6."VERSION_ID",r6."RETRIES",r6."RETRY_DATE",r6."RESULT",r6."TOPIC",r6."PARTITION",r6."OFFSET",r6."CTIME",r6."MTIME" , 6 as table_index from Retry_Record_6 r6
 union all
 select r7."ID",r7."MEASUREMENT_ID",r7."TASK_TYPE",r7."VERSION_ID",r7."RETRIES",r7."RETRY_DATE",r7."RESULT",r7."TOPIC",r7."PARTITION",r7."OFFSET",r7."CTIME",r7."MTIME" , 7 as table_index from Retry_Record_7 r7
 union all
 select r8."ID",r8."MEASUREMENT_ID",r8."TASK_TYPE",r8."VERSION_ID",r8."RETRIES",r8."RETRY_DATE",r8."RESULT",r8."TOPIC",r8."PARTITION",r8."OFFSET",r8."CTIME",r8."MTIME" , 8 as table_index from Retry_Record_8 r8
 union all
 select r9."ID",r9."MEASUREMENT_ID",r9."TASK_TYPE",r9."VERSION_ID",r9."RETRIES",r9."RETRY_DATE",r9."RESULT",r9."TOPIC",r9."PARTITION",r9."OFFSET",r9."CTIME",r9."MTIME" , 9 as table_index from Retry_Record_9 r9
 union all
 select r10."ID",r10."MEASUREMENT_ID",r10."TASK_TYPE",r10."VERSION_ID",r10."RETRIES",r10."RETRY_DATE",r10."RESULT",r10."TOPIC",r10."PARTITION",r10."OFFSET",r10."CTIME",r10."MTIME" , 10 as table_index from Retry_Record_10 r10
 union all
 select r11."ID",r11."MEASUREMENT_ID",r11."TASK_TYPE",r11."VERSION_ID",r11."RETRIES",r11."RETRY_DATE",r11."RESULT",r11."TOPIC",r11."PARTITION",r11."OFFSET",r11."CTIME",r11."MTIME" , 11 as table_index from Retry_Record_11 r11
 union all
 select r12."ID",r12."MEASUREMENT_ID",r12."TASK_TYPE",r12."VERSION_ID",r12."RETRIES",r12."RETRY_DATE",r12."RESULT",r12."TOPIC",r12."PARTITION",r12."OFFSET",r12."CTIME",r12."MTIME" , 12 as table_index from Retry_Record_12 r12
 union all
 select r13."ID",r13."MEASUREMENT_ID",r13."TASK_TYPE",r13."VERSION_ID",r13."RETRIES",r13."RETRY_DATE",r13."RESULT",r13."TOPIC",r13."PARTITION",r13."OFFSET",r13."CTIME",r13."MTIME" , 13 as table_index from Retry_Record_13 r13
 union all
 select r14."ID",r14."MEASUREMENT_ID",r14."TASK_TYPE",r14."VERSION_ID",r14."RETRIES",r14."RETRY_DATE",r14."RESULT",r14."TOPIC",r14."PARTITION",r14."OFFSET",r14."CTIME",r14."MTIME" , 14 as table_index from Retry_Record_14 r14
 union all
 select r15."ID",r15."MEASUREMENT_ID",r15."TASK_TYPE",r15."VERSION_ID",r15."RETRIES",r15."RETRY_DATE",r15."RESULT",r15."TOPIC",r15."PARTITION",r15."OFFSET",r15."CTIME",r15."MTIME" , 15 as table_index from Retry_Record_15 r15
 union all
 select r16."ID",r16."MEASUREMENT_ID",r16."TASK_TYPE",r16."VERSION_ID",r16."RETRIES",r16."RETRY_DATE",r16."RESULT",r16."TOPIC",r16."PARTITION",r16."OFFSET",r16."CTIME",r16."MTIME" , 16 as table_index from Retry_Record_16 r16
 union all
 select r17."ID",r17."MEASUREMENT_ID",r17."TASK_TYPE",r17."VERSION_ID",r17."RETRIES",r17."RETRY_DATE",r17."RESULT",r17."TOPIC",r17."PARTITION",r17."OFFSET",r17."CTIME",r17."MTIME" , 17 as table_index from Retry_Record_17 r17
 union all
 select r18."ID",r18."MEASUREMENT_ID",r18."TASK_TYPE",r18."VERSION_ID",r18."RETRIES",r18."RETRY_DATE",r18."RESULT",r18."TOPIC",r18."PARTITION",r18."OFFSET",r18."CTIME",r18."MTIME" , 18 as table_index from Retry_Record_18 r18
 union all
 select r19."ID",r19."MEASUREMENT_ID",r19."TASK_TYPE",r19."VERSION_ID",r19."RETRIES",r19."RETRY_DATE",r19."RESULT",r19."TOPIC",r19."PARTITION",r19."OFFSET",r19."CTIME",r19."MTIME" , 19 as table_index from Retry_Record_19 r19
 union all
 select r20."ID",r20."MEASUREMENT_ID",r20."TASK_TYPE",r20."VERSION_ID",r20."RETRIES",r20."RETRY_DATE",r20."RESULT",r20."TOPIC",r20."PARTITION",r20."OFFSET",r20."CTIME",r20."MTIME" , 20 as table_index from Retry_Record_20 r20
 union all
 select r21."ID",r21."MEASUREMENT_ID",r21."TASK_TYPE",r21."VERSION_ID",r21."RETRIES",r21."RETRY_DATE",r21."RESULT",r21."TOPIC",r21."PARTITION",r21."OFFSET",r21."CTIME",r21."MTIME" , 21 as table_index from Retry_Record_21 r21
 union all
 select r22."ID",r22."MEASUREMENT_ID",r22."TASK_TYPE",r22."VERSION_ID",r22."RETRIES",r22."RETRY_DATE",r22."RESULT",r22."TOPIC",r22."PARTITION",r22."OFFSET",r22."CTIME",r22."MTIME" , 22 as table_index from Retry_Record_22 r22
 union all
 select r23."ID",r23."MEASUREMENT_ID",r23."TASK_TYPE",r23."VERSION_ID",r23."RETRIES",r23."RETRY_DATE",r23."RESULT",r23."TOPIC",r23."PARTITION",r23."OFFSET",r23."CTIME",r23."MTIME" , 23 as table_index from Retry_Record_23 r23


/

