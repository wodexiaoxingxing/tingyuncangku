create procedure alter_cdn_u_summ_to_part(tablestr number) authid current_user is
sqlStr varchar2(32767);
rangeDate date;
rangeDesc varchar2(8);
partName1 varchar2(64);
rangeName1 varchar2(64);
partName2 varchar2(64);
rangeName2 varchar2(64);
partName3 varchar2(64);
rangeName3 varchar2(64);
partName4 varchar2(64);
rangeName4 varchar2(64);
partName5 varchar2(64);
rangeName5 varchar2(64);
partName6 varchar2(64);
rangeName6 varchar2(64);
partName7 varchar2(64);
rangeName7 varchar2(64);
partName8 varchar2(64);
rangeName8 varchar2(64);
partName9 varchar2(64);
rangeName9 varchar2(64);
partName10 varchar2(64);
rangeName10 varchar2(64);
partName11 varchar2(64);
rangeName11 varchar2(64);
createDate date;
begin
  DBMS_OUTPUT.ENABLE(999999999999999999999);
  createDate:=sysdate-100;
  rangeDate := trunc(createDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd'); 
  partName1:='p_cdn_u_summ_'||tableStr||'_'||rangeDesc;
  rangeName1:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';      
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd'); 
  partName2:='p_cdn_u_summ_'||tableStr||'_'||rangeDesc;
  rangeName2:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName3:='p_cdn_u_summ_'||tableStr||'_'||rangeDesc;
  rangeName3:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName4:='p_cdn_u_summ_'||tableStr||'_'||rangeDesc;
  rangeName4:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';      
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd'); 
  partName5:='p_cdn_u_summ_'||tableStr||'_'||rangeDesc;
  rangeName5:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName6:='p_cdn_u_summ_'||tableStr||'_'||rangeDesc;
  rangeName6:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName7:='p_cdn_u_summ_'||tableStr||'_'||rangeDesc;
  rangeName7:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';      
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd'); 
  partName8:='p_cdn_u_summ_'||tableStr||'_'||rangeDesc;
  rangeName8:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName9:='p_cdn_u_summ_'||tableStr||'_'||rangeDesc;
  rangeName9:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName10:='p_cdn_u_summ_'||tableStr||'_'||rangeDesc;
  rangeName10:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName11:='p_cdn_u_summ_'||tableStr||'_'||rangeDesc;
  rangeName11:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')'; 
  -- 1 创建临时表
  --create_procedure_log('alter_cdn_u_summ_to_part',tableStr||',begin','run');
    begin
      sqlStr:='drop table NB_CDN_U_SUMM_'||tablestr;
      dbms_output.put_line(sqlStr||';');
      --execute immediate sqlStr;
    exception when others then
      create_procedure_log('alter_cdn_u_summ_to_part',tableStr||','||sqlerrm,'error');  
    end; 
          
    sqlStr:='create table NB_CDN_U_SUMM_'|| tablestr ||' 
             (
                tm_base DATE,
                task_id INTEGER,
                domain_id INTEGER,
                cdn_id INTEGER,
                region_id INTEGER,
                isp_id INTEGER,
                elements INTEGER,
                bytes INTEGER,
                point_total INTEGER,
                hits INTEGER
              ) partition by range (TM_BASE)(
              partition '||partName1||' values less than ('||rangeName1||'),
              partition '||partName2||' values less than ('||rangeName2||'),
              partition '||partName3||' values less than ('||rangeName3||'),
              partition '||partName4||' values less than ('||rangeName4||'),
              partition '||partName5||' values less than ('||rangeName5||'),
              partition '||partName6||' values less than ('||rangeName6||'),
              partition '||partName7||' values less than ('||rangeName7||'),
              partition '||partName8||' values less than ('||rangeName8||'),
              partition '||partName9||' values less than ('||rangeName9||'),
              partition '||partName10||' values less than ('||rangeName10||'),
              partition '||partName11||' values less than ('||rangeName11||'))
              ';   
        dbms_output.put_line(sqlStr||';');
        --execute immediate sqlStr;
        -- 索引改名
        begin
          sqlStr:='alter index idx_cdn_u_summ_'||tableStr||' rename to idx_cdn_u_summ_'||tablestr||'_bak';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_cdn_u_summ_to_part',tableStr||','||sqlStr||','||sqlerrm,'error'); 
        end;  
       
        -- 创建索引  
        begin
          --create_procedure_log('alter_cdn_u_perf_to_part',tableStr||','||'创建索引in_page_perf','run'); 
          sqlStr:='create index idx_cdn_u_summ_'||tableStr||' on NB_CDN_U_SUMM_'||tableStr||' (tm_base,task_id,domain_id) compress 3 LOCAL parallel 4  tableSpace  NETBEN_IND nologging';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_cdn_u_summ_to_part',tableStr||','||sqlStr||','||sqlerrm,'error'); 
        end;  
       
        /*
        --2.检查原始表能否在线重定义,采用rowid方式  用系统管理员执行
        --create_procedure_log('alter_cdn_u_perf_to_part',tableStr||','||'检查原始表能否在线重定义','run'); 
        dbms_output.put_line('exec DBMS_REDEFINITION.CAN_REDEF_TABLE(''NETBEN'',''NB_CDN_USAGE_SUMMARY_'||tableStr||''',DBMS_REDEFINITION.cons_use_rowid);'); 
        --DBMS_REDEFINITION.CAN_REDEF_TABLE('NETBEN', 'NB_PAGE_'||tableStr, DBMS_REDEFINITION.cons_use_rowid); 
        
        --3.执行在线重新定义 系统管理员执行
        --create_procedure_log('alter_cdn_u_perf_to_part',tableStr||','||'执行在线重新定义','run'); 
        dbms_output.put_line('exec DBMS_REDEFINITION.START_REDEF_TABLE(''NETBEN'', ''NB_CDN_USAGE_SUMMARY_'||tableStr||''',''NB_CDN_USAGE_SUMM_'||tableStr||'_T'', '''', DBMS_REDEFINITION.cons_use_rowid);');
        --DBMS_REDEFINITION.START_REDEF_TABLE('NETBEN', 'NB_PAGE_'||tableStr, 'NB_PAGE_'||tableStr||'_TEMP', '', DBMS_REDEFINITION.cons_use_rowid); 
        
        --4.执行数据同步 系统管理员执行
        --create_procedure_log('alter_cdn_u_perf_to_part',tableStr||','||'执行数据同步','run'); 
        dbms_output.put_line('exec DBMS_REDEFINITION.sync_interim_table(''NETBEN'', ''NB_CDN_USAGE_SUMMARY_'||tableStr||''',''NB_CDN_USAGE_SUMM_'||tableStr||'_T'');');
        --DBMS_REDEFINITION.sync_interim_table('NETBEN', 'NB_PAGE_'||tableStr, 'NB_PAGE_'||tableStr||'_TEMP');
        
        --执行两次
        --create_procedure_log('alter_cdn_u_perf_to_part',tableStr||','||'再次执行数据同步','run'); 
        dbms_output.put_line('exec DBMS_REDEFINITION.sync_interim_table(''NETBEN'', ''NB_CDN_USAGE_SUMMARY_'||tableStr||''', ''NB_CDN_USAGE_SUMM_'||tableStr||'_T'');');
        --DBMS_REDEFINITION.sync_interim_table('NETBEN', 'NB_PAGE_'||tableStr, 'NB_PAGE_'||tableStr||'_TEMP');
        
        --5.完成在线重新定义 系统管理员执行
        --create_procedure_log('alter_cdn_u_perf_to_part',tableStr||','||'完成在线重新定义','run'); 
        dbms_output.put_line('exec DBMS_REDEFINITION.FINISH_REDEF_TABLE(''NETBEN'', ''NB_CDN_USAGE_SUMMARY_'||tableStr||''',''NB_CDN_USAGE_SUMM_'||tableStr||'_T'');');
        --DBMS_REDEFINITION.FINISH_REDEF_TABLE('NETBEN', 'NB_PAGE_'||tableStr, 'NB_PAGE_'||tableStr||'_TEMP');
       
        -- 索引改名
        begin
          sqlStr:='alter index idx_cdn_u_summ_'||tableStr||' rename to idx_cdn_u_summ_'||tablestr||'_bak';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_cdn_u_summ_to_part',tableStr||','||sqlStr||','||sqlerrm,'error'); 
        end;  
       
        -- 创建索引  
        begin
          --create_procedure_log('alter_cdn_u_perf_to_part',tableStr||','||'创建索引in_page_perf','run'); 
          sqlStr:='create index idx_cdn_u_summ_'||tableStr||' on NB_CDN_USAGE_SUMMARY_'||tableStr||' (tm_base,task_id,domain_id) compress 3 LOCAL parallel 4  tableSpace  NETBEN_IND nologging';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_cdn_u_summ_to_part',tableStr||','||sqlStr||','||sqlerrm,'error'); 
        end;  
       
      sqlStr:='drop table NB_CDN_USAGE_SUMM_'||tablestr||'_t';
      dbms_output.put_line(sqlStr||';');  
      create_procedure_log('alter_cdn_u_summ_to_part',tableStr||',end','run');
      */
      exception when others then
        create_procedure_log('alter_cdn_u_summ_to_part',tableStr||','||sqlerrm,'error');  
end alter_cdn_u_summ_to_part;


/

