create PROCEDURE update_ec_part authid current_user is
DROP_ERROR exception;
ADD_ERROR exception;

sqlStr varchar2(4000);
currDate date := trunc(sysdate,'dd');

partNameNew varchar2(64);
partValueNew varchar2(64);
partDate date;


tabName  varchar2(128);
partName  varchar2(128);
tablespaceName  varchar2(128);
begin
  DBMS_OUTPUT.ENABLE (1000000000);
  create_procedure_log('update_ec_part','begin','run');
  for tab in(select tabName,partName from (
    select tabName,partName,decode(is_date(tm,'yymmdd'),0,null,1,to_date(tm,'yymmdd')) tm
      from(select table_name tabName,partition_name partName,substr(partition_name, -6) tm
        from user_tab_partitions where regexp_like( table_name,'^NB_EC_[0-9]')))
     where tm<= currDate - 18)
  loop
    begin
       partDate:=to_date(substr(tab.partName,-6),'yymmdd');
       if  partDate > currDate - 18 then  raise DROP_ERROR; end if;
       sqlStr:='alter table '||tab.tabName||' drop partition '||tab.partName;
       dbms_output.put_line(sqlStr||';');
       --execute immediate sqlStr;
       --create_procedure_log('update_ec_part','Drop part,Table:'||tab.tabname||',partName:'||tab.partName,'run');
    exception
       when DROP_ERROR then null;
       when others then
         --dbms_output.put_line('dropError,Table:'||tab.tabname||','||sqlerrm);
         create_procedure_log('update_ec_part','dropError,Table:'||tab.tabname||','||sqlerrm,'error');
    end;
  end loop;
    --处理增加分区，一次只增加一个
  for tab in(
    select a.table_name tabName,a.partition_name partName,tablespace_name tablespaceName from
      (select table_name,partition_position,partition_name,tablespace_name from user_tab_partitions where regexp_like( table_name,'^NB_EC_[0-9]'))a,
      (select table_name,max(partition_position) partition_position from user_tab_partitions where regexp_like( table_name,'^NB_EC_[0-9]') group by table_name)b
        where a.table_name = b.table_name and a.partition_position = b.partition_position
    )loop
      begin
        partDate:=to_date(substr(tab.partName,-6),'yymmdd');
        if partDate > currDate + 40 then raise ADD_ERROR; end if;
        partNameNew:=substr(tab.partName,1,length(tab.partName)-6)||to_char(partDate+1,'yymmdd');
        partValueNew :='to_date('''||to_char(partDate+1,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
        sqlStr := 'ALTER TABLE '||tab.tabName || ' ADD PARTITION '||partNameNew||' VALUES LESS THAN('||partValueNew||') tablespace '||tab.tablespacename;
        --create_procedure_log('update_ec_part',sqlStr||';','run');
        dbms_output.put_line(sqlStr||';');
        --execute immediate sqlStr;
        --create_procedure_log('update_ec_part','Add Part,Table:'||tab.tabname||',partName:'||partNameNew,'run');
      exception
        when ADD_ERROR then null;
        when others then
          --dbms_output.put_line('addError,Table:'||tab.tabname||','||sqlerrm);
          create_procedure_log('update_ec_part','addError,Table:'||tab.tabname||','||sqlerrm,'error');
      end;
    end loop;
  create_procedure_log('update_ec_part','end','run');
  exception
     when DROP_ERROR then null;
    --dbms_output.put_line('aa,'||sqlerrm);
    when others then
    create_procedure_log('update_ec_part','Outer error,'||sqlerrm,'error');
end update_ec_part;


/

