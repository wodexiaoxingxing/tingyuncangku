create procedure insert_elem_to_newtask(ownerId number) authid current_user is
sqlStr varchar2(32767);
countSum1 int;
countSum2 int;
countSum3 int;
begin
create_procedure_log('insert_elem_to_newtask','OwnerId:'||ownerId||',begin','run');
sqlStr:='select count(1) from nb_m_task where owner_id = '||ownerId||' and ctime > sysdate -1/2';
      dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr into countSum1;
      if countSum1 > 0 then
      for tab in (select id as task_id from nb_m_task where owner_id = ownerId and ctime > sysdate -1/2) loop
      begin
      select count(1) into countSum2 from nb_elem_url_task_auto where task_id = tab.task_id;
      if countSum2 = 0 then
        sqlStr:='insert into nb_elem_url_task_auto select tmp.url_id, tmp.task_id, tmp.elem_type_id, sysdate, tmp.s from (select url_id, task_id, elem_type_id, sum(point_total) s  from nb_et_'||tab.task_id||'where tm_base > sysdate - 1 group by url_id, task_id, elem_type_id order by s desc) tmp where rownum < 100';
        dbms_output.put_line(sqlStr||';');
        --execute immediate sqlStr;
        commit;
      select count(1) into countSum3 from nb_elem_url_task_auto where task_id=tab.task_id;
      dbms_output.put_line('insert nums:'||countSum3);
      create_procedure_log('insert_elem_to_newtask','ownerId:'||ownerId||'taskid:'||tab.task_id||'numbers:'||countSum3,'run');
      else
      create_procedure_log('insert_elem_to_newtask','ownerId:'||ownerId||'taskid:'||tab.task_id||'have elements in the table!','Warning');
       end if;
      end;
      end loop;
     else 
     create_procedure_log('insert_elem_to_newtask','ownerId:'||ownerId||' no new task finded!','end');
     end if;
end insert_elem_to_newtask;


/

