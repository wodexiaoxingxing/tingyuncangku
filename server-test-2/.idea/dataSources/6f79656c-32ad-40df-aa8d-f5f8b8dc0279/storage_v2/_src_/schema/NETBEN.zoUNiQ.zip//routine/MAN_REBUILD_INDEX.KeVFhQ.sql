create PROCEDURE          "MAN_REBUILD_INDEX" authid current_user is
sqlStr varchar2(4000);
pname varchar2(40);

c1 number;
c2 number;
 begin
    for ec in  (SELECT distinct INDEX_NAME  FROM USER_INDEXES t where  INDEX_NAME='IN_MV_PAGE_PERF_TEST_OS_BS_ID')
    loop
        begin
        dbms_output.put_line(ec.index_name);
          select count(*) into c1 from user_indexes i where i.PARTITIONED='NO' AND i.INDEX_NAME=ec.index_name;
          if c1>0
            then
                 sqlStr := 'ALTER INDEX '||ec.index_name||' REBUILD TABLESPACE NETBEN_IND NOLOGGING parallel 4';
                dbms_output.put_line(sqlStr);
      --          execute immediate  sqlStr;
      else
        select count(*) into c2 from USER_PART_INDEXES WHERE SUBPARTITIONING_TYPE<>'NONE' and index_name=EC.INDEX_NAME;
         if c2>0
           then
           for pname in( SELECT t.subpartition_name FROM USER_IND_SUBPARTITIONS t where t.index_name=ec.index_name )
           loop
                  sqlStr := 'ALTER INDEX '||ec.index_name||' REBUILD SUBPARTITION '||PNAME.SUBPARTITION_NAME||' TABLESPACE NETBEN_IND  parallel 4';
                 dbms_output.put_line(sqlStr);
          end loop;

          else
             for pname in ( select t.partition_name from  user_ind_partitions t where t.index_name=ec.index_name)
                  loop
                  sqlStr := 'ALTER INDEX '||ec.index_name||' REBUILD PARTITION '||PNAME.PARTITION_NAME||' TABLESPACE NETBEN_IND NOLOGGING parallel 4';
                dbms_output.put_line(sqlStr);
                  end loop;
          end if;
          end if;
     exception when  others then
      MON_PC_ERROR_LOG('MAN_REBUILD_INDEX',sqlerrm,ec.index_name);
      end;
    end loop;
end MAN_REBUILD_INDEX;


/

