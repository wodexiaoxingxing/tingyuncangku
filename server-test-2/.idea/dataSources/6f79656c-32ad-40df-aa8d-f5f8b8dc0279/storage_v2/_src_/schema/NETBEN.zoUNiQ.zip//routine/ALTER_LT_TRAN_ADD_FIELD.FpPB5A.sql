create PROCEDURE          "ALTER_LT_TRAN_ADD_FIELD" 
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(400);
  v_s number;
begin
  for tableName in(select t.table_name as name from user_tables t where t.table_name like 'LT_TRAN_%') loop
  begin

    --删除主键
    /*select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='ID';
    if v_s = 1 then
       sqlStr:= 'alter table '||tableName.Name||' drop column ID';
       execute immediate sqlStr;
    end if;
    --删除tm_day2
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TM_DAY2';
    if v_s = 1 then
       sqlStr:= 'alter table '||tableName.Name||' drop column TM_DAY2';
       execute immediate sqlStr;
    end if;
    --删除tm_day4
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TM_DAY4';
    if v_s = 1 then
       sqlStr:= 'alter table '||tableName.Name||' drop column TM_DAY4';
       execute immediate sqlStr;
    end if;
    --删除tm_day8
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TM_DAY8';
    if v_s = 1 then
       sqlStr:= 'alter table '||tableName.Name||' drop column TM_DAY8';
       execute immediate sqlStr;
    end if;
    --删除tm_day16
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TM_DAY16';
    if v_s = 1 then
       sqlStr:= 'alter table '||tableName.Name||' drop column TM_DAY16';
       execute immediate sqlStr;
    end if;
    */
     select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='PING_PACKET_LOST';
      if v_s < 1 then
        DBMS_OUTPUT.PUT_LINE('alter ' ||tableName.Name);
        sqlStr := 'alter table '||tableName.Name||' add PING_PACKET_LOST number';
        execute   immediate   sqlStr ;
      end if;

    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlStr);
        create_procedure_log('alter_lt_tran_add_field',v_error_desc,sqlcode);
  end;
  end loop;
end alter_lt_tran_add_field;


/

