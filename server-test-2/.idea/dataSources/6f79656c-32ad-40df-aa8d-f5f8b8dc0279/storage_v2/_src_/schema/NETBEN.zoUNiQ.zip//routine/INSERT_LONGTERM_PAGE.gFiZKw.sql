create procedure insert_longterm_page authid current_user
is
   sqlStr varchar2(4000);
   startDate date := trunc(sysdate-1,'dd');
   endDate date := trunc(sysdate,'dd');
   errorDesc varchar2(4000);
   v_s number;
   dayNum number;
   currDayNum number;
begin
create_procedure_log('insert_longterm_page','begin','message');
for item in (select substr(t.table_name, 9) as name from user_tables t where regexp_like(t.TABLE_NAME,'^NB_PAGE_[0-9]+$')) loop
begin
   create_procedure_log('insert_longterm_page','tableStr:'||item.name,'message');
   --DBMS_OUTPUT.PUT_LINE(item.name||'  '||to_char(sysdate,'hh24:mi:ss'));
   --判断是否该表已经创建
   --DBMS_OUTPUT.PUT_LINE(item.name);
   select count(*) into v_s from user_tables t where t.table_name = 'LT_PAGE_'||item.name;
   if (v_s<1) then
       --表不存在，创建新表
       sqlStr:='create table LT_PAGE_'||item.name||'
		       (
      		 TASK_ID        NUMBER NOT NULL,
		       CITY_ID        NUMBER NOT NULL,
		       ISP_ID         NUMBER NOT NULL,
		       NET_SPEED_ID   NUMBER NOT NULL,
		       TM_DAY         DATE,
           PAGE_SEQ       NUMBER,
           ERROR_CODE     NUMBER,
           POINT_TOTAL    NUMBER,
           BYTE_TOTAL     NUMBER,
           RATE_DOWNLOAD  NUMBER,
           TS_TOTAL       NUMBER,
           TS_DNS         NUMBER,
           TS_CONNECT     NUMBER,
           TS_FIRST_PACKET NUMBER,
           TS_USER        NUMBER,
           BYTE_PAGE_BASE NUMBER,
           RATE_DOWNLOAD_PAGE_BASE NUMBER,
           NUM_FIRST_ELEM NUMBER,
           BYTE_FIRST NUMBER,
           NUM_DOM NUMBER,
           cont_err_total number,
           cont_ele_total number,
           ts_ssl number,
           ts_request number,
           ts_client number,
           ts_contents number,
           ts_network number,
           num_host number,
           ts_dns_total number,
           num_connect number,
           ts_connect_total number,
           ts_page_base number,
           ts_redirect number,
           ts_extra_data number,
           ts_open_page number,
           ts_close number,
           num_iframe number,
           num_no_compress_elem number,
           num_no_expire_elem number,
           num_no_etag_elem number,
					 
					 dest_city_id   NUMBER,
					 dest_isp_id    NUMBER,
					 dest_ip        VARCHAR2(39),				 
					 ts_first_paint number,
					 ts_dom_load number,
					 ts_dom_interact number,
					 ts_dom_cont_load_start number,
					 ts_dom_cont_load_end number,
					 ts_dom_complete number,
					 num_elem_lazy number,
					 num_quic_handshake number,
					 num_quic_connection number,
					 ts_quic_first_100 number
		       )';
         execute   immediate   sqlStr;
         --创建索引
         sqlStr:='create index IN_LT_PAGE_PERF_'||item.name||' on LT_PAGE_'||item.name||' (task_id,tm_day,city_id,isp_id,error_code) tableSpace netben_ind';
	       execute   immediate   sqlStr;
     end if;

  --删除指定日期的长期库中的数据,防止重复数据
  sqlStr := 'delete from lt_page_'||item.name||' where tm_day  >=:sDate and tm_day < :eDate';
  execute immediate sqlStr using startDate,endDate;
  commit;

  --从实时库中插入指定日期的数据
  sqlStr:='insert into lt_page_'||item.name||'
           (task_id,city_id,isp_id,net_speed_id,tm_day,page_seq,error_code,
					  dest_city_id,dest_isp_id,dest_ip,
            point_total,byte_total,rate_download,ts_total,ts_dns,ts_connect,ts_first_packet,ts_user,
            byte_page_base,rate_download_page_base,num_first_elem,byte_first,num_dom,
            cont_err_total,cont_ele_total,ts_ssl,ts_request,ts_client,ts_contents,ts_network,num_host,ts_dns_total,num_connect,ts_connect_total,
             ts_page_base,ts_redirect,ts_extra_data,ts_open_page,ts_close,num_iframe,num_no_compress_elem,num_no_expire_elem,num_no_etag_elem,
					 				 
					 ts_first_paint,
					 ts_dom_load,
					 ts_dom_interact,
					 ts_dom_cont_load_start,
					 ts_dom_cont_load_end,
					 ts_dom_complete,
					 num_elem_lazy,
					 num_quic_handshake,
					 num_quic_connection,
					 ts_quic_first_100
						 )
        select
		       task_id,
		       city_id,
		       isp_id,
		       net_speed_id,
		       trunc(tm_base,''dd'') as tm_day,
           page_seq,
           error_code,
					 dest_city_id,
					 dest_isp_id,
					 dest_ip,	
		       sum(point_total),
           round(avg(byte_total),0) as byte_total,
           round(avg(rate_download),0) as rate_download,
           round(avg(ts_total),0) as ts_total,
		       round(avg(ts_dns),0) as ts_dns,
           round(avg(ts_connect),0) as ts_connect,
		       round(avg(ts_first_packet),0) as ts_first_packet,
           round(avg(ts_user),0) as ts_user,
           round(avg(byte_page_base),0) as byte_page_base,
           round(avg(rate_download_page_base),0) as rate_download_page_base,
           round(avg(num_first_elem),0) as num_first_elem_number,
           round(avg(byte_first),0) as byte_first,
           round(avg(num_dom),0) as num_dom,
           round(avg(cont_err_total),0) as cont_err_total,
           round(avg(cont_ele_total),0) as cont_ele_total,
           round(avg(ts_ssl),0) as ts_ssl,
           round(avg(ts_request),0) as ts_request,
           round(avg(ts_client),0) as ts_client,
           round(avg(ts_contents),0) as ts_contents,
           round(avg(ts_network),0) as ts_network,
           round(avg(num_host),0) as num_host,
           round(avg(ts_dns_total),0) as ts_dns_total,
           round(avg(num_connect),0) as num_connect,
           round(avg(ts_connect_total),0) as ts_connect_total,
           round(avg(ts_page_base),0) as ts_page_base,
           round(avg(ts_redirect),0) as ts_redirect,
           round(avg(ts_extra_data),0) as ts_extra_data,
           round(avg(ts_open_page),0) as ts_open_page,
           round(avg(ts_close),0) as ts_close,
           round(avg(num_iframe),0) as num_iframe,
           round(avg(num_no_compress_elem),0) as num_no_compress_elem,
           round(avg(num_no_expire_elem),0) as num_no_expire_elem,
           round(avg(num_no_etag_elem),0) as num_no_etag_elem, 
					 round(avg(ts_first_paint),0) as ts_first_paint,
           round(avg(ts_dom_load),0) as ts_dom_load,
           round(avg(ts_dom_interact),0) as ts_dom_interact,
           round(avg(ts_dom_cont_load_start),0) as ts_dom_cont_load_start,
           round(avg(ts_dom_cont_load_end),0) as ts_dom_cont_load_end,
           round(avg(ts_dom_complete),0) as ts_dom_complete,
           round(avg(num_elem_lazy),0) as num_elem_lazy,
           round(avg(num_quic_handshake),0) as num_quic_handshake,
           round(avg(num_quic_connection),0) as num_quic_connection,
					 round(avg(ts_quic_first_100),0) as ts_quic_first_100
		    from NB_PAGE_'||item.name||'
           where tm_base >= :sDate and  tm_base < :eDate and is_noise = 0
		       group by task_id,
		                city_id,
		                isp_id,
		                net_speed_id,
                    trunc(tm_base,''dd''),
                    page_seq,
		                error_code,
										dest_city_id,
										dest_isp_id,
										dest_ip
		    ';
       execute immediate sqlStr using startDate,endDate;
       commit;
     --删除超时数据，现定为两年,循环按天删除
     sqlStr:='select :sd1 - trunc(min(tm_day),''dd'') - 730  from lt_page_'|| item.name ||' where tm_day < :sd2 - 730';
        execute immediate sqlStr  into dayNum using startDate,startDate;
        if dayNum is not null and dayNum > 0 then
          for i in 1..dayNum loop
            currDayNum := 730 + dayNum - i;
            sqlStr:='delete from lt_page_'||item.name||' where tm_day  < :sd -'||currDayNum;
            execute immediate sqlStr using startDate;
            commit;
          end loop;
        end if;
     exception when  others then
        errorDesc := 'TableStr:'||item.name||' Error Code:'|| sqlerrm || '  Sql:'||sqlStr ;
        create_procedure_log('insert_longterm_page',errorDesc,'error');
  end;
end loop;
create_procedure_log('insert_longterm_page','end','message');
end insert_longterm_page;
/

