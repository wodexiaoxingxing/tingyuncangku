create PROCEDURE          "UPDATE_IS_NOISE" authid current_user is
sqlStr varchar2(4000);
begin
sqlStr:='update nb_tran_1759 set is_noise = 0 where tm_base > sysdate -3';
execute immediate sqlStr;
sqlStr:='update nb_page_1759 set is_noise = 0 where tm_base > sysdate -3';
execute immediate sqlStr;
sqlStr:='update nb_stream_1759 set is_noise = 0 where tm_base > sysdate -3';
execute immediate sqlStr;
sqlStr:='update nb_tran_20000 set is_noise = 0 where tm_base > sysdate -3';
execute immediate sqlStr;
sqlStr:='update nb_page_20000 set is_noise = 0 where tm_base > sysdate -3';
execute immediate sqlStr;
sqlStr:='update nb_stream_1759 set error_code = 0  where member_id in(4,7) and tm_base > sysdate -3';
execute immediate sqlStr; 

commit;
end update_is_noise;


/

