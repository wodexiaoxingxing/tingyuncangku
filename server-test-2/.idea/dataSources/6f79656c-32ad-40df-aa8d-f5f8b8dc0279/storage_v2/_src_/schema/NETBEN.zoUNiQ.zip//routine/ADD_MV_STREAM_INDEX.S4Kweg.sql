create PROCEDURE          "ADD_MV_STREAM_INDEX" authid current_user
is
  sqlStr  varchar2(4000);
  errorDesc varchar2(4000);
  v_s number;
begin
for item in (select substr(t.table_name, 11) as name from user_tables t where t.table_name like 'NB_STREAM_%') loop
    begin
    select count(*) into v_s from user_indexes t where t.index_name = 'IN_MV_STREAM_ERROR_'||item.name;
    if (v_s=0) then
         create_procedure_log('add_mv_stream_index',item.name,'message');
         sqlStr:='create index IN_MV_STREAM_ERROR_'||item.name||' on MV_STREAM_'||item.name||' (TASK_ID,TM_HOUR8,ERROR_CODE,CITY_ID) nologging tableSpace NETBEN_IDX';
       	 execute   immediate   sqlStr;
    end if;
    select count(*) into v_s from user_indexes t where t.index_name = 'IN_MV_STREAM_PERF_'||item.name;
    if (v_s=0) then
         create_procedure_log('add_mv_stream_index',item.name,'message');
         sqlStr:='create index IN_MV_STREAM_PERF_'||item.name||' on MV_STREAM_'||item.name||' (TASK_ID,TM_HOUR8,CITY_ID,ISP_ID) nologging tableSpace NETBEN_IDX';
       	 execute   immediate   sqlStr;
    end if;
    
    exception when  others then
         errorDesc := 'Error Code:'|| sqlcode || '  table ' || item.name;
          --DBMS_OUTPUT.PUT_LINE(errorDesc);
         create_procedure_log('add_mv_stream_index',errorDesc,'error');
    end;
  end loop;
end add_mv_stream_index;


/

