create PROCEDURE "ALTER_LT_STREAM_ADD_FIELD"
is 
  sqlStr  varchar2(4000);  
  v_error_desc varchar2(4000);
  v_s number;
begin
  for tableName in(select t.table_name as name from user_tables t where t.table_name like 'LT_STREAM_%' ) loop
  begin
   -- create_procedure_log('alter_custom_add_field',tableName.name,'message');
   
      select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='DATA_RATE';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add DATA_RATE NUMBER';
       execute   immediate   sqlStr ;
     --    DBMS_OUTPUT.PUT_LINE(sqlStr);
      end if;
       select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='FLUENCY';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add FLUENCY NUMBER';
      execute   immediate   sqlStr ;
  --        DBMS_OUTPUT.PUT_LINE(sqlStr);  PLAY_IN_5S
      end if;
       select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='PLAY_IN_5S';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add PLAY_IN_5S NUMBER';
      execute   immediate   sqlStr ;
  --        DBMS_OUTPUT.PUT_LINE(sqlStr);  
      end if;
       
    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlStr);
        create_procedure_log('alter_custom_add_field',v_error_desc,sqlcode);
  end;
  end loop;
END ALTER_LT_STREAM_ADD_FIELD;


/

