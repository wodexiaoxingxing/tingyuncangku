create view NB_V_DPMBR_DP_EN as
select 0 AS ID, MEMBER_ID, IMPCI_ID, TRUNC(cdate, 'DD') AS CDATE, SUM(DATA_POINTS) AS DATA_POINTS
    from NB_DPMBR_DP_EN
    where cdate < TRUNC(SYSDATE, 'DD')
    GROUP BY TRUNC(cdate, 'DD'), MEMBER_ID, IMPCI_ID


/

