create PROCEDURE UPDATE_TASK_SLA_AUTO2
(
  app_convert_factor IN NUMBER default 12  -- 积分/MB：1MB数据流量=12积分
, wifi_convert_factor IN NUMBER default 2  -- 积分/MB：1MB WIFI流量=2积分
, integral_convert_factor in number default 6  -- 积分/分： 1分 = 600积分
, start_dt IN DATE default sysdate-2/24        --执行时间
, end_dt IN DATE default sysdate    --结束时间
, delay_mi in number default 100        --延迟时间 最低100min
, task_count IN NUMBER default 5        --点数 5
, rtime in date default sysdate         --定时任务执行时间
) AS 
task_avg_cost number; --单点次成本->单位b
task_sla_rate number;  --sla比例->
email_msg clob; --邮件内容
t_len number;
len1 number; -- 数量
len2 number; -- 数量
num number; --序号
--设置延迟时间
start_t DATE:= start_dt-delay_mi/60/24;
end_t DATE:= end_dt-delay_mi/60/24;

--声明游标1，任务以及对应的平均流量
Cursor cur1 is  select aa.TASK_ID, aa.wifi_flows, aa.app_flows, bb.count
from (
select a.TASK_ID,sum(WIFI_FLOWS) wifi_flows,sum(app_flows) app_flows
from 
  (select TASK_ID,WIFI_FLOWS,app_flows,CREATE_DT from nbsdev.NB_M_FLOWS_DETAIL_0 where TASK_ID > 0
  union select TASK_ID,WIFI_FLOWS,app_flows,CREATE_DT from nbsdev.NB_M_FLOWS_DETAIL_1 where TASK_ID > 0
  union select TASK_ID,WIFI_FLOWS,app_flows,CREATE_DT from nbsdev.NB_M_FLOWS_DETAIL_2 where TASK_ID > 0
  union select TASK_ID,WIFI_FLOWS,app_flows,CREATE_DT from nbsdev.NB_M_FLOWS_DETAIL_3 where TASK_ID > 0
  union select TASK_ID,WIFI_FLOWS,app_flows,CREATE_DT from nbsdev.NB_M_FLOWS_DETAIL_4 where TASK_ID > 0
  union select TASK_ID,WIFI_FLOWS,app_flows,CREATE_DT from nbsdev.NB_M_FLOWS_DETAIL_5 where TASK_ID > 0
  union select TASK_ID,WIFI_FLOWS,app_flows,CREATE_DT from nbsdev.NB_M_FLOWS_DETAIL_6 where TASK_ID > 0
  union select TASK_ID,WIFI_FLOWS,app_flows,CREATE_DT from nbsdev.NB_M_FLOWS_DETAIL_7 where TASK_ID > 0
  union select TASK_ID,WIFI_FLOWS,app_flows,CREATE_DT from nbsdev.NB_M_FLOWS_DETAIL_8 where TASK_ID > 0
  union select TASK_ID,WIFI_FLOWS,app_flows,CREATE_DT from nbsdev.NB_M_FLOWS_DETAIL_9 where TASK_ID > 0
  )a
where CREATE_DT between start_t and end_t -- 保证时间对应在相同的时间段内
group by a.TASK_ID) aa
left join (
select b.TASK_ID, sum(count) count
from nb_bill_task_mob_hour b
where b.CALC_DATE between start_t and end_t -- 保证时间对应在相同的时间段内
group by b.TASK_ID) bb
on aa.TASK_ID = bb.TASK_ID
where bb.count > task_count; -- 指定最低低任务点次

-- 声明游标2，nb_sla_grad_settings表中的结果集并按阈值排序
Cursor cur2 is select THRESHOLD,SLA_RATE from nb_sla_grad_settings order by THRESHOLD;
-- 游标3
Cursor cur3(r_time date) is select * from nb_sla_alert_log where rtime = r_time order by sla_rate,avg_cost; 
BEGIN
  t_len := 0;
  -- 打印存储过程日志
  create_sla_procedure_log('begin',null,null,null,'time:'||to_char(start_t,'yyyy-mm-dd hh24:mi:ss')||' -> '||to_char(end_t,'yyyy-mm-dd hh24:mi:ss'),rtime,null,null,null);
  for task_one in cur1 LOOP
    begin
      task_avg_cost := round((round(task_one.wifi_flows/1024/1024,2)*wifi_convert_factor+round(task_one.app_flows/1024/1024,2)*app_convert_factor)/task_one.count/integral_convert_factor, 1);
      task_sla_rate := 100;
      -- 保存日志
      create_sla_procedure_log('source',task_one.task_id,task_avg_cost,task_sla_rate,'success',rtime,task_one.app_flows,task_one.wifi_flows,task_one.count);
      
      -- 平均流量保存到nb_m_task_avg_cost_auto表
      merge into nb_m_task_avg_cost_auto t1
        using dual on (t1.task_id = task_one.task_id)
      when matched then
        update set avg_cost=task_avg_cost,mtime=sysdate
      when not matched then
        insert (task_id,avg_cost,ctime,mtime) values(task_one.task_id,task_avg_cost,sysdate,sysdate); 
      
      -- 根据表nb_sla_grad_settings数据进行比对，比较阈值（threshold）来设置sla_rate;
      for sla_one in cur2 Loop
        begin
          if task_avg_cost >= sla_one.threshold then
            task_sla_rate := sla_one.sla_rate;
          else exit;
          end if;
        end;
      end Loop;

      -- 进行merge操作，只对系统自动生成的数据进行操作（opt_type = 0）
      len1 := 0;
      len2 := 0;
      select count(*) into len1 from nb_m_task_sla_rate where task_id = task_one.task_id;
      --更新操作
      if len1 = 1 then
        select count(*) into len2 from nb_m_task_sla_rate where task_id = task_one.task_id and opt=0 and sla_rate!=task_sla_rate;
        if len2 = 1 then
          update nb_m_task_sla_rate set sla_rate=task_sla_rate,mtime=sysdate where opt=0 and task_id=task_one.task_id;
          --计数
          t_len := t_len + 1;
          -- 保存日志
          create_sla_procedure_log('run',task_one.task_id,task_avg_cost,task_sla_rate,'success',rtime,task_one.app_flows,task_one.wifi_flows,task_one.count);
          -- sla报警日志,记录邮件信息
          create_sla_alert_log(task_one.task_id,task_one.count,task_avg_cost,task_sla_rate,rtime,task_one.app_flows,task_one.wifi_flows,null);
        end if;
      end if;
      --新增操作
      if len1 = 0 and task_sla_rate != 100 then
        insert into nb_m_task_sla_rate (task_id,sla_rate,ctime,mtime,opt) values(task_one.task_id,task_sla_rate,sysdate,sysdate,0);
        --计数
        t_len := t_len + 1;
        -- 保存日志
        create_sla_procedure_log('run',task_one.task_id,task_avg_cost,task_sla_rate,'success',rtime,task_one.app_flows,task_one.wifi_flows,task_one.count);
        -- sla报警日志，记录邮件信息
        create_sla_alert_log(task_one.task_id,task_one.count,task_avg_cost,task_sla_rate,rtime,task_one.app_flows,task_one.wifi_flows,null);
      end if;
      len1 := 0;
      len2 := 0;

    exception
      when others then
        create_sla_procedure_log('run:error',task_one.task_id,task_avg_cost,task_sla_rate,sqlerrm,rtime,task_one.app_flows,task_one.wifi_flows,task_one.count);
    end;
  end LOOP;
  
  -- 发送邮件-记录日志，内网环境下，运维通过shell脚本查询日志表，发送邮件，外网通过存储过程实现
  if t_len > 0 then
    num:=0;
    email_msg := '<html><body><table border="0" cellpadding="0" cellspacing="1" bgcolor="black"><tr bgcolor="#66ffff"><th>序号</th><th>任务id</th><th>任务名称</th><th>用户代码</th><th>点次</th><th>app流量（MB）</th><th>wifi流量（MB）</th><th>平均成本（分）</th><th>sla（%）</th></tr>';
    for item in cur3(rtime) loop
      begin
        num := num + 1;
        email_msg:=email_msg||'<tr bgcolor="white"><td>'||num||'</td><td>'||item.task_id||'</td><td>'||item.task_name||'</td><td>'||item.user_code||'</td><td>'||item.count||'</td><td>'||round(item.app_flows/1024/1024,2)||'</td><td>'||round(item.wifi_flows/1024/1024,2)||'</td><td>'||item.avg_cost||'</td><td>'||item.sla_rate||'</td></tr>';
      end;
    end loop;
    email_msg := email_msg || '</table></body></html>';
    networkhtml_sendmail('mservice@tingyun.com','真机sla流量限制警报',email_msg);
    create_sla_procedure_log('sendmail',null,null,null,email_msg,rtime,null,null,null);
  end if;
  create_sla_procedure_log('end',null,null,null,null,rtime,null,null,null);
  commit;
exception
 when others then
 create_sla_procedure_log('procedure:error',null,null,null,sqlerrm,rtime,null,null,null);
END UPDATE_TASK_SLA_AUTO2;
/

