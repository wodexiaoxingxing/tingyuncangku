create procedure CREATE_TESTIN_DATA_TABLE(tableStr in varchar, info  out varchar) authid current_user is
  sqlStr        varchar2(8000);
  errorDesc     varchar2(4000);
  ---------------- 主变量 ---------------------------------------------------------------------------
  createDate    date := sysdate;
  orderNum      number;
  rangeDate     varchar2(128);
  partname1     varchar2(128);
  STEP_partname1 varchar2(128);
  STRUCT_partname1 varchar2(128);
  rangedate1    varchar2(128);
  partname2     varchar2(128);
  STEP_partname2 varchar2(128);
  STRUCT_partname2 varchar2(128);
  rangedate2    varchar2(128);
  partname3     varchar2(128);
  STEP_partname3 varchar2(128);
  STRUCT_partname3 varchar2(128);
  rangedate3    varchar2(128);
  table_name varchar2(100);
  --------------- 临时变量----------------------------------------------------------------------------
  s             number;

begin

  create_procedure_log('CREATE_TESTIN_DATA_TABLE', 'create table:NB_TESTIN_RPT_SCRIPT_' || tableStr, 'run');


  -- 判断是否指定表已经建立
  select count(*) into s from user_tables where table_name = 'NB_TESTIN_RPT_SCRIPT_' || tableStr;
  if s > 0 then
    create_procedure_log('CREATE_TESTIN_DATA_TABLE', 'table:NB_TESTIN_RPT_SCRIPT_' || tableStr || '已经存在', 'warning');
    return;
  end if;

  -- 创建element
  -- 首先计算出elem的分区名称及值范围
  select order_num, to_char(sunday, 'yyyy-mm-dd')
    into orderNum, rangeDate
    from nb_part_calendar t
   where t.sunday = (select trunc(createDate + 8 - to_char(createDate, 'd'), 'd') from dual);

  partname1     := 'PART_SCRIPT_' || tableStr || '_' || orderNum;
  STEP_partname1 := 'PART_STEP_' || tableStr || '_' || orderNum;
  STRUCT_partname1 := 'PART_STRUCT_' || tableStr || '_' || orderNum;
  rangedate1    := 'to_date(''' || rangeDate || ''',''yyyy-mm-dd'')';

  select order_num, to_char(sunday, 'yyyy-mm-dd')
    into orderNum, rangeDate
    from nb_part_calendar t
   where t.sunday = (select trunc(createDate + 15 - to_char(createDate, 'd'), 'd') from dual);

  partname2     := 'PART_SCRIPT_' || tableStr || '_' || orderNum;
  STEP_partname2 := 'PART_STEP_' || tableStr || '_' || orderNum;
  STRUCT_partname2 := 'PART_STRUCT_' || tableStr || '_' || orderNum;
  rangedate2    := 'to_date(''' || rangeDate || ''',''yyyy-mm-dd'')';

  select order_num, to_char(sunday, 'yyyy-mm-dd')
    into orderNum, rangeDate
    from nb_part_calendar t
   where t.sunday = (select trunc(createDate + 22 - to_char(createDate, 'd'), 'd') from dual);

  partname3     := 'PART_SCRIPT_' || tableStr || '_' || orderNum;
  STEP_partname3 := 'PART_STEP_' || tableStr || '_' || orderNum;
  STRUCT_partname3 := 'PART_STRUCT_' || tableStr || '_' || orderNum;
  rangedate3    := 'to_date(''' || rangeDate || ''',''yyyy-mm-dd'')';
 table_name := 'NB_TESTIN_RPT_SCRIPT_' || tableStr;
  sqlStr := 'create table NB_TESTIN_RPT_SCRIPT_' || tableStr || '
      (
        ID                       NUMBER,
        TASK_ID                  NUMBER,
        SCRIPT_ID                NUMBER,
        SCRIPT_NO                NUMBER,
        PROBE_ID                 NUMBER,
        TIME_STAMP               DATE,
        CITY_ID                  NUMBER,
        NET_SPEED_ID             NUMBER,
        ISP_ID                   NUMBER,
        DEVICE_NAME              VARCHAR2(32),
        OS_VERSION               VARCHAR2(32),
        RESOLUTION_RATIO         VARCHAR2(128),
        TAKE_UP_TIME             NUMBER,
        MARK_TIME                NUMBER,
        MARK_COUNT               NUMBER,
        ERROR_CODE               NUMBER,
        NBFS_PATH                VARCHAR2(128),
        OS_ID                    NUMBER,
        OS_VER_ID                NUMBER,
        SCRIPT_NAME              VARCHAR2(1024),
        HANDLE_SVR               VARCHAR2(128),
        testin_monitor_id        VARCHAR2(32),
        testin_task_id           VARCHAR2(32),
        testin_subtask_id        VARCHAR2(32),
        INLINE                   NUMBER,
        CRASH                    NUMBER(10),
        POINT_TOTAL              NUMBER(1) DEFAULT 1,
        ctime timestamp default sysdate
  ) pctfree 0
    partition by range (TIME_STAMP)(
                  partition ' || partname1 || ' values less than (' || rangedate1 || '),
                  partition ' || partname2 || ' values less than (' || rangedate2 || '),
                  partition ' || partname3 || ' values less than (' || rangedate3 || '))
              tablespace NETBEN_NEW';
  execute immediate sqlStr;
  info := info || table_name || ' created, ';

  -- 索引
  sqlStr := 'create index IDX_TESTIN_CRIPT_' || tableStr || ' on NB_TESTIN_RPT_SCRIPT_' || tableStr || ' (task_id ,script_no) local tableSpace  NETBEN_IND nologging';
  execute immediate sqlStr;

  --创建表
  info := info || table_name || ' created, ';
  sqlStr := 'create table NB_TESTIN_RPT_STEP_' || tableStr || '
    (
        ID                       NUMBER,
        REPORT_SCRIPT_ID         NUMBER,
        TASK_ID                  NUMBER,
        STEP_ID                  NUMBER,
        SCRIPT_ID                NUMBER,
        SCRIPT_NO                NUMBER,
        PROBE_ID                 NUMBER,
        TIME_STAMP               DATE,
        CITY_ID                  NUMBER,
        NET_SPEED_ID             NUMBER,
        ISP_ID                   NUMBER,
        DEVICE_NAME              VARCHAR2(32),
        OS_VERSION               VARCHAR2(32),
        RESOLUTION_RATIO         VARCHAR2(128),
        START_TIME               DATE,
        END_TIME                 DATE,
        DELAY_TIME               NUMBER,
        DESCR                    VARCHAR2(128),
        ERROR_CODE                NUMBER,
        ERROR_MSG                 NUMBER,
        OS_ID                    NUMBER,
        OS_VER_ID                NUMBER,
        SCRIPT_NAME               VARCHAR2(1024),
        HANDLE_SVR               VARCHAR2(128),
        POINT_TOTAL              NUMBER(1) DEFAULT 1,
        type INTEGER default 2
    ) pctfree 0
    partition by range (TIME_STAMP)(
                  partition ' || STEP_partname1 || ' values less than (' || rangedate1 || '),
                  partition ' || STEP_partname2 || ' values less than (' || rangedate2 || '),
                  partition ' || STEP_partname3 || ' values less than (' || rangedate3 || '))
              tablespace NETBEN_NEW';
  execute immediate sqlStr;
  info := info || table_name || ' created, ';

  -- 索引 task_id ,script_no
  sqlStr := 'create index IDX_TESTIN_STEP_' || tableStr || ' on NB_TESTIN_RPT_STEP_' || tableStr || ' (task_id ,script_no) local tableSpace  NETBEN_IND nologging';
  execute immediate sqlStr;

    sqlStr := 'create index IDX_TESTIN_STEPDESCR_' || tableStr || ' on NB_TESTIN_RPT_STEP_' || tableStr || ' (DESCR) local tableSpace  NETBEN_IND nologging';
  execute immediate sqlStr;

  -- 创建表
  info := info || table_name || ' created, ';
  sqlStr := 'create table NB_TESTIN_RPT_STRUCT_' || tableStr || '
    (
        monitor_id     VARCHAR2(32) not null,
        task_id        INTEGER not null,
        nbfs_path      NVARCHAR2(256) not null,
        ctime          DATE default sysdate not null,
        testin_task_id VARCHAR2(32),
        HANDLE_SVR     VARCHAR2(128)
    ) pctfree 0
    partition by range (ctime)(
                  partition ' || STRUCT_partname1 || ' values less than (' || rangedate1 || '),
                  partition ' || STRUCT_partname2 || ' values less than (' || rangedate2 || '),
                  partition ' || STRUCT_partname3 || ' values less than (' || rangedate3 || '))
              tablespace NETBEN_NEW';
  execute immediate sqlStr;
  info := info || table_name || ' created, ';

  --索引 TESTIN_TASK_ID,MONITOR_ID, TASK_ID
  sqlStr := 'create index IDX_TESTIN_STRUCT_' || tableStr || ' on NB_TESTIN_RPT_STRUCT_' || tableStr || ' (TESTIN_TASK_ID,MONITOR_ID, TASK_ID) local  tableSpace  NETBEN_IND nologging';
  execute immediate sqlStr;

exception
  when others then
    errorDesc := 'Error :' || sqlerrm || '  tableStr:' || tableStr;
    --DBMS_OUTPUT.PUT_LINE(v_error_desc);
    create_procedure_log('CREATE_TESTIN_DATA_TABLE', errorDesc, 'error');

end CREATE_TESTIN_DATA_TABLE;
/

