create PROCEDURE          "CALC_FIELD_AVG" (
 taskId in number,
 createDate in date
 ) authid current_user
is
  sqlStr  varchar2(8000);
  errorDesc varchar2(4000);
  ---------------- 主变量 ---------------------------------------------------------------------------
  taskType number; -- 0 ping 1 页面 2 事务 3 流媒体 5 手机应用 10 路由 255 私有协议
  tableName varchar2(16);
  ctime date;
  calcDate date;
  ---------------- 临时变量 --------------------------------------------------------------------------
  task_type number;
  agreement_id number;
  task_option varchar(2);
  table_str varchar(8);
  runCount number;
begin
  --首先判断是否指定的任务正在执行,如果有执行的，将不在执行该存储过程
  select count(task_id) into runCount from nb_is_avg_run_status where task_id = taskId;
  if (runCount < 1) then
    sqlStr:= 'insert into nb_is_avg_run_status values(:taskId,:ctime)';
    execute immediate sqlStr using taskId,sysdate;
    commit;

    if (createDate is null) then
        ctime := sysdate;
    else
        ctime := createDate;
    end if;
    calcDate := trunc(ctime,'d');
    --任务类型判断 ,取出任务类型及对应的分析表
    select type,task_option,agreement_id into task_type,task_option,agreement_id from nb_m_task where id = taskId;

    select table_str into table_str from nb_m_agreement where id = agreement_id;
    if (task_type = 1) then
       if (task_option = 'P') then
          taskType := 0;
          tableName := 'tran_' || table_str;
       elsif (task_option = 'T') then
          taskType := 10;
          tableName := 'trace_' || table_str;
       else
          taskType := 1;
          tableName := 'page_' || table_str;
       end if;
     else
       taskType := task_type;
       if (task_type = 255) then
          tableName := 'custom_' || table_str;
       elsif(task_type = 2) then
          tableName := 'tran_' || table_str;
       elsif(task_type = 5) then
          tableName := 'mobapp_' || table_str;
       elsif(task_type = 3) then
          tableName := 'stream_' || table_str;
       end if;
     end if;
     -- 首先删除可能生成的数据
     sqlStr := 'delete from nb_is_avg where task_id = :tid and calc_date = :cdate';
     execute immediate sqlStr using taskId,calcDate;
     commit;
     -- 1 性能指标分析 , 暂时只实现页面及流媒体
     if (taskType = 1) then
       -- 1） 页面，涉及的性能指标 ts_total,ts_dns,ts_connect,ts_first_packet,ts_contents,cont_ele_total,cont_err_total,byte_total,byte_base_page
       sqlStr := 'insert into nb_is_avg(task_id,calc_date,calc_type,calc_item,ts_total,ts_dns,ts_connect,
               ts_first_packet,ts_contents,byte_total,byte_page_base,cont_err_total,cont_ele_total,
               ts_user,num_first_elem,byte_first,percent_succ,
               ts_total_stddev,ts_dns_stddev,ts_connect_stddev,ts_first_packet_stddev,ts_contents_stddev,
               byte_total_stddev,byte_page_base_stddev,cont_err_total_stddev,cont_ele_total_stddev,
               ts_user_stddev,num_first_elem_stddev,byte_first_stddev,ctime)
               select :tid,:calcDate,0,0,tmp.*,:ctime
                  from
                    (select
                      trunc(case when point_succ=0 then 0 else ts_total / point_succ end,0) as ts_total,
                      trunc(case when point_succ=0 then 0 else ts_dns / point_succ end,0) as ts_dns,
                      trunc(case when point_succ=0 then 0 else ts_connect / point_succ end,0) as ts_connect,
                      trunc(case when point_succ=0 then 0 else ts_first_packet / point_succ end,0) as ts_first_packet,
                      trunc(case when point_succ=0 then 0 else ts_contents / point_succ end,0) as ts_contents,
                      trunc(case when point_succ=0 then 0 else byte_total / point_succ end,0) as byte_total,
                      trunc(case when point_succ=0 then 0 else byte_page_base / point_succ end,0) as byte_page_base,
                      trunc(case when point_succ=0 then 0 else cont_err_total / point_succ end,2) as cont_err_total,
                      trunc(case when point_succ=0 then 0 else cont_ele_total / point_succ end,0) as cont_ele_total,
                      trunc(case when point_succ=0 then 0 else ts_user / point_succ end,0) as ts_user,
                      trunc(case when point_succ=0 then 0 else num_first_elem / point_succ end,0) as num_first_elem,
                      trunc(case when point_succ=0 then 0 else byte_first / point_succ end,0) as byte_first,
                      trunc(case when point_succ=0 then 0 else point_succ / point_total end,4) as percent_succ,
                      trunc(ts_total_stddev,0) as ts_total_stddev,
                      trunc(ts_dns_stddev,0) as ts_dns_stddev,
                      trunc(ts_connect_stddev,0) as ts_connect_stddev,
                      trunc(ts_first_packet_stddev,0) as ts_first_packet_stddev,
                      trunc(ts_contents_stddev,0) as ts_contents_stddev,
                      trunc(byte_total_stddev,0) as byte_total_stddev,
                      trunc(byte_page_base_stddev,0) as byte_page_base_stddev,
                      trunc(cont_err_total_stddev,2) as cont_err_total_stddev,
                      trunc(cont_ele_total_stddev,2) as cont_ele_total_stddev,
                      trunc(ts_user_stddev,0) as ts_user_stddev,
                      trunc(num_first_elem_stddev,0) as num_first_elem_stddev,
                      trunc(byte_first_stddev,0) as byte_first_stddev
                    from
                      (select
                        sum(case when error_code > 600000 then 0 else ts_total * point_total end) as ts_total,
                        sum(case when error_code > 600000 then 0 else ts_dns * point_total end) as ts_dns,
                        sum(case when error_code > 600000 then 0 else ts_connect * point_total end) as ts_connect,
                        sum(case when error_code > 600000 then 0 else ts_first_packet * point_total end) as ts_first_packet,
                        sum(case when error_code > 600000 then 0 else ts_contents * point_total end) as ts_contents,
                        sum(case when error_code > 600000 then 0 else byte_total * point_total end) as byte_total,
                        sum(case when error_code > 600000 then 0 else byte_page_base * point_total end) as byte_page_base,
                        sum(case when error_code > 600000 then 0 else cont_err_total * point_total end) as cont_err_total,
                        sum(case when error_code > 600000 then 0 else cont_ele_total * point_total end) as cont_ele_total,
                        sum(case when error_code > 600000 then 0 else ts_user * point_total end) as ts_user,
                        sum(case when error_code > 600000 then 0 else num_first_elem * point_total end) as num_first_elem,
                        sum(case when error_code > 600000 then 0 else byte_first * point_total end) as byte_first,
                        sum(case when error_code > 600000 then 0 else point_total end) as point_succ,
                        sum(point_total) as point_total,
                        stddev(case when error_code > 600000 then null else ts_total end) as ts_total_stddev,
                        stddev(case when error_code > 600000 then null else ts_dns end) as ts_dns_stddev,
                        stddev(case when error_code > 600000 then null else ts_connect end) as ts_connect_stddev,
                        stddev(case when error_code > 600000 then null else ts_first_packet end) as ts_first_packet_stddev,
                        stddev(case when error_code > 600000 then null else ts_contents end) as ts_contents_stddev,
                        stddev(case when error_code > 600000 then null else byte_total end) as byte_total_stddev,
                        stddev(case when error_code > 600000 then null else byte_page_base end) as byte_page_base_stddev,
                        stddev(case when error_code > 600000 then null else cont_err_total end) as cont_err_total_stddev,
                        stddev(case when error_code > 600000 then null else cont_ele_total end) as cont_ele_total_stddev,
                        stddev(case when error_code > 600000 then null else ts_user end) as ts_user_stddev,
                        stddev(case when error_code > 600000 then null else num_first_elem end) as num_first_elem_stddev,
                        stddev(case when error_code > 600000 then null else byte_first end) as byte_first_stddev
                      from
                        (select trunc(tm_hour8,''dd'') as tm_day,case when error_code < 600000 then 0 else 600001 end as error_code,
                          sum(ts_total * point_total)/sum(point_total) as ts_total,
                          sum(ts_dns * point_total)/sum(point_total) as ts_dns,
                          sum(ts_connect * point_total)/sum(point_total) as ts_connect,
                          sum(ts_first_packet * point_total)/sum(point_total) as ts_first_packet,
                          sum(ts_contents * point_total)/sum(point_total) as ts_contents,
                          sum(byte_total * point_total)/sum(point_total) as byte_total,
                          sum(byte_page_base * point_total)/sum(point_total) as byte_page_base,
                          sum(cont_err_total * point_total)/sum(point_total) as cont_err_total,
                          sum(cont_ele_total * point_total)/sum(point_total) as cont_ele_total,
                          sum(ts_user * point_total)/sum(point_total) as ts_user,
                          sum(num_first_elem * point_total)/sum(point_total) as num_first_elem,
                          sum(byte_first * point_total)/sum(point_total) as byte_first,
                          sum(point_total) as point_total
                        from mv_'|| tableName || '
                        where tm_hour8 > :ctime - 60
                              and task_id = :tid
                              and is_noise = 0
                        group by trunc(tm_hour8,''dd''),case when error_code < 600000 then 0 else 600001 end
                        )
                       )
                     ) tmp';
        execute immediate sqlStr using taskId,calcDate,ctime,ctime,taskId;
        commit;
      elsif (taskType = 3) then
        -- 2）流媒体,涉及的性能指标 ts_total,ts_dns,ts_connect_tcp,ts_buffer,ts_rebuffer
        sqlStr := 'insert into nb_is_avg(task_id,calc_date,calc_type,calc_item,ts_total,ts_dns,ts_connect_tcp,
                         ts_first_packet,buffer_count,ts_buffer,ts_rebuffer,percent_succ,
                         ts_total_stddev,ts_dns_stddev,ts_connect_tcp_stddev,ts_first_packet_stddev,buffer_count_stddev,
                         ts_buffer_stddev,ts_rebuffer_stddev,ctime)
               select :tid,:calcDate,0,0,tmp.*,:ctime
                  from
                    (select
                      trunc(case when point_succ=0 then 0 else ts_total / point_succ end,0) as ts_total,
                      trunc(case when point_succ=0 then 0 else ts_dns / point_succ end,0) as ts_dns,
                      trunc(case when point_succ=0 then 0 else ts_connect_tcp / point_succ end,0) as ts_connect_tcp,
                      trunc(case when point_succ=0 then 0 else ts_first_packet / point_succ end,0) as ts_first_packet,
                      trunc(case when point_succ=0 then 0 else buffer_count / point_succ end,2) as buffer_count,
                      trunc(case when point_succ=0 then 0 else ts_buffer / point_succ end,0) as ts_buffer,
                      trunc(case when point_succ=0 then 0 else ts_rebuffer / point_succ end,0) as ts_rebuffer,
                      trunc(case when point_succ=0 then 0 else point_succ / point_total end,4) as percent_succ,
                      trunc(ts_total_stddev,0) as ts_total_stddev,
                      trunc(ts_dns_stddev,0) as ts_dns_stddev,
                      trunc(ts_connect_tcp_stddev,0) as ts_connect_tcp_stddev,
                      trunc(ts_first_packet_stddev,0) as ts_first_packet_stddev,
                      trunc(buffer_count_stddev,0) as buffer_count_stddev,
                      trunc(ts_buffer_stddev,0) as ts_buffer_stddev,
                      trunc(ts_rebuffer_stddev,0) as ts_rebuffer_stddev
                    from
                      (select
                        sum(case when error_code > 600000 then 0 else ts_total * point_total end) as ts_total,
                        sum(case when error_code > 600000 then 0 else ts_dns * point_total end) as ts_dns,
                        sum(case when error_code > 600000 then 0 else ts_connect_tcp * point_total end) as ts_connect_tcp,
                        sum(case when error_code > 600000 then 0 else ts_first_packet * point_total end) as ts_first_packet,
                        sum(case when error_code > 600000 then 0 else buffer_count * point_total end) as buffer_count,
                        sum(case when error_code > 600000 then 0 else ts_buffer * point_total end) as ts_buffer,
                        sum(case when error_code > 600000 then 0 else ts_rebuffer * point_total end) as ts_rebuffer,
                        sum(case when error_code > 600000 then 0 else point_total end) as point_succ,
                        sum(point_total) as point_total,
                        stddev(case when error_code > 600000 then null else ts_total end) as ts_total_stddev,
                        stddev(case when error_code > 600000 then null else ts_dns end) as ts_dns_stddev,
                        stddev(case when error_code > 600000 then null else ts_connect_tcp end) as ts_connect_tcp_stddev,
                        stddev(case when error_code > 600000 then null else ts_first_packet end) as ts_first_packet_stddev,
                        stddev(case when error_code > 600000 then null else buffer_count end) as buffer_count_stddev,
                        stddev(case when error_code > 600000 then null else ts_buffer end) as ts_buffer_stddev,
                        stddev(case when error_code > 600000 then null else ts_rebuffer end) as ts_rebuffer_stddev
                      from
                        (select trunc(tm_hour8,''dd'') as tm_day,case when error_code < 600000 then 0 else 600001 end as error_code,
                          sum(ts_total * point_total)/sum(point_total) as ts_total,
                          sum(ts_dns * point_total)/sum(point_total) as ts_dns,
                          sum(ts_connect_tcp * point_total)/sum(point_total) as ts_connect_tcp,
                          sum(ts_first_packet * point_total)/sum(point_total) as ts_first_packet,
                          sum(buffer_count * point_total)/sum(point_total) as buffer_count,
                          sum(ts_buffer * point_total)/sum(point_total) as ts_buffer,
                          sum(ts_rebuffer * point_total)/sum(point_total) as ts_rebuffer,
                          sum(point_total) as point_total
                        from mv_'|| tableName || '
                        where tm_hour8 > :ctime - 60
                              and task_id = :tid
                              and is_noise = 0
                        group by trunc(tm_hour8,''dd''),case when error_code < 600000 then 0 else 600001 end
                        )
                       )
                     ) tmp';

        execute immediate sqlStr using taskId,calcDate,ctime,ctime,taskId;
        commit;
      end if;
      -- 2 主机分析
      if (taskType = 1) then
       -- 1） 页面，涉及的性能指标
       sqlStr := 'insert into nb_is_avg(task_id,calc_date,calc_type,calc_item,ts_total,ts_dns,ts_connect,
               ts_first_packet,ts_contents,byte_total,byte_page_base,cont_err_total,cont_ele_total,
               ts_user,num_first_elem,byte_first,percent_succ,
               ts_total_stddev,ts_dns_stddev,ts_connect_stddev,ts_first_packet_stddev,ts_contents_stddev,
               byte_total_stddev,byte_page_base_stddev,cont_err_total_stddev,cont_ele_total_stddev,
               ts_user_stddev,num_first_elem_stddev,byte_first_stddev,ctime)
               select :tid,:calcDate,1,tmp.*,:ctime
                  from
                    (select
                      dest_ip,
                      trunc(case when point_succ=0 then 0 else ts_total / point_succ end,0) as ts_total,
                      trunc(case when point_succ=0 then 0 else ts_dns / point_succ end,0) as ts_dns,
                      trunc(case when point_succ=0 then 0 else ts_connect / point_succ end,0) as ts_connect,
                      trunc(case when point_succ=0 then 0 else ts_first_packet / point_succ end,0) as ts_first_packet,
                      trunc(case when point_succ=0 then 0 else ts_contents / point_succ end,0) as ts_contents,
                      trunc(case when point_succ=0 then 0 else byte_total / point_succ end,0) as byte_total,
                      trunc(case when point_succ=0 then 0 else byte_page_base / point_succ end,0) as byte_page_base,
                      trunc(case when point_succ=0 then 0 else cont_err_total / point_succ end,2) as cont_err_total,
                      trunc(case when point_succ=0 then 0 else cont_ele_total / point_succ end,0) as cont_ele_total,
                      trunc(case when point_succ=0 then 0 else ts_user / point_succ end,0) as ts_user,
                      trunc(case when point_succ=0 then 0 else num_first_elem / point_succ end,0) as num_first_elem,
                      trunc(case when point_succ=0 then 0 else byte_first / point_succ end,0) as byte_first,
                      trunc(case when point_succ=0 then 0 else point_succ / point_total end,4) as percent_succ,
                      trunc(ts_total_stddev,0) as ts_total_stddev,
                      trunc(ts_dns_stddev,0) as ts_dns_stddev,
                      trunc(ts_connect_stddev,0) as ts_connect_stddev,
                      trunc(ts_first_packet_stddev,0) as ts_first_packet_stddev,
                      trunc(ts_contents_stddev,0) as ts_contents_stddev,
                      trunc(byte_total_stddev,0) as byte_total_stddev,
                      trunc(byte_page_base_stddev,0) as byte_page_base_stddev,
                      trunc(cont_err_total_stddev,2) as cont_err_total_stddev,
                      trunc(cont_ele_total_stddev,2) as cont_ele_total_stddev,
                      trunc(ts_user_stddev,0) as ts_user_stddev,
                      trunc(num_first_elem_stddev,0) as num_first_elem_stddev,
                      trunc(byte_first_stddev,0) as byte_first_stddev
                    from
                      (select
                        dest_ip,
                        sum(case when error_code > 600000 then 0 else ts_total * point_total end) as ts_total,
                        sum(case when error_code > 600000 then 0 else ts_dns * point_total end) as ts_dns,
                        sum(case when error_code > 600000 then 0 else ts_connect * point_total end) as ts_connect,
                        sum(case when error_code > 600000 then 0 else ts_first_packet * point_total end) as ts_first_packet,
                        sum(case when error_code > 600000 then 0 else ts_contents * point_total end) as ts_contents,
                        sum(case when error_code > 600000 then 0 else byte_total * point_total end) as byte_total,
                        sum(case when error_code > 600000 then 0 else byte_page_base * point_total end) as byte_page_base,
                        sum(case when error_code > 600000 then 0 else cont_err_total * point_total end) as cont_err_total,
                        sum(case when error_code > 600000 then 0 else cont_ele_total * point_total end) as cont_ele_total,
                        sum(case when error_code > 600000 then 0 else ts_user * point_total end) as ts_user,
                        sum(case when error_code > 600000 then 0 else num_first_elem * point_total end) as num_first_elem,
                        sum(case when error_code > 600000 then 0 else byte_first * point_total end) as byte_first,
                        sum(case when error_code > 600000 then 0 else point_total end) as point_succ,
                        sum(point_total) as point_total,
                        stddev(case when error_code > 600000 then null else ts_total end) as ts_total_stddev,
                        stddev(case when error_code > 600000 then null else ts_dns end) as ts_dns_stddev,
                        stddev(case when error_code > 600000 then null else ts_connect end) as ts_connect_stddev,
                        stddev(case when error_code > 600000 then null else ts_first_packet end) as ts_first_packet_stddev,
                        stddev(case when error_code > 600000 then null else ts_contents end) as ts_contents_stddev,
                        stddev(case when error_code > 600000 then null else byte_total end) as byte_total_stddev,
                        stddev(case when error_code > 600000 then null else byte_page_base end) as byte_page_base_stddev,
                        stddev(case when error_code > 600000 then null else cont_err_total end) as cont_err_total_stddev,
                        stddev(case when error_code > 600000 then null else cont_ele_total end) as cont_ele_total_stddev,
                        stddev(case when error_code > 600000 then null else ts_user end) as ts_user_stddev,
                        stddev(case when error_code > 600000 then null else num_first_elem end) as num_first_elem_stddev,
                        stddev(case when error_code > 600000 then null else byte_first end) as byte_first_stddev
                      from
                        (select 
                          ip2long(dest_ip) as dest_ip,
                          trunc(tm_hour8,''dd'') as tm_day,case when error_code < 600000 then 0 else 600001 end as error_code,
                          sum(ts_total * point_total)/sum(point_total) as ts_total,
                          sum(ts_dns * point_total)/sum(point_total) as ts_dns,
                          sum(ts_connect * point_total)/sum(point_total) as ts_connect,
                          sum(ts_first_packet * point_total)/sum(point_total) as ts_first_packet,
                          sum(ts_contents * point_total)/sum(point_total) as ts_contents,
                          sum(byte_total * point_total)/sum(point_total) as byte_total,
                          sum(byte_page_base * point_total)/sum(point_total) as byte_page_base,
                          sum(cont_err_total * point_total)/sum(point_total) as cont_err_total,
                          sum(cont_ele_total * point_total)/sum(point_total) as cont_ele_total,
                          sum(ts_user * point_total)/sum(point_total) as ts_user,
                          sum(num_first_elem * point_total)/sum(point_total) as num_first_elem,
                          sum(byte_first * point_total)/sum(point_total) as byte_first,
                          sum(point_total) as point_total
                        from mv_'|| tableName || '
                        where tm_hour8 > :ctime - 60
                              and task_id = :tid
                              and is_noise = 0
                              and dest_ip is not null
                        group by trunc(tm_hour8,''dd''),case when error_code < 600000 then 0 else 600001 end,
                              ip2long(dest_ip)
                        )group by dest_ip
                       )
                     ) tmp';
        execute immediate sqlStr using taskId,calcDate,ctime,ctime,taskId;
        commit;
      elsif (taskType = 3) then
        -- 2）流媒体,涉及的性能指标
        sqlStr := 'insert into nb_is_avg(task_id,calc_date,calc_type,calc_item,ts_total,ts_dns,ts_connect_tcp,
                         ts_first_packet,buffer_count,ts_buffer,ts_rebuffer,percent_succ,
                         ts_total_stddev,ts_dns_stddev,ts_connect_tcp_stddev,ts_first_packet_stddev,buffer_count_stddev,
                         ts_buffer_stddev,ts_rebuffer_stddev,ctime)
               select :tid,:calcDate,1,tmp.*,:ctime
                  from
                    (select
                      dest_ip,
                      trunc(case when point_succ=0 then 0 else ts_total / point_succ end,0) as ts_total,
                      trunc(case when point_succ=0 then 0 else ts_dns / point_succ end,0) as ts_dns,
                      trunc(case when point_succ=0 then 0 else ts_connect_tcp / point_succ end,0) as ts_connect_tcp,
                      trunc(case when point_succ=0 then 0 else ts_first_packet / point_succ end,0) as ts_first_packet,
                      trunc(case when point_succ=0 then 0 else buffer_count / point_succ end,2) as buffer_count,
                      trunc(case when point_succ=0 then 0 else ts_buffer / point_succ end,0) as ts_buffer,
                      trunc(case when point_succ=0 then 0 else ts_rebuffer / point_succ end,0) as ts_rebuffer,
                      trunc(case when point_succ=0 then 0 else point_succ / point_total end,4) as percent_succ,
                      trunc(ts_total_stddev,0) as ts_total_stddev,
                      trunc(ts_dns_stddev,0) as ts_dns_stddev,
                      trunc(ts_connect_tcp_stddev,0) as ts_connect_tcp_stddev,
                      trunc(ts_first_packet_stddev,0) as ts_first_packet_stddev,
                      trunc(buffer_count_stddev,0) as buffer_count_stddev,
                      trunc(ts_buffer_stddev,0) as ts_buffer_stddev,
                      trunc(ts_rebuffer_stddev,0) as ts_rebuffer_stddev
                    from
                      (select
                        dest_ip,
                        sum(case when error_code > 600000 then 0 else ts_total * point_total end) as ts_total,
                        sum(case when error_code > 600000 then 0 else ts_dns * point_total end) as ts_dns,
                        sum(case when error_code > 600000 then 0 else ts_connect_tcp * point_total end) as ts_connect_tcp,
                        sum(case when error_code > 600000 then 0 else ts_first_packet * point_total end) as ts_first_packet,
                        sum(case when error_code > 600000 then 0 else buffer_count * point_total end) as buffer_count,
                        sum(case when error_code > 600000 then 0 else ts_buffer * point_total end) as ts_buffer,
                        sum(case when error_code > 600000 then 0 else ts_rebuffer * point_total end) as ts_rebuffer,
                        sum(case when error_code > 600000 then 0 else point_total end) as point_succ,
                        sum(point_total) as point_total,
                        stddev(case when error_code > 600000 then null else ts_total end) as ts_total_stddev,
                        stddev(case when error_code > 600000 then null else ts_dns end) as ts_dns_stddev,
                        stddev(case when error_code > 600000 then null else ts_connect_tcp end) as ts_connect_tcp_stddev,
                        stddev(case when error_code > 600000 then null else ts_first_packet end) as ts_first_packet_stddev,
                        stddev(case when error_code > 600000 then null else buffer_count end) as buffer_count_stddev,
                        stddev(case when error_code > 600000 then null else ts_buffer end) as ts_buffer_stddev,
                        stddev(case when error_code > 600000 then null else ts_rebuffer end) as ts_rebuffer_stddev
                      from
                        (select
                          ip2long(dest_ip) as dest_ip,
                          trunc(tm_hour8,''dd'') as tm_day,case when error_code < 600000 then 0 else 600001 end as error_code,
                          sum(ts_total * point_total)/sum(point_total) as ts_total,
                          sum(ts_dns * point_total)/sum(point_total) as ts_dns,
                          sum(ts_connect_tcp * point_total)/sum(point_total) as ts_connect_tcp,
                          sum(ts_first_packet * point_total)/sum(point_total) as ts_first_packet,
                          sum(buffer_count * point_total)/sum(point_total) as buffer_count,
                          sum(ts_buffer * point_total)/sum(point_total) as ts_buffer,
                          sum(ts_rebuffer * point_total)/sum(point_total) as ts_rebuffer,
                          sum(point_total) as point_total
                        from mv_'|| tableName || '
                        where tm_hour8 > :ctime - 60
                              and task_id = :tid
                              and is_noise = 0
                              and dest_ip is not null
                        group by trunc(tm_hour8,''dd''),case when error_code < 600000 then 0 else 600001 end,
                            ip2long(dest_ip)
                        )group by dest_ip
                       )
                     ) tmp';
        execute immediate sqlStr using taskId,calcDate,ctime,ctime,taskId;
        commit;
      end if;
      -- 3 城市分析
      if (taskType = 1) then
       -- 1） 页面，涉及的性能指标
       sqlStr := 'insert into nb_is_avg(task_id,calc_date,calc_type,calc_item,ts_total,ts_dns,ts_connect,
               ts_first_packet,ts_contents,byte_total,byte_page_base,cont_err_total,cont_ele_total,
               ts_user,num_first_elem,byte_first,percent_succ,
               ts_total_stddev,ts_dns_stddev,ts_connect_stddev,ts_first_packet_stddev,ts_contents_stddev,
               byte_total_stddev,byte_page_base_stddev,cont_err_total_stddev,cont_ele_total_stddev,
               ts_user_stddev,num_first_elem_stddev,byte_first_stddev,ctime)
               select :tid,:calcDate,2,tmp.*,:ctime
                  from
                    (select
                      city_id,
                      trunc(case when point_succ=0 then 0 else ts_total / point_succ end,0) as ts_total,
                      trunc(case when point_succ=0 then 0 else ts_dns / point_succ end,0) as ts_dns,
                      trunc(case when point_succ=0 then 0 else ts_connect / point_succ end,0) as ts_connect,
                      trunc(case when point_succ=0 then 0 else ts_first_packet / point_succ end,0) as ts_first_packet,
                      trunc(case when point_succ=0 then 0 else ts_contents / point_succ end,0) as ts_contents,
                      trunc(case when point_succ=0 then 0 else byte_total / point_succ end,0) as byte_total,
                      trunc(case when point_succ=0 then 0 else byte_page_base / point_succ end,0) as byte_page_base,
                      trunc(case when point_succ=0 then 0 else cont_err_total / point_succ end,2) as cont_err_total,
                      trunc(case when point_succ=0 then 0 else cont_ele_total / point_succ end,0) as cont_ele_total,
                      trunc(case when point_succ=0 then 0 else ts_user / point_succ end,0) as ts_user,
                      trunc(case when point_succ=0 then 0 else num_first_elem / point_succ end,0) as num_first_elem,
                      trunc(case when point_succ=0 then 0 else byte_first / point_succ end,0) as byte_first,
                      trunc(case when point_succ=0 then 0 else point_succ / point_total end,4) as percent_succ,
                      trunc(ts_total_stddev,0) as ts_total_stddev,
                      trunc(ts_dns_stddev,0) as ts_dns_stddev,
                      trunc(ts_connect_stddev,0) as ts_connect_stddev,
                      trunc(ts_first_packet_stddev,0) as ts_first_packet_stddev,
                      trunc(ts_contents_stddev,0) as ts_contents_stddev,
                      trunc(byte_total_stddev,0) as byte_total_stddev,
                      trunc(byte_page_base_stddev,0) as byte_page_base_stddev,
                      trunc(cont_err_total_stddev,2) as cont_err_total_stddev,
                      trunc(cont_ele_total_stddev,2) as cont_ele_total_stddev,
                      trunc(ts_user_stddev,0) as ts_user_stddev,
                      trunc(num_first_elem_stddev,0) as num_first_elem_stddev,
                      trunc(byte_first_stddev,0) as byte_first_stddev
                    from
                      (select
                        city_id,
                        sum(case when error_code > 600000 then 0 else ts_total * point_total end) as ts_total,
                        sum(case when error_code > 600000 then 0 else ts_dns * point_total end) as ts_dns,
                        sum(case when error_code > 600000 then 0 else ts_connect * point_total end) as ts_connect,
                        sum(case when error_code > 600000 then 0 else ts_first_packet * point_total end) as ts_first_packet,
                        sum(case when error_code > 600000 then 0 else ts_contents * point_total end) as ts_contents,
                        sum(case when error_code > 600000 then 0 else byte_total * point_total end) as byte_total,
                        sum(case when error_code > 600000 then 0 else byte_page_base * point_total end) as byte_page_base,
                        sum(case when error_code > 600000 then 0 else cont_err_total * point_total end) as cont_err_total,
                        sum(case when error_code > 600000 then 0 else cont_ele_total * point_total end) as cont_ele_total,
                        sum(case when error_code > 600000 then 0 else ts_user * point_total end) as ts_user,
                        sum(case when error_code > 600000 then 0 else num_first_elem * point_total end) as num_first_elem,
                        sum(case when error_code > 600000 then 0 else byte_first * point_total end) as byte_first,
                        sum(case when error_code > 600000 then 0 else point_total end) as point_succ,
                        sum(point_total) as point_total,
                        stddev(case when error_code > 600000 then null else ts_total end) as ts_total_stddev,
                        stddev(case when error_code > 600000 then null else ts_dns end) as ts_dns_stddev,
                        stddev(case when error_code > 600000 then null else ts_connect end) as ts_connect_stddev,
                        stddev(case when error_code > 600000 then null else ts_first_packet end) as ts_first_packet_stddev,
                        stddev(case when error_code > 600000 then null else ts_contents end) as ts_contents_stddev,
                        stddev(case when error_code > 600000 then null else byte_total end) as byte_total_stddev,
                        stddev(case when error_code > 600000 then null else byte_page_base end) as byte_page_base_stddev,
                        stddev(case when error_code > 600000 then null else cont_err_total end) as cont_err_total_stddev,
                        stddev(case when error_code > 600000 then null else cont_ele_total end) as cont_ele_total_stddev,
                        stddev(case when error_code > 600000 then null else ts_user end) as ts_user_stddev,
                        stddev(case when error_code > 600000 then null else num_first_elem end) as num_first_elem_stddev,
                        stddev(case when error_code > 600000 then null else byte_first end) as byte_first_stddev
                      from
                        (select 
                          city_id,
                          trunc(tm_hour8,''dd'') as tm_day,case when error_code < 600000 then 0 else 600001 end as error_code,
                          sum(ts_total * point_total)/sum(point_total) as ts_total,
                          sum(ts_dns * point_total)/sum(point_total) as ts_dns,
                          sum(ts_connect * point_total)/sum(point_total) as ts_connect,
                          sum(ts_first_packet * point_total)/sum(point_total) as ts_first_packet,
                          sum(ts_contents * point_total)/sum(point_total) as ts_contents,
                          sum(byte_total * point_total)/sum(point_total) as byte_total,
                          sum(byte_page_base * point_total)/sum(point_total) as byte_page_base,
                          sum(cont_err_total * point_total)/sum(point_total) as cont_err_total,
                          sum(cont_ele_total * point_total)/sum(point_total) as cont_ele_total,
                          sum(ts_user * point_total)/sum(point_total) as ts_user,
                          sum(num_first_elem * point_total)/sum(point_total) as num_first_elem,
                          sum(byte_first * point_total)/sum(point_total) as byte_first,
                          sum(point_total) as point_total
                        from mv_'|| tableName || '
                        where tm_hour8 > :ctime - 60
                              and task_id = :tid
                              and is_noise = 0
                        group by trunc(tm_hour8,''dd''),case when error_code < 600000 then 0 else 600001 end,city_id
                        )group by city_id
                       )
                     ) tmp';
        execute immediate sqlStr using taskId,calcDate,ctime,ctime,taskId;
        commit;
      elsif (taskType = 3) then
        -- 2）流媒体,涉及的性能指标
        sqlStr := 'insert into nb_is_avg(task_id,calc_date,calc_type,calc_item,ts_total,ts_dns,ts_connect_tcp,
                         ts_first_packet,buffer_count,ts_buffer,ts_rebuffer,percent_succ,
                         ts_total_stddev,ts_dns_stddev,ts_connect_tcp_stddev,ts_first_packet_stddev,buffer_count_stddev,
                         ts_buffer_stddev,ts_rebuffer_stddev,ctime)
               select :tid,:calcDate,2,tmp.*,:ctime
                  from
                    (select
                      city_id,
                      trunc(case when point_succ=0 then 0 else ts_total / point_succ end,0) as ts_total,
                      trunc(case when point_succ=0 then 0 else ts_dns / point_succ end,0) as ts_dns,
                      trunc(case when point_succ=0 then 0 else ts_connect_tcp / point_succ end,0) as ts_connect_tcp,
                      trunc(case when point_succ=0 then 0 else ts_first_packet / point_succ end,0) as ts_first_packet,
                      trunc(case when point_succ=0 then 0 else buffer_count / point_succ end,2) as buffer_count,
                      trunc(case when point_succ=0 then 0 else ts_buffer / point_succ end,0) as ts_buffer,
                      trunc(case when point_succ=0 then 0 else ts_rebuffer / point_succ end,0) as ts_rebuffer,
                      trunc(case when point_succ=0 then 0 else point_succ / point_total end,4) as percent_succ,
                      trunc(ts_total_stddev,0) as ts_total_stddev,
                      trunc(ts_dns_stddev,0) as ts_dns_stddev,
                      trunc(ts_connect_tcp_stddev,0) as ts_connect_tcp_stddev,
                      trunc(ts_first_packet_stddev,0) as ts_first_packet_stddev,
                      trunc(buffer_count_stddev,0) as buffer_count_stddev,
                      trunc(ts_buffer_stddev,0) as ts_buffer_stddev,
                      trunc(ts_rebuffer_stddev,0) as ts_rebuffer_stddev
                    from
                      (select
                        city_id,
                        sum(case when error_code > 600000 then 0 else ts_total * point_total end) as ts_total,
                        sum(case when error_code > 600000 then 0 else ts_dns * point_total end) as ts_dns,
                        sum(case when error_code > 600000 then 0 else ts_connect_tcp * point_total end) as ts_connect_tcp,
                        sum(case when error_code > 600000 then 0 else ts_first_packet * point_total end) as ts_first_packet,
                        sum(case when error_code > 600000 then 0 else buffer_count * point_total end) as buffer_count,
                        sum(case when error_code > 600000 then 0 else ts_buffer * point_total end) as ts_buffer,
                        sum(case when error_code > 600000 then 0 else ts_rebuffer * point_total end) as ts_rebuffer,
                        sum(case when error_code > 600000 then 0 else point_total end) as point_succ,
                        sum(point_total) as point_total,
                        stddev(case when error_code > 600000 then null else ts_total end) as ts_total_stddev,
                        stddev(case when error_code > 600000 then null else ts_dns end) as ts_dns_stddev,
                        stddev(case when error_code > 600000 then null else ts_connect_tcp end) as ts_connect_tcp_stddev,
                        stddev(case when error_code > 600000 then null else ts_first_packet end) as ts_first_packet_stddev,
                        stddev(case when error_code > 600000 then null else buffer_count end) as buffer_count_stddev,
                        stddev(case when error_code > 600000 then null else ts_buffer end) as ts_buffer_stddev,
                        stddev(case when error_code > 600000 then null else ts_rebuffer end) as ts_rebuffer_stddev
                      from
                        (select
                          city_id,
                          trunc(tm_hour8,''dd'') as tm_day,case when error_code < 600000 then 0 else 600001 end as error_code,
                          sum(ts_total * point_total)/sum(point_total) as ts_total,
                          sum(ts_dns * point_total)/sum(point_total) as ts_dns,
                          sum(ts_connect_tcp * point_total)/sum(point_total) as ts_connect_tcp,
                          sum(ts_first_packet * point_total)/sum(point_total) as ts_first_packet,
                          sum(buffer_count * point_total)/sum(point_total) as buffer_count,
                          sum(ts_buffer * point_total)/sum(point_total) as ts_buffer,
                          sum(ts_rebuffer * point_total)/sum(point_total) as ts_rebuffer,
                          sum(point_total) as point_total
                        from mv_'|| tableName || '
                        where tm_hour8 > :ctime - 60
                              and task_id = :tid
                              and is_noise = 0
                        group by trunc(tm_hour8,''dd''),case when error_code < 600000 then 0 else 600001 end,
                            city_id
                        )group by city_id
                       )
                     ) tmp';
        execute immediate sqlStr using taskId,calcDate,ctime,ctime,taskId;
        commit;
      end if;
      -- 4 运营商分析
      if (taskType = 1) then
       -- 1） 页面，涉及的性能指标
       sqlStr := 'insert into nb_is_avg(task_id,calc_date,calc_type,calc_item,ts_total,ts_dns,ts_connect,
               ts_first_packet,ts_contents,byte_total,byte_page_base,cont_err_total,cont_ele_total,
               ts_user,num_first_elem,byte_first,percent_succ,
               ts_total_stddev,ts_dns_stddev,ts_connect_stddev,ts_first_packet_stddev,ts_contents_stddev,
               byte_total_stddev,byte_page_base_stddev,cont_err_total_stddev,cont_ele_total_stddev,
               ts_user_stddev,num_first_elem_stddev,byte_first_stddev,ctime)
               select :tid,:calcDate,3,tmp.*,:ctime
                  from
                    (select
                      isp_id,
                      trunc(case when point_succ=0 then 0 else ts_total / point_succ end,0) as ts_total,
                      trunc(case when point_succ=0 then 0 else ts_dns / point_succ end,0) as ts_dns,
                      trunc(case when point_succ=0 then 0 else ts_connect / point_succ end,0) as ts_connect,
                      trunc(case when point_succ=0 then 0 else ts_first_packet / point_succ end,0) as ts_first_packet,
                      trunc(case when point_succ=0 then 0 else ts_contents / point_succ end,0) as ts_contents,
                      trunc(case when point_succ=0 then 0 else byte_total / point_succ end,0) as byte_total,
                      trunc(case when point_succ=0 then 0 else byte_page_base / point_succ end,0) as byte_page_base,
                      trunc(case when point_succ=0 then 0 else cont_err_total / point_succ end,2) as cont_err_total,
                      trunc(case when point_succ=0 then 0 else cont_ele_total / point_succ end,0) as cont_ele_total,
                      trunc(case when point_succ=0 then 0 else ts_user / point_succ end,0) as ts_user,
                      trunc(case when point_succ=0 then 0 else num_first_elem / point_succ end,0) as num_first_elem,
                      trunc(case when point_succ=0 then 0 else byte_first / point_succ end,0) as byte_first,
                      trunc(case when point_succ=0 then 0 else point_succ / point_total end,4) as percent_succ,
                      trunc(ts_total_stddev,0) as ts_total_stddev,
                      trunc(ts_dns_stddev,0) as ts_dns_stddev,
                      trunc(ts_connect_stddev,0) as ts_connect_stddev,
                      trunc(ts_first_packet_stddev,0) as ts_first_packet_stddev,
                      trunc(ts_contents_stddev,0) as ts_contents_stddev,
                      trunc(byte_total_stddev,0) as byte_total_stddev,
                      trunc(byte_page_base_stddev,0) as byte_page_base_stddev,
                      trunc(cont_err_total_stddev,2) as cont_err_total_stddev,
                      trunc(cont_ele_total_stddev,2) as cont_ele_total_stddev,
                      trunc(ts_user_stddev,0) as ts_user_stddev,
                      trunc(num_first_elem_stddev,0) as num_first_elem_stddev,
                      trunc(byte_first_stddev,0) as byte_first_stddev
                    from
                      (select
                        isp_id,
                        sum(case when error_code > 600000 then 0 else ts_total * point_total end) as ts_total,
                        sum(case when error_code > 600000 then 0 else ts_dns * point_total end) as ts_dns,
                        sum(case when error_code > 600000 then 0 else ts_connect * point_total end) as ts_connect,
                        sum(case when error_code > 600000 then 0 else ts_first_packet * point_total end) as ts_first_packet,
                        sum(case when error_code > 600000 then 0 else ts_contents * point_total end) as ts_contents,
                        sum(case when error_code > 600000 then 0 else byte_total * point_total end) as byte_total,
                        sum(case when error_code > 600000 then 0 else byte_page_base * point_total end) as byte_page_base,
                        sum(case when error_code > 600000 then 0 else cont_err_total * point_total end) as cont_err_total,
                        sum(case when error_code > 600000 then 0 else cont_ele_total * point_total end) as cont_ele_total,
                        sum(case when error_code > 600000 then 0 else ts_user * point_total end) as ts_user,
                        sum(case when error_code > 600000 then 0 else num_first_elem * point_total end) as num_first_elem,
                        sum(case when error_code > 600000 then 0 else byte_first * point_total end) as byte_first,
                        sum(case when error_code > 600000 then 0 else point_total end) as point_succ,
                        sum(point_total) as point_total,
                        stddev(case when error_code > 600000 then null else ts_total end) as ts_total_stddev,
                        stddev(case when error_code > 600000 then null else ts_dns end) as ts_dns_stddev,
                        stddev(case when error_code > 600000 then null else ts_connect end) as ts_connect_stddev,
                        stddev(case when error_code > 600000 then null else ts_first_packet end) as ts_first_packet_stddev,
                        stddev(case when error_code > 600000 then null else ts_contents end) as ts_contents_stddev,
                        stddev(case when error_code > 600000 then null else byte_total end) as byte_total_stddev,
                        stddev(case when error_code > 600000 then null else byte_page_base end) as byte_page_base_stddev,
                        stddev(case when error_code > 600000 then null else cont_err_total end) as cont_err_total_stddev,
                        stddev(case when error_code > 600000 then null else cont_ele_total end) as cont_ele_total_stddev,
                        stddev(case when error_code > 600000 then null else ts_user end) as ts_user_stddev,
                        stddev(case when error_code > 600000 then null else num_first_elem end) as num_first_elem_stddev,
                        stddev(case when error_code > 600000 then null else byte_first end) as byte_first_stddev
                      from
                        (select 
                          isp_id,
                          trunc(tm_hour8,''dd'') as tm_day,case when error_code < 600000 then 0 else 600001 end as error_code,
                          sum(ts_total * point_total)/sum(point_total) as ts_total,
                          sum(ts_dns * point_total)/sum(point_total) as ts_dns,
                          sum(ts_connect * point_total)/sum(point_total) as ts_connect,
                          sum(ts_first_packet * point_total)/sum(point_total) as ts_first_packet,
                          sum(ts_contents * point_total)/sum(point_total) as ts_contents,
                          sum(byte_total * point_total)/sum(point_total) as byte_total,
                          sum(byte_page_base * point_total)/sum(point_total) as byte_page_base,
                          sum(cont_err_total * point_total)/sum(point_total) as cont_err_total,
                          sum(cont_ele_total * point_total)/sum(point_total) as cont_ele_total,
                          sum(ts_user * point_total)/sum(point_total) as ts_user,
                          sum(num_first_elem * point_total)/sum(point_total) as num_first_elem,
                          sum(byte_first * point_total)/sum(point_total) as byte_first,
                          sum(point_total) as point_total
                        from mv_'|| tableName || '
                        where tm_hour8 > :ctime - 60
                              and task_id = :tid
                              and is_noise = 0
                        group by trunc(tm_hour8,''dd''),case when error_code < 600000 then 0 else 600001 end,isp_id
                        )group by isp_id
                       )
                     ) tmp';
        execute immediate sqlStr using taskId,calcDate,ctime,ctime,taskId;
        commit;
      elsif (taskType = 3) then
        -- 2）流媒体,涉及的性能指标
        sqlStr := 'insert into nb_is_avg(task_id,calc_date,calc_type,calc_item,ts_total,ts_dns,ts_connect_tcp,
                         ts_first_packet,buffer_count,ts_buffer,ts_rebuffer,percent_succ,
                         ts_total_stddev,ts_dns_stddev,ts_connect_tcp_stddev,ts_first_packet_stddev,buffer_count_stddev,
                         ts_buffer_stddev,ts_rebuffer_stddev,ctime)
               select :tid,:calcDate,3,tmp.*,:ctime
                  from
                    (select
                      isp_id,
                      trunc(case when point_succ=0 then 0 else ts_total / point_succ end,0) as ts_total,
                      trunc(case when point_succ=0 then 0 else ts_dns / point_succ end,0) as ts_dns,
                      trunc(case when point_succ=0 then 0 else ts_connect_tcp / point_succ end,0) as ts_connect_tcp,
                      trunc(case when point_succ=0 then 0 else ts_first_packet / point_succ end,0) as ts_first_packet,
                      trunc(case when point_succ=0 then 0 else buffer_count / point_succ end,2) as buffer_count,
                      trunc(case when point_succ=0 then 0 else ts_buffer / point_succ end,0) as ts_buffer,
                      trunc(case when point_succ=0 then 0 else ts_rebuffer / point_succ end,0) as ts_rebuffer,
                      trunc(case when point_succ=0 then 0 else point_succ / point_total end,4) as percent_succ,
                      trunc(ts_total_stddev,0) as ts_total_stddev,
                      trunc(ts_dns_stddev,0) as ts_dns_stddev,
                      trunc(ts_connect_tcp_stddev,0) as ts_connect_tcp_stddev,
                      trunc(ts_first_packet_stddev,0) as ts_first_packet_stddev,
                      trunc(buffer_count_stddev,0) as buffer_count_stddev,
                      trunc(ts_buffer_stddev,0) as ts_buffer_stddev,
                      trunc(ts_rebuffer_stddev,0) as ts_rebuffer_stddev
                    from
                      (select
                        isp_id,
                        sum(case when error_code > 600000 then 0 else ts_total * point_total end) as ts_total,
                        sum(case when error_code > 600000 then 0 else ts_dns * point_total end) as ts_dns,
                        sum(case when error_code > 600000 then 0 else ts_connect_tcp * point_total end) as ts_connect_tcp,
                        sum(case when error_code > 600000 then 0 else ts_first_packet * point_total end) as ts_first_packet,
                        sum(case when error_code > 600000 then 0 else buffer_count * point_total end) as buffer_count,
                        sum(case when error_code > 600000 then 0 else ts_buffer * point_total end) as ts_buffer,
                        sum(case when error_code > 600000 then 0 else ts_rebuffer * point_total end) as ts_rebuffer,
                        sum(case when error_code > 600000 then 0 else point_total end) as point_succ,
                        sum(point_total) as point_total,
                        stddev(case when error_code > 600000 then null else ts_total end) as ts_total_stddev,
                        stddev(case when error_code > 600000 then null else ts_dns end) as ts_dns_stddev,
                        stddev(case when error_code > 600000 then null else ts_connect_tcp end) as ts_connect_tcp_stddev,
                        stddev(case when error_code > 600000 then null else ts_first_packet end) as ts_first_packet_stddev,
                        stddev(case when error_code > 600000 then null else buffer_count end) as buffer_count_stddev,
                        stddev(case when error_code > 600000 then null else ts_buffer end) as ts_buffer_stddev,
                        stddev(case when error_code > 600000 then null else ts_rebuffer end) as ts_rebuffer_stddev
                      from
                        (select
                          isp_id,
                          trunc(tm_hour8,''dd'') as tm_day,case when error_code < 600000 then 0 else 600001 end as error_code,
                          sum(ts_total * point_total)/sum(point_total) as ts_total,
                          sum(ts_dns * point_total)/sum(point_total) as ts_dns,
                          sum(ts_connect_tcp * point_total)/sum(point_total) as ts_connect_tcp,
                          sum(ts_first_packet * point_total)/sum(point_total) as ts_first_packet,
                          sum(buffer_count * point_total)/sum(point_total) as buffer_count,
                          sum(ts_buffer * point_total)/sum(point_total) as ts_buffer,
                          sum(ts_rebuffer * point_total)/sum(point_total) as ts_rebuffer,
                          sum(point_total) as point_total
                        from mv_'|| tableName || '
                        where tm_hour8 > :ctime - 60
                              and task_id = :tid
                              and is_noise = 0
                        group by trunc(tm_hour8,''dd''),case when error_code < 600000 then 0 else 600001 end,
                            isp_id
                        )group by isp_id
                       )
                     ) tmp';
        execute immediate sqlStr using taskId,calcDate,ctime,ctime,taskId;
        commit;
      end if;
      --执行完成后，删除该执行的状态
      sqlStr:= 'delete from nb_is_avg_run_status where task_id =:taskId';
      execute immediate sqlStr using taskId;
      commit;
    end if;
    exception when  others then
        --如果出现异常后，也要删除该执行的状态
        sqlStr:= 'delete from nb_is_avg_run_status where task_id =:taskId';
        execute immediate sqlStr using taskId;
        commit;
        errorDesc := 'Error Message:'|| sqlerrm || '  tab:' || tableName;
        create_procedure_log('calc_field_avg',errorDesc,'error');

end calc_field_avg;


/

