create procedure calc_bill_day authid current_user is

  sqlStr       varchar2(4000);
  errorDesc varchar2(4000);
  --startDate date := to_date('2020-08-01','yyyy-mm-dd');
  --endDate date := to_date('2020-09-07','yyyy-mm-dd');
  startDate date := trunc(sysdate-2,'dd');
  endDate date := trunc(sysdate,'dd');
  s int;
begin
  -- 用于测试增加输出缓存
  --dbms_output.enable(buffer_size=>null) ;

  create_procedure_log('calc_bill_day', 'begin', 'run');
  --首先删除可能已经生成的数据
      sqlStr := 'delete from nb_bill_task_day where calc_date >= :sDate and  calc_date < :eDate and source=''oracle''';
      execute immediate sqlStr using startDate,endDate;
      commit;
  --循环，查寻出所有的表
  for tableName in (select distinct table_str as name,id from nb_m_agreement) loop
  begin
     --create_procedure_log('calc_bill_day', tableName.Name, 'run');
      --从page表中生成每日的数据
    select count(*)  INTO s FROM nb_m_task where (type=1 or type=2) and agreement_id in (select id from nb_m_agreement where table_str =tableName.name);
      if s > 0 then
        begin
          sqlStr := 'insert into nb_bill_task_day value
                       select task_id,trunc(tm_base,''dd''),sum(point_total),sysdate,'||tableName.id||',''oracle'',sum(case when is_noise in (114,116) then point_total else 0 end)
                          from nb_page_'||tableName.name||' p,nb_m_task t
                         where p.tm_base >= :sDate and p.tm_base < :eDate
                           and p.is_noise in (0,114,116)
                           and t.agreement_id = '||tableName.id||'
                           and t.task_option != ''P''
                           and p.task_id = t.id
                         group by p.task_id, trunc(p.tm_base, ''dd'')';
          execute immediate sqlStr using startDate,endDate;
          commit;
        exception when others then
          errorDesc := sqlerrm||',tableName:nb_page_' || tableName.name ;
          --DBMS_OUTPUT.PUT_LINE(errorDesc);
          create_procedure_log('calc_bill_day',errorDesc,'warning');
        end;
      end if;
      --从stream表中生成每日的数据
      select count(*)  INTO s FROM nb_m_task where type=3 and agreement_id in (select id from nb_m_agreement where table_str =tableName.name);
      if s > 0 then
        begin
          sqlStr := 'insert into nb_bill_task_day value
                       select task_id,trunc(tm_base,''dd''),sum(point_total),sysdate,'||tableName.id||',''oracle'',sum(case when is_noise in (114,116) then point_total else 0 end))
                          from nb_stream_'||tableName.name||' p,nb_m_task t
                           where p.tm_base >= :sDate and p.tm_base < :eDate
                              and p.is_noise in (0,114,116)
                              and t.agreement_id = '||tableName.id||'
                              and p.task_id = t.id
                           group by task_id,trunc(tm_base,''dd'')';
          execute immediate sqlStr using startDate,endDate;
          commit;
        exception when  others then
          errorDesc := sqlerrm||',tableName:nb_stream_' || tableName.name ;
          --DBMS_OUTPUT.PUT_LINE(errorDesc);
          create_procedure_log('calc_bill_day',errorDesc,'warning');
        end;
      end if;
      --从custom表中生成每日的数据
      select count(*)  INTO s FROM nb_m_task where type=255 and agreement_id in (select id from nb_m_agreement where table_str =tableName.name);
      if s > 0 then
        begin
          sqlStr := 'insert into nb_bill_task_day value
                       select task_id,trunc(tm_base,''dd''),sum(point_total),sysdate,'||tableName.id||',''oracle'',sum(case when is_noise in (114,116) then point_total else 0 end)
                          from nb_custom_'||tableName.name||' p,nb_m_task t
                            where p.tm_base >= :sDate and p.tm_base < :eDate
                              and p.is_noise in (0,114,116)
                              and t.agreement_id = '||tableName.id||'
                              and p.task_id = t.id
                           group by task_id,trunc(tm_base,''dd'')';
          execute immediate sqlStr using startDate,endDate;
          commit;
        exception when  others then
          errorDesc := sqlerrm||',tableName:nb_custom_' || tableName.name ;
          --DBMS_OUTPUT.PUT_LINE(errorDesc);
          create_procedure_log('calc_bill_day',errorDesc,'warning');
        end;
      end if;
      --从trace表中生成每日的数据
      select count(*)  INTO s FROM nb_m_task where task_option='T' and type=1 and agreement_id in (select id from nb_m_agreement where table_str =tableName.name);
      if s > 0 then
        begin
          sqlStr := 'insert into nb_bill_task_day value
                       select task_id,trunc(tm_base,''dd''),sum(point_total),sysdate,'||tableName.id||',''oracle'',sum(case when is_noise in (114,116) then point_total else 0 end)
                          from nb_trace_'||tableName.name||' p,nb_m_task t
                            where p.tm_base >= :sDate and p.tm_base < :eDate
                              and p.is_noise in (0,114,116)
                              and t.agreement_id = '||tableName.id||'
                              and p.task_id = t.id
                           group by task_id,trunc(tm_base,''dd'')';
          execute immediate sqlStr using startDate,endDate;
          commit;
        exception when  others then
          errorDesc := sqlerrm||',tableName:nb_trace_' || tableName.name ;
          --DBMS_OUTPUT.PUT_LINE(errorDesc);
          create_procedure_log('calc_bill_day',errorDesc,'warning');
        end;
      end if;
      --从手机页面监测表中生成每日的数据
      select count(*)  INTO s FROM nb_m_task where (type=102 or type=103) and agreement_id in (select id from nb_m_agreement where table_str =tableName.name);
      if s > 0 then
        begin
          sqlStr := 'insert into nb_bill_task_day value
                       select task_id,trunc(tm_base,''dd''),sum(point_total),sysdate,'||tableName.id||',''oracle'',sum(case when is_noise in (114,116) then point_total else 0 end)
                          from nb_mob_page_'||tableName.name||' p,nb_m_task t
                            where p.tm_base >= :sDate and p.tm_base < :eDate
                              and p.is_noise in (0,114,116)
                              and t.agreement_id = '||tableName.id||'
                              and p.task_id = t.id
                           group by task_id,trunc(tm_base,''dd'')';
          execute immediate sqlStr using startDate,endDate;
          commit;
        exception when  others then
          errorDesc := sqlerrm||',tableName:nb_mob_page_' || tableName.name ;
          --DBMS_OUTPUT.PUT_LINE(errorDesc);
          create_procedure_log('calc_bill_day',errorDesc,'warning');
        end;
      end if;
      --从手机短信监测表中生成每日的数据
      select count(*)  INTO s FROM nb_m_task where type=105 and agreement_id in (select id from nb_m_agreement where table_str =tableName.name);
      if s > 0 then
        begin
          sqlStr := 'insert into nb_bill_task_day value
                       select task_id,trunc(tm_base,''dd''),sum(point_total),sysdate,'||tableName.id||',''oracle'',sum(case when is_noise in (114,116) then point_total else 0 end)
                          from nb_mob_sms_'||tableName.name||' p,nb_m_task t
                            where p.tm_base >= :sDate and p.tm_base < :eDate
                              and p.is_noise in (0,114,116)
                              and t.agreement_id = '||tableName.id||'
                              and p.task_id = t.id
                           group by task_id,trunc(tm_base,''dd'')';
          execute immediate sqlStr using startDate,endDate;
          commit;
        exception when  others then
          errorDesc := sqlerrm||',tableName:nb_mob_sms_' || tableName.name ;
          --DBMS_OUTPUT.PUT_LINE(errorDesc);
          create_procedure_log('calc_bill_day',errorDesc,'warning');
        end;
      end if;
         --从手机流媒体监测表中生成每日的数据
      select count(*)  INTO s FROM nb_m_task where type=111 and agreement_id in (select id from nb_m_agreement where table_str =tableName.name);
      if s > 0 then
        begin
          sqlStr := 'insert into nb_bill_task_day value
                       select task_id,trunc(tm_base,''dd''),sum(point_total),sysdate,'||tableName.id||',''oracle'',sum(case when is_noise in (114,116) then point_total else 0 end)
                          from nb_mob_stream_'||tableName.name||' p,nb_m_task t
                            where p.tm_base >= :sDate and p.tm_base < :eDate
                              and p.is_noise in (0,114,116)
                              and t.agreement_id = '||tableName.id||'
                              and p.task_id = t.id
                           group by task_id,trunc(tm_base,''dd'')';
          execute immediate sqlStr using startDate,endDate;
          commit;
        exception when  others then
          errorDesc := sqlerrm||',tableName:nb_mob_stream_' || tableName.name ;
          --DBMS_OUTPUT.PUT_LINE(errorDesc);
          create_procedure_log('calc_bill_day',errorDesc,'warning');
        end;
      end if;
      --从ping监测表中生成每日的数据,包括pc ping及手机ping
      select count(*)  INTO s FROM nb_m_task where task_option='P' and agreement_id in (select id from nb_m_agreement where table_str =tableName.name);
      if s > 0 then
      begin
        sqlStr := 'insert into nb_bill_task_day value
                     select p.task_id, trunc(p.tm_base, ''dd''), sum(p.point_total), sysdate,'||tableName.id||',''oracle'',sum(case when is_noise in (114,116) then point_total else 0 end)
                        from nb_ping_'||tableName.name||' p,nb_m_task t
                       where p.tm_base >= :sDate and p.tm_base < :eDate
                         and p.is_noise in (0,114,116)
                         and t.agreement_id = '||tableName.id||'
                         and t.task_option = ''P''
                         and p.task_id = t.id
                       group by p.task_id, trunc(p.tm_base, ''dd'')';
        execute immediate sqlStr using startDate,endDate;
        commit;
      exception when  others then
        errorDesc := sqlerrm||',tableName:nb_ping_' || tableName.name ;
        --DBMS_OUTPUT.PUT_LINE(errorDesc);
        create_procedure_log('calc_bill_day',errorDesc,'warning');
      end;
      end if;
  end;
  end loop;

  --计算即时监测点数
  sqlStr:= 'insert into nb_bill_task_day  value
              select type, ctime, s, sysdate, agreement_id,''oracle'',0
              from (select case when type in(1,2,3,255) then 0 else -1 end type,trunc(ctime) ctime,count(*) s,agreement_id from nb_instant
             where status = 2 and agreement_id >0
               and ctime >= :sDate  and ctime < :eDate
               group by case when type in(1,2,3,255) then 0 else -1 end,trunc(ctime),agreement_id)';
        execute immediate sqlStr using startDate,endDate;
        commit;

   -- 每月的2号生成上月的汇总数据，放到临时表用于比对按月汇总，得出点数是否准确
  if (to_char(sysdate,'dd')=2) then
    sqlStr := 'delete from nb_bill_task_tmp where calc_date = :calcDate ';
    execute immediate sqlStr using add_months(trunc(sysdate,'mm'),-1);
    commit;

    sqlStr := 'insert into nb_bill_task_tmp value
                 select task_id,trunc(calc_date,''mm''),sum(count),sysdate
                    from nb_bill_task_day
                     where calc_date >= :sDate and calc_date < :eDate
                     group by task_id,trunc(calc_date,''mm'')';
    execute immediate sqlStr using add_months(trunc(sysdate,'mm'),-1),trunc(sysdate,'mm');
    commit;
  end if;

  create_procedure_log('calc_bill_day', 'end', 'run');
end calc_bill_day;
/

