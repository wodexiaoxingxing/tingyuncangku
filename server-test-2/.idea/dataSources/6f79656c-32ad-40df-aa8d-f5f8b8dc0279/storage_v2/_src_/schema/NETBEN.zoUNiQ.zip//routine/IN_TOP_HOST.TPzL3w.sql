create PROCEDURE          "IN_TOP_HOST" (
  tableStr in number,
  taskId   in number
) authid current_user
is
  sqlStr  varchar2(4000);
  s number;
  errorDesc varchar2(4000);
  startDate date;
  endDate date;

begin
  create_procedure_log('in_top_host','tableStr:' || tableStr || ' taskId:' || taskId || '  begin','run');
  select count(*) INTO s FROM user_tables where table_name = 'NB_ET_' || taskId;
  if s < 1 then
    create_procedure_log('in_top_host','tableStr:' || tableStr || ' taskId:' || taskId ||' 任务表未找到','alarm');
    return;
  end if;
  startDate := trunc(sysdate-10,'dd');
  endDate := trunc(sysdate,'dd');
  --删除指定日期内的所有生成数据，防止重复生成数据
  sqlStr:='delete nb_top_host where task_id = :tid and tm_day >= :sDate and tm_day < :eDate';
  execute immediate sqlStr using taskId,startDate,endDate;
  commit;
    sqlStr:='insert into nb_top_host(task_id,tm_day,url_host,domain_id,byte_total,performance,rate,
             error_count,point_succ_byte,point_succ_perf,point_succ_rate,point_total,table_str)
               select '||taskId||',t.tm_day,d.name,t.domain_id,t.byte_total,t.performance,t.rate,
                   t.error_count,t.point_succ_byte,t.point_succ_perf,t.point_succ_rate,t.point_total,'||tableStr||'
               from
                  (select trunc(e.tm_base, ''dd'') as tm_day,e.domain_id,
                     round(avg(case when e.error_code > 600000 then null else e.byte_total end),0) as byte_total,
                     round(avg(case when e.error_code > 600000 then null else e.ts_element end),0) as performance,
                     round(avg(case when e.error_code > 600000 and error_code != 612271 then null else e.rate_download end),0) as rate,
                     sum(case when e.error_code > 600000 then 1 else 0 end) as error_count,
                     sum(case when e.error_code > 600000 then 0 else 1 end) as point_succ_byte,
                     sum(case when e.error_code > 600000 then 0 else 1 end) as point_succ_perf,
                     sum(case when e.error_code > 600000 and error_code != 612271 then 0 else 1 end) as point_succ_rate,
                     sum(1) as point_total
                  from nb_et_'|| taskId ||' e
                  where tm_base >= :startDate and tm_base < :endDate
                  group by trunc(e.tm_base, ''dd''),e.domain_id
                  )t,nb_e_domain d
               where t.domain_id = d.id
            ';
    execute immediate sqlStr using startDate,endDate;
    commit;

    create_procedure_log('in_top_host','tableStr:' || tableStr || ' taskId:' || taskId || '  end','run');
    --如果创建序列失败，则显示出失败代码
    exception when  others then
      errorDesc := 'tableStr:' || tableStr || ' taskId:' || taskId ||' Error:' || sqlerrm;
      --DBMS_OUTPUT.PUT_LINE(errorDesc);
      create_procedure_log('in_top_host',errorDesc,'error');
end in_top_host;


/

