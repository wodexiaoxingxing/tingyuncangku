create PROCEDURE          "MY_GET_MBR_PROC" (
  cc  out rc_cursor
  ) is
begin
  open cc for
    select * from nb_m_member;
end;


/

