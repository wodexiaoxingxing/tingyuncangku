create procedure probe_summary authid current_user is
  total number;
  dt date := sysdate;

begin
  create_procedure_log('probe_summary', 'probe_summary begin', 'begin');

  select count(1)
    into total
    from nb_m_probe_summary_hour
   where calc_date between trunc(dt - 1) and trunc(dt) - 1/86400;

  if total > 0 then
    delete from nb_m_probe_summary where calc_date = trunc(dt - 1);
    commit;

    insert into nb_m_probe_summary
      (host_id,
       company_id,
       user_name,
       member_id,
       online_time,
       system_flows,
       app_flows,
       app_wifi_flows,
       total_dsp,
       total_col,
       calc_date)
      select host_id,
             company_id,
             user_name,
             member_id,
             sum(online_time) as online_time,
             sum(system_flows) as system_flows,
             sum(app_flows) as app_flows,
             sum(app_wifi_flows) as app_wifi_flows,
             sum(total_dsp) as total_dsp,
             sum(total_col) as total_col,
             trunc(dt - 1) as calc_date
        from nb_m_probe_summary_hour
       where calc_date between trunc(dt - 1) and trunc(dt) - 1/86400
       group by host_id, company_id, user_name, member_id;
    commit;

  end if;
  create_procedure_log('probe_summary', 'probe_summary end', 'end');

exception
  when others then
    --dbms_output.put_line(sqlerrm);
    create_procedure_log('probe_summary', sqlerrm, 'error');

end probe_summary;


/

