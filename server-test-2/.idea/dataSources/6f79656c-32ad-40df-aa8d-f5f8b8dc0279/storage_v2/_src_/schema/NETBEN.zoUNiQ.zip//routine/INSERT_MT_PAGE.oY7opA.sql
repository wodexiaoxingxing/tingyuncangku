create procedure insert_mt_page authid current_user is
POINT_RANGE CONSTANT  NUMBER:=10000;
SUFF_ERROR EXCEPTION;
--创建分区用变量
rangeDate date;
rangeDesc varchar2(8);
partName1 varchar2(64);
rangeName1 varchar2(64);
partName2 varchar2(64);
rangeName2 varchar2(64);
partName3 varchar2(64);
rangeName3 varchar2(64);
createDate date:=sysdate;--创建分区时的当前时间
--生成数据用变量
sqlStr varchar2(4000);
inSqlStr varchar2(4000);--专用于生成数据的sql
suff number;
stime date;
etime date;
tmpEtime date;
point number;
tmpPoint number;

rangeTimeMin date;--既可做为一个优化的条件，通过此字段可使用到分区或索引，同时对新加的page表，第一次数据可从此时间开始
rangeTimeMax date;
begin
  create_procedure_log('insert_mt_page','begin','run');
  rangeTimeMin:=trunc(sysdate,'dd');
  rangeTimeMax:=trunc(sysdate+4,'dd');
  for tab in(SELECT table_name as name FROM user_tables  where table_name like 'NB_PAGE_'||'%' order by table_name) loop
    begin
      begin
        suff:=substr(tab.name,9);
        --if suff!=22 then raise SUFF_ERROR; end if;
      exception when others then
        --如果后缀不是数字则不是正式表，不处理直接exit
        --dbms_output.put_line(tab.name);
        raise SUFF_ERROR;
      end;
      --select count(*) into v_s from user_tables t where t.table_name = 'MT_PAGE_'||suff;
      --通过异常来判断是否表存在
      begin
        sqlStr:='insert into mt_page_'||suff||' (tm_base) values (sysdate)';
        execute immediate sqlStr;
        rollback;
      exception when others then
        -- 创建不存在的表
        rangeDate := trunc(createDate + 7,'d');
        rangeDesc := to_char(rangeDate,'yymmdd');
        partName1:='P_MT_PAGE_'||suff||'_'||rangeDesc;
        rangeName1:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
        rangeDate := trunc(rangeDate + 7,'d');
        rangeDesc := to_char(rangeDate,'yymmdd');
        partName2:='P_MT_PAGE_'||suff||'_'||rangeDesc;
        rangeName2:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
        rangeDate := trunc(rangeDate + 7,'d');
        rangeDesc := to_char(rangeDate,'yymmdd');
        partName3:='P_MT_PAGE_'||suff||'_'||rangeDesc;
        rangeName3:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
        sqlStr:='create table mt_page_'||suff||'(
                    task_id                 NUMBER,
                    page_seq                NUMBER,
                    city_id                 NUMBER,
                    isp_id                  NUMBER,
                    net_speed_id            NUMBER,
                    error_code              NUMBER,
                    is_noise                INTEGER,
                    dest_ip                 VARCHAR2(39),
                    dest_city_id            NUMBER,
                    dest_isp_id             NUMBER, 
                    is_cdn_cover            INTEGER,
                    tm_base                 DATE,
                    os_ver_id               INTEGER,
                    bs_id                   INTEGER,
                    bs_ver_id               INTEGER,
                    cont_err_total          NUMBER,
                    cont_ele_total          NUMBER,
                    point_total             NUMBER,
                    byte_total              NUMBER,
                    rate_download           NUMBER,
                    ts_total                NUMBER,
                    ts_page_base            NUMBER,
                    ts_dns                  NUMBER,
                    ts_connect              NUMBER,
                    ts_ssl                  NUMBER,
                    ts_redirect             NUMBER,
                    ts_request              NUMBER,
                    ts_first_packet         NUMBER,
                    ts_client               NUMBER,
                    ts_contents             NUMBER,
                    ts_user                 NUMBER,
                    ts_network              NUMBER,
                    byte_page_base          NUMBER,
                    rate_download_page_base NUMBER,
                    num_first_elem          NUMBER,
                    byte_first              NUMBER,
                    num_host                NUMBER,
                    ts_dns_total            NUMBER,
                    num_connect             NUMBER,
                    ts_connect_total        NUMBER,
                    num_dom                 NUMBER,
                    num_elem_lazy           NUMBER,
                    ts_first_paint          NUMBER,
                    ts_full_screen          NUMBER,
                    ts_unload_start         NUMBER,
                    ts_unload_end           NUMBER,
                    ts_dom_load             NUMBER,
                    ts_dom_interact         NUMBER,
                    ts_dom_cont_load_start  NUMBER,
                    ts_dom_cont_load_end    NUMBER,
                    ts_dom_complete         NUMBER,
                    ts_load_evt_start       NUMBER,
                    ts_load_evt_end         NUMBER,
                    queue_time					    NUMBER, 
	                  application_server_time NUMBER
               )
                partition by range (TM_BASE)(
                        partition '||partName1||' values less than ('||rangeName1||'),
                        partition '||partName2||' values less than ('||rangeName2||'),
                        partition '||partName3||' values less than ('||rangeName3||'))
                        tableSpace NETBEN_BG';
            execute immediate sqlStr;
            sqlStr:='create index IDX_MT_PAGE_PERF_'||suff||' on MT_PAGE_'||suff||' (tm_base,task_id) compress LOCAL parallel 4 tableSpace  NETBEN_IND nologging';
            execute immediate sqlStr;
      end;--创建分区结束

      -- 首先取出上一次计算的创建时间，做为起始时间，有可能是新表，则处理异常后取startTime为最小范围时间
      -- 计算时是按大于等于上一次创建时间，小于本次查到的最大创建时间，这是为了防止ctime重复，可能丢失数据
      begin
        sqlStr:='select max(etime) from nb_log_mt_ctime where table_str=:ts';
        execute immediate sqlStr into stime using suff;
        if stime is null then stime:=rangeTimeMin; end if;
      exception when others then
        stime:=rangeTimeMin;
      end;

      -- 计算出本次结束的时间,最大时间减5分钟，防止有未及时提交的数据
      sqlStr:='select max(ctime) from '||tab.name ||' where tm_base >= :rt and tm_base<:et and ctime > :st';
      execute immediate sqlStr into etime using rangeTimeMin,rangeTimeMax,stime;
      sqlStr:='select max(ctime),count(ctime) from '||tab.name ||' where tm_base >= :rt and tm_base<:et and ctime > :st and ctime < :et';
      execute immediate sqlStr into etime,point using rangeTimeMin,rangeTimeMax,stime,etime-1/24/30;
      
      --dbms_output.put_line(tab.name||','||to_char(etime,'yyyy-mm-dd hh24:mi')||',stime:'||to_char(stime,'yyyy-mm-dd hh24:mi')||',point:'||point);
      -- dbms_output.put_line(startId||','||endId||','||point);
      if point>0 then
        -- 先申明生成数据sql,分不同情况用不同参数调用
        inSqlStr:='insert into mt_page_'||suff||
           '(task_id,page_seq,city_id,isp_id,net_speed_id,error_code,is_noise,dest_ip,dest_city_id,dest_isp_id,is_cdn_cover,os_ver_id,bs_id,bs_ver_id,tm_base,
           cont_err_total,cont_ele_total,point_total,byte_total,rate_download,ts_total,ts_page_base,ts_dns,ts_connect,
           ts_ssl,ts_redirect,ts_request,ts_first_packet,ts_client,ts_contents,ts_user,ts_network,byte_page_base,
           rate_download_page_base,num_first_elem,byte_first,num_host,ts_dns_total,num_connect,ts_connect_total,num_dom,
           num_elem_lazy,ts_first_paint,ts_full_screen,ts_unload_start,ts_unload_end,ts_dom_load,ts_dom_interact,
           ts_dom_cont_load_start,ts_dom_cont_load_end,ts_dom_complete,ts_load_evt_start,ts_load_evt_end,
           queue_time,application_server_time)
          select task_id,page_seq,city_id,isp_id,net_speed_id,error_code,is_noise,dest_ip,dest_city_id,dest_isp_id,is_cdn_cover,os_ver_id,bs_id,bs_ver_id,
            (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8) / 24) as tm_base,
            avg(cont_err_total) as cont_err_total,
            avg(cont_ele_total) as cont_ele_total,
            sum(point_total) as point_total,
            avg(byte_total) as byte_total,
            avg(rate_download) as rate_download,
            avg(ts_total) as ts_total,
            avg(ts_page_base) as ts_page_base,
            avg(ts_dns) as ts_dns,
            avg(ts_connect) as ts_connect,
            avg(ts_ssl) as ts_ssl,
            avg(ts_redirect) as ts_redirect,
            avg(ts_request) as ts_request,
            avg(ts_first_packet) as ts_first_packet,
            avg(ts_client) as ts_client,
            avg(ts_contents) as ts_contents,
            avg(ts_user) as ts_user,
            avg(ts_network) as ts_network,
            avg(byte_page_base) as byte_page_base,
            avg(rate_download_page_base) as rate_download_page_base,
            avg(num_first_elem) as num_first_elem,
            avg(byte_first) as byte_first,
            avg(num_host) as num_host,
            avg(ts_dns_total) as ts_dns_total,
            avg(num_connect) as num_connect,
            avg(ts_connect_total) as ts_connect_total,
            avg(num_dom) as num_dom,
            avg(num_elem_lazy) as num_elem_lazy,
            avg(ts_first_paint) as ts_first_paint,
            avg(ts_full_screen) as ts_full_screen,
            avg(ts_unload_start) as ts_unload_start,
            avg(ts_unload_end) as ts_unload_end,
            avg(ts_dom_load) as ts_dom_load,
            avg(ts_dom_interact) as ts_dom_interact,
            avg(ts_dom_cont_load_start) as ts_dom_cont_load_start,
            avg(ts_dom_cont_load_end) as ts_dom_cont_load_end,
            avg(ts_dom_complete) as ts_dom_complete,
            avg(ts_load_evt_start) as ts_load_evt_start,
            avg(ts_load_evt_end) as ts_load_evt_end,
            avg(queue_time) as queue_time,
            avg(application_server_time) as application_server_time
        from '||tab.name||'
        where tm_base >= :sd and tm_base < :ed and ctime > :st and ctime <= :et
        group by task_id,page_seq,city_id,isp_id,net_speed_id,error_code,is_noise,dest_ip,dest_city_id,dest_isp_id,is_cdn_cover,os_ver_id,bs_id,bs_ver_id,
            (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''),''hh24'')) + 8, 8) / 24)
            ';

        if point > POINT_RANGE then
          loop
            -- 如果超过了一次处理范围，分批处理，每次取出当前的开始time及结束time,结束时间要小于等于前面取出的最大结束时间
            sqlStr:='select max(ctime),count(ctime) from (select ctime,rownum from '||tab.name ||' where tm_base >=:rt and tm_base <:et and ctime>:sc and ctime<=:ec order by ctime) where rownum<=:rn';
            execute immediate sqlStr into tmpEtime,tmpPoint using rangeTimeMin,rangeTimeMax,stime,etime,POINT_RANGE;
            create_procedure_log('insert_mt_page','tableName:'||tab.name||','||'stime:'||to_char(stime,'yyyy-mm-dd hh24:mi:ss')||',endTime:'||to_char(tmpEtime,'yyyy-mm-dd hh24:mi:ss')||',point:'||tmpPoint,'run');
            -- 执行生成数据语句
            execute immediate inSqlStr using rangeTimeMin,rangeTimeMax,stime,tmpEtime;
            commit;
            sqlStr:='insert into nb_log_mt_ctime(table_str,stime,etime,point,ctime) values(:ts,:st,:et,:p,:ct)';
            execute immediate sqlStr using suff,stime,tmpEtime,tmpPoint,sysdate;
            commit;
            -- 当前结束时间如果等于最初取的结束时间时，结束循环
            --dbms_output.put_line(to_char(tmpEtime,'yyyy-mm-dd hh24:mi:ss')||','||to_char(etime,'yyyy-mm-dd hh24:mi:ss'));
            exit when tmpEtime = etime;
            -- 将循环中上一次结束ID给到开始ID
            stime:=tmpEtime;
          end loop;
        else
            -- 如果在一次处理范围内，则直接生成数据
            dbms_output.put_line(to_char(tmpEtime,'yyyy-mm-dd hh24:mi:ss')||','||to_char(etime,'yyyy-mm-dd hh24:mi:ss'));
            create_procedure_log('insert_mt_page','tableName:'||tab.name||','||'stime:'||to_char(stime,'yyyy-mm-dd hh24:mi:ss')||',etime:'||to_char(etime,'yyyy-mm-dd hh24:mi:ss')||',point:'||point,'run');
            execute immediate inSqlStr using rangeTimeMin,rangeTimeMax,stime,etime;
            commit;
            sqlStr:='insert into nb_log_mt_ctime(table_str,stime,etime,point,ctime) values(:ts,:st,:et,:p,:ct)';
            execute immediate sqlStr using suff,stime,etime,point,sysdate;
            commit;
        end if; 
      else
        create_procedure_log('insert_mt_page','tableName:'||tab.name||','||'stime:'||to_char(stime,'yyyy-mm-dd hh24:mi:ss')||',etime:'||to_char(etime,'yyyy-mm-dd hh24:mi:ss')||',point:'||point,'run');
      end if;
    exception when SUFF_ERROR then
      --如果是后缀不正确则不处理
      create_procedure_log('insert_mt_page','tableName:'||tab.name||','||sqlerrm,'error');
       null;
    when others then
       dbms_output.put_line('tableName'||tab.name||','||sqlerrm);
      create_procedure_log('insert_mt_page','tableName:'||tab.name||','||sqlerrm,'error');
    end;
  end loop;
  create_procedure_log('insert_mt_page','end','run');
end insert_mt_page;


/

