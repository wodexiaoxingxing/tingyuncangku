create PROCEDURE add_et_list (task_id  varchar2)  is
sqlStr varchar2(4000);
TABLESTR varchar2(100);
 begin
  select table_str into TABLESTR from nb_m_agreement where id in (select agreement_id from nb_m_task where id=TASK_ID);

 sqlStr :='insert into nb_et_url_'||TABLESTR||'
  select url_id as id, task_id, domain_id,elem_type_id, (max(tm_base) - to_date(''2007-01-01'',''yyyy-mm-dd'')) * 86400 as mtime, count(*)+50 as point
  from nb_et_'||TASK_ID||'
  group by task_id, url_id, domain_id, elem_type_id';
                 dbms_output.put_line(sqlStr);
                  execute immediate sqlStr;
                  execute immediate 'commit';
end add_et_list;


/

