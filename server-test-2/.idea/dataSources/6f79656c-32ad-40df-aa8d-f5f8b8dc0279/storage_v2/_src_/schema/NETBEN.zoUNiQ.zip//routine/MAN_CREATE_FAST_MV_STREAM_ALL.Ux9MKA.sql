create procedure man_create_fast_mv_stream_all authid current_user
is
  sqlStr  varchar2(4000);
  v_name varchar2(400);
  v_error_desc varchar2(4000);
  v_s number;
   CURSOR c_emp IS SELECT substr(t.table_name,11) FROM user_tables t where t.table_name like 'NB_STREAM_%';
begin
OPEN c_emp;
LOOP
  begin
     FETCH c_emp INTO v_name;
    EXIT WHEN c_emp%NOTFOUND;
    --创建物化视图日志
    SELECT count(*)  INTO v_s FROM USER_MVIEW_LOGS WHERE MASTER='NB_STREAM_'||v_name;
     --DBMS_OUTPUT.PUT_LINE(v_s);
    if v_s >0 then
        sqlStr:=  'drop table MLOG$_NB_STREAM_'||v_name;
        --DBMS_OUTPUT.PUT_LINE(sqlstr);
        execute immediate sqlstr;

        sqlStr:=  'drop materialized view log on nb_stream_'||v_name;
    --DBMS_OUTPUT.PUT_LINE(sqlstr);
        execute immediate sqlstr;
    end if;
       sqlStr:='create materialized view log on NB_STREAM_'||v_name||' with rowid,
      sequence (task_id,
      city_id,
      isp_id,
      net_speed_id,
      error_code,
      is_noise,
      dest_ip,
      tm_base,
      point_total,
      rate_download,
      buffer_count,
      ts_total,
      ts_dns,
      ts_connect,
      ts_redirect,
      ts_buffer,
      ts_rebuffer,
      ts_first_play,
      ts_play,
      ts_full,
      ts_user,
      rece_package,
      lose_package,
      ts_connect_tcp,
      ts_first_packet,
      ts_contents,
      os_ver_id,
      bs_id,
      bs_ver_id,
      data_rate,
      play_in_5s,
      fluency
      ) including new values';
    --DBMS_OUTPUT.PUT_LINE(sqlstr);
    execute immediate sqlStr;
     --page物化视图
    select count(*)  INTO v_s FROM user_tables t where t.table_name = 'MV_STREAM_'||v_name;
    if v_s > 0 then
       sqlStr:='drop materialized view mv_stream_'||v_name;
       --DBMS_OUTPUT.PUT_LINE(sqlStr);
      execute immediate sqlStr;
     end if;
      create_procedure_log('create_fast_mv_stream_all','start materialized view  mv_stream_'||v_name,'message');
    sqlStr:='create materialized view MV_STREAM_'||v_name||'
    refresh fast
    start with sysdate next sysdate + 4/24
    as
    (select task_id,
    city_id,
    isp_id,
    net_speed_id,
    error_code,
    is_noise,
    dest_ip,
    (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8) / 24) as tm_hour8,
    os_ver_id,
    bs_id,
    bs_ver_id,
    count(*) as c1,
    count(point_total) as c2,
    count(rate_download) as c3,
    count(ts_total) as c4,
    count(ts_dns) as c5,
    count(ts_connect) as c6,
    count(ts_redirect) as c7,
    count(ts_buffer) as c8,
    count(ts_rebuffer) as c9,
    count(ts_first_play) as c10,
    count(ts_play) as c11,
    count(ts_full) as c12,
    count(ts_user) as c13,
    count(rece_package) as c14,
    count(lose_package) as c15,
    count(buffer_count) as c16,
    count(ts_connect_tcp) as c17,
    count(ts_first_packet) as c18,
    count(ts_contents) as c19,
    count(data_rate) as c20,
    count(play_in_5s) as c21,
    count(fluency) as c22,
    avg(buffer_count) as buffer_count,
    sum(point_total) as point_total,
    avg(rate_download) as rate_download,
    avg(data_rate) as data_rate,
    avg(ts_total) as ts_total,
    avg(ts_dns) as ts_dns,
    avg(ts_connect) as ts_connect,
    avg(ts_redirect) as ts_redirect,
    avg(ts_buffer) as ts_buffer,
    avg(ts_rebuffer) as ts_rebuffer,
    avg(ts_first_play) as ts_first_play,
    avg(ts_play) as ts_play,
    avg(ts_full) as ts_full,
    avg(ts_user) as ts_user,
    avg(rece_package) as rece_package,
    avg(lose_package) as lose_package,
    avg(ts_connect_tcp) as ts_connect_tcp,
    avg(ts_first_packet) as ts_first_packet,
    avg(ts_contents) as ts_contents,
    avg(play_in_5s) as play_in_5s,
    avg(fluency) as fluency
    from NB_STREAM_'||v_name||'
    group by task_id,
      city_id,
      isp_id,
      net_speed_id,
      error_code,
      is_noise,
      dest_ip,
      (trunc(tm_base,''hh24'') - mod(to_number(to_char(trunc(tm_base,''hh24''), ''hh24'')) + 8, 8) / 24),
      os_ver_id,
      bs_id,
      bs_ver_id)';

        --DBMS_OUTPUT.PUT_LINE(sqlStr);
     execute   immediate   sqlStr;

   -- MV_STREAM 索引
	  sqlStr:='create index IN_MV_STREAM_PERF_'||v_name||' on MV_STREAM_'||v_name||' (TASK_ID,TM_HOUR8, CITY_ID,ISP_ID) tableSpace NETBEN_IND';
     --DBMS_OUTPUT.PUT_LINE(sqlStr);
     execute   immediate   sqlStr;
     sqlStr:='create index IN_MV_STREAM_ERROR_'||v_name||' on MV_STREAM_'||v_name||' (TASK_ID,TM_HOUR8, ERROR_CODE,CITY_ID) tableSpace NETBEN_IND';
     --DBMS_OUTPUT.PUT_LINE(sqlStr);
     execute   immediate   sqlStr;


   --如果创建失败，则显示出失败的表
   exception when  others then
        v_error_desc := 'Error table:NB_STREAM_'||v_name;
        DBMS_OUTPUT.PUT_LINE(v_error_desc);
        MON_PC_ERROR_LOG('man_create_fast_mv_stream_all',sqlerrm,v_error_desc);

    end;

END LOOP;


CLOSE c_emp;
end man_create_fast_mv_stream_all;


/

