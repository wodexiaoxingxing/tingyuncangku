create procedure del_expire_data(num number) authid current_user is
type tabType is table of varchar2(32) index by BINARY_INTEGER;
tabTypeImpl tabType;
sqlStr     varchar2(4000);
tab   varchar2(32);
days  number;
curDays number;
suff varchar2(16);
rangeDays number;--用于判断删除策略,最近插入数据的时间，20天-91天不做处理，91天后truncate
rows number;--测试时用于只做前几个
minId number;
maxId number;
persist_days integer;
begin
  dbms_output.enable(1000000000000000);
  tabTypeImpl(1):='NB_TRACE';
  tabTypeImpl(2):='NB_STREAM';
  tabTypeImpl(3):='NB_CUSTOM';
  tabTypeImpl(4):='NB_MOB_TRAN';
  tabTypeImpl(5):='NB_MOB_PAGE';
  tabTypeImpl(6):='NB_PAGE';
  tabTypeImpl(7):='NB_TRAN';
  tabTypeImpl(8):='NB_PING';

  --数据删除，分别删除tran,page,ping,stream,trace,route,custom,mob_tran,mob_page
  --删除分十个线程，每次循环删除90天前的数据，每个循环删除半天数据
  create_procedure_log('del_expire_data'||num,'begin','run');
  for s in 1..tabTypeImpl.count loop
    rows:=0;
    for tab in(SELECT t.table_name as name FROM user_tables t where t.partitioned='NO' and regexp_like( t.table_name,tabTypeImpl(s)||'_\d+'||num||'$'))loop
      begin
        rows:=rows+1;
        if rows>5000 then
          goto next1;
        end if;
        sqlStr:='select trunc(sysdate,''dd'') - trunc(max(tm_base),''dd'')  from '|| tab.name ||' where tm_base < sysdate + 3';
        execute immediate sqlStr into rangeDays;


        -- 20~91天内没新数据,或表里没数据的，不做处理
        if rangeDays is null or (rangeDays > 20 and rangeDays < 91) then
          goto next;
        end if;
        -- 获取数据保存天数, 默认91天
        persist_days := get_persist_days(tab.name, 91);
        -- persist_days 天以上的truncate
        if rangeDays > persist_days then
          if tabTypeImpl(s)='NB_TRACE' then
            suff := substr(tab.name,10);
            sqlStr:='truncate table nb_route_'||suff;
            --dbms_output.put_line(sqlstr||';');
            execute immediate sqlStr;
            commit;
            create_procedure_log('del_expire_data'||num,'truncate tableName:nb_route_'||suff,'run');
          end if;

          if tabTypeImpl(s)='NB_STREAM' then
            suff := substr(tab.name,11);
            sqlStr:='truncate table nb_rate_'||suff;
            --dbms_output.put_line(sqlstr||';');
            execute immediate sqlStr;
            sqlStr:='truncate table nb_stream_uvmos_'||suff;
            --dbms_output.put_line(sqlstr||';');
            execute immediate sqlStr;
            commit;
            create_procedure_log('del_expire_data'||num,'truncate tableName:nb_rate_'||suff,'run');
          end if;
            sqlStr:='truncate table '||tab.name;
            --dbms_output.put_line(sqlstr||';');
            execute immediate sqlStr;
            commit;
            create_procedure_log('del_expire_data'||num,'truncate tableName:'||tab.name,'run');
            goto next;
        end if;

        sqlStr:='select trunc(sysdate,''dd'') - trunc(min(tm_base),''dd'') - ' || persist_days || '  from '|| tab.name ||' where tm_base < trunc(sysdate,''dd'')-' || persist_days;
        execute immediate sqlStr into days;
        -- dbms_output.put_line('tableName:'||tab.name||',days:'||days);
        if days is null or days < 1 then  goto next; end if;
        days:=round(days);
        for i in 1..days loop
          curDays := persist_days + days - i;
          -- 特殊删除traceRt的数据
          if tabTypeImpl(s)='NB_TRACE' then
            suff := substr(tab.name,10);
            sqlStr:='select min(id) minId,max(id) maxId from '||tab.name||' where tm_base < trunc(sysdate,''dd'')-'||curDays;
            execute immediate sqlStr into minId,maxId;
            if minId is null then
              goto next;
            end if;
            --dbms_output.put_line(sqlstr||';');
            sqlStr:='delete from nb_route_'||suff||' where trace_id >='||minId||' and trace_id <='||maxId;
            --dbms_output.put_line(sqlstr||';'||chr(13)||'commit;');
            execute immediate sqlStr;
            commit;
            create_procedure_log('del_expire_data'||num,'tableName:nb_route_'||suff||',del date:'||to_char(sysdate - curDays,'yyyy-mm-dd'),'run');
          end if;
          -- 特殊删除stream的数据
          if tabTypeImpl(s)='NB_STREAM' then
            suff := substr(tab.name,11);
            sqlStr:='select min(id) minId,max(id) maxId from '||tab.name||' where tm_base < trunc(sysdate,''dd'')-'||curDays;
            execute immediate sqlStr into minId,maxId;
            --dbms_output.put_line(sqlstr||';');
            if minId is null then
              goto next;
            end if;
            sqlStr:='delete from nb_rate_'||suff||' where stream_id >='||minId||' and stream_id <='||maxId;
            --dbms_output.put_line(sqlstr||';'||chr(13)||'commit;');
            execute immediate sqlStr;
            commit;
            sqlStr:='delete from nb_stream_uvmos_'||suff||' where stream_id >='||minId||' and stream_id <='||maxId;
            --dbms_output.put_line(sqlstr||';'||chr(13)||'commit;');
            execute immediate sqlStr;
            commit;
            create_procedure_log('del_expire_data'||num,'tableName:nb_rate_'||suff|| ',del date:'||to_char(sysdate - curDays,'yyyy-mm-dd'),'run');
          end if;
            sqlStr:='delete from '||tab.name||' where tm_base < trunc(sysdate,''dd'')-'||curDays;
            --dbms_output.put_line(sqlstr||';'||chr(13)||'commit;');
            execute immediate sqlStr;
            commit;
            create_procedure_log('del_expire_data'||num,'tableName:'||tab.name||',del date:'||to_char(sysdate - curDays,'yyyy-mm-dd'),'run');
        end loop;

      <<next>>
        null;
      exception when others then
          --dbms_output.put_line('error:'||sqlStr);
          create_procedure_log('del_expire_data'||num,'tableName:'||tab.name||sqlerrm,'error');
      end;
    end loop;
    <<next1>>
        null;
  end loop;
  create_procedure_log('del_expire_data'||num,'end','run');
end del_expire_data;
/

