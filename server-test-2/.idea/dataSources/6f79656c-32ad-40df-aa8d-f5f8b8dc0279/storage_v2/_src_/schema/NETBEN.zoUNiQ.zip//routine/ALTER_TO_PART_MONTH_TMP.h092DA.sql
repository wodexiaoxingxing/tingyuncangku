create procedure alter_to_part_month_tmp(tableName varchar2,partNamePre varchar2) authid current_user is
sqlStr varchar2(32767);
rangeDate date;
rangeDesc varchar2(8);
partName1 varchar2(64);
rangeName1 varchar2(64);
partName2 varchar2(64);
rangeName2 varchar2(64);
partName3 varchar2(64);
rangeName3 varchar2(64);
partName4 varchar2(64);
rangeName4 varchar2(64);
partName5 varchar2(64);
rangeName5 varchar2(64);
partName6 varchar2(64);
rangeName6 varchar2(64);
partName7 varchar2(64);
rangeName7 varchar2(64);
partName8 varchar2(64);
rangeName8 varchar2(64);
partName9 varchar2(64);
rangeName9 varchar2(64);
partName10 varchar2(64);
rangeName10 varchar2(64);
partName11 varchar2(64);
rangeName11 varchar2(64);
partName12 varchar2(64);
rangeName12 varchar2(64);
partName13 varchar2(64);
rangeName13 varchar2(64);
partName14 varchar2(64);
rangeName14 varchar2(64);
createDate date;
--拷贝数据用变量
stDesc varchar2(32);
etDesc varchar2(32);
begin
  DBMS_OUTPUT.ENABLE(999999999999999999999);
  createDate:=sysdate-360;
  rangeDate := trunc(createDate,'mm');
  rangeDesc := to_char(rangeDate,'yyyymm');
  partName1:=partNamePre||'_'||rangeDesc;
  rangeName1:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := add_months(rangeDate,1);
  rangeDesc := to_char(rangeDate,'yyyymm');
  partName2:=partNamePre||'_'||rangeDesc;
  rangeName2:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := add_months(rangeDate,1);
  rangeDesc := to_char(rangeDate,'yyyymm');
  partName3:=partNamePre||'_'||rangeDesc;
  rangeName3:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := add_months(rangeDate,1);
  rangeDesc := to_char(rangeDate,'yyyymm');
  partName4:=partNamePre||'_'||rangeDesc;
  rangeName4:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := add_months(rangeDate,1);
  rangeDesc := to_char(rangeDate,'yyyymm');
  partName5:=partNamePre||'_'||rangeDesc;
  rangeName5:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := add_months(rangeDate,1);
  rangeDesc := to_char(rangeDate,'yyyymm');
  partName6:=partNamePre||'_'||rangeDesc;
  rangeName6:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := add_months(rangeDate,1);
  rangeDesc := to_char(rangeDate,'yyyymm');
  partName7:=partNamePre||'_'||rangeDesc;
  rangeName7:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := add_months(rangeDate,1);
  rangeDesc := to_char(rangeDate,'yyyymm');
  partName8:=partNamePre||'_'||rangeDesc;
  rangeName8:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := add_months(rangeDate,1);
  rangeDesc := to_char(rangeDate,'yyyymm');
  partName9:=partNamePre||'_'||rangeDesc;
  rangeName9:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := add_months(rangeDate,1);
  rangeDesc := to_char(rangeDate,'yyyymm');
  partName10:=partNamePre||'_'||rangeDesc;
  rangeName10:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
    rangeDate := add_months(rangeDate,1);
  rangeDesc := to_char(rangeDate,'yyyymm');
  partName11:=partNamePre||'_'||rangeDesc;
  rangeName11:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
    rangeDate := add_months(rangeDate,1);
  rangeDesc := to_char(rangeDate,'yyyymm');
  partName12:=partNamePre||'_'||rangeDesc;
  rangeName12:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
    rangeDate := add_months(rangeDate,1);
  rangeDesc := to_char(rangeDate,'yyyymm');
  partName13:=partNamePre||'_'||rangeDesc;
  rangeName13:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
   rangeDate := add_months(rangeDate,1);
  rangeDesc := to_char(rangeDate,'yyyymm');
  partName14:=partNamePre||'_'||rangeDesc;
  rangeName14:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  -- 1 创建临时表
  create_procedure_log('alter_to_part_month_tmp',tableName||',begin','run');
    begin
      sqlStr:='drop table '||tableName||'_t';
      dbms_output.put_line(sqlStr||';');
      --execute immediate sqlStr;表空间也要重写
    exception when others then
      create_procedure_log('alter_to_part_month_tmp',tableName||','||sqlerrm,'error');
    end;

    sqlStr:=' create table '||tableName||'_t partition by range (ctime)(
              partition '||partName1||' values less than ('||rangeName2||'),
              partition '||partName2||' values less than ('||rangeName3||'),
              partition '||partName3||' values less than ('||rangeName4||'),
              partition '||partName4||' values less than ('||rangeName5||'),
              partition '||partName5||' values less than ('||rangeName6||'),
              partition '||partName6||' values less than ('||rangeName7||'),
              partition '||partName7||' values less than ('||rangeName8||'),
              partition '||partName8||' values less than ('||rangeName9||'),
              partition '||partName9||' values less than ('||rangeName10||'),
              partition '||partName10||' values less than ('||rangeName11||')
              partition '||partName11||' values less than ('||rangeName12||')
              partition '||partName12||' values less than ('||rangeName13||')
              partition '||partName13||' values less than ('||rangeName14||'))
              tablespace saas
              as select * from '||tableName||' where 1=0';
        dbms_output.put_line(sqlStr||';');
        --execute immediate sqlStr;



        -- 创建索引,这个语句要重写
         begin
          create_procedure_log('alter_to_part_month_tmp',tableName||','||'创建索引IDX_SS_REG_LOG_CTIME','run');
          sqlStr:='create index IDX_SS_REG_LOG_CTIME on '||tableName||'_t CTIME  LOCAL tableSpace SAAS_IND nologging';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_to_part_month_tmp',tableName||','||sqlStr||','||sqlerrm,'error');
        end;
        /*
        begin
          create_procedure_log('alter_to_part_month_tmp',tableName||','||'创建索引idx_nb_plg_id','run');
          sqlStr:='create index idx_nb_plg_id on '||tableName||'_t (id) local compress 1 tableSpace NETBEN_IDX_NEW nologging';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_to_part_month_tmp',tableName||','||sqlStr||','||sqlerrm,'error');
        end;

        begin
          create_procedure_log('alter_to_part_month_tmp',tableName||','||'创建索引idx_nb_plg_csm','run');
          sqlStr:='create index idx_nb_plg_ch on '||tableName||'_t (ctime,host_id) local compress 2 tableSpace NETBEN_IDX_NEW nologging';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_to_part_month_tmp',tableName||','||sqlStr||','||sqlerrm,'error');
        end;


       begin
          create_procedure_log('alter_to_part_month_tmp',tableName||','||'创建索引in_page_perf','run');
          sqlStr:='create index in_dsp_mb_task on '||tableName||'_temp (ctime,task_id) compress 2 LOCAL tableSpace NETBEN_IND nologging';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_to_part_month_tmp',tableName||','||sqlStr||','||sqlerrm,'error');
        end;
        */
        --注意时间的起始点，保留天数，i的最大值加1
        for i in 1..360 loop
          stDesc:=to_char(sysdate - (361-i)-1,'yyyy-mm-dd');
          etDesc:=to_char(sysdate - (360-i)-1,'yyyy-mm-dd');
          sqlStr:='insert into '||tableName||'_t
              select * from '||tableName||' where ctime >= to_date('''||stDesc||''',''yyyy-mm-dd'') and ctime<to_date('''||etDesc||''',''yyyy-mm-dd'')';
          dbms_output.put_line(sqlStr||';');
          dbms_output.put_line('commit;');
        end loop;
      sqlStr:='rename '||tableName|| ' to '||tableName||'_bk';
      dbms_output.put_line(sqlStr||';');
      sqlStr:='rename '||tableName||'_t to '||tableName;
      dbms_output.put_line(sqlStr||';');
      --改完名后把最后1天数据导过来
      stDesc:=to_char(sysdate-1,'yyyy-mm-dd');
      etDesc:=to_char(sysdate+1,'yyyy-mm-dd');
      sqlStr:='insert into '||tableName||'
              select * from '||tableName||'_bk where ctime >= to_date('''||stDesc||''',''yyyy-mm-dd'') and ctime<to_date('''||etDesc||''',''yyyy-mm-dd'')';
      dbms_output.put_line(sqlStr||';');
      dbms_output.put_line('commit;');
      create_procedure_log('alter_to_part_month_tmp',tableName||',end','run');
      exception when others then
        create_procedure_log('alter_to_part_month_tmp',tableName||','||sqlerrm,'error');
end alter_to_part_month_tmp;


/

