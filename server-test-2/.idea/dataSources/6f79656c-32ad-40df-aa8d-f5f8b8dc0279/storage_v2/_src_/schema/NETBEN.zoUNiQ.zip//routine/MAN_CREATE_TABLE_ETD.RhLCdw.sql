create PROCEDURE          "MAN_CREATE_TABLE_ETD" authid current_user is
  sqlStr  varchar2(8000);
  ---------------- ?????? ---------------------------------------------------------------------------
  createDate date := sysdate;
  orderNum   number;
  rangeDate  varchar2(128);
  partname1  varchar2(128);
  etd_partname1  varchar2(128);
  ett_partname1  varchar2(128);
  rangedate1 varchar2(128);
  partname2  varchar2(128);
  etd_partname2  varchar2(128);
  ett_partname2  varchar2(128);
  rangedate2 varchar2(128);
  partname3  varchar2(128);
  etd_partname3  varchar2(128);
  ett_partname3  varchar2(128);
  rangedate3 varchar2(128);
  taskId  varchar2(128);
  c int;
begin
     -- 2.??????????????????????et???????????????? ????????????????????
   for et in  (SELECT distinct substr(t.table_name,7) task
               from user_tables t
               where table_name like 'NB_ET%'
               AND table_name NOT like 'NB_ET_URL%'
               AND table_name NOT like 'NB_ETT%'
               AND table_name NOT like 'NB_ETD%')
     loop
 begin
        taskid := et.task;
 --??????????elem??????????????????
     select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 8 - to_char( createDate,'d'),'d') from dual);

        partname1:='PART_ET_'||taskid||'_'||orderNum;
  etd_partname1:='PART_ETD_'||taskid||'_'||orderNum;
  ett_partname1:='PART_ETT_'||taskid||'_'||orderNum;
        rangedate1:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';
    select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 15 - to_char( createDate,'d'),'d') from dual);
        partname2:='PART_ET_'||taskid||'_'||orderNum;
  etd_partname2:='PART_ETD_'||taskid||'_'||orderNum;
  ett_partname2:='PART_ETT_'||taskid||'_'||orderNum;
        rangedate2:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';
    select order_num,to_char(sunday,'yyyy-mm-dd') into orderNum,rangeDate from nb_part_calendar t
        where t.sunday = (select trunc(createDate + 22 - to_char( createDate,'d'),'d') from dual);
        partname3:='PART_ET_'||taskid||'_'||orderNum;
  etd_partname3:='PART_ETD_'||taskid||'_'||orderNum;
  ett_partname3:='PART_ETT_'||taskid||'_'||orderNum;
        rangedate3:='to_date('''||rangeDate||''',''yyyy-mm-dd'')';

SELECT COUNT(*) INTO C FROM USER_TABLES WHERE TABLE_NAME= 'NB_ETD_'||taskid ;
IF C<1 THEN
    --??????????
    sqlStr:='create table NB_ETD_'||taskid||'
    (
      PAGE_ID          NUMBER,
      TASK_ID          NUMBER,
      CITY_ID          NUMBER,
      ISP_ID           NUMBER,
      NET_SPEED_ID     NUMBER,
      TM_BASE          DATE,
      DOMAIN_ID        NUMBER,
      PROBE_IP         NUMBER,
      URL_IP           NUMBER,
      BYTE_TOTAL       NUMBER,
      TS_DNS           NUMBER,
      TS_CONNECT       NUMBER,
      TS_SSL           NUMBER,
      TS_REDIRECT      NUMBER,
      TS_REQUEST       NUMBER,
      TS_FIRST_PACKET  NUMBER,
      TS_REMAIN_PACKET NUMBER,
      TS_ELEMENT       NUMBER,
      TS_CLOSE         NUMBER,
      TS_BLOCK         NUMBER,
      BYTE_SENT        NUMBER,
      RATE_DOWNLOAD     NUMBER,
      RATE_UPLOAD     NUMBER,
      POINT_TOTAL     NUMBER,
      POINT_SUCC     NUMBER
    ) pctfree 0
    partition by range (TM_BASE)(
                  partition '||etd_partname1||' values less than ('||rangedate1||') tablespace netben_bg,
                  partition '||etd_partname2||' values less than ('||rangedate2||') tablespace netben_bg,
                  partition '||etd_partname3||' values less than ('||rangedate3||')) tablespace netben_bg';

--DBMS_OUTPUT.PUT_LINE(sqlStr);
execute   immediate   sqlStr;
    --???????? tm_base,domain_id
    sqlStr:='create index IDX_ETD_DID_'||taskid||' on NB_ETD_'||taskid||' (DOMAIN_ID,TM_BASE) local
            (partition '||etd_partname1||',partition '||etd_partname2||',partition '||etd_partname3||') compress 2 PCTFREE 0
            tableSpace  NETBEN_IND nologging';

--DBMS_OUTPUT.PUT_LINE(sqlStr);
execute   immediate   sqlStr;
END IF;

SELECT COUNT(*) INTO C FROM USER_TABLES WHERE TABLE_NAME= 'NB_ETT_'||taskid ;
IF C<1 THEN
   --??????????????
    sqlStr:='create table NB_ETT_'||taskid||'
    (
      PAGE_ID          NUMBER,
      TASK_ID          NUMBER,
      CITY_ID          NUMBER,
      ISP_ID           NUMBER,
      NET_SPEED_ID     NUMBER,
      TM_BASE          DATE,
      ELEM_TYPE_ID     NUMBER,
      PROBE_IP         NUMBER,
      BYTE_TOTAL       NUMBER,
      TS_DNS           NUMBER,
      TS_CONNECT       NUMBER,
      TS_SSL           NUMBER,
      TS_REDIRECT      NUMBER,
      TS_REQUEST       NUMBER,
      TS_FIRST_PACKET  NUMBER,
      TS_REMAIN_PACKET NUMBER,
      TS_ELEMENT       NUMBER,
      TS_CLOSE         NUMBER,
      TS_BLOCK         NUMBER,
      BYTE_SENT        NUMBER,
      RATE_DOWNLOAD     NUMBER,
      RATE_UPLOAD     NUMBER,
      POINT_TOTAL     NUMBER,
      POINT_SUCC     NUMBER
    ) pctfree 0
    partition by range (TM_BASE)(
                  partition '||ett_partname1||' values less than ('||rangedate1||') tablespace netben_bg,
                  partition '||ett_partname2||' values less than ('||rangedate2||') tablespace netben_bg,
                  partition '||ett_partname3||' values less than ('||rangedate3||')) tablespace netben_bg';


--DBMS_OUTPUT.PUT_LINE(sqlStr);
execute   immediate   sqlStr;

    --???????? tm_base,type_id
    sqlStr:='create index IDX_ETT_TID_'||taskid||' on NB_ETT_'||taskid||' (ELEM_TYPE_ID,TM_BASE) local
            (partition '||ett_partname1||',partition '||ett_partname2||',partition '||ett_partname3||') compress 2 PCTFREE 0
            tableSpace  NETBEN_IND nologging';

--DBMS_OUTPUT.PUT_LINE(sqlStr);
execute   immediate   sqlStr;
END IF;
end;
       end loop;

    exception when  others then
      DBMS_OUTPUT.PUT_LINE(sqlStr);
      MON_PC_ERROR_LOG('CREATE_TABLE_ETD',sqlerrm,taskId);
     DBMS_OUTPUT.PUT_LINE(taskId||' ERROR!');

end MAN_CREATE_TABLE_ETD;


/

