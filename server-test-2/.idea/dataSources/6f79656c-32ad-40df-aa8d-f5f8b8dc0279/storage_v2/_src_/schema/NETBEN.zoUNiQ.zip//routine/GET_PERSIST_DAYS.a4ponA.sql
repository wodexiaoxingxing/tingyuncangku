create function get_persist_days(table_name   in varchar2,
                                            default_days in integer)
  return integer is
  days number;
begin
  select t.days
    into days
    from nb_m_data_persist_day t
   where table_name like ('%_' || t.table_str);

  if days is null then
    return default_days;
  else
    return days;
  end if;
EXCEPTION
  -- 找不到记录时返回默认天数
  WHEN NO_DATA_FOUND THEN
    return default_days;
end get_persist_days;
/

