create procedure alter_to_part_week_tmp(tableName varchar2,partNamePre varchar2) authid current_user is
sqlStr varchar2(32767);
rangeDate date;
rangeDesc varchar2(8);
partName1 varchar2(64);
rangeName1 varchar2(64);
partName2 varchar2(64);
rangeName2 varchar2(64);
partName3 varchar2(64);
rangeName3 varchar2(64);
partName4 varchar2(64);
rangeName4 varchar2(64);
partName5 varchar2(64);
rangeName5 varchar2(64);
partName6 varchar2(64);
rangeName6 varchar2(64);
partName7 varchar2(64);
rangeName7 varchar2(64);
partName8 varchar2(64);
rangeName8 varchar2(64);
partName9 varchar2(64);
rangeName9 varchar2(64);
partName10 varchar2(64);
rangeName10 varchar2(64);
createDate date;
--拷贝数据用变量
stDesc varchar2(32);
etDesc varchar2(32);
begin
  DBMS_OUTPUT.ENABLE(999999999999999999999);
  createDate:=sysdate-63;
  rangeDate := trunc(createDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName1:=partNamePre||'_'||rangeDesc;
  rangeName1:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'dd');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName2:=partNamePre||'_'||rangeDesc;
  rangeName2:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'dd');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName3:=partNamePre||'_'||rangeDesc;
  rangeName3:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'dd');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName4:=partNamePre||'_'||rangeDesc;
  rangeName4:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'dd');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName5:=partNamePre||'_'||rangeDesc;
  rangeName5:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'dd');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName6:=partNamePre||'_'||rangeDesc;
  rangeName6:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'dd');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName7:=partNamePre||'_'||rangeDesc;
  rangeName7:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'dd');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName8:=partNamePre||'_'||rangeDesc;
  rangeName8:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'dd');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName9:=partNamePre||'_'||rangeDesc;
  rangeName9:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'dd');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName10:=partNamePre||'_'||rangeDesc;
  rangeName10:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  -- 1 创建临时表
  create_procedure_log('alter_to_part_week_tmp',tableName||',begin','run');
    begin
      sqlStr:='drop table '||tableName||'_t';
      dbms_output.put_line(sqlStr||';');
      --execute immediate sqlStr;
    exception when others then
      create_procedure_log('alter_to_part_week_tmp',tableName||','||sqlerrm,'error');
    end;

    sqlStr:=' create table '||tableName||'_t partition by range (cdate)(
              partition '||partName1||' values less than ('||rangeName1||'),
              partition '||partName2||' values less than ('||rangeName2||'),
              partition '||partName3||' values less than ('||rangeName3||'),
              partition '||partName4||' values less than ('||rangeName4||'),
              partition '||partName5||' values less than ('||rangeName5||'),
              partition '||partName6||' values less than ('||rangeName6||'),
              partition '||partName7||' values less than ('||rangeName7||'),
              partition '||partName8||' values less than ('||rangeName8||'),
              partition '||partName9||' values less than ('||rangeName9||'),
              partition '||partName10||' values less than ('||rangeName10||'))
              tablespace netben_bg
              as select * from '||tableName||' where 1=0';
        dbms_output.put_line(sqlStr||';');
        --execute immediate sqlStr;



        -- 创建索引,这个语句要重写
        begin
          create_procedure_log('alter_to_part_week_tmp',tableName||','||'创建索引hour_probeid','run');
          sqlStr:='create index hour_probeid on '||tableName||'_t(Calc_date,probe_id)local tableSpace NETBEN_IND nologging';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_to_part_week_tmp',tableName||','||sqlStr||','||sqlerrm,'error');
        end;

        begin
          create_procedure_log('alter_to_part_week_tmp',tableName||','||'创建索引hour_probeid','run');
          sqlStr:='create index hour_memberid on '||tableName||'_t(calc_date,member_id)local tableSpace NETBEN_IND nologging';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_to_part_week_tmp',tableName||','||sqlStr||','||sqlerrm,'error');
        end;

        for i in 1..180 loop
          stDesc:=to_char(sysdate - (181-i)-1,'yyyy-mm-dd');
          etDesc:=to_char(sysdate - (180-i)-1,'yyyy-mm-dd');
          sqlStr:='insert into '||tableName||'_t
              select * from '||tableName||' where cdate >= to_date('''||stDesc||''',''yyyy-mm-dd'') and cdate<to_date('''||etDesc||''',''yyyy-mm-dd'')';
          dbms_output.put_line(sqlStr||';');
          dbms_output.put_line('commit;');
        end loop;
      sqlStr:='rename '||tableName|| ' to '||tableName||'_his';
      dbms_output.put_line(sqlStr||';');
      sqlStr:='rename '||tableName||'_t to '||tableName;
      dbms_output.put_line(sqlStr||';');
      --改完名后把最后1天数据导过来
      stDesc:=to_char(sysdate-1,'yyyy-mm-dd');
      etDesc:=to_char(sysdate+1,'yyyy-mm-dd');
      sqlStr:='insert into '||tableName||'
              select * from '||tableName||'_his where cdate >= to_date('''||stDesc||''',''yyyy-mm-dd'') and cdate<to_date('''||etDesc||''',''yyyy-mm-dd'')';
      dbms_output.put_line(sqlStr||';');
      dbms_output.put_line('commit;');
      create_procedure_log('alter_to_part_week_tmp',tableName||',end','run');
      exception when others then
        create_procedure_log('alter_to_part_week_tmp',tableName||','||sqlerrm,'error');
end alter_to_part_week_tmp;


/

