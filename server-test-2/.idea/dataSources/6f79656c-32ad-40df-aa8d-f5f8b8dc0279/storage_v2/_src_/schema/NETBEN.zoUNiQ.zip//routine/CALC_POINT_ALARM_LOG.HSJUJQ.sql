create PROCEDURE          "CALC_POINT_ALARM_LOG" authid current_user is
sqlStr       varchar2(4000);
currDate date;
alarmType number;
v_count number;
begin
  create_procedure_log('calc_point_alarm_log', 'calc_point_alarm_log begin', 'test');
  currDate := sysdate;
  --开始生成需要发送警报的记录
  for item in (select id,count,range_type,start_date  from nb_point_alarm_table where status = 1) loop
  dbms_output.put_line(item.id);
      alarmType := 0;
      v_count := 0;
      --首先删除该日期内已经生成的数据，防止数据重复
      sqlStr := 'delete from nb_point_alarm_log where cdate >= :sDate and cdate < :eDate and alarm_id = :id';
      execute immediate sqlStr using trunc(currDate, 'dd'), trunc(currDate+1 , 'dd'),item.id;               
      commit;      
      --按每月来计算
      if item.range_type = 1 then 
          sqlStr := 'select sum(count) from nb_point_alarm_day where alarm_id = :alarmId and calc_date >= :sDate and calc_date < :eDate' ;
          execute immediate sqlStr into v_count using item.id,trunc(currDate -1,'mm'),add_months(trunc(currDate-1,'mm'),1);
          --判断是否警报（两种方式 1还剩5%之内 2已经超出)
          if v_count > item.count then
              alarmType := 2;
          elsif v_count > item.count * 95 /100 then
              alarmType := 1;
          end if;
          if alarmType > 0 then 
              sqlStr := 'insert into nb_point_alarm_log value (select seq_point_alarm.nextval,:alarmId,:alarmCount,sysdate,:count,:aType from dual)';
              execute immediate sqlStr using item.id,v_count,item.count,alarmType;
          end if;
      end if;
      --按指定日期来计算
      if item.range_type = 2 then 
          sqlStr := 'select sum(count) from nb_point_alarm_day where alarm_id = :alarmId and calc_date >= :sDate ' ;
          execute immediate sqlStr into v_count  using item.id,trunc(item.start_date,'dd') ;
          --判断是否警报（两种方式 1还剩5%之内 2已经超出)
          if v_count > item.count then
              alarmType := 2;
          elsif v_count > item.count * 95 /100 then
              alarmType := 1;
          end if;
          if alarmType > 0 then 
              sqlStr := 'insert into nb_point_alarm_log value (select seq_point_alarm.nextval,:alarmId,:alarmCount,sysdate,:count,:aType from dual)';
              execute immediate sqlStr using item.id,v_count,item.count,alarmType;
          end if;
      end if;
  
  end loop;
  create_procedure_log('calc_point_alarm_log', 'calc_point_alarm_log end', 'test');
end calc_point_alarm_log;


/

