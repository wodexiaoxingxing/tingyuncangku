create PROCEDURE createTRAN(tableStr IN varchar2,res OUT number) authid current_user is
  sqlStr     varchar2(8000);
  errorDesc varchar2(4000);
BEGIN

  create_procedure_log('createTRAN', 'create table:NB_TRAN_' || tableStr, 'run');  

  --创建Tran  
  sqlStr := 'create table NB_TRAN_' || tableStr || '
    (
      ID                  NUMBER not null,
      TASK_ID             NUMBER,
      CITY_ID             NUMBER,
      ISP_ID              NUMBER,
      NET_SPEED_ID        NUMBER,
      TM_BASE             DATE,
      TM_HOUR             DATE,
      TM_DAY              DATE,
      TM_HALF_HOUR        DATE,
      PROBE_IP            NUMBER,
      ERROR_CODE          NUMBER,
      CONT_ERR_TOTAL      NUMBER,
      ERROR_PAGE_SEQ      NUMBER,
      PAGE_TOTAL          NUMBER,
      BYTE_TOTAL          NUMBER,
      TS_TOTAL            NUMBER,
      TS_NETWORK          NUMBER,
      TS_PING_AVG         NUMBER,      
      TS_PING_START       NUMBER,
      PING_ERROR          NUMBER,
      TS_PING_MAX         NUMBER,
      TS_PING_MIN         NUMBER,
      PING_PACKET_LOST    NUMBER,
      POINT_TOTAL         NUMBER default 1,
      DNS_SERVER          VARCHAR2(128),
      DNS_SERVER_IP       NUMBER,
      DEST_IP             VARCHAR2(39),
      PING_DEST_IP        VARCHAR2(39),
      MEMBER_ID           INTEGER,
      VERSION_ID          INTEGER,
      OS_VER_ID           INTEGER,
      BS_ID               INTEGER,
      BS_VER_ID           INTEGER,
      FLASH_VER           VARCHAR2(32),
      PERCENT_CPU         NUMBER,
      PERCENT_CPU_TASK    NUMBER,  
      PERCENT_MEM         NUMBER,  
      PERCENT_MEM_TASK    NUMBER,  
      RATE_AVG            NUMBER,  
      BAND_WIDTH          NUMBER,
      CPU_TYPE            VARCHAR2(128),
      MEM_SIZE            INTEGER,    
      IS_NOISE            INTEGER,
      PCAP_PATH           VARCHAR2(512)
    ) pctfree 0';
  execute immediate sqlStr;

  --主键  
  sqlStr := 'alter table NB_TRAN_' || tableStr || ' add constraint PK_NB_TRAN_' || tableStr || ' primary key (ID) using index';
  execute immediate sqlStr;

  --索引
  sqlStr := 'create index IN_TRAN_PERF_' || tableStr || ' on NB_TRAN_' || tableStr || ' (TM_BASE, TASK_ID) tableSpace NETBEN_idx_new nologging';
  execute immediate sqlStr; 
  res:=0;
  
exception
  when others then
    errorDesc := 'Error :' || sqlerrm || '  tableStr:' || tableStr;
    --DBMS_OUTPUT.PUT_LINE(v_error_desc);
    create_procedure_log('createTRAN', errorDesc, 'error');
    res:=1;
    
END createTRAN;


/

