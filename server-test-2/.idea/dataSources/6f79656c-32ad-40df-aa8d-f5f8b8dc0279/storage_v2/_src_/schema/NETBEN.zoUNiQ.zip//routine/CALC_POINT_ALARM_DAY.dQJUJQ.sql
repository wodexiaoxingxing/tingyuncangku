create PROCEDURE          "CALC_POINT_ALARM_DAY" authid current_user is
sqlStr       varchar2(4000);
tableName varchar2(64);
currDate date;
v_s number;
v_tran_count number;
v_stream_count number;
begin
  create_procedure_log('calc_point_alarm_day', 'calc_point_alarm_day begin', 'test');
  currDate := sysdate;
  --循环，查寻出所有的表
  for item in (select table_str ,calc_type,id  from nb_point_alarm_table where status = 1) loop
      
      --首先删除该日期内已经生成的数据，防止数据重复
      sqlStr := 'delete from nb_point_alarm_day where calc_date >= :sDate and calc_date < :eDate and alarm_id = :id';
      execute immediate sqlStr using trunc(currDate - 1, 'dd'), trunc(currDate , 'dd'),item.id;               
      commit;      
      v_tran_count:=0;
      v_stream_count:=0;
      --判断是否有页面或Tran监测
      select count(*)  INTO v_s FROM user_tables where  table_name = 'NB_TRAN_'||item.table_str;
      if v_s > 0  then
          tableName := 'nb_tran_'||item.table_str;
         
          sqlStr:='select count(*) from '|| tableName||' where is_noise = 0 and tm_base >= :sDate and tm_base < :eDate';
          execute immediate sqlStr into v_tran_count using trunc(currDate - 1, 'dd'), trunc(currDate , 'dd');
      end if;
      --判断是否有流媒体监测      
      select count(*)  INTO v_s FROM user_tables where  table_name = 'NB_STREAM_'||item.table_str;
      if v_s > 0  then
          tableName := 'nb_stream_'||item.table_str;
          sqlStr:='select count(*)  from '|| tableName||' where is_noise = 0 and tm_base >= :sDate and tm_base < :eDate';
          execute immediate sqlStr into v_stream_count using trunc(currDate - 1, 'dd'), trunc(currDate , 'dd');
      end if;
      dbms_output.put_line(v_tran_count ||'  '||v_stream_count);
      --合计，则从tran表及stream表两个表中取出数据
      if item.calc_type = 0 then
          sqlStr := 'insert into nb_point_alarm_day  value (select seq_point_alarm.nextval,:cDate,:id,:count from dual)';
          execute immediate sqlStr using trunc(currDate - 1, 'dd'),item.id,v_tran_count + v_stream_count;          
          commit;
      end if;
      --Tran,则从tran表中取出数据
      if item.calc_type = 1 then
          sqlStr := 'insert into nb_point_alarm_day  value (select seq_point_alarm.nextval,:cDate,:id,:count from dual)';
          execute immediate sqlStr using trunc(currDate - 1, 'dd'),item.id,v_tran_count;          
          commit;
      end if;
       --Stream，则从stream表两个表中取出数据
      if item.calc_type = 3 then
          sqlStr := 'insert into nb_point_alarm_day  value (select seq_point_alarm.nextval,:cDate,:id,:count from dual)';
          execute immediate sqlStr using trunc(currDate - 1, 'dd'),item.id,v_stream_count;          
          commit;
      end if;
  end loop;
  create_procedure_log('calc_point_alarm_day', 'calc_point_alarm_day end', 'test');
end calc_point_alarm_day;


/

