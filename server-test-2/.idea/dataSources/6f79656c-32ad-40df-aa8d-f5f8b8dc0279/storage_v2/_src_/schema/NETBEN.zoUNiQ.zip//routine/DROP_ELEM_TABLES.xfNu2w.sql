create PROCEDURE          "DROP_ELEM_TABLES" (
  tableStr in varchar2
 ) authid current_user
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(4000);
  s number;
begin
  select count(*) into s from user_tables where table_name = 'NB_EC_' || tableStr;
  if s > 0 then
     sqlStr := 'drop table NB_EC_' || tableStr;
     execute   immediate sqlStr;
  end if;
  
  select count(*) into s from user_tables where table_name = 'NB_E_URL_' || tableStr;
  if s > 0 then
     sqlStr := 'drop table NB_E_URL_' || tableStr;
     execute   immediate sqlStr;
  end if;
  
  select count(*) into s from user_tables where table_name = 'NB_ET_URL_' || tableStr;
  if s > 0 then
     sqlStr := 'drop table NB_ET_URL_' || tableStr;
     execute   immediate sqlStr;
  end if;
  
  for tid in(select id from nb_m_task where agreement_id = (select id from nb_m_agreement where table_str=tableStr)) loop
  begin
    select count(*) into s from user_tables where table_name = 'NB_ET_' || tid.id;
    if s > 0 then
       sqlStr := 'drop table NB_ET_' || tid.id;
       execute   immediate sqlStr;
    end if;
    
    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlStr);
        create_procedure_log('DROP_ELEM_TABLES',v_error_desc,sqlcode);
  end;
  end loop;
end DROP_ELEM_TABLES;


/

