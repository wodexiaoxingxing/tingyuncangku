create PROCEDURE          "MBR_EN_RECOMM_DISPOSITE" is
  prcn         varchar2(30);
  rcm_reason   varchar2(30);
  cnt          integer;
  sid          number;
  last_balance number;
  rcm_income   number;
  rcm_money    number;
  rcm_date     date;
begin
  prcn := 'MBR_EN_RECOMM_DISPOSITE';
  CREATE_PROCEDURE_LOG(prcn, 'start', 'run');

  -- 被推荐人收益
  rcm_income := 50;
  -- 推荐奖励金额
  rcm_money := 10;
  -- 被推荐人收益月份(上月)
  rcm_date := trunc(trunc(sysdate, 'MM') - 1, 'MM');

  rcm_reason := 'DPMBRRECOM';
  
  -- 查找有被推荐人的会员id及被推荐人的id及被推荐人上月产生的收益(收入,不包括支出),
  -- 且推荐人和被推荐人类型为5(nb_m_member.mbr_type=5),
  -- 且推荐人和被推荐人id都不等于0
  for rmember in (select m.id, b.member_id, sum(b.money) as money
                    from nb_m_mbr_en_cash_balance b,
                         (select m.id, rm.id as rid
                            from nb_m_member m, nb_m_member rm
                           where rm.recomm_id = m.id
                             and m.id != 0
                             and rm.recomm_id != 0
                             and rm.recomm_id != rm.id
                             and m.mbr_type = 5
                             and rm.mbr_type = 5
                           order by m.id) m
                   where m.rid = b.member_id
                     and b.money > 0
                     and b.ctime >= rcm_date
                     and b.ctime < trunc(sysdate, 'mm')
                   group by m.id, b.member_id) loop
  
    -- 被推荐人产生收益大于等于50时才发给推荐人奖金
    if rmember.money >= rcm_income then
      -- 查询上月推荐奖金是否生成
      -- 查询本月是否已经生成过
      select count(*)
        into cnt
        from nb_m_member_cash_balance
       where member_id = rmember.id
         and reason = rcm_reason
         and ctime >= trunc(sysdate, 'mm')
         and dpmbr_id = rmember.member_id
         and ctime < sysdate;
    
      --只有等于0时才处理
      --大于0时代表已经生成过了
      if cnt = 0 then
        -- 生成推荐奖金
        last_balance := 0;
        -- 生成ID
        select MBR_CASH_BAL_ID_SEQ.Nextval into sid from dual;
        -- 测试是否已经有奖金记录
        cnt := 0;
        select count(*)
          into cnt
          from NB_V_MBR_RECMD_EN_CASH_POOL
         where member_id = rmember.id;
      
        if cnt > 0 then
          select balance
            into last_balance
            from NB_V_MBR_RECMD_EN_CASH_POOL
           where member_id = rmember.id;
        else
          -- 没有记录，balance = 0;
          last_balance := 0;
        end if;
        -- 插入奖金记录
        insert into nb_m_member_cash_balance
          (id,
           member_id,
           ctime,
           money,
           balance,
           reason,
           creator_id,
           dpmbr_id,
           dpmbr_bal,
           dpmbr_bal_month,
           req_id,
           comments)
        values
          (sid,
           rmember.id,
           sysdate,
           rcm_money,
           last_balance + rcm_money,
           rcm_reason,
           0,
           rmember.member_id,
           rmember.money,
           rcm_date,
           0,
           'recommend');
      
        -- 保存插入日志: 记录ID,推荐人ID,被推荐人ID,被推荐人收益,推荐月份
        CREATE_PROCEDURE_LOG(prcn,
                             'insert data',
                             sid || ',' || rmember.id || ',' ||
                             rmember.member_id || ',' || rcm_money || ',' ||
                             rcm_date);
      else
        -- 保存提示日志,已经生成过:推荐人ID,被推荐人ID
        CREATE_PROCEDURE_LOG(prcn,
                             'has data',
                             rmember.id || ',' || rmember.member_id || ',' ||
                             rmember.money);
      end if;
    end if;
  
  end loop;
  -- 提交数据
  commit;

  CREATE_PROCEDURE_LOG(prcn, 'run', 'end');

end MBR_EN_RECOMM_DISPOSITE;


/

