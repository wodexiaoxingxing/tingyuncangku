create procedure alter_ping_to_part_copy_e(tablestr number) authid current_user is
RUN_ERROR EXCEPTION;--当出现某些异常时，程序体不能继续运行，此时记录日志并抛出此异常
sqlStr varchar2(32767);
rangeDate date;
rangeDesc varchar2(8);
partName1 varchar2(64);
rangeName1 varchar2(64);
partName2 varchar2(64);
rangeName2 varchar2(64);
partName3 varchar2(64);
rangeName3 varchar2(64);
partName4 varchar2(64);
rangeName4 varchar2(64);
partName5 varchar2(64);
rangeName5 varchar2(64);
partName6 varchar2(64);
rangeName6 varchar2(64);
partName7 varchar2(64);
rangeName7 varchar2(64);
partName8 varchar2(64);
rangeName8 varchar2(64);
partName9 varchar2(64);
rangeName9 varchar2(64);
partName10 varchar2(64);
rangeName10 varchar2(64);
createDate date;
--拷贝数据用变量
stDesc varchar2(32);
etDesc varchar2(32);
begin
  DBMS_OUTPUT.ENABLE(999999999999999999999);
  createDate:=sysdate-60;
  rangeDate := trunc(createDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName1:='part_ping_'||tableStr||'_'||rangeDesc;
  rangeName1:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName2:='part_ping_'||tableStr||'_'||rangeDesc;
  rangeName2:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName3:='part_ping_'||tableStr||'_'||rangeDesc;
  rangeName3:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName4:='part_ping_'||tableStr||'_'||rangeDesc;
  rangeName4:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName5:='part_ping_'||tableStr||'_'||rangeDesc;
  rangeName5:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName6:='part_ping_'||tableStr||'_'||rangeDesc;
  rangeName6:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName7:='part_ping_'||tableStr||'_'||rangeDesc;
  rangeName7:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName8:='part_ping_'||tableStr||'_'||rangeDesc;
  rangeName8:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName9:='part_ping_'||tableStr||'_'||rangeDesc;
  rangeName9:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  rangeDate := trunc(rangeDate + 7,'d');
  rangeDesc := to_char(rangeDate,'yymmdd');
  partName10:='part_ping_'||tableStr||'_'||rangeDesc;
  rangeName10:='to_date('''||to_char(rangeDate,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
  -- 1 创建临时表
  create_procedure_log('alter_ping_to_part_copy_e',tableStr||',begin','run');
    begin
      sqlStr:='drop table nb_ping_'||tablestr||'_temp';
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      create_procedure_log('alter_ping_to_part_copy_e',tableStr||','||'删除临时表_temp','run');
    exception when others then
      create_procedure_log('alter_ping_to_part_copy_e',tableStr||','||'删除临时表失败_temp,'||sqlerrm,'error');
    end;
    begin
      sqlStr:='drop table nb_ping_'||tablestr||'_bk';
      --dbms_output.put_line(sqlStr||';');
      execute immediate sqlStr;
      create_procedure_log('alter_ping_to_part_copy_e',tableStr||','||'删除临时表_bk','run');
    exception when others then
      create_procedure_log('alter_ping_to_part_copy_e',tableStr||','||'删除临时表失败_bk,'||sqlerrm,'error');
    end;
    begin
      sqlStr:=' create table nb_ping_'||tableStr||'_temp partition by range (tm_base)(
              partition '||partName1||' values less than ('||rangeName1||'),
              partition '||partName2||' values less than ('||rangeName2||'),
              partition '||partName3||' values less than ('||rangeName3||'),
              partition '||partName4||' values less than ('||rangeName4||'),
              partition '||partName5||' values less than ('||rangeName5||'),
              partition '||partName6||' values less than ('||rangeName6||'),
              partition '||partName7||' values less than ('||rangeName7||'),
              partition '||partName8||' values less than ('||rangeName8||'),
              partition '||partName9||' values less than ('||rangeName9||'),
              partition '||partName10||' values less than ('||rangeName10||'))
              tablespace netben_bg
              as select * from nb_ping_'||tableStr||' where 1=0';   
        --dbms_output.put_line(sqlStr||';');
        execute immediate sqlStr;
        create_procedure_log('alter_ping_to_part_copy_e',tableStr||',创建临时表','run');
      exception when others then
        create_procedure_log('alter_ping_to_part_copy_e',tableStr||',创建临时表失败,'||sqlerrm,'error');
        raise RUN_ERROR;
      end;
        -- 删除物化视图
        begin
          sqlStr:='drop materialized view log on nb_ping_'||tableStr;
           --dbms_output.put_line(sqlStr||';');
          execute immediate sqlStr;
          create_procedure_log('alter_ping_to_part_copy_e',tableStr||',删除物化视图日志','run');
        exception when  others then
          create_procedure_log('alter_ping_to_part_copy_e',tableStr||',删除物化视图日志失败,'||sqlerrm,'error');
        end;
        begin
          sqlStr:='drop materialized view mv_ping_'||tableStr;
           --dbms_output.put_line(sqlStr||';');
          execute immediate sqlStr;
          create_procedure_log('alter_ping_to_part_copy_e',tableStr||',删除物化视图','run');
        exception when  others then
          create_procedure_log('alter_ping_to_part_copy_e',tableStr||',删除物化视图失败,'||sqlerrm,'error');
        end;

        -- 修改索引名称，空出名称
        for i in 1..10 loop
          begin
            sqlStr:='alter index in_ping_perf_'||tableStr||' rename to in_ping_perf_'||tablestr||'_bak';
             --dbms_output.put_line(sqlStr||';');
            execute immediate sqlStr;
            create_procedure_log('alter_ping_to_part_copy_e',tableStr||','||'修改索引名称perf','run');
            exit;
          exception when others then
            if i=10 then
              create_procedure_log('alter_ping_to_part_copy_e',tableStr||','||'修改索引名称perf失败,'||sqlerrm,'error');
            end if;
          end;
        end loop;
        for i in 1..10 loop
          begin
            sqlStr:='alter index in_ping_pageid_'||tableStr||' rename to in_ping_pageid_'||tablestr||'_bak';
             --dbms_output.put_line(sqlStr||';');
            execute immediate sqlStr;
            create_procedure_log('alter_ping_to_part_copy_e',tableStr||','||'修改索引名称pageid','run');
            exit;
          exception when others then
            if i=10 then
              create_procedure_log('alter_ping_to_part_copy_e',tableStr||','||'修改索引名称tranid失败,'||sqlerrm,'error');
            end if;
          end;
        end loop;
        for i in 1..10 loop
          begin
            sqlStr:='alter index in_ping_id_'||tableStr||' rename to in_ping_id_'||tablestr||'_bak';
            --dbms_output.put_line(sqlStr||';');
             execute immediate sqlStr;
            create_procedure_log('alter_ping_to_part_copy_e',tableStr||','||'修改索引名称pageid','run');
            exit;
          exception when others then
            if i=10 then
              create_procedure_log('alter_ping_to_part_copy_e',tableStr||','||'修改索引名称pageid失败,'||sqlerrm,'error');
            end if;
          end;
        end loop;

        
        -- 创建索引  
        begin
          create_procedure_log('alter_ping_to_part',tableStr||','||'创建索引in_ping_perf','run'); 
          sqlStr:='create index in_ping_perf_'||tableStr||' on nb_ping_'||tableStr||'_temp (task_id,tm_base)local compress 1 tableSpace NETBEN_idx_new nologging';
          --dbms_output.put_line(sqlStr||';');
          execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_ping_to_part',tableStr||','||sqlStr||','||sqlerrm,'error'); 
        end;  
       
        /*
        begin
          create_procedure_log('alter_ping_to_part',tableStr||','||'创建索引in_ping_pageid','run'); 
          sqlStr:='create index in_ping_pageid_'||tableStr||' on nb_ping_'||tableStr||'_temp (id) local tableSpace NETBEN_idx_new nologging';
          dbms_output.put_line(sqlStr||';');
          --execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_ping_to_part',tableStr||','||sqlStr||','||sqlerrm,'error'); 
        end;
        */  
        begin
          create_procedure_log('alter_ping_to_part',tableStr||','||'创建索引in_ping_id','run'); 
          sqlStr:='create index in_ping_id_'||tableStr||' on nb_ping_'||tableStr||'_temp (ping_id) local tableSpace NETBEN_idx_new nologging';
          --dbms_output.put_line(sqlStr||';');
          execute immediate sqlStr;
        exception when others then
          create_procedure_log('alter_ping_to_part',tableStr||','||sqlStr||','||sqlerrm,'error'); 
        end;
        
        --开始导入数据
        create_procedure_log('alter_ping_to_part_copy_e',tableStr||',开始导入数据','run');
        for i in 1..90 loop
          stDesc:=to_char(sysdate -(91-i)-1,'yyyy-mm-dd');
          etDesc:=to_char(sysdate-(90-i)-1,'yyyy-mm-dd');
          sqlStr:='insert into nb_ping_'||tableStr||'_temp 
              select * from nb_ping_'||tableStr||' where tm_base >= to_date('''||stDesc||''',''yyyy-mm-dd'') and tm_base<to_date('''||etDesc||''',''yyyy-mm-dd'')';
          --dbms_output.put_line(sqlStr||';');
          --dbms_output.put_line('commit;'); 
          execute immediate sqlStr;
          commit;
          create_procedure_log('alter_ping_to_part_copy_e',tableStr||',导入数据,'||stDesc||'~'||etDesc,'run');     
        end loop; 
        
        
        -- 修改表名
        for i in 1..10 loop
          begin
            sqlStr:='rename nb_ping_'||tablestr|| ' to nb_ping_'||tablestr||'_bk';
            --dbms_output.put_line(sqlStr||';');
            execute immediate sqlStr;
            create_procedure_log('alter_ping_to_part_copy_e',tableStr||',修改表名,将正式表改成_bk','run');
            exit;
          exception when others then
            if i=10 then
              create_procedure_log('alter_ping_to_part_copy_e',tableStr||',修改表名,将正式表改成_bk失败,'||sqlerrm,'error');
              raise RUN_ERROR;
            end if;
          end;
        end loop;
        begin
          sqlStr:='rename nb_ping_'||tablestr||'_temp to nb_ping_'||tablestr;
          --dbms_output.put_line(sqlStr||';');
          execute immediate sqlStr;
          create_procedure_log('alter_ping_to_part_copy_e',tableStr||',修改表名,将临时表改成正式表','run');
        exception when others then
          create_procedure_log('alter_ping_to_part_copy_e',tableStr||',修改表名,将临时表改成正式表失败,'||sqlerrm,'error');
          raise RUN_ERROR;
        end;
      --改完名后把最后1天数据导过来

      stDesc:=to_char(sysdate-1,'yyyy-mm-dd');
      etDesc:=to_char(sysdate+1,'yyyy-mm-dd');
      sqlStr:='insert into nb_ping_'||tableStr||' 
              select * from nb_ping_'||tableStr||'_bk where tm_base >= to_date('''||stDesc||''',''yyyy-mm-dd'') and tm_base<to_date('''||etDesc||''',''yyyy-mm-dd'')';
      --dbms_output.put_line(sqlStr||';');
      --dbms_output.put_line('commit;'); 
      execute immediate sqlStr;
      commit;
      create_procedure_log('alter_ping_to_part_copy_e',tableStr||',最后一次导入数据,'||stDesc||'~'||etDesc,'run');
      create_procedure_log('alter_ping_to_part_copy_e',tableStr||',end','run');
    exception when RUN_ERROR then
      create_procedure_log('alter_ping_to_part_copy_e',tableStr||',出现不能正常执行的异常,'||sqlerrm,'error');
end alter_ping_to_part_copy_e;


/

