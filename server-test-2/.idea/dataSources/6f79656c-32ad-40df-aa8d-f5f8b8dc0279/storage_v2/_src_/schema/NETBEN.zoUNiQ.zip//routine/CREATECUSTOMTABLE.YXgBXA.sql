create procedure createCustomTable(tableStr IN varchar2) authid current_user is
    sqlStr varchar2(4000);
begin
    --create trace sequence
    sqlStr := 'create sequence SEQ_NB_CUSTOM_ID_' || tableStr || '
      minvalue 1
      maxvalue 9999999999999999999999999
      start with 1
      increment by 1
      cache 500';
    execute immediate sqlStr;

    --create TABLE of NB_CUSTOM
    sqlStr := 'create table NB_CUSTOM_' || tableStr || '
  (
  ID                NUMBER not null,
  TASK_ID           NUMBER,
  PROTOCOL_ID       VARCHAR2(16),
  PROBE_IP          NUMBER,
  CITY_ID           NUMBER,
  ISP_ID            NUMBER,
  NET_SPEED_ID      NUMBER,
  MEMBER_ID         NUMBER,
  DNS_SERVER        VARCHAR2(128),
  TM_BASE           DATE,
  ERROR_CODE        NUMBER,
  IS_NOISE          NUMBER,
  VERSION_ID        INTEGER,
  OS_VER_ID         INTEGER,
  BS_ID             INTEGER,
  BS_VER_ID         INTEGER,
  PERCENT_CPU       NUMBER,
  PERCENT_CPU_TASK  NUMBER,
  PERCENT_MEM       NUMBER,
  PERCENT_MEM_TASK  NUMBER,
  RATE_AVG          NUMBER,
  BAND_WIDTH        NUMBER,
  DEST_IP           VARCHAR2(39),
  DEST_CITY_ID        NUMBER,
  DEST_ISP_ID         NUMBER,
  DEST_NAME         VARCHAR2(512),
  TS_TOTAL          NUMBER,
  LOG_MSG           VARCHAR2(4000),
  PING_RESULT       VARCHAR2(512),
  TRACERT_RESULT    VARCHAR2(512),
  NSLOOKUP_RESULT   VARCHAR2(512),
  POINT_TOTAL       INTEGER default 1,
  CUST_FIELD1       NUMBER,
  CUST_FIELD2       NUMBER,
  CUST_FIELD3       NUMBER,
  CUST_FIELD4       NUMBER,
  CUST_FIELD5       NUMBER,
  CUST_FIELD6       NUMBER,
  CUST_FIELD7       NUMBER,
  CUST_FIELD8       NUMBER,
  CUST_FIELD9       NUMBER,
  CUST_FIELD10      NUMBER,
  CUST_FIELD11      NUMBER,
  CUST_FIELD12      NUMBER,
  CUST_FIELD13      NUMBER,
  CUST_FIELD14      NUMBER,
  CUST_FIELD15      NUMBER,
  CUST_FIELD16      NUMBER,
  CUST_FIELD17      NUMBER,
  CUST_FIELD18      NUMBER,
  CUST_FIELD19      NUMBER,
  CUST_FIELD20      NUMBER,
  CUST_FIELD21      NUMBER,
  CUST_FIELD22      NUMBER,
  CUST_FIELD23      NUMBER,
  CUST_FIELD24      NUMBER,
  CUST_FIELD25      NUMBER,
  CUST_FIELD26      NUMBER,
  CUST_FIELD27      NUMBER,
  CUST_FIELD28      NUMBER,
  CUST_FIELD29      NUMBER,
  CUST_FIELD30      NUMBER,

  COUNTRY_ID        NUMBER,
  REGION_ID         NUMBER,
  DISTINCT_ID       NUMBER,
  DEST_COUNTRY_ID   NUMBER,
  DEST_REGION_ID    NUMBER,
  IS_CDN_COVER      NUMBER,
  IS_ISP_COVER      NUMBER,
      TRACE_ID            VARCHAR2(128),
      FEEDBACK            INTEGER
  ) pctfree 0
  tablespace NETBEN';
    execute immediate sqlStr;

    sqlStr := 'alter table NB_CUSTOM_' || tableStr || '
    add constraint PK_NB_CUSTOM_' || tableStr ||
              ' primary key (ID)
      using index
      tablespace NETBEN';
    execute immediate sqlStr;

    -- NB_CUSTOM index
    sqlStr := 'create index IN_CUSTOM_PERF_' || tableStr || ' on NB_CUSTOM_' ||
              tableStr || ' (TM_BASE,TASK_ID) tableSpace NETBEN_IDX_NEW';
    execute immediate sqlStr;

end createCustomTable;
/

