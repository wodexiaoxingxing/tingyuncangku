create PROCEDURE          "DEL_TRAN_PAGE_BY_2DAY" 
authid current_user
is
  sqlStr varchar2(4000);
  v_error_desc varchar2(4000);
  task sys_refcursor;
  v_taskId number;
begin
for tableName in(select table_str as name from nb_m_agreement where owner_id < 2000) loop
begin
      --内循环，取出一个表内的所有任务ID      
  sqlStr := 'select id from nb_m_task where owner_id ='||tableName.Name;
  open task for sqlStr;
  loop
    fetch task into v_taskId;
    EXIT WHEN task%NOTFOUND;
    for i in 1..100 loop
        sqlStr:='delete from nb_tran_'||tableName.Name||' where tm_base between sysdate - 57 -(100-'||i||')*2 -3
           and sysdate - 57 - (100-'||i||')*2  and task_id='||v_taskId;
        execute immediate sqlStr;
        commit;
        create_procedure_log('del_tran_page_by_2day   tran:'||v_taskId,sqlStr,i);
        
        sqlStr:='delete from nb_page_'||tableName.Name||' where tm_base between sysdate - 57 -(100-'||i||')*2 -3
           and sysdate - 57 - (100-'||i||')*2  and task_id='||v_taskId;
        execute immediate sqlStr;
        commit;
        create_procedure_log('del_tran_page_by_2day  page:'||v_taskId,sqlStr,i);
        
    end loop;
  end loop;
  close task;
      --如果在一个外循环中出现错误，则此外循环将无法完成，而跳到下一循环
  exception when  others then
        v_error_desc := ' Error: tableStr ='|| tableName.Name || '   ' ||sqlStr;
        DBMS_OUTPUT.PUT_LINE(sqlcode); 
        DBMS_OUTPUT.PUT_LINE(v_error_desc);
end;        
end loop;        
        --create_procedure_log('in_top_elem_perf',v_error_desc,sqlcode);
end del_tran_page_by_2day;


/

