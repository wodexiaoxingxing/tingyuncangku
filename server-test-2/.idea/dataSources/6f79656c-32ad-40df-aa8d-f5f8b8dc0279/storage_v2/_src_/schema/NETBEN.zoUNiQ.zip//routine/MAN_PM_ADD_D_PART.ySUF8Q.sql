create PROCEDURE MAN_PM_ADD_D_PART
    ( TAB_NAME  VARCHAR2 ,
      COUNTER  NUMBER ,  -- 插入多少个
      TS_NAME  VARCHAR2
    )
    IS
        QUERY_STR  VARCHAR2(4000);
        P_NAME   VARCHAR2(40);        --分区名字
        T_NAME   VARCHAR2(40);
        STR1     VARCHAR2(40);
        ERR_LOG     VARCHAR2(100);
        TDAY     DATE;
        TDAY2     DATE;
        TSTARTDAY   DATE;
        C INT;
        SPRE VARCHAR2(40);  ---文件名前缀

    BEGIN
    --该程序用于增加每日的分区
    -- 取当前用户名做前缀名
        SELECT USER INTO SPRE FROM DUAL;
    -- error log
     ERR_LOG := 'Error occured! Partition '||TAB_NAME||' add errcor';
    --取当前最大的分区
    select TO_DATE(SUBSTR(MAX(PARTITION_NAME),
                          length(MAX(PARTITION_NAME)) - 5,
                          8) ,
                   'yymmdd')
      INTO TSTARTDAY
      from user_tab_partitions
     where table_name = TAB_NAME;
DBMS_OUTPUT.PUT_LINE(TSTARTDAY);
              TSTARTDAY :=trunc(TSTARTDAY,'day') ;

DBMS_OUTPUT.PUT_LINE(TSTARTDAY);

      FOR I IN 1..COUNTER LOOP

    SELECT SUBSTR(PARTITION_NAME,1,length(PARTITION_NAME)-6) into T_NAME  FROM USER_TAB_PARTITIONS WHERE TABLE_NAME=TAB_NAME and rownum=1;

DBMS_OUTPUT.PUT_LINE(T_NAME);
              TDAY := TSTARTDAY + I*1;
             TDAY2 := TSTARTDAY + (I+1)*1;
            P_NAME := T_NAME||TO_CHAR(TDAY,'yymmdd');
             STR1 :=TO_CHAR(TDAY2,'yyyymmdd');
DBMS_OUTPUT.PUT_LINE(P_NAME);
DBMS_OUTPUT.PUT_LINE(STR1);
        SELECT COUNT(*) INTO C FROM USER_TAB_PARTITIONS WHERE PARTITION_NAME = P_NAME;
        IF C<=0 THEN
            QUERY_STR :='alter table '
                      ||TAB_NAME
                      ||' add  PARTITION '
                      ||P_NAME
                      ||' VALUES LESS THAN  (to_date('
                      ||CHR(39)
                      ||STR1
                      ||CHR(39)
                      ||','
                      ||CHR(39)
                      ||'yyyymmdd'
                      ||CHR(39)
                      ||')) tablespace '
                      ||TS_NAME;
DBMS_OUTPUT.PUT_LINE(QUERY_STR);
 EXECUTE IMMEDIATE (QUERY_STR);
         END IF;
       END LOOP;

     exception when  others then
      MON_PC_ERROR_LOG('MAN_PM_ADD_D_PART',sqlerrm,TAB_NAME);
 /*     
exception
       when VALUE_ERROR then
  insert into mn_err_log (ertime,event,detail) values (sysdate,'Add partition too long!',ERR_LOG);

       when others then
  insert into mn_err_log (ertime,event,detail) values (sysdate,'Add partition error!',ERR_LOG);
*/

    END MAN_PM_ADD_D_PART;


/

