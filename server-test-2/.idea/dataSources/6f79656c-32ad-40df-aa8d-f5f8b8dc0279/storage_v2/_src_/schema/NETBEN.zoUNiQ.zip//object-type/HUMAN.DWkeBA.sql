create TYPE          "HUMAN"                                          as object(
name varchar2(20),sex varchar2(1),birthday date,note varchar2(300),
member function get_age return number)

/

