create PROCEDURE task_summary(start_time in date,
                                         end_time   in date,
                                         isp_id     in NUMBER) is
                                         
  table_str  nb_m_agreement.table_str%type;
  sys_cur    sys_refcursor;
  sql_str    varchar2(4096);
  task_count NUMBER;
  
begin

  OPEN sys_cur FOR
    select distinct (agree.table_str)
      from nb_m_task task
      left outer join nb_m_agreement agree
        on task.agreement_id = agree.id
     where exists (select 1
              from nb_m_task
             where id = task.id
               and status = 1
               and type = 102
               and task_option = 'S'
               and ts_id = 4
               and expire >= start_time);

  LOOP
    FETCH sys_cur INTO table_str;
    EXIT WHEN sys_cur%NOTFOUND;
    BEGIN
      sql_str := 'select count(1) from NB_MOB_PAGE_' || table_str ||
                 ' where isp_id = ' || isp_id ||
                 ' and tm_base between :start_time and :end_time';
                 
      --DBMS_OUTPUT.PUT_LINE(sql_str);
      EXECUTE IMMEDIATE sql_str INTO task_count USING start_time, end_time;
      DBMS_OUTPUT.PUT_LINE(task_count);
      
      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(sqlerrm);
    END;
  END LOOP;

  CLOSE sys_cur;
  
  /*
  seqList := '';
  for i in 1 .. seqCount loop
    open seq_cur for 'select SEQ_NB_TRAN_ID_' || tableStr || '.nextval from dual';
    fetch seq_cur into seq;
    seqList := seqList || ',' || to_char(seq);
    close seq_cur;
  end loop;
  if length(seqList) > 0 then
     seqList := substr(seqList, 2);
  end if;*/
END task_summary;


/

