create PROCEDURE          "IN_TOP_CDN" authid current_user
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(4000);
begin
  create_procedure_log('in_top_cdn','in_top_cdn begin','test');
  --首先删除指定日期内的所有生成数据，防止重复生成数据
  sqlStr:='delete from nb_top_cdn where tm_day=:st or tm_day<sysdate-20';
  execute immediate sqlStr using trunc(sysdate-1,'dd');
  commit;
  --循环，查寻出所有的表
  for tableName in(SELECT substr(t.table_name,9) as name FROM user_tables t where t.table_name like 'NB_TRAN_%') loop
  begin
  --判断一下是否有cdn
     for task in(SELECT id as id FROM nb_m_task t where  t.owner_id=tableName.name) loop
        sqlStr:='update nb_m_task set cdn = 1 where id = :t1 and
                  (select count(distinct dest_ip) from nb_tran_'||tableName.name||' t
                  where t.tm_base between :sT and :eT
                     and task_id =:t2) > 1';
         execute immediate sqlStr using task.id,trunc(sysdate-1,'dd'),trunc(sysdate,'dd'),task.id;
         commit;
        
         sqlStr:='update nb_m_task set cdn=-1 where cdn = 0 and id=:t1';
         execute immediate sqlStr using task.id;
         commit;
    end loop;
    --对有多主机的任务进行cdn数据分析
    sqlStr:='insert into nb_top_cdn
       select trunc(sysdate - 1 ,''dd''),
            task_id,city_id,decode(dest_ip,null,''DNS is wrong'',dest_ip),
            round(performance,0),round(decode(point_total,0,0,point_succ / point_total),2) available,
            point_total, point_succ
       from (
         select t.task_id,
             t.city_id,
             t.dest_ip,
             sum(t.point_total) point_total,
             sum(case when t.error_code > 600000 then 0 else t.point_total end) point_succ,
             avg(case when t.error_code > 600000 then null else t.ts_total end) performance
         from nb_tran_'||tableName.name||' t
         where dest_ip is not null and is_noise = 0 and t.tm_base between :sT and :eT and t.task_id in(select id from nb_m_task where cdn = 1 and task_option != ''p'' and status = 1)
         group by task_id,t.dest_ip,t.city_id
       )';
     execute immediate sqlStr using trunc(sysdate-1,'dd'),trunc(sysdate,'dd');
     commit;

     --如果创建序列失败，则显示出失败代码
    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || 'tableName:'||tableName.name;
        --DBMS_OUTPUT.PUT_LINE(v_error_desc);
        create_procedure_log('in_top_cdn',v_error_desc,sqlcode);
    end;
    end loop;

    create_procedure_log('in_top_cdn','in_top_cdn end','test');

end in_top_cdn;


/

