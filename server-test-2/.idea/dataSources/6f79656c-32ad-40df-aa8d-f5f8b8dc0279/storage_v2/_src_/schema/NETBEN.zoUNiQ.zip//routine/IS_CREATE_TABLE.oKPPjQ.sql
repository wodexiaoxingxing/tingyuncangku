create function is_create_table(table_name varchar2) return integer is
begin
  execute immediate 'select count(1) from '|| table_name || ' where rownum = 0' ;
  return 0;
exception
  when others then
    return -1;
end is_create_table;


/

