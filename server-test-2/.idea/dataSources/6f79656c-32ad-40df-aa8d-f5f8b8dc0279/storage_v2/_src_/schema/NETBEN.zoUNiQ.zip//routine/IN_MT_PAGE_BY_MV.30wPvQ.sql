create procedure in_mt_page_by_mv(sd date,days number) authid current_user is
   SUFF_ERROR EXCEPTION;
   inSqlStr varchar2(4000);
   sqlStr varchar2(4000);
   startDate date;
   calcDate date;
   suff number;
   v_s number;
   inDays number;
begin
if sd is null or days is null then
  startDate:=trunc(sysdate-1,'dd');
  inDays := 1;
else
  startDate:=trunc(sd,'dd');
  inDays:=days;
end if;
  create_procedure_log('in_mt_page_by_mv','begin','run');
  for tab in(SELECT t.table_name as name FROM user_tables t where t.table_name like 'MT_PAGE_'||'%') loop
    begin
      calcDate:=startDate;
      begin
        suff:=substr(tab.name,9);
        -- if suff!=22 then raise SUFF_ERROR; end if;
      exception when others then
        --如果后缀不是数字则不是正式表，不处理直接exit
        --dbms_output.put_line(tab.name);
        raise SUFF_ERROR;
      end;
      --先申明插入数据的sql
      inSqlStr:='insert into mt_page_'||suff||
           '(task_id,page_seq,city_id,isp_id,net_speed_id,error_code,is_noise,dest_ip,os_ver_id,bs_id,bs_ver_id,tm_base,
           cont_err_total,cont_ele_total,point_total,byte_total,rate_download,ts_total,ts_page_base,ts_dns,ts_connect,
           ts_ssl,ts_redirect,ts_request,ts_first_packet,ts_client,ts_contents,ts_user,ts_network,byte_page_base,
           rate_download_page_base,num_first_elem,byte_first,num_host,ts_dns_total,num_connect,ts_connect_total,num_dom,
           num_elem_lazy,ts_first_paint,ts_full_screen,ts_unload_start,ts_unload_end,ts_dom_load,ts_dom_interact,
           ts_dom_cont_load_start,ts_dom_cont_load_end,ts_dom_complete,ts_load_evt_start,ts_load_evt_end)
          select task_id,page_seq,city_id,isp_id,net_speed_id,error_code,is_noise,dest_ip,os_ver_id,bs_id,bs_ver_id,tm_hour8,
          cont_err_total,cont_ele_total,point_total,byte_total,rate_download,ts_total,ts_page_base,ts_dns,ts_connect,
           ts_ssl,ts_redirect,ts_request,ts_first_packet,ts_client,ts_contents,ts_user,ts_network,byte_page_base,
            rate_download_page_base,num_first_elem,byte_first,num_host,ts_dns_total,num_connect,ts_connect_total,num_dom,
            num_elem_lazy,ts_first_paint,ts_full_screen,ts_unload_start,ts_unload_end,ts_dom_load,ts_dom_interact,
            ts_dom_cont_load_start,ts_dom_cont_load_end,ts_dom_complete,ts_load_evt_start,ts_load_evt_end
        from mv_page_'||suff||'
        where tm_hour8 = :sd
            ';
     --按8个小时为一次执行体来执行
     for i in 1..inDays loop
       for j in 1..3 loop
          sqlStr:='select count(*)  from nb_log_mvtomt where table_str=:ts and calc_date=:st';
          execute immediate sqlStr into v_s using suff,calcDate;
          if v_s < 1 then
            create_procedure_log('in_mt_page_by_mv','tableName:'||tab.name||','||'calcDate:'||to_char(calcDate,'yyyy-mm-dd hh24:mi'),'run');
            -- 执行生成数据语句
            execute immediate inSqlStr using calcDate;
            commit;
            -- 记录日志，可在出问题后重新执行时进行判断
            begin
              sqlStr:='insert into nb_log_mvtomt(table_str,calc_date,ctime) values(:ts,:st,:ct)';
              execute immediate sqlStr using suff,calcDate,sysdate;
              commit;
            exception when others then
              create_procedure_log('in_mt_page_by_mv','tableName:'||tab.name||',calcDate:'||to_char(calcDate,'yyyy-mm-dd hh24:mi')||','||sqlerrm,'error');
            end;
          end if;
          calcDate:=calcDate+8/24;
       end loop;
    end loop;

    exception when SUFF_ERROR then
      --如果是后缀不正确则不处理
      null;
    when others then
      -- dbms_output.put_line('tableName'||tab.name||','||sqlerrm);
      create_procedure_log('in_mt_page_by_mv','tableName:'||tab.name||',calcDate:'||to_char(calcDate,'yyyy-mm-dd hh24:mi')||','||sqlerrm,'error');
    end;
  end loop;
  create_procedure_log('in_mt_page_by_mv','end','run');
end in_mt_page_by_mv;


/

