create PROCEDURE          "ALTER_ETD_ADD_FIELD" 
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(4000);
  v_s number;
begin
  for tableName in(select t.table_name as name from user_tables t where t.table_name like 'NB_ETD_%') loop
  begin
    DBMS_OUTPUT.PUT_LINE('alter ' ||tableName.Name);
      select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='PROBE_IP';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add PROBE_IP NUMBER';
        execute   immediate   sqlStr ;
      end if;

      select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='URL_IP';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add URL_IP NUMBER';
        execute   immediate   sqlStr ;
      end if;

    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlStr);
        create_procedure_log('alter_stream_add_field',v_error_desc,sqlcode);
  end;
  end loop;
  for tableName in(select t.table_name as name from user_tables t where t.table_name like 'NB_ETT_%') loop
  begin
    DBMS_OUTPUT.PUT_LINE('alter ' ||tableName.Name);
      select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='PROBE_IP';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add PROBE_IP NUMBER';
        execute   immediate   sqlStr ;
      end if;

    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlStr);
        create_procedure_log('alter_stream_add_field',v_error_desc,sqlcode);
  end;
  end loop;
end alter_etd_add_field;


/

