create PROCEDURE          "TEST_BATCHINSERT_SPEEDLOG" (batchCount in integer) is
   sqlStr varchar2(4000);
   commitCount integer := 0;
   outputCount integer := 0;
begin
   DBMS_OUTPUT.PUT_LINE('start batch insert to NB_M_DDC_SPEED_LOG at ' || sysdate);
   for i in 1 .. batchCount loop
      sqlStr := 'INSERT INTO NB_M_DDC_SPEED_LOG(TM_BASE,TASK_ID,CITY_ID,ISP_ID,SPEED_ID,HOST_ID,PROBE_IP,ERROR_CODE,SPEED_DL,SPEED_DL_AVG) 
                        VALUES (sysdate,' || 
                        floor(dbms_random.value(100, 10000)) || ',' || 
                        floor(dbms_random.value(481101, 489901)) || ',' || 
                        floor(dbms_random.value(1, 100)) || ',' ||
                        floor(dbms_random.value(1, 6)) || ',' ||
                        floor(dbms_random.value(100000, 999999)) || ',' ||
                        'IP2LONG(''192.168.1.' || floor(dbms_random.value(1, 255)) || '''),' ||
                        floor(dbms_random.value(0, 7000000)) || ',' ||
                        floor(dbms_random.value(1000, 10000000)) || ',' ||
                        floor(dbms_random.value(1000, 10000000)) ||
                        ')';
       commitCount := commitCount + 1;
       execute immediate sqlStr;
       if commitCount > 10000 then
           commit;
           commitCount := 0;
       end if;
       
       if outputCount > 10000 then
           --DBMS_OUTPUT.PUT_LINE('processing ' || i || ' inserted ..');
           outputCount := 0;
       end if;
   end loop;
   commit;
   DBMS_OUTPUT.PUT_LINE('finished batch insert to NB_M_DDC_SPEED_LOG at ' || sysdate);
end TEST_BATCHINSERT_SPEEDLOG;


/

