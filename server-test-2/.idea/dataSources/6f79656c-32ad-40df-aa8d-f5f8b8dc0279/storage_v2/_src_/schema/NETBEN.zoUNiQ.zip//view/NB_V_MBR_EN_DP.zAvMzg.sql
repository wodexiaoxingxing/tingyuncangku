create view NB_V_MBR_EN_DP as
select MAX(ID) AS ID, MEMBER_ID, IMPCI_ID, TRUNC(ctime, 'DD') AS CDATE, SUM(DATA_POINTS) AS DATA_POINTS
    from NB_m_en_datas
    where ctime < TRUNC(SYSDATE, 'DD')
    GROUP BY TRUNC(ctime, 'DD'), MEMBER_ID, IMPCI_ID


/

