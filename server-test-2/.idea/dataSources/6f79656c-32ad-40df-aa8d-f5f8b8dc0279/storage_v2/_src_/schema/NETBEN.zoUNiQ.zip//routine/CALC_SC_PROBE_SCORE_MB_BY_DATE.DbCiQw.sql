create procedure calc_sc_probe_score_mb_by_date(cDate date) is
  currDate date;
  sqlStr   varchar2(4000);
  s int;
begin
  --此程序一天只能执行一次,在生成积分时只处理绑定过的客户端帐号
  --结转和保底计算时都记在前一天
  currDate:=cDate;

  create_procedure_log('calc_sc_probe_score_mb_by_date','begin','run');
  --  删除节点积分可能重复的数据
  /*
  sqlStr := 'delete from nb_sc_probe_day where calc_date = :cdate ';
  execute immediate sqlStr  using trunc(currDate - 1);
  commit;
  sqlStr := 'delete from nb_sc_member_day where calc_date = :cdate and calc_way = 1';
  execute immediate sqlStr  using trunc(currDate - 1);
  commit;
  create_procedure_log('calc_sc_probe_score_mb_by_date','1.1 删除节点积分可能重复的数据完成','run');
  */


  -- 1 生成截转积分
  -- 1.1 首先生成临时数据

  sqlStr:='truncate table nb_sc_account_day_max';
  execute immediate sqlStr;
  sqlStr:='insert into nb_sc_account_day_max(id,account_id,score_balance,data_points_balance)
              select id,account_id,score_balance,data_points_balance
                from nb_sc_account_day
                where id in
                  (select max(id) from nb_sc_account_day group by account_id)';
  execute immediate sqlStr;
  commit;
  create_procedure_log('calc_sc_probe_score_mb_by_date','1.1 生成用于截转积分的临时数据完成','run');

  -- 1.2 生成客户端帐号的结转积分数据
  sqlStr:='insert into nb_sc_member_day(calc_date,calc_way,member_id,account_id,score,data_points,ctime)
            select :cd,4,m.id,m.account_id,v.score_balance,v.data_points_total,sysdate
              from nb_v_score_balance_max v,nb_m_member m
             where v.member_id = m.id and m.account_id>0 and v.reason != ''IC''
          ';
 execute immediate sqlStr using trunc(currDate -1);
 commit;
 create_procedure_log('calc_sc_probe_score_mb_by_date','1.2 生成客户端帐号的结转积分数据完成','run');

  -- 1.3 生成会员帐号的截转积分数据
  sqlStr:='insert into nb_sc_account_day(id,calc_date,calc_way,account_id,score,data_points,score_balance,data_points_balance,note,ctime)
            select seq_nb_sc_account_day.nextval,:cd,4,p.account_id,p.sc,p.dp,
                   case when a.score_balance is null then p.sc else p.sc + a.score_balance end,
                   case when a.data_points_balance is null then p.dp else p.dp + a.data_points_balance end,
                   p.mid,sysdate
              from (select m.account_id,sum(v.score_balance) sc,sum(v.data_points_total) dp,
                    to_char(substr(wm_concat(m.username),0,3900)) mid
                      from nb_v_score_balance_max v,nb_m_member m
                      where v.member_id = m.id and m.account_id > 0 and v.reason !=''IC''
                      group by m.account_id )p,
                   nb_sc_account_day_max a
             where p.account_id = a.account_id(+) ';
 execute immediate sqlStr using trunc(currDate -1);
 commit;
 create_procedure_log('calc_sc_probe_score_mb_by_date','1.3 生成会员帐号的截转积分数据完成','run');
 -- 1.4 最后将原积分表中的积分清空并制标记
 sqlStr:='insert into nb_m_score_balance(id,member_id,cdate,score,score_balance,data_points,data_points_total,reason)
           select score_bal_id_seq.Nextval,v.member_id,:cd,0,0,0,0,''IC''
              from nb_v_score_balance_max v,nb_m_member m
             where v.member_id = m.id and m.account_id > 0 and v.reason !=''IC''';
 execute immediate sqlStr using trunc(currDate -1);
 commit;
 create_procedure_log('calc_sc_probe_score_mb_by_date','1.4 生成原积分表中的积分清空并制标记完成','run');

  -- 2 生成由直付会员奖金转换成的结转积分
  -- 2.1 生成临时数据
  sqlStr:='truncate table nb_sc_account_day_max';
  execute immediate sqlStr;
  sqlStr:='insert into nb_sc_account_day_max(id,account_id,score_balance,data_points_balance)
              select id,account_id,score_balance,data_points_balance
                from nb_sc_account_day
                where id in
                  (select max(id) from nb_sc_account_day group by account_id)';
  execute immediate sqlStr;
  commit;
  create_procedure_log('calc_sc_probe_score_mb_by_date','2.1 生成用于直付会员奖金转换成截转积分的临时数据完成','run');

  -- 2.2 生成直付会员奖金转换成的客户端帐号的结转积分数据
  sqlStr:='insert into nb_sc_member_day(calc_date,calc_way,member_id,account_id,score,data_points,ctime)
            select :cd,4,m.id,m.account_id,v.balance*600,0,sysdate
              from (select member_id,balance,reason from nb_m_dpmbr_cash_balance where id in
                        (select max(id) from nb_m_dpmbr_cash_balance group by member_id)) v,nb_m_member m
             where v.member_id = m.id and m.account_id>0 and v.reason != ''IC''';
 execute immediate sqlStr using trunc(currDate -1);
 commit;
 create_procedure_log('calc_sc_probe_score_mb_by_date','2.2 生成用于直付会员奖金转换成结转积分的客户端帐号的数据完成','run');

  -- 2.3 生成直付会员奖金转换成的会员帐号的截转积分数据
  sqlStr:='insert into nb_sc_account_day(id,calc_date,calc_way,account_id,score,data_points,score_balance,data_points_balance,note,ctime)
            select seq_nb_sc_account_day.nextval,:cd,4,p.account_id,p.sc,0,
                   case when a.score_balance is null then p.sc else p.sc + a.score_balance end,
                   a.data_points_balance,
                   p.mid,sysdate
              from (select m.account_id,sum(v.balance * 600) sc,
                         to_char(substr(wm_concat(m.username),0,3900)) mid
                      from (select member_id,balance,reason from nb_m_dpmbr_cash_balance where id in
                              (select max(id) from nb_m_dpmbr_cash_balance group by member_id)) v,
                            nb_m_member m
                      where v.member_id = m.id and m.account_id > 0 and v.reason !=''IC''
                      group by m.account_id )p,
                   nb_sc_account_day_max a
             where p.account_id = a.account_id(+) ';
 execute immediate sqlStr using trunc(currDate -1);
 commit;
 create_procedure_log('calc_sc_probe_score_mb_by_date','2.3 生成用于直付会员奖金转换成结转积分的会员帐号的截转积分数据完成','run');
 -- 2.4 最后将原直付会员现金清空并制标记
 sqlStr:='insert into nb_m_dpmbr_cash_balance(id,member_id,ctime,money,balance,reason,creator_id,month)
           select dpmbr_cash_bal_id_seq.Nextval,v.member_id,:cd,0,0,''IC'',0,trunc(:cd,''mm'')
              from (select member_id,balance,reason from nb_m_dpmbr_cash_balance where id in
                     (select max(id) from nb_m_dpmbr_cash_balance group by member_id)) v,
                  nb_m_member m
             where v.member_id = m.id and m.account_id > 0 and v.reason !=''IC''';
 execute immediate sqlStr using trunc(currDate -1),trunc(currDate -1);
 commit;
 create_procedure_log('calc_sc_probe_score_mb_by_date','2.4 原直付会员现金清空并制标记完成','run');

 -- 3 生成由推荐奖金转换成的结转积分
  -- 3.1 生成临时数据
  sqlStr:='truncate table nb_sc_account_day_max';
  execute immediate sqlStr;
  sqlStr:='insert into nb_sc_account_day_max(id,account_id,score_balance,data_points_balance)
              select id,account_id,score_balance,data_points_balance
                from nb_sc_account_day
                where id in
                  (select max(id) from nb_sc_account_day group by account_id)';
  execute immediate sqlStr;
  commit;
  create_procedure_log('calc_sc_probe_score_mb_by_date','3.1 生成用于直付会员奖金转换成截转积分的临时数据完成','run');

  -- 3.2 生成推荐奖金转换成的客户端帐号的结转积分数据
  sqlStr:='insert into nb_sc_member_day(calc_date,calc_way,member_id,account_id,score,data_points,ctime)
            select :cd,4,m.id,m.account_id,v.balance*600,0,sysdate
              from (select member_id,balance,reason from nb_m_member_cash_balance where id in
                        (select max(id) from nb_m_member_cash_balance group by member_id)) v,nb_m_member m
             where v.member_id = m.id and m.account_id>0 and v.reason != ''IC''';
 execute immediate sqlStr using trunc(currDate -1);
 commit;
 create_procedure_log('calc_sc_probe_score_mb_by_date','3.2 生成推荐奖金转换成的客户端帐号的结转积分数据完成','run');

  -- 3.3 生成推荐奖金转换成的会员帐号的截转积分数据
  sqlStr:='insert into nb_sc_account_day(id,calc_date,calc_way,account_id,score,data_points,score_balance,data_points_balance,note,ctime)
            select seq_nb_sc_account_day.nextval,:cd,4,p.account_id,p.sc,0,
                   case when a.score_balance is null then p.sc else p.sc + a.score_balance end,
                   a.data_points_balance,
                   p.mid,sysdate
              from (select m.account_id,sum(v.balance * 600) sc,
                         to_char(substr(wm_concat(m.username),0,3900)) mid
                      from (select member_id,balance,reason from nb_m_member_cash_balance where id in
                              (select max(id) from nb_m_member_cash_balance group by member_id)) v,
                            nb_m_member m
                      where v.member_id = m.id and m.account_id > 0 and v.reason !=''IC''
                      group by m.account_id )p,
                   nb_sc_account_day_max a
             where p.account_id = a.account_id(+) ';
 execute immediate sqlStr using trunc(currDate -1);
 commit;
 create_procedure_log('calc_sc_probe_score_mb_by_date','3.3 生成推荐奖金转换成的会员帐号的截转积分数据完成','run');
 -- 3.4 最后将原直付会员推荐现金清空并制标记
 sqlStr:='insert into nb_m_member_cash_balance(id,member_id,ctime,money,balance,reason,creator_id,dpmbr_bal_month)
           select mbr_cash_bal_id_seq.Nextval,v.member_id,:cd,0,0,''IC'',0,trunc(sysdate,''mm'')
              from (select member_id,balance,reason from nb_m_member_cash_balance where id in
                     (select max(id) from nb_m_member_cash_balance group by member_id)) v,
                  nb_m_member m
             where v.member_id = m.id and m.account_id > 0 and v.reason !=''IC''';
 execute immediate sqlStr using trunc(currDate -1);
 commit;
 create_procedure_log('calc_sc_probe_score_mb_by_date','3.4 原直付会员推荐现金清空并制标记完成','run');


  -- 4.1 删除在线时长可能重复的数据
  sqlStr := 'delete from nb_sc_probe_online where calc_date = :cdate';
  execute immediate sqlStr  using trunc(currDate - 1);
  commit;
  create_procedure_log('calc_sc_probe_score_mb_by_date','4.1 删除在线时长可能重复的数据完成','run');

  -- 4.2 生成pc客户端每天在线时长
  sqlStr := 'insert into nb_sc_probe_online(calc_date,member_id,probe_id,online_time,ctime)
               select trunc(time_stamp),member_id,host_id,count(1)*10,sysdate
                 from nb_m_proberuntime_log
                 where time_stamp >= :st and time_stamp < :et
                 group by trunc(time_stamp),member_id,host_id
             ';
  execute immediate sqlStr  using trunc(currDate - 1), trunc(currDate);
  commit;
  create_procedure_log('calc_sc_probe_score_mb_by_date','4.2 生成PC节点在线时长数据完成','run');

  -- 4.3 生成手机每天在线时长
  sqlStr:='insert into nb_sc_probe_online(calc_date,member_id,probe_id,online_time,ctime)
               select trunc(time_stamp),member_id,host_id,count(1)*10,sysdate
                 from nb_m_proberuntime_log_mobile
                 where time_stamp >= :st and time_stamp < :et and member_id > 0
                 group by trunc(time_stamp),member_id,host_id
             ';
  execute immediate sqlStr  using trunc(currDate - 1), trunc(currDate);
  commit;
  create_procedure_log('calc_sc_probe_score_mb_by_date','4.3 生成mobile节点在线时长数据完成','run');

  -- 4.4 生成PC节点每天积分（只能算一天,只算有积分的）
  sqlStr := 'insert into nb_sc_probe_day(calc_date,member_id,probe_id,score,data_points,ctime,account_id,online_time)
               select :cd,h.member_id,h.probe_id,h.sc,h.dp,sysdate,m.account_id,o.ot
                 from (select member_id, probe_id, sum(score) sc, sum(data_points) dp
                         from nb_sc_probe_hour
                         where calc_date >= :sd1
                           and calc_date < :ed1
                         group by  member_id, probe_id) h,
                      (select member_id,probe_id,online_time ot
                         from nb_sc_probe_online
                         where calc_date >= :st2 and calc_date < :ed2)o,
                      (select id,account_id from nb_m_member where account_id >0) m
                 where h.member_id = m.id and h.member_id=o.member_id(+) and h.probe_id=o.probe_id(+)';
  execute immediate sqlStr  using trunc(currDate - 1),trunc(currDate - 1),trunc(currDate),trunc(currDate - 1),trunc(currDate);
  commit;
  create_procedure_log('calc_sc_probe_score_mb_by_date','4.4 生成每日PC节点积分数据完成','run');
  
  -- 4.5 生成mobile节点每天积分（只能算一天,只算有积分的）
  sqlStr := 'insert into nb_sc_probe_day(calc_date,member_id,probe_id,app_flows,app_wifi_flows,ctime,account_id,online_time,score,net_type)
               select :cd,h.member_id,h.host_id,h.app_flows,h.app_wifi_flows,sysdate,m.account_id,h.online_time,
                  round(app_wifi_flows/1024/1024*3 + app_flows/1024/1024*12),1
                 from (select member_id, host_id ,sum(app_flows) app_flows,sum(app_wifi_flows) app_wifi_flows,sum(online_time) online_time
                         from nb_m_probe_summary_hour
                         where calc_date >= :sd1 and calc_date < :ed1
                           and member_id > 0
                         group by member_id, host_id) h,
                      (select id,account_id from nb_m_member where account_id >0) m
                 where h.member_id = m.id';
  execute immediate sqlStr  using trunc(currDate - 1),trunc(currDate - 1),trunc(currDate);
  commit;
  create_procedure_log('calc_sc_probe_score_mb_by_date','4.5 生成每日mobile节点积分数据完成','run');


  -- 4.6 追加只有在线时长，但没有产生积分的数据
  sqlStr := 'insert into nb_sc_probe_day(calc_date,member_id,probe_id,score,data_points,ctime,account_id,online_time)
              select :cd , o.member_id,o.probe_id,0,0,sysdate,m.account_id,o.ot
                 from (select member_id, probe_id, ot
                   from (select member_id, probe_id, online_time ot
                           from nb_sc_probe_online
                          where calc_date>= :sd1
                            and calc_date < :ed1) a
                      where not exists (select 1 from
                                  (select probe_id from nb_sc_probe_day where calc_date = :sd2) b
                                      where a.probe_id = b.probe_id)
                    ) o,
                   (select id, account_id from nb_m_member where account_id > 0) m
             where o.member_id = m.id';
  execute immediate sqlStr  using trunc(currDate - 1),trunc(currDate - 1),trunc(currDate),trunc(currDate - 1);
  commit;
  create_procedure_log('calc_sc_probe_score_mb_by_date','4.6 生成没有积分只有在线节点的数据完成','run');

  -- 4.7 生成客户端帐号每天积分
  sqlStr := 'insert into nb_sc_member_day(calc_date,calc_way,member_id,account_id,score,data_points,ctime,online_time,app_flows,app_wifi_flows)
               select cd,1,member_id,account_id,sc,dp,sysdate,ot,app_flows,app_wifi_flows
                 from(select trunc(calc_date) cd,member_id,account_id,sum(score) sc,sum(data_points) dp,sum(online_time) ot
                    ,sum(app_flows) app_flows,sum(app_wifi_flows) app_wifi_flows
                         from nb_sc_probe_day
                         where calc_date >= :sd
                           and calc_date < :ed
                         group by trunc(calc_date),member_id,account_id
                      )
             ';
  execute immediate sqlStr  using trunc(currDate - 1), trunc(currDate);
  commit;
  create_procedure_log('calc_sc_probe_score_mb_by_date','4.7 生成每日客户端帐号积分数据完成','run');

  -- 5 生成会员任务积分
  -- 5.1 首先生成临时数据,取最大ID,因为会员数量有限，无需优化
  sqlStr:='truncate table nb_sc_account_day_max';
  execute immediate sqlStr;
  sqlStr:='insert into nb_sc_account_day_max(id,account_id,score_balance,data_points_balance,app_flows_balance,app_wifi_flows_balance)
              select id,account_id,score_balance,data_points_balance,app_flows_balance,app_wifi_flows_balance
                from nb_sc_account_day
                where id in
                  (select max(id) from nb_sc_account_day group by account_id)';
  execute immediate sqlStr;
  commit;
  create_procedure_log('calc_sc_probe_score_mb_by_date','5.1 生成用于任务积分的临时数据完成','run');

  -- 5.2 生成当天的会员任务积分数据
  sqlStr:='insert into nb_sc_account_day(id,calc_date,calc_way,account_id,score,data_points,score_balance,data_points_balance,ctime
                           ,app_flows,app_wifi_flows,app_flows_balance,app_wifi_flows_balance)
            select seq_nb_sc_account_day.nextval,p.cd,1,p.account_id,p.sc,p.dp,
                   case when a.score_balance is null then p.sc else p.sc + a.score_balance end,
                   case when a.data_points_balance is null then p.dp else p.dp + a.data_points_balance end,
                   sysdate,
                   p.app_flows,p.app_wifi_flows,
                   case when a.app_flows_balance is null then p.app_flows else p.app_flows + a.app_flows_balance end,
                   case when a.app_wifi_flows_balance is null then p.app_wifi_flows else p.app_wifi_flows + a.app_wifi_flows_balance end
              from (select trunc(calc_date) cd,
                           account_id,
                           sum(data_points) dp,
                           sum(score) sc,
                           sum(app_flows) app_flows,
                           sum(app_wifi_flows) app_wifi_flows
                      from nb_sc_member_day
                     where calc_date >=:sd and calc_date <:ed
                       and calc_way = 1
                     group by trunc(calc_date), account_id) p,
                   nb_sc_account_day_max a
             where p.account_id = a.account_id(+)';
 execute immediate sqlStr using trunc(currDate - 1),trunc(currDate);
 commit;
 create_procedure_log('calc_sc_probe_score_mb_by_date','5.2 生成会员任务积分数据完成','run');

 -- 6 生成会员推荐积分
 -- 6.1 首先生成临时数据
  sqlStr:='truncate table nb_sc_account_day_max';
  execute immediate sqlStr;
  sqlStr:='insert into nb_sc_account_day_max(id,account_id,score_balance,data_points_balance,app_flows_balance,app_wifi_flows_balance)
              select id,account_id,score_balance,data_points_balance,app_flows_balance,app_wifi_flows_balance
                from nb_sc_account_day
                where id in
                  (select max(id) from nb_sc_account_day group by account_id)';
  execute immediate sqlStr;
  commit;
  create_procedure_log('calc_sc_probe_score_mb_by_date','6.1 生成用于推荐积分的临时数据完成','run');

  -- 6.2 然后生成当天的推荐积分数据
  sqlStr:='insert into nb_sc_account_day(id,calc_date,calc_way,account_id,score,data_points,score_balance,data_points_balance,ctime
                                ,app_flows,app_wifi_flows,app_flows_balance,app_wifi_flows_balance)
            select seq_nb_sc_account_day.nextval,p.cd,2,p.account_id,p.sc,0,
                   case when a.score_balance is null then p.sc else p.sc + a.score_balance end,
                   case when a.data_points_balance is null then 0 else a.data_points_balance end,
                   sysdate,0,0,
                   case when a.app_flows_balance is null then 0 else a.app_flows_balance end,
                   case when a.app_wifi_flows_balance is null then 0 else a.app_wifi_flows_balance end
              from (select pd.cd,m.recomm_id as account_id,round(sum(pd.sc)*0.1)sc
                      from
                         (select trunc(calc_date) cd,
                            account_id,
                            sum(score) sc
                           from nb_sc_probe_day
                           where calc_date = :sd
                           group by trunc(calc_date), account_id) pd,
                          (select id,recomm_id from nb_m_member_account where recomm_id >0) m
                       where pd.account_id = m.id
                       group by pd.cd,m.recomm_id )p,
                   nb_sc_account_day_max a
             where p.account_id = a.account_id(+)';
 execute immediate sqlStr using trunc(currDate - 1);
 commit;
 create_procedure_log('calc_sc_probe_score_mb_by_date','6.2 生成推荐积分数据完成','run');


 -- 7 生成保底积分(每个月的第一天生成）
 if (to_char(currDate,'dd')=1) then
   -- 7.1 首先生成临时数据
  sqlStr:='truncate table nb_sc_account_day_max';
  execute immediate sqlStr;
  sqlStr:='insert into nb_sc_account_day_max(id,account_id,score_balance,data_points_balance,app_flows_balance,app_wifi_flows_balance)
              select id,account_id,score_balance,data_points_balance,app_flows_balance,app_wifi_flows_balance
                from nb_sc_account_day
                where id in
                  (select max(id) from nb_sc_account_day group by account_id)';
  execute immediate sqlStr;
  commit;
  create_procedure_log('calc_sc_probe_score_mb_by_date','7.1 生成用于保底积分的临时数据完成','run');

  -- 7.2 生成每个客户端帐号的保底积分,时间记在前一天

   sqlStr:='insert into nb_sc_member_day(calc_date,calc_way,member_id,account_id,score,data_points,ctime)
        select :cd,6,id,account_id,bd,0,sysdate
            from(
              select id,account_id,case when mbr_type=15 then 600*80 when mbr_type = 16 then 600*120 when mbr_type = 17 then 600*200 end bd
                from (select id,account_id,mbr_type from nb_m_member where account_id >0 and mbr_type in (15, 16, 17))
                ) ';
  execute immediate sqlStr using trunc(currDate-1);
  commit;
  /* 原设计
  sqlStr:='insert into nb_sc_member_day(calc_date,calc_way,member_id,account_id,score,data_points,ctime)
        select :cd,6,id,account_id,case when bd > 0 then round(bd) else 0 end bd,0,sysdate
            from(
              select m.id,m.account_id,sc,case when m.mbr_type=15 then 600*50*olt-sc when m.mbr_type = 16 then 600*100*olt-sc when m.mbr_type = 17 then 600*150*olt-sc end bd
                from (select member_id, sum(score) sc
                        from nb_sc_probe_day
                       where calc_date >= :sd1 and calc_date < :ed1
                       group by member_id) d,
                     (select member_id,case when olt>1 then 1 else olt end olt from
                       (select member_id,sum(online_time)/ ((trunc(sysdate ,''mm'')-trunc(sysdate -27,''mm''))*1440) olt
                         from nb_sc_probe_online
                         where calc_date >= :sd2 and calc_date < :ed2
                         group by member_id)) ol,
                     (select id,account_id,mbr_type from nb_m_member where account_id >0) m
                 where m.mbr_type in (15, 16, 17) and d.member_id = ol.member_id and d.member_id = m.id)';*/

  create_procedure_log('calc_sc_probe_score_mb_by_date','7.2 生成每个客户端帐号的保底积分完成','run');

  -- 7.3 生成会员帐号的保底积分
  sqlStr:='insert into nb_sc_account_day(id,calc_date,calc_way,account_id,score,data_points,score_balance,data_points_balance,note,ctime
             ,app_flows,app_wifi_flows,app_flows_balance,app_wifi_flows_balance)
            select seq_nb_sc_account_day.nextval,:cd,6,p.account_id,p.sc,0,
                   case when a.score_balance is null then p.sc else p.sc + a.score_balance end,
                   case when a.data_points_balance is null then 0 else  a.data_points_balance end,
                   p.mid,sysdate,0,0,
                   case when a.app_flows_balance is null then 0 else a.app_flows_balance end,
                   case when a.app_wifi_flows_balance is null then 0 else a.app_wifi_flows_balance end
              from (select d.account_id,sum(score) sc ,to_char(substr(wm_concat(m.username),0,3900)) mid
                      from nb_sc_member_day d,nb_m_member m
                      where calc_date >= :sd1 and calc_date<:ed1 and calc_way =6 and d.member_id = m.id
                      group by d.account_id)p,
                   nb_sc_account_day_max a
             where p.account_id = a.account_id(+)';
 execute immediate sqlStr using trunc(currDate-1),trunc(currDate-1),trunc(currDate);
 commit;
 create_procedure_log('calc_sc_probe_score_mb_by_date','7.3 生成会员帐号的保底积分完成','run');
 end if;

 -- 最后判断数据收集是否正常入库
 select case when max(ctime)<(trunc(sysdate) + 0.6) then 1 else 0 end into s from nb_sc_probe_hour where calc_date > trunc(sysdate -1) and calc_date < trunc(sysdate);
  if s<1 then
   create_procedure_log('calc_sc_probe_score_mb_by_date','错误：数据收集未按时入库,晚入库','error');
 end if;

 select count(*) into s from (select trunc(calc_date,'hh') from nb_sc_probe_hour where calc_date > trunc(sysdate -1) and calc_date < trunc(sysdate) group by trunc(calc_date,'hh'));
  if s<23 then
   create_procedure_log('calc_sc_probe_score_mb_by_date','错误：数据收集未按时入库,少入库','error');
 end if;

 --结束

 create_procedure_log('calc_sc_probe_score_mb_by_date','end','run');
 exception when  others then
   create_procedure_log('calc_sc_probe_score_mb_by_date',sqlerrm,'error');
end calc_sc_probe_score_mb_by_date;


/

