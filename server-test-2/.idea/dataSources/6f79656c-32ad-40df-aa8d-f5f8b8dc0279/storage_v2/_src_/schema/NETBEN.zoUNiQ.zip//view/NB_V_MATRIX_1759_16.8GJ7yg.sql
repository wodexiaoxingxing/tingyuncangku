create view NB_V_MATRIX_1759_16 as
SELECT t.task_id, t.city_id,
	SUM(CASE WHEN t.ping_error = 10 OR t.ping_packet_lost = 10000 THEN 0 ELSE t.ts_ping_avg END) AS perf,
	COUNT(CASE WHEN t.ping_error = 10 OR t.ping_packet_lost = 10000 THEN NULL ELSE 1 END) AS succ,
	SUM(CASE WHEN t.ping_error = 10 THEN 0 ELSE t.ping_packet_lost END) AS loss,
	COUNT(CASE WHEN t.ping_error = 10 THEN NULL ELSE 1 END) AS total
FROM NB_TRAN_1759 t
WHERE t.task_id IN (3000) AND t.tm_base > sysdate - interval '60' MINUTE AND t.city_id IN (481101,481201,481301,481401,481501,482101,482201,482301,483101,483201,483301,483401,483501,483601,483701,484101,484201,484301,484401,484501,484601,485001,485101,485201,485301,485401,486101,486201,486301,486401,486501) AND t.is_noise = 0
GROUP BY t.task_id, t.city_id
ORDER BY t.task_id, t.city_id


/

