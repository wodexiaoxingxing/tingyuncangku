create PROCEDURE          "ADD_PAGE_TRANIDX" authid current_user
is
  sqlStr  varchar2(4000);
  errorDesc varchar2(4000);
  v_s number;
begin
for item in (select substr(t.table_name, 9) as name from user_tables t where t.table_name like 'NB_PAGE_%') loop
    begin
    select count(*) into v_s from user_indexes t where t.index_name = 'IN_PAGE_TRANID_'||item.name;
    if (v_s=0) then
         create_procedure_log('add_page_tranidx',item.name,'message');
         sqlStr:='create index IN_PAGE_TRANID_'||item.name||' on NB_PAGE_'||item.name||' (TRAN_ID) tableSpace NETBEN_IDX';
       	 execute   immediate   sqlStr;
    end if;
    exception when  others then
         errorDesc := 'Error Code:'|| sqlcode || '  table ' || item.name;
          --DBMS_OUTPUT.PUT_LINE(errorDesc);
          create_procedure_log('add_page_tranidx',errorDesc,'error');
    end;
  end loop;
end add_page_tranidx;


/

