create procedure createStreamTable(tableStr IN varchar2) authid current_user is
    sqlStr varchar2(4000);
begin
    --创建Stream sequence
    sqlStr := 'create sequence SEQ_NB_STREAM_ID_' || tableStr || '
      minvalue 1
      maxvalue 9999999999999999999999999
      start with 1
      increment by 1
      cache 500';
    execute immediate sqlStr;

    --创建Stream 表
    sqlStr := 'create table NB_STREAM_' || tableStr || '
  (
  ID                      NUMBER not null,
  TASK_ID                 NUMBER,
  CITY_ID                 NUMBER,
  ISP_ID                  NUMBER,
  NET_SPEED_ID            NUMBER,
  TM_BASE                 DATE,
  TM_DAY                  DATE,
  TM_HOUR                 DATE,
  TM_HALF_HOUR            DATE,
  PROBE_IP                NUMBER,
  MEMBER_ID               NUMBER,
  ERROR_CODE              NUMBER,
  ERROR_PATH              VARCHAR2(256),
  POINT_TOTAL             NUMBER default 1,
  BYTE_TOTAL              NUMBER,
  RATE_DOWNLOAD           NUMBER,
  RATE_FRAME_LOSS         NUMBER,
  DNS_SERVER              VARCHAR2(128),
  DNS_SERVER_IP           NUMBER,
  DEST_IP                 VARCHAR2(39),
  DEST_CITY_ID            NUMBER,
  DEST_ISP_ID             NUMBER,
  PING_RESULT             VARCHAR2(512),
  TRACERT_RESULT          VARCHAR2(512),
  NSLOOKUP_RESULT         VARCHAR2(512),
  METATAGS                VARCHAR2(4000),
  ELEMENTS_RESULT         VARCHAR2(512),
  HTTP_SERVER             VARCHAR2(256),
  HTTP_VIA                VARCHAR2(256),
  PROTOCOL_TYPE           VARCHAR2(256),
  RECE_PACKAGE            NUMBER,
  LOSE_PACKAGE            NUMBER,
  URL_SOURCE              VARCHAR2(2048),
  URL_DEST                VARCHAR2(2048),
  REBUFFER_DESC           VARCHAR2(1024),
  BUFFER_COUNT            NUMBER,
  TS_TOTAL                NUMBER,
  TS_SSL                  NUMBER,
  TS_DNS                  NUMBER,
  TS_CONNECT              NUMBER,
  TS_REDIRECT             NUMBER,
  TS_BUFFER               NUMBER,
  TS_REBUFFER             NUMBER,
  TS_FIRST_PLAY           NUMBER,
  TS_PLAY                 NUMBER,
  TS_FULL                 NUMBER,
  TS_USER                 NUMBER,
  TS_CONNECT_TCP          NUMBER,
  TS_FIRST_PACKET         NUMBER,
  TS_CONTENTS             NUMBER,
  TS_CAP_PLAYER           NUMBER,
  VERSION_ID              INTEGER,
  OS_VER_ID               INTEGER,
  BS_ID                   INTEGER,
  BS_VER_ID               INTEGER,
  FLASH_VER               VARCHAR2(32),
  PERCENT_CPU             NUMBER,
  PERCENT_CPU_TASK        NUMBER,
  PERCENT_MEM             NUMBER,
  PERCENT_MEM_TASK        NUMBER,
  RATE_AVG                NUMBER,
  BAND_WIDTH              NUMBER,
  FILE_SIZE               NUMBER,
  DURATION                NUMBER,
  DATA_RATE               INTEGER,
  PLAY_IN_5S              INTEGER,
  FLUENCY                 INTEGER,
  OS_ID                   INTEGER,
  HW_ID                   INTEGER,
  MB_TYPE                 INTEGER,
  BB_ID                   INTEGER,
  WIFI                    INTEGER,
  SCREEN_WIDTH            INTEGER,
  SCREEN_HEIGHT           INTEGER,
  IMEI                    INTEGER,
  MOBILE_SIGNAL           INTEGER,
  IS_NOISE                NUMBER default 0,

  UVMOS                   NUMBER,  -- U-vMOS会话得分
  VIDEO_QUALITY           NUMBER,  -- 视频质量会话得分
  VIEWING_EXPERIENCE      NUMBER,  -- 观看体验会话得分
  INTERACTIVE_EXPERIENCE  NUMBER,  -- 交互体验会话得分

  PCAP_PATH               VARCHAR2(512),
      COUNTRY_ID INTEGER,
      REGION_ID INTEGER,
      DISTINCT_ID INTEGER,
      DEST_COUNTRY_ID INTEGER,
      DEST_REGION_ID INTEGER,
      IS_CDN_COVER INTEGER,
      IS_ISP_COVER INTEGER,
    http_port            varchar(8),
  HTTP_LOCAL_PORT                VARCHAR2(8),
      TRACE_ID            VARCHAR2(128),
      FEEDBACK            INTEGER
  ) pctfree 0
  tablespace NETBEN';
    execute immediate sqlStr;

    sqlStr := 'alter table NB_STREAM_' || tableStr || '
    add constraint PK_NB_STREAM_' || tableStr ||
              ' primary key (ID)
      using index
      tablespace NETBEN';
    execute immediate sqlStr;

    -- NB_STREAM 索引
    sqlStr := 'create index IN_STREAM_PERF_' || tableStr || ' on NB_STREAM_' ||
              tableStr || ' (TM_BASE,TASK_ID) tableSpace NETBEN_IDX_NEW';
    execute immediate sqlStr;

    --创建Stream Rate表
    sqlStr := 'create table NB_RATE_' || tableStr || '
  (
    STREAM_ID NUMBER not null,
    S1 NUMBER,
  S2 NUMBER,
  S3 NUMBER,
  S4 NUMBER,
  S5 NUMBER,
  S6 NUMBER,
  S7 NUMBER,
  S8 NUMBER,
  S9 NUMBER,
  S10 NUMBER,
  S11 NUMBER,
  S12 NUMBER,
  S13 NUMBER,
  S14 NUMBER,
  S15 NUMBER,
  S16 NUMBER,
  S17 NUMBER,
  S18 NUMBER,
  S19 NUMBER,
  S20 NUMBER,
  S21 NUMBER,
  S22 NUMBER,
  S23 NUMBER,
  S24 NUMBER,
  S25 NUMBER,
  S26 NUMBER,
  S27 NUMBER,
  S28 NUMBER,
  S29 NUMBER,
  S30 NUMBER,
  S31 NUMBER,
  S32 NUMBER,
  S33 NUMBER,
  S34 NUMBER,
  S35 NUMBER,
  S36 NUMBER,
  S37 NUMBER,
  S38 NUMBER,
  S39 NUMBER,
  S40 NUMBER,
  S41 NUMBER,
  S42 NUMBER,
  S43 NUMBER,
  S44 NUMBER,
  S45 NUMBER,
  S46 NUMBER,
  S47 NUMBER,
  S48 NUMBER,
  S49 NUMBER,
  S50 NUMBER,
  S51 NUMBER,
  S52 NUMBER,
  S53 NUMBER,
  S54 NUMBER,
  S55 NUMBER,
  S56 NUMBER,
  S57 NUMBER,
  S58 NUMBER,
  S59 NUMBER,
  S60 NUMBER
  ) pctfree 0
  tablespace NETBEN';
    execute immediate sqlStr;

    sqlStr := 'create index PK_NB_RATE_' || tableStr || ' on NB_RATE_' ||
              tableStr || ' (STREAM_ID) tablespace NETBEN_IDX_NEW';
    execute immediate sqlStr;

    --创建NB_STREAM_UVMOS表
    sqlStr := 'create table NB_STREAM_UVMOS_' || tableStr || '
  (
      STREAM_ID                NUMBER not null,
      UVMOS                    VARCHAR2(4000),  -- U-vMOS即时得分
      VIDEO_QUALITY            VARCHAR2(4000),  -- 视频质量即时得分
      VIEWING_EXPERIENCE       VARCHAR2(4000),  -- 观看体验即时得分
      INTERACTIVE_EXPERIENCE   VARCHAR2(4000)   -- 交互体验即时得分
  ) pctfree 0
  tablespace NETBEN';
    execute immediate sqlStr;

    sqlStr := 'create index PK_NB_STREAM_UVMOS_' || tableStr || ' on NB_STREAM_UVMOS_' ||
              tableStr || ' (STREAM_ID) tablespace NETBEN_IDX_NEW';
    execute immediate sqlStr;

    -- 创建NB_STREAM_RATE表
    sqlStr := 'create table NB_STREAM_RATE_' || tableStr || '
  (
    STREAM_ID                     NUMBER not null,
    BIT_RATE_FLOW_STR             VARCHAR2(4000), -- 比特率
    FRAME_LOSS_RATE_FLOW_STR      VARCHAR2(4000)  -- 丢帧率
  ) pctfree 0
  tablespace NETBEN';
    execute immediate sqlStr;

    sqlStr := 'create index PK_NB_STREAM_RATE_' || tableStr || ' on NB_STREAM_RATE_' ||
              tableStr || ' (STREAM_ID) tablespace NETBEN_IDX_NEW';
    execute immediate sqlStr;

end createStreamTable;
/

