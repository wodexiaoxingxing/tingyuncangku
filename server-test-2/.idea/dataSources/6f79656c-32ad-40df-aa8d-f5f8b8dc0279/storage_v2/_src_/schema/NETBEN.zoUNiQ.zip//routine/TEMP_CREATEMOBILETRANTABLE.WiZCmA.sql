create procedure TEMP_createMobileTranTable(
       tableStr IN varchar2
) authid current_user
is
sqlStr  varchar2(4000);
begin
    --????Tran sequence 
    sqlStr:='create sequence SEQ_NB_MOB_TRAN_ID_'||tableStr||'
			minvalue 1
			maxvalue 9999999999999999999999999
			start with 1
			increment by 1
			cache 500';
    -- execute   immediate   sqlStr;
    
        --????TRAN
    sqlStr:='create table NB_MOB_TRAN_'||tableStr||'
		(
		  ID              NUMBER not null,
		  TASK_ID         NUMBER,
		  CITY_ID         NUMBER,
		  ISP_ID          NUMBER,
		  NET_SPEED_ID    NUMBER,
		  TM_BASE         DATE,
		  PROBE_IP        NUMBER,
		  ERROR_CODE      NUMBER,
		  CONT_ERR_TOTAL  NUMBER,
		  POINT_TOTAL     NUMBER default 1,
		  ERROR_PAGE_SEQ  NUMBER,	
		  PAGE_TOTAL      NUMBER,	
		  BYTE_TOTAL      NUMBER,	
		  DNS_SERVER	 VARCHAR2(128),	
		  DNS_SERVER_IP	 NUMBER,
		  DEST_IP         VARCHAR2(39),
		  TS_TOTAL        NUMBER,
		  TS_NETWORK      NUMBER,
		  MEMBER_ID		 INTEGER,
		  OS_VER_ID 	INTEGER,
		  BS_ID			INTEGER,
		  BS_VER_ID		INTEGER,
		  HW_ID		INTEGER,
			MOBILE_SIGNAL	INTEGER,
			SCREEN_WIDTH	INTEGER,
			SCREEN_HEIGHT	INTEGER,
			longitude	NUMBER,
			latitude	NUMBER,
		  IS_NOISE		  INTEGER		  
		) pctfree 0';  
    execute   immediate   sqlStr;
    --???? 
    sqlStr:='alter table NB_MOB_TRAN_'||tableStr||'
		  add constraint PK_NB_MOB_TRAN_'||tableStr||' primary key (ID)
		  using index ';
    execute   immediate   sqlStr;
    --????
	sqlStr:='create index IN_MOB_TRAN_PERF_'||tableStr||' on NB_MOB_TRAN_'||tableStr||' (TASK_ID,TM_BASE, CITY_ID,  ISP_ID) tableSpace NETBEN_IND';
	execute   immediate   sqlStr;

		--Tran log
    sqlStr:='create materialized view log on NB_MOB_TRAN_'||tableStr||' with rowid,
			sequence (task_id,
					city_id,
					isp_id,
					net_speed_id,
					error_code,
					is_noise,
					tm_base,
					point_total,
					ts_total,
					os_ver_id,
					bs_id,
					bs_ver_id,
					hw_id) including new values';
    execute   immediate   sqlStr;
            
    --Tran???????? '' => '||chr(39)||'
    sqlStr:='create materialized view MV_MOB_TRAN_'||tableStr||'
		refresh fast
		start with sysdate next sysdate + 4/24 
		as
    	(select task_id,
		    city_id,
		    isp_id,
		    net_speed_id,
	      error_code,
          is_noise,
          (tm_base - mod(to_number(to_char(tm_base, '||chr(39)||'hh24'||chr(39)||')) + 8, 8) / 24) as tm_hour8,
          os_ver_id,
          bs_id,
          bs_ver_id,
      hw_id,
          count(*) as c1,
          count(point_total) as c2,
          count(ts_total) as c3,
        sum(point_total) as point_total,
        avg(ts_total) as ts_tota
    from NB_MOB_TRAN_'||tableStr||' 
    group by task_id,
      city_id,
      isp_id,
      net_speed_id,
      error_code,
      is_noise,
      (tm_base - mod(to_number(to_char(tm_base, '||chr(39)||'hh24'||chr(39)||')) + 8, 8) / 24),
            os_ver_id,
            bs_id,
            bs_ver_id,
      hw_id)';

    execute   immediate   sqlStr;    
    --????
  sqlStr:='create index IN_MV_MOB_TRAN_PERF_'||tableStr||' on MV_MOB_TRAN_'||tableStr||' (TASK_ID,TM_HOUR8, CITY_ID, ISP_ID) tableSpace NETBEN_IND';  
    execute   immediate   sqlStr;
END TEMP_createMobileTranTable;


/

