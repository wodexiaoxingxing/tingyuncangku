create procedure createElemContentTable(tableStr in varchar2) authid current_user is
  sqlStr       varchar2(8000);
  errorDesc    varchar2(4000);
  ---------------- 主变量 ---------------------------------------------------------------------------
  createDate   date := sysdate;
  orderNum     number;
  ecPart       number;
  rangeDate    varchar2(128);
  partname1    varchar2(128);
  ee_partname1 varchar2(128);
  rangedate1   varchar2(128);
  partname2    varchar2(128);
  ee_partname2 varchar2(128);
  rangedate2   varchar2(128);
  partname3    varchar2(128);
  ee_partname3 varchar2(128);
  rangedate3   varchar2(128);

  v_order      number;
  v_range_date date;
  v_partname1  varchar2(128);
  v_rangedate1 varchar2(128);
  v_partname2  varchar2(128);
  v_rangedate2 varchar2(128);
  v_partname3  varchar2(128);
  v_rangedate3 varchar2(128);

  --------------- 临时变量----------------------------------------------------------------------------
  s            number;

begin

  create_procedure_log('createElemContentTable', 'create table:nb_ec_' || tableStr, 'run');

  -- 判断是否该tableStr合法
  select count(*) into s from nb_m_agreement where table_str = tableStr;
  if s = 0 and tableStr <> 'UNKNOWN' then
    create_procedure_log('createElemContentTable', 'tableStr:' || tableStr || '不存在', 'warning');
    return;
  end if;

  -- 判断是否指定表已经建立
  select count(*) into s from user_tables where table_name = 'NB_EC_' || tableStr;
  if s > 0 then
    create_procedure_log('createElemContentTable', 'table:nb_ec_' || tableStr || '已经存在', 'warning');
    --return;
  end if;

  -- 创建nb_ec及nb_ee
  -- 首先计算出ec的分区名称及值范围
  select order_num, to_char(sunday, 'yyyy-mm-dd'),to_char(sunday,'yymmdd')
    into orderNum, rangeDate,ecPart
    from nb_part_calendar t
   where t.sunday = (select trunc(createDate + 8 - to_char(createDate, 'd'), 'd') from dual);

  partname1    := 'PART_EC_' || tableStr || '_' || ecPart;
  ee_partname1 := 'PART_EE_' || tableStr || '_' || orderNum;
  rangedate1   := 'to_date(''' || rangeDate || ''',''yyyy-mm-dd'')';
  DBMS_OUTPUT.PUT_LINE(rangedate1);

  select order_num, to_char(sunday, 'yyyy-mm-dd'),to_char(sunday,'yymmdd')
    into orderNum, rangeDate,ecPart
    from nb_part_calendar t
   where t.sunday = (select trunc(createDate + 15 - to_char(createDate, 'd'), 'd') from dual);

  partname2    := 'PART_EC_' || tableStr || '_' || ecPart;
  ee_partname2 := 'PART_EE_' || tableStr || '_' || orderNum;
  rangedate2   := 'to_date(''' || rangeDate || ''',''yyyy-mm-dd'')';

  select order_num, to_char(sunday, 'yyyy-mm-dd'),to_char(sunday,'yymmdd')
    into orderNum, rangeDate,ecPart
    from nb_part_calendar t
   where t.sunday = (select trunc(createDate + 22 - to_char(createDate, 'd'), 'd') from dual);

  partname3    := 'PART_EC_' || tableStr || '_' || ecPart;
  ee_partname3 := 'PART_EE_' || tableStr || '_' || orderNum;
  rangedate3   := 'to_date(''' || rangeDate || ''',''yyyy-mm-dd'')';

  sqlStr := 'create table NB_EC_' || tableStr || '
  (
	URL_ID                   NUMBER,
	PAGE_ID                  NUMBER,
	ELEMENT_SEQ              NUMBER,
	TASK_ID                  NUMBER,
	TM_BASE                  DATE,
	URL_HOST                 VARCHAR2(64),
	URL_PROTOCOL             VARCHAR2(16),
	URL_PORT                 VARCHAR2(8),
	URL_PATH                 VARCHAR2(4000),
	DNS_SERVER               VARCHAR2(128),
	ELEMENT_TYPE             VARCHAR2(32),
	HTTP_STAT_CODE           NUMBER,
	HTTP_HEAD_SIZE           NUMBER,
	HTTP_BODY_COMP           VARCHAR2(2),
	HTTP_SERVER              VARCHAR2(256),
	HTTP_VIA                 VARCHAR2(256),
	HTTP_REQ_HEADER          VARCHAR2(4000),
	HTTP_RESP_HEADER         VARCHAR2(4000),
	SOCKET_ID                NUMBER,
	DNS_RESOLVED             NUMBER,
	CONN_ESTABLISHED         NUMBER,
	REQUESTED                NUMBER,
	APPLICATION_ID           NUMBER,
	APPLICATION_INSTANCE_ID  NUMBER,
	TRACE_GUID               VARCHAR2(512),
	ACTION_NAME              VARCHAR2(512),
    ERROR_LOG                VARCHAR2(1024)
  ) pctfree 0
    partition by range (TM_BASE)(
                  partition ' || partname1 || ' values less than (' || rangedate1 || '),
                  partition ' || partname2 || ' values less than (' || rangedate2 || '),
                  partition ' || partname3 || ' values less than (' || rangedate3 || ')) tablespace NETBEN_IND';
  execute immediate sqlStr;

  -- 元素索引 tm_base,url_id,error_code
  sqlStr := 'create index IDX_EC_PID_' || tableStr || ' on NB_EC_' || tableStr || ' (PAGE_ID) local tableSpace  NETBEN_IND nologging';
  execute immediate sqlStr;

  sqlStr := 'create table NB_EE_' || tableStr || '
    (
      URL_ID           NUMBER,
      PAGE_ID          NUMBER,
      PAGE_SEQ         INTEGER,
      TASK_ID          NUMBER,
      CITY_ID          NUMBER,
      ISP_ID           NUMBER,
      NET_SPEED_ID     NUMBER,
      TM_BASE          DATE,
      DOMAIN_ID        NUMBER,
      ELEM_TYPE_ID     NUMBER,
      OS_VER_ID        INTEGER,
      BS_ID            INTEGER,
      BS_VER_ID        INTEGER,
      PROBE_IP         NUMBER,
      MEMBER_ID        INTEGER,
      ELEMENT_SEQ      NUMBER,
      RECORD_TYPE      CHAR(1),
      ERROR_CODE       NUMBER,
      REDIRECT_TOTAL   NUMBER,
      URL_IP           NUMBER,
      BYTE_TOTAL       NUMBER,
      TS_START_OFFSET  NUMBER,
      TS_DNS           NUMBER,
      TS_CONNECT       NUMBER,
      TS_SSL           NUMBER,
      TS_REDIRECT      NUMBER,
      TS_REQUEST       NUMBER,
      TS_FIRST_PACKET  NUMBER,
      TS_REMAIN_PACKET NUMBER,
      TS_ELEMENT       NUMBER,
      TS_CLOSE         NUMBER,
      TS_BLOCK         NUMBER,
      BYTE_SENT        NUMBER,
      RATE_DOWNLOAD    NUMBER,
      RATE_UPLOAD      NUMBER,
      POINT_TOTAL      NUMBER,
      QUIC_VERSION     VARCHAR2(10),
      PROTOCOL_VERSION VARCHAR2(10),
      NUM_QUIC_HANDSHAKE NUMBER,
      TS_QUIC_FIRST_100 NUMBER,
      QUIC_PACKET_LOST  NUMBER,
      QUIC_CONNECTION_ID VARCHAR2(30),
      DEST_IP_VERSION INTEGER,
    ) pctfree 0

    partition by range (TM_BASE)(
                  partition ' || ee_partname1 || ' values less than (' || rangedate1 || '),
                  partition ' || ee_partname2 || ' values less than (' || rangedate2 || '),
                  partition ' || ee_partname3 || ' values less than (' || rangedate3 || ')) tablespace NETBEN_NEW';
  execute immediate sqlStr;

  -- 元素索引 tm_base,url_id,error_code
  sqlStr := 'create index IDX_EE_UID_' || tableStr || ' on NB_EE_' || tableStr || ' (TM_BASE,URL_ID,ERROR_CODE) local compress 2 tableSpace NETBEN_IND nologging';
  execute immediate sqlStr;

  -- 域名索引 tm_base,domain_id,error_code
  sqlStr := 'create index IDX_EE_DID_' || tableStr || ' on NB_EE_' || tableStr || ' (TM_BASE,DOMAIN_ID,ERROR_CODE) local compress 2 tableSpace  NETBEN_IND  nologging';
  execute immediate sqlStr;

  -- 类型索引 tm_base,type_id,error_code
  sqlStr := 'create index IDX_EE_TID_' || tableStr || ' on NB_EE_' || tableStr || ' (TM_BASE,ELEM_TYPE_ID,ERROR_CODE) local compress 2 tableSpace  NETBEN_IND nologging';
  execute immediate sqlStr;


  -- 创建NB_EL_XXX表（用于向下兼容，一旦新元素架构发生性能问题，可以快速在线回滚）
  -- 首先计算出el的分区名称及值范围
  select order_num, sunday
    into v_order, v_range_date
    from nb_part_calendar t
   where t.sunday = (select trunc(sysdate + 8 - to_char(sysdate, 'd'), 'd') from dual);

  v_partname1  := 'PART_EL_URL_' || tableStr || '_' || v_order;
  v_rangedate1 := 'to_date(' || chr(39) || to_char(v_range_date, 'yyyy-mm-dd') || chr(39) || ',' || chr(39) || 'yyyy-mm-dd' || chr(39) || ')';

  select order_num, sunday
    into v_order, v_range_date
    from nb_part_calendar t
   where t.sunday = (select trunc(sysdate + 15 - to_char(sysdate, 'd'), 'd') from dual);

  v_partname2  := 'PART_EL_URL_' || tableStr || '_' || v_order;
  v_rangedate2 := 'to_date(' || chr(39) || to_char(v_range_date, 'yyyy-mm-dd') || chr(39) || ',' || chr(39) || 'yyyy-mm-dd' || chr(39) || ')';

  select order_num, sunday
    into v_order, v_range_date
    from nb_part_calendar t
   where t.sunday = (select trunc(sysdate + 22 - to_char(sysdate, 'd'), 'd') from dual);

  v_partname3  := 'PART_EL_URL_' || tableStr || '_' || v_order;
  v_rangedate3 := 'to_date(' || chr(39) || to_char(v_range_date, 'yyyy-mm-dd') || chr(39) || ',' || chr(39) || 'yyyy-mm-dd' || chr(39) || ')';
  sqlStr       := 'create table NB_EL_URL_' || tableStr || '
    (
      ID      NUMBER,
      URL     VARCHAR2(4000),
      CTIME   DATE
    ) pctfree 0
    partition by range (CTIME)(
                  partition ' || v_partname1 || ' values less than (' || v_rangedate1 || '),
                  partition ' || v_partname2 || ' values less than (' || v_rangedate2 || '),
                  partition ' || v_partname3 || ' values less than (' || v_rangedate3 || ')) tableSpace NETBEN_NEW';
  execute immediate sqlStr;

  --索引
  sqlStr := 'create index IDX_NB_EL_URL_' || tableStr || ' on NB_EL_URL_' || tableStr || ' (ID) local tableSpace  NETBEN_IND nologging';
  execute immediate sqlStr;

  -- 创建NB_el_task_XXX表（用于向下兼容，一旦新元素架构发生性能问题，可以快速在线回滚）
  -- 首先计算出elem的分区名称及值范围
  select order_num, sunday
    into v_order, v_range_date
    from nb_part_calendar t
   where t.sunday = (select trunc(sysdate + 8 - to_char(sysdate, 'd'), 'd') from dual);

  v_partname1  := 'PART_ELT_URL_' || tableStr || '_' || v_order;
  v_rangedate1 := 'to_date(' || chr(39) || to_char(v_range_date, 'yyyy-mm-dd') || chr(39) || ',' || chr(39) || 'yyyy-mm-dd' || chr(39) || ')';

  select order_num, sunday
    into v_order, v_range_date
    from nb_part_calendar t
   where t.sunday = (select trunc(sysdate + 15 - to_char(sysdate, 'd'), 'd') from dual);

  v_partname2  := 'PART_ELT_URL_' || tableStr || '_' || v_order;
  v_rangedate2 := 'to_date(' || chr(39) || to_char(v_range_date, 'yyyy-mm-dd') || chr(39) || ',' || chr(39) || 'yyyy-mm-dd' || chr(39) || ')';

  select order_num, sunday
    into v_order, v_range_date
    from nb_part_calendar t
   where t.sunday = (select trunc(sysdate + 22 - to_char(sysdate, 'd'), 'd') from dual);

  v_partname3  := 'PART_ELT_URL_' || tableStr || '_' || v_order;
  v_rangedate3 := 'to_date(' || chr(39) || to_char(v_range_date, 'yyyy-mm-dd') || chr(39) || ',' || chr(39) || 'yyyy-mm-dd' || chr(39) || ')';
  sqlStr       := 'create table NB_ELT_URL_' || tableStr || '
    (
      TASK_ID       NUMBER,
      ID            NUMBER,
      ELEM_TYPE_ID  NUMBER,
      CTIME         DATE
    ) pctfree 0
    partition by range (CTIME)(
                  partition ' || v_partname1 || ' values less than (' || v_rangedate1 || '),
                  partition ' || v_partname2 || ' values less than (' || v_rangedate2 || '),
                  partition ' || v_partname3 || ' values less than (' || v_rangedate3 || ')) tableSpace NETBEN_NEW';
  execute immediate sqlStr;

  --索引
  sqlStr := 'create index IDX_NB_ELT_URL_' || tableStr || ' on NB_ELT_URL_' || tableStr || ' (TASK_ID,ID) compress 2 local tableSpace  NETBEN_IND nologging';
  execute immediate sqlStr;

exception
  when others then
    errorDesc := 'Error :' || sqlerrm || '  tableStr:' || tableStr;
    --DBMS_OUTPUT.PUT_LINE(v_error_desc);
    create_procedure_log('createElemContentTable', errorDesc, 'error');

end createElemContentTable;
/

