create procedure createMobilePageTable(tableStr IN varchar2)
    authid current_user is
    sqlStr varchar2(4000);
begin
    --创建Tran sequence
    sqlStr := 'create sequence SEQ_NB_MOB_TRAN_ID_' || tableStr || '
      minvalue 1
      maxvalue 9999999999999999999999999
      start with 1
      increment by 1
      cache 500';
    execute   immediate   sqlStr;

    --创建TRAN
    sqlStr := 'create table NB_MOB_TRAN_' || tableStr || '
  (
    ID              NUMBER not null,
    TASK_ID         NUMBER,
    CITY_ID         NUMBER,
    ISP_ID          NUMBER,
    NET_SPEED_ID    NUMBER,
    TM_BASE         DATE,
    PROBE_IP        NUMBER,
    ERROR_CODE      NUMBER,
    CONT_ERR_TOTAL  NUMBER,
    POINT_TOTAL     NUMBER default 1,
    ERROR_PAGE_SEQ  NUMBER,
    PAGE_TOTAL      NUMBER,
    BYTE_TOTAL      NUMBER,
    DNS_SERVER      VARCHAR2(128),
    DNS_SERVER_IP   NUMBER,
    DEST_IP         VARCHAR2(39),
    DEST_CITY_ID    NUMBER,
    DEST_ISP_ID     NUMBER,
    TS_TOTAL        NUMBER,
    TS_NETWORK      NUMBER,
    MEMBER_ID       INTEGER,
    OS_VER_ID       INTEGER,
    BS_ID           INTEGER,
    BS_VER_ID       INTEGER,
    HW_ID           INTEGER,
    MOBILE_SIGNAL   INTEGER,
    SCREEN_WIDTH    INTEGER,
    SCREEN_HEIGHT   INTEGER,
    LONGITUDE       NUMBER,
    LATITUDE        NUMBER,
    IS_NOISE        INTEGER,
  COUNTRY_ID      INTEGER,
  REGION_ID       INTEGER,
  DISTINCT_ID     INTEGER,
  DEST_COUNTRY_ID INTEGER,
  DEST_REGION_ID  INTEGER,
  IS_CDN_COVER    INTEGER,
  IS_ISP_COVER    INTEGER,
  CLIENT_VERSION  VARCHAR2(128),
  DEST_IP_VERSION INTEGER,
      TRACE_ID            VARCHAR2(128),
      FEEDBACK            INTEGER
  ) pctfree 0';
    execute immediate sqlStr;
    --主键
    sqlStr := 'alter table NB_MOB_TRAN_' || tableStr || '
      add constraint PK_NB_MOB_TRAN_' || tableStr ||
              ' primary key (ID)
        using index ';
    execute immediate sqlStr;
    --索引
    sqlStr := 'create index IN_MOB_TRAN_PERF_' || tableStr ||
              ' on NB_MOB_TRAN_' || tableStr ||
              ' (TM_BASE,TASK_ID) tableSpace NETBEN_IDX_NEW';
    execute immediate sqlStr;

    --创建Page sequence
    sqlStr := 'create sequence SEQ_NB_MOB_PAGE_ID_' || tableStr || '
      minvalue 1
      maxvalue 9999999999999999999999999
      start with 1
      increment by 1
      cache 500';
    execute immediate sqlStr;

    --创建page
    sqlStr := 'create table NB_MOB_PAGE_' || tableStr || '
  (
    ID                       NUMBER not null,
    TRAN_ID                  NUMBER,
    TASK_ID                  NUMBER,
    CITY_ID                  NUMBER,
    ISP_ID                   NUMBER,
    NET_SPEED_ID             NUMBER,
    TM_BASE                  DATE,
    PROBE_IP                 NUMBER,
    PAGE_SEQ                 NUMBER,
    ERROR_CODE               NUMBER,
    ERROR_PATH               VARCHAR2(256),
    CONT_ERR_TOTAL           NUMBER,
    CONT_ELE_TOTAL           NUMBER,
    REDIRECT_TOTAL           NUMBER,
    POINT_TOTAL              NUMBER default 1,
    BYTE_TOTAL               NUMBER,
    RATE_DOWNLOAD            NUMBER,
    BYTE_PAGE_BASE           NUMBER,
    RATE_DOWNLOAD_PAGE_BASE  NUMBER,
    DNS_SERVER               VARCHAR2(128),
    DNS_SERVER_IP            NUMBER,
    DEST_IP                  VARCHAR2(39),
    DEST_CITY_ID             NUMBER,
    DEST_ISP_ID              NUMBER,
    PING_RESULT              VARCHAR2(512),
    TRACERT_RESULT           VARCHAR2(512),
    NSLOOKUP_RESULT          VARCHAR2(512),
    SCRIPT_ERROR_RESULT      VARCHAR2(2000),
    HTTP_SERVER              VARCHAR2(256),
    HTTP_VIA                 VARCHAR2(256),
    TS_TOTAL                 NUMBER,
    TS_PAGE_BASE             NUMBER,
    TS_DNS                   NUMBER,
    TS_CONNECT               NUMBER,
    TS_REDIRECT              NUMBER,
    TS_REQUEST               NUMBER,
    TS_FIRST_PACKET          NUMBER,
    TS_CLIENT                NUMBER,
    TS_CONTENTS              NUMBER,
    TS_EXTRA_DATA            NUMBER,
    TS_OPEN_PAGE             NUMBER,
    TS_NETWORK               NUMBER,
    TS_SSL                   NUMBER,
    NUM_HOST                 NUMBER,
    TS_DNS_TOTAL             NUMBER,
    NUM_CONNECT              NUMBER,
    TS_CONNECT_TOTAL         NUMBER,
    NUM_DOM                  NUMBER,
    NUM_IFRAME               NUMBER,
    NUM_NO_COMPRESS_ELEM     NUMBER,
    NUM_NO_EXPIRE_ELEM       NUMBER,
    NUM_NO_ETAG_ELEM         NUMBER,
    MEMBER_ID                INTEGER,
    OS_VER_ID                INTEGER,
    BS_ID                    INTEGER,
    BS_VER_ID                INTEGER,
    HW_ID                    INTEGER,
    LOG_MSG_RESULT           VARCHAR2(512),
    NUM_ELEM_LAZY            INTEGER,
    TS_USER                  INTEGER,
    TS_FIRST_PAINT           INTEGER,
    TS_FULL_SCREEN           INTEGER,
    TS_UNLOAD_START          INTEGER,
    TS_UNLOAD_END            INTEGER,
    TS_DOM_LOAD              INTEGER,
    TS_DOM_INTERACT          INTEGER,
    TS_DOM_CONT_LOAD_START   INTEGER,
    TS_DOM_CONT_LOAD_END     INTEGER,
    TS_DOM_COMPLETE          INTEGER,
    TS_LOAD_EVT_START        INTEGER,
    TS_LOAD_EVT_END          INTEGER,
    SRC_PATH                 VARCHAR2(512), -- 页面源码路径
    BITRATE_TREND_RESULT     VARCHAR2(512), -- 流量变化趋势
    TS_DNS_PROJ              INTEGER,       -- DNS投影时间
    TS_CONNECT_PROJ          INTEGER,       -- 建连投影时间
    TS_FIRST_PACKET_PROJ     INTEGER,       -- 首包投影时间
    MOBILE_SIGNAL            INTEGER,
    SCREEN_WIDTH             INTEGER,
    SCREEN_HEIGHT            INTEGER,
    LONGITUDE                NUMBER,
    LATITUDE                 NUMBER,
    IS_NOISE                 INTEGER,
    OS                       VARCHAR2(128),
    BS_VER                   VARCHAR2(128),
    HW                       VARCHAR2(128),
  COUNTRY_ID               INTEGER,
  REGION_ID                INTEGER,
  DISTINCT_ID              INTEGER,
  DEST_COUNTRY_ID          INTEGER,
  DEST_REGION_ID           INTEGER,
  IS_CDN_COVER             INTEGER,
  IS_ISP_COVER             INTEGER,
  CLIENT_VERSION           VARCHAR2(128),
  DEST_IP_VERSION          INTEGER,
    http_port                varchar(8),
  HTTP_LOCAL_PORT                VARCHAR2(8),
      TRACE_ID            VARCHAR2(128),
      FEEDBACK            INTEGER
  ) pctfree 0';
    execute immediate sqlStr;
    --主键
    sqlStr := 'alter table NB_MOB_PAGE_' || tableStr || '
      add constraint PK_NB_MOB_PAGE_' || tableStr ||
              ' primary key (ID)
        using index ';
    execute immediate sqlStr;
    --索引
    sqlStr := 'create index IN_MOB_PAGE_TRANID_' || tableStr ||
              ' on NB_MOB_PAGE_' || tableStr ||
              ' (TRAN_ID) tableSpace NETBEN_IDX_NEW';
    execute immediate sqlStr;
    sqlStr := 'create index IN_MOB_PAGE_PERF_' || tableStr ||
              ' on NB_MOB_PAGE_' || tableStr ||
              ' (TM_BASE,TASK_ID) tableSpace NETBEN_IDX_NEW';
    execute immediate sqlStr;
END createMobilePageTable;
/

