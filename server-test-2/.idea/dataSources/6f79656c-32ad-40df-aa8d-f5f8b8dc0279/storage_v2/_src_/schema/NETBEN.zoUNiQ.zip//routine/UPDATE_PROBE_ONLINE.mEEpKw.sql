create procedure UPDATE_PROBE_ONLINE is
begin
  --首先处理pc相关的私有节点
  delete from NB_M_PROBE_ONLINE ro
   where (ro.probe_id, ro.agreement_id, ro.member_id) in
         (select t.probe_id, t.agreement_id, t.member_id
            from NB_M_PROBE_ONLINE t,
                 (select distinct pl.host_id,
                                  a.id,
                                  m.id member_id,
                                  m.username,
                                  pl.ipaddress
                    from nb_m_member_agreement ma,
                         nb_m_agreement        a,
                         nb_m_member           m,
                         nb_m_proberuntime_log pl
                   where ma.member_id = m.id
                     and ma.agreement_id = a.id
                     and pl.member_id = m.id
                     and m.mbr_type = 4
                     and pl.member_type = 4
                     and pl.time_stamp > sysdate - 1
                  union
                  select distinct pl.host_id,
                                  ag.agreement_id,
                                  m.id member_id,
                                  m.username,
                                  pl.ipaddress
                    from nb_m_probgrp          g,
                         nb_m_grp_mbr          gm,
                         nb_m_member           m,
                         nb_v_agree_probgrp    ag,
                         nb_m_proberuntime_log pl
                   where g.by_mbr_id = 1
                     and g.id = gm.grp_id
                     and gm.mbr_id = m.id
                     and ag.grp_id = g.id
                     and pl.member_id = m.id
                     and m.mbr_type = 4
                     and pl.member_type = 4
                     and pl.time_stamp > sysdate - 1) s
           where t.probe_id = s.host_id
             and t.member_id = s.member_id);
  commit;             
  insert into NB_M_PROBE_ONLINE
    select distinct pl.host_id,
                    a.id,
                    m.id member_id,
                    m.username,
                    pl.ipaddress,
                    sysdate,
                    0
      from nb_m_member_agreement ma,
           nb_m_agreement        a,
           nb_m_member           m,
           nb_m_proberuntime_log pl
     where ma.member_id = m.id
       and ma.agreement_id = a.id
       and pl.member_id = m.id
       and m.mbr_type = 4
       and pl.member_type = 4
       and pl.time_stamp > sysdate - 1
    union
    select distinct pl.host_id,
                    ag.agreement_id,
                    m.id member_id,
                    m.username,
                    pl.ipaddress,
                    sysdate,
                    0
      from nb_m_probgrp          g,
           nb_m_grp_mbr          gm,
           nb_m_member           m,
           nb_v_agree_probgrp    ag,
           nb_m_proberuntime_log pl
     where g.by_mbr_id = 1
       and g.id = gm.grp_id
       and gm.mbr_id = m.id
       and ag.grp_id = g.id
       and pl.member_id = m.id
       and m.mbr_type = 4
       and pl.member_type = 4
       and pl.time_stamp > sysdate - 1;
  commit;
  --然后处理手机相关的私有节点
  delete from NB_M_PROBE_ONLINE ro
   where (ro.probe_id, ro.agreement_id, ro.member_id) in
         (select t.probe_id, t.agreement_id, t.member_id
            from NB_M_PROBE_ONLINE t,
                 (select distinct pl.host_id,
                                  a.id,
                                  m.id member_id,
                                  m.username,
                                  pl.ipaddress
                    from nb_m_member_agreement ma,
                         nb_m_agreement        a,
                         nb_m_member           m,
                         nb_m_proberuntime_log_mobile pl
                   where ma.member_id = m.id
                     and ma.agreement_id = a.id
                     and pl.member_id = m.id
                     and m.mbr_type = 4
                     and pl.member_type = 4
                     and pl.time_stamp > sysdate - 1
                  union
                  select distinct pl.host_id,
                                  ag.agreement_id,
                                  m.id member_id,
                                  m.username,
                                  pl.ipaddress
                    from nb_m_probgrp          g,
                         nb_m_grp_mbr          gm,
                         nb_m_member           m,
                         nb_v_agree_probgrp    ag,
                         nb_m_proberuntime_log_mobile pl
                   where g.by_mbr_id = 1
                     and g.id = gm.grp_id
                     and gm.mbr_id = m.id
                     and ag.grp_id = g.id
                     and pl.member_id = m.id
                     and m.mbr_type = 4
                     and pl.member_type = 4
                     and pl.time_stamp > sysdate - 1) s
           where t.probe_id = s.host_id
             and t.member_id = s.member_id);
  commit;             
  insert into NB_M_PROBE_ONLINE
    select distinct pl.host_id,
                    a.id,
                    m.id member_id,
                    m.username,
                    pl.ipaddress,
                    sysdate,
                    1
      from nb_m_member_agreement ma,
           nb_m_agreement        a,
           nb_m_member           m,
           nb_m_proberuntime_log_mobile pl
     where ma.member_id = m.id
       and ma.agreement_id = a.id
       and pl.member_id = m.id
       and m.mbr_type = 4
       and pl.member_type = 4
       and pl.time_stamp > sysdate - 1
    union
    select distinct pl.host_id,
                    ag.agreement_id,
                    m.id member_id,
                    m.username,
                    pl.ipaddress,
                    sysdate,
                    1
      from nb_m_probgrp          g,
           nb_m_grp_mbr          gm,
           nb_m_member           m,
           nb_v_agree_probgrp    ag,
           nb_m_proberuntime_log_mobile pl
     where g.by_mbr_id = 1
       and g.id = gm.grp_id
       and gm.mbr_id = m.id
       and ag.grp_id = g.id
       and pl.member_id = m.id
       and m.mbr_type = 4
       and pl.member_type = 4
       and pl.time_stamp > sysdate - 1;
  commit;
  -- 最后将可能重复的数据删除掉
 delete from nb_m_probe_online
  where (probe_id, agreement_id) in
        (select probe_id, agreement_id
           from nb_m_probe_online
          group by probe_id, agreement_id
         having count(*) > 1)
    and rowid not in (select max(rowid)
                        from nb_m_probe_online
                       group by probe_id, agreement_id
                      having count(*) > 1);
  commit;                      
                      
end UPDATE_PROBE_ONLINE;


/

