create procedure calc_tx_bill_day authid current_user is
--腾讯定制点次账单
  sqlStr varchar2(4000);
  errorDesc varchar2(4000);
  startDate date;
  endDate date;
begin
  create_procedure_log('calc_tx_bill_day', 'begin', 'run');
  if(to_char(sysdate,'mmdd') = to_char(last_day(add_months(sysdate,-1))+1,'mmdd')) then 
    begin
      --获取上月第一天
      startDate:= TO_DATE(TO_CHAR(ADD_MONTHS(trunc(TO_DATE(TO_CHAR(TRUNC(SYSDATE, 'mm'), 'yyyy-mm-dd'),'yyyy-mm-dd')),-1),'yyyy-mm-dd'),'yyyy-mm-dd');
      --获取上月最后一天
      endDate:=TO_DATE(TO_CHAR(last_day(ADD_MONTHS(trunc(TO_DATE(TO_CHAR(TRUNC(SYSDATE, 'mm'), 'yyyy-mm-dd'),'yyyy-mm-dd')),-1)),'yyyy-mm-dd'),'yyyy-mm-dd');
    end; 
   end if; 
   if(to_char(sysdate,'mmdd') != to_char(last_day(add_months(sysdate,-1))+1,'mmdd')) then 
     begin
       --获取当月第一天
       startDate:= trunc(last_day(add_months(sysdate,-1))+1);
       --获取当月最后一天
       endDate:= trunc(last_day(sysdate));
     end;    
   end if;
   begin
  sqlStr:='--持续监测
select
     trunc(sysdate-1)  统计数据时间,
     case
     when monthT.countryType = 2 and monthT.type = 2 then ''AST''
　　 when monthT.countryType = 1 and monthT.type = 0 then ''PC海外监测''
     when monthT.countryType = 1 and monthT.type = 1 then ''海外手机wap监测''
     when monthT.countryType = 0 and monthT.type = 0 then ''PC国内监测''
     when monthT.countryType = 0 and monthT.type = 1 then ''国内手机wap监测''
　　else ''其它''
　  end 测试类型,
     monthT.money 单价,
     case
      when dayT.dayCount is null then 0
     else dayT.dayCount
　   end 当天监测量,
     case
      when monthT.monthCount is null then 0
     else monthT.monthCount 
　   end 当月监测量,
     monthT.money * monthT.monthCount 本月监测费用  
from
-- 当月
(select
　　 countryType,
     type,
      case
       when countryType = 2 and type = 2 then 0.018
       when countryType = 1 and type = 0 then 0.032
       when countryType = 1 and type = 1 then 0.08
       when countryType = 0 and type = 0 then 0.032
       when countryType = 0 and type = 1 then 0.08
      else 0.032
     end money,
     sum(n.count) as monthCount
from(
select
　　case
    when m.type = 2 then 2
　　when m.name like ''%海外%'' then 1
　　else 0
　　end as countryType,
    m.type,
    m.name,
    m.count
from (
  select
     d.name name,
    case
      when d.task_type =15 then 2
    when d.task_type >100 and d.task_type!= 255 and d.task_type !=15 then 1
    else 0
    end as type,
     sum(count) count
  from (
    select * from nb_bill_task_day where agree_id = 1760 
      and calc_date >=:sDate
      and calc_date <=:eDate
  ) a,nb_m_task t,nb_m_agree_detail d
  where a.task_id = t.id and t.detail_id = d.id
  group by t.detail_id,d.name,d.task_type
) m
) n
group by n.countryType,n.type
) monthT
left join
--当天
(select
   countryType,
   type,
    sum(n.count) as dayCount
from(
select
　　case
    when m.type = 2 then 2
　　when m.name like ''%海外%'' then 1
　　else 0
　　end as countryType,
    m.type,
    m.name,
    m.count
from (
  select
     d.name name,
    case
      when d.task_type =15 then 2
    when d.task_type >100 and d.task_type!= 255 and d.task_type !=15 then 1
    else 0
    end as type,
     sum(count) count
  from (
    select * from nb_bill_task_day where agree_id = 1760 
     and calc_date = trunc(sysdate -1)
  ) a,nb_m_task t,nb_m_agree_detail d
  where a.task_id = t.id and t.detail_id = d.id
  group by t.detail_id,d.name,d.task_type
) m
) n
group by n.countryType,n.type
) dayT 
on monthT.countryType = dayT.countryType and monthT.type=dayT.type
union all
--即时监测
select trunc(sysdate-1)  统计数据时间,
     case
     when m.type = 1 then ''真机即时监测''
　　else ''PC即时监测''
　  end 测试类型,
     m.money 单价,
     case
      when d.icount is null then 0
     else d.icount
　   end 当天监测量,
     case
      when m.icount is null then 0
     else m.icount 
　   end 当月监测量,
     m.money * m.icount 本月监测费用
from
--每月          
(select type,case when type = 1 then 0.08
　　else 0.032
　  end money,
    icount
from (select case when type in(1,2,3,255) then 0 else 1 end type,count(*) icount from nb_instant
  where status = 2 and agreement_id =1760
        and trunc(ctime) >= :sDate
        and trunc(ctime) <= :eDate
 group by case when type in(1,2,3,255) then 0 else 1 end) 
 ) m left join
 -- 每天
(select type,icount
from (select case when type in(1,2,3,255) then 0 else 1 end type,count(*) icount from nb_instant
  where status = 2 and agreement_id =1760
        and trunc(ctime) = trunc(sysdate-1)
 group by case when type in(1,2,3,255) then 0 else 1 end)
 ) d on m.type=d.type 
 
 union all
 
 select null as 数据统计时间,
     ''总计'' as 测试类型,
      sum(money) as 单价,
      sum(dayCount) as 当天监测量,
      sum(monthCount) as 当月监测量,
      sum(total) as 本月监测费用
 from(
 --持续监测
select
     trunc(sysdate-1)  统计数据时间,
     case
     when monthT.countryType = 2 and monthT.type = 2 then ''AST''
　　 when monthT.countryType = 1 and monthT.type = 0 then ''PC海外监测''
     when monthT.countryType = 1 and monthT.type = 1 then ''海外手机wap监测''
     when monthT.countryType = 0 and monthT.type = 0 then ''PC国内监测''
     when monthT.countryType = 0 and monthT.type = 1 then ''国内手机wap监测''
　　else ''其它''
　  end 测试类型,
     monthT.money money,
     case
      when dayT.dayCount is null then 0
     else dayT.dayCount
　   end dayCount,
     case
      when monthT.monthCount is null then 0
     else monthT.monthCount 
　   end monthCount,
     monthT.money * monthT.monthCount total  
from
-- 当月
(select
　　 countryType,
     type,
      case
       when countryType = 2 and type = 2 then 0.018
       when countryType = 1 and type = 0 then 0.032
       when countryType = 1 and type = 1 then 0.08
       when countryType = 0 and type = 0 then 0.032
       when countryType = 0 and type = 1 then 0.08
      else 0.032
     end money,
     sum(n.count) as monthCount
from(
select
　　case
    when m.type = 2 then 2
　　when m.name like ''%海外%'' then 1
　　else 0
　　end as countryType,
    m.type,
    m.name,
    m.count
from (
  select
     d.name name,
    case
      when d.task_type =15 then 2
    when d.task_type >100 and d.task_type!= 255 and d.task_type !=15 then 1
    else 0
    end as type,
     sum(count) count
  from (
    select * from nb_bill_task_day where agree_id = 1760 
      and calc_date >=:sDate
      and calc_date <=:eDate
  ) a,nb_m_task t,nb_m_agree_detail d
  where a.task_id = t.id and t.detail_id = d.id
  group by t.detail_id,d.name,d.task_type
) m
) n
group by n.countryType,n.type
) monthT
left join
--当天
(select
   countryType,
   type,
    sum(n.count) as dayCount
from(
select
　　case
    when m.type = 2 then 2
　　when m.name like ''%海外%'' then 1
　　else 0
　　end as countryType,
    m.type,
    m.name,
    m.count
from (
  select
     d.name name,
    case
      when d.task_type =15 then 2
    when d.task_type >100 and d.task_type!= 255 and d.task_type !=15 then 1
    else 0
    end as type,
     sum(count) count
  from (
    select * from nb_bill_task_day where agree_id = 1760 
     and calc_date = trunc(sysdate -1)
  ) a,nb_m_task t,nb_m_agree_detail d
  where a.task_id = t.id and t.detail_id = d.id
  group by t.detail_id,d.name,d.task_type
) m
) n
group by n.countryType,n.type
) dayT 
on monthT.countryType = dayT.countryType and monthT.type=dayT.type
union all
--即时监测
select trunc(sysdate-1)  统计数据时间,
     case
     when m.type = 1 then ''真机即时监测''
　　else ''PC即时监测''
　  end 测试类型,
     m.money 单价,
     case
      when d.icount is null then 0
     else d.icount
　   end 当天监测量,
     case
      when m.icount is null then 0
     else m.icount 
　   end 当月监测量,
     m.money * m.icount 本月监测费用
from
--每月          
(select type,case when type = 1 then 0.08
　　else 0.032
　  end money,
    icount
from (select case when type in(1,2,3,255) then 0 else 1 end type,count(*) icount from nb_instant
  where status = 2 and agreement_id =1760
        and trunc(ctime) >= :sDate
        and trunc(ctime) <= :eDate
 group by case when type in(1,2,3,255) then 0 else 1 end) 
 ) m left join
 -- 每天
(select type,icount
from (select case when type in(1,2,3,255) then 0 else 1 end type,count(*) icount from nb_instant
  where status = 2 and agreement_id =1760
        and trunc(ctime) = trunc(sysdate-1)
 group by case when type in(1,2,3,255) then 0 else 1 end)
 ) d on m.type=d.type 
 ) ';
    execute immediate sqlStr using startDate,endDate;
    exception when others then
      errorDesc := sqlerrm||',error agreeid:' || 1760 ;
      create_procedure_log('calc_bill_day',errorDesc,'warning');
  end;
  create_procedure_log('calc_tx_bill_day', 'end', 'run');
end calc_tx_bill_day;
/

