create PROCEDURE "DEL_EL_elt_URL_PART" authid current_user is
sqlStr varchar2(4000);
v_error_desc varchar2(4000);
order_curr number;
range_date_curr date;
v_s number;
v_p number;
v_partname varchar2(64);
v_rangedate_desc varchar2(128);
v_rangedate varchar2(128);

begin
 -- 1 计算出当前日期所对应的应该插入分区的时间范围及序号,是根据当前日期算出下周的周日，
 --   即为了安全，将会提前两周处理,每周开始日期为周日
    select order_num,sunday into order_curr,range_date_curr from nb_part_calendar t
        where t.sunday = (select trunc(sysdate - (20 + to_char( sysdate,'d')),'d') from dual);
        v_rangedate_desc:=to_char(range_date_curr,'yyyy-mm-dd');
        v_rangedate:='to_date('''||v_rangedate_desc||''',''yyyy-mm-dd'')';
    -- 2.取出所有已经建立分区的nb_el_url表后缀，开始循环 注：无分区的表不处理
    for el in  (SELECT distinct substr(t.table_name,11) suff FROM user_tables t where t.partitioned='YES' and t.table_name like 'NB_EL_URL_%')
    loop
        begin
            -- 2.1.判断是否要删除的分区已经存在,如果存在则删除，如果不存在则不处理
            v_partname:= 'PART_EL_URL_'||el.suff||'_'||order_curr;
            select count(*) into v_s from user_tab_partitions t where t.partition_name= v_partname;
            if v_s > 0 then
               select count(*) into v_p from user_tab_partitions p where p.table_name='NB_EL_URL_'||el.suff;
               -- 2.2.安全检查，如果该elem表所属的分区数少于5,则警告并不执行删除分区的操作
               if v_p > 5 then
                   sqlStr := 'ALTER TABLE nb_el_url_'||el.suff||' DROP PARTITION '||v_partname;
                   execute immediate sqlStr;
               else
                   v_error_desc:='The count of patitions is less than 5,delete cancel.partname:'||v_partname||'  rangedate:'||v_rangedate_desc;
                   create_procedure_log('del_el_url_part',v_error_desc,'warning');
                   -- dbms_output.put_line(v_error_desc);
               end if;
            else
               -- 不存在则写警告日志
               v_error_desc:='The partition is not exist,cannot delete,partname:'||v_partname||' rangedate'||v_rangedate_desc;
               -- dbms_output.put_line(v_error_desc);
               create_procedure_log('del_el_url_part',v_error_desc,'warning');
            end if;
        exception when  others then
            v_error_desc := sqlerrm || ',' ||sqlStr;
            -- DBMS_OUTPUT.PUT_LINE(v_error_desc);
            create_procedure_log('del_el_url_part',v_error_desc,'error');
        end;
    end loop;
    -- 2.取出所有已经建立分区的elem表后缀，开始循环 注：无分区的表不处理
    for elt in  (SELECT distinct substr(t.table_name,12) suff FROM user_tables t where t.partitioned='YES' and t.table_name like 'NB_ELT_URL_%')
    loop
        begin
            -- 3.判断是否要删除的分区已经存在,如果存在则删除，如果不存在则不处理
            v_partname:= 'PART_ELT_URL_'||elt.suff||'_'||order_curr;
            -- 判断增加的分区是否已经存在 
            select count(*) into v_s from user_tab_partitions t where t.partition_name= v_partname;
            -- 存在则删除分区
            if v_s > 0 then
               select count(*) into v_p from user_tab_partitions p where p.table_name='NB_ELT_URL_'||el.suff;
               -- 安全检查，如果该elem表所属的分区数少于5,则警告并不执行删除分区的操作
               if v_p > 5 then
                   sqlStr := 'ALTER TABLE nb_elt_url_'||elt.suff||' DROP PARTITION '||v_partname;
                   execute immediate sqlStr;
               else
                   v_error_desc:='The count of patitions is less than 5,delete cancel.partname:'||v_partname||'  rangedate:'||v_rangedate_desc;
                   create_procedure_log('del_el_url_part',v_error_desc,'warning');
                   -- dbms_output.put_line(v_error_desc);
               end if;
            else
               -- 不存在则写警告日志
               v_error_desc:='The partition is not exist,cannot delete,partname:'||v_partname||' rangedate'||v_rangedate_desc;
               -- dbms_output.put_line(v_error_desc);
               create_procedure_log('del_el_url_part',v_error_desc,'warning');
            end if;
        exception when  others then
            v_error_desc := sqlerrm || ',' ||sqlStr;
            -- DBMS_OUTPUT.PUT_LINE(v_error_desc);
            create_procedure_log('del_el_url_part',v_error_desc,'error');
        end;
    end loop;
end del_el_elt_url_part;


/

