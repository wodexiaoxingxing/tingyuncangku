create PROCEDURE          "ALTER_PAGE_PART_S" 
(tableStr IN varchar2) authid current_user
is
  sqlStr  varchar2(4000);
  v_is_part varchar2(32); 
  v_s number;
begin
  -- 判断是否该表已经做过分区
  select t.partitioned into v_is_part from user_tables t where t.table_name = 'NB_PAGE_'||tableStr;
  dbms_output.put_line(v_is_part);
  if v_is_part = 'YES' then return; end if;
  dbms_output.put_line('begin create table');
  sqlStr:='create table NB_PAGE_'||tableStr||'_temp
		(
		  ID              NUMBER not null,
		  TRAN_ID         NUMBER,
		  TASK_ID         NUMBER,
		  CITY_ID         NUMBER,
		  ISP_ID          NUMBER,
		  NET_SPEED_ID    NUMBER,
		  TM_BASE         DATE,
		  TM_DAY          DATE,
		  TM_HOUR         DATE,
		  TM_HALF_HOUR    DATE,
		  PROBE_IP        NUMBER,
		  PAGE_SEQ        NUMBER,
		  ERROR_CODE      NUMBER,
		  ERROR_PATH      VARCHAR2(256),
		  CONT_ERR_TOTAL  NUMBER,
		  CONT_ELE_TOTAL  NUMBER,
		  REDIRECT_TOTAL  NUMBER,
		  POINT_TOTAL     NUMBER default 1,
		  BYTE_TOTAL      NUMBER,	
		  RATE_DOWNLOAD   NUMBER,	
		  DEST_IP         VARCHAR2(39),
		  PING_RESULT     VARCHAR2(512),
		  TRACERT_RESULT  VARCHAR2(512),  
		  HTTP_SERVER     VARCHAR2(256),
		  HTTP_VIA        VARCHAR2(256),		  
		  TS_TOTAL        NUMBER,
		  TS_PAGE_BASE    NUMBER,
		  TS_DNS          NUMBER,
		  TS_CONNECT      NUMBER,
		  TS_SSL          NUMBER,
		  TS_REDIRECT     NUMBER,
		  TS_REQUEST      NUMBER,
		  TS_FIRST_PACKET NUMBER,
		  TS_CLIENT       NUMBER,
		  TS_CONTENTS     NUMBER,
		  TS_EXTRA_DATA   NUMBER,
		  TS_OPEN_PAGE    NUMBER,
		  TS_USER         NUMBER,
		  TS_NETWORK      NUMBER,
		  TS_CLOSE        NUMBER,
		  IS_NOISE	  NUMBER		  
		)
		partition by range (TM_BASE)
 (
  partition part_page_'||tableStr||'_25 values less than (TO_DATE(''2008-04-20'', ''YYYY-MM-DD'')),
  partition part_page_'||tableStr||'_26 values less than (TO_DATE(''2008-04-27'', ''YYYY-MM-DD'')),
  partition part_page_'||tableStr||'_27 values less than (TO_DATE(''2008-05-04'', ''YYYY-MM-DD'')),
  partition part_page_'||tableStr||'_28 values less than (TO_DATE(''2008-05-11'', ''YYYY-MM-DD'')),
  partition part_page_'||tableStr||'_29 values less than (TO_DATE(''2008-05-18'', ''YYYY-MM-DD'')),
  partition part_page_'||tableStr||'_30 values less than (TO_DATE(''2008-05-25'', ''YYYY-MM-DD'')),
  partition part_page_'||tableStr||'_31 values less than (TO_DATE(''2008-06-01'', ''YYYY-MM-DD'')),
  partition part_page_'||tableStr||'_32 values less than (TO_DATE(''2008-06-08'', ''YYYY-MM-DD'')),
  partition part_page_'||tableStr||'_33 values less than (TO_DATE(''2008-06-15'', ''YYYY-MM-DD'')),
  partition part_page_'||tableStr||'_34 values less than (TO_DATE(''2008-06-22'', ''YYYY-MM-DD'')),
  partition part_page_'||tableStr||'_35 values less than (TO_DATE(''2008-06-29'', ''YYYY-MM-DD''))
 )';
  execute immediate sqlStr;
  
  -- 2.删除原表的物化视图
    --先删除日志
    sqlStr := 'drop materialized view log on nb_page_'||tableStr;
    execute immediate sqlStr;
    --再删除物化视图
    sqlStr := 'drop materialized view mv_page_'||tableStr;
    execute immediate sqlStr;
    
  --3.检查原始表能否在线重定义,采用rowid方式  用系统管理员执行
  dbms_output.put_line('DBMS_REDEFINITION.CAN_REDEF_TABLE');
  DBMS_REDEFINITION.CAN_REDEF_TABLE('NETBEN', 'NB_PAGE_'||tableStr, DBMS_REDEFINITION.cons_use_rowid); 
  
  --4.执行在线重新定义 系统管理员执行
  dbms_output.put_line('DBMS_REDEFINITION.START_REDEF_TABLE');
  DBMS_REDEFINITION.START_REDEF_TABLE('NETBEN', 'NB_PAGE_'||tableStr, 'NB_PAGE_'||tableStr||'_TEMP', '', DBMS_REDEFINITION.cons_use_rowid); 
  
  
  --5.执行数据同步 系统管理员执行
  dbms_output.put_line('DBMS_REDEFINITION.sync_interim_table');
  DBMS_REDEFINITION.sync_interim_table('NETBEN', 'NB_PAGE_'||tableStr, 'NB_PAGE_'||tableStr||'_TEMP');
  --执行两次
  DBMS_REDEFINITION.sync_interim_table('NETBEN', 'NB_PAGE_'||tableStr, 'NB_PAGE_'||tableStr||'_TEMP');
  
  --6.完成在线重新定义 系统管理员执行
  dbms_output.put_line('DBMS_REDEFINITION.FINISH_REDEF_TABLE');
  DBMS_REDEFINITION.FINISH_REDEF_TABLE('NETBEN', 'NB_PAGE_'||tableStr, 'NB_PAGE_'||tableStr||'_TEMP');
  
  
  --删除临时表
  sqlStr:='drop table nb_page_'||tableStr||'_temp';
  execute immediate sqlStr;
  
  --7.创建一个local 索引 及主键
  --先判断是否同名索引存在，如果存在，则删除
  
  sqlStr:='alter table NB_PAGE_'||tableStr||'  add constraint PK_NB_PAGE_'||tableStr||' primary key (ID) using index';
  execute immediate sqlStr;
  
  select count(*) into v_s from user_indexes t where t.index_name='IN_PAGE_PERF_'||tableStr;
  if v_s > 0 then 
      sqlStr:='drop index IN_PAGE_PERF_'||tableStr;
      execute immediate sqlStr;
  end if;
  sqlStr:='create index in_page_perf_'||tableStr||' on nb_page_'||tableStr||'(task_id,tm_base,city_id,isp_id) local
   (partition part_page_'||tableStr||'_25,
    partition part_page_'||tableStr||'_26,
    partition part_page_'||tableStr||'_27,
    partition part_page_'||tableStr||'_28,
    partition part_page_'||tableStr||'_29,
    partition part_page_'||tableStr||'_30,
    partition part_page_'||tableStr||'_31,
    partition part_page_'||tableStr||'_32,
    partition part_page_'||tableStr||'_33,
    partition part_page_'||tableStr||'_34,
    partition part_page_'||tableStr||'_35
    )tablespace netben_idx'; 
  execute immediate sqlStr;
  
  select count(*) into v_s from user_indexes t where t.index_name='IN_PAGE_ERROR_'||tableStr;
  if v_s > 0 then 
      sqlStr:='drop index IN_PAGE_ERROR_'||tableStr;
      execute immediate sqlStr;
  end if;
  
  sqlStr:='create index in_page_error_'||tableStr||' on nb_page_'||tableStr||'(task_id,tm_base,error_code,city_id) local
   (partition part_page_'||tableStr||'_25,
    partition part_page_'||tableStr||'_26,
    partition part_page_'||tableStr||'_27,
    partition part_page_'||tableStr||'_28,
    partition part_page_'||tableStr||'_29,
    partition part_page_'||tableStr||'_30,
    partition part_page_'||tableStr||'_31,
    partition part_page_'||tableStr||'_32,
    partition part_page_'||tableStr||'_33,
    partition part_page_'||tableStr||'_34,
    partition part_page_'||tableStr||'_35
    )tablespace netben_idx';
  execute immediate sqlStr;
  select count(*) into v_s from user_indexes t where t.index_name='IN_PAGE_TRANID_'||tableStr;
  if v_s > 0 then 
      sqlStr:='drop index IN_PAGE_TRANID_'||tableStr;
      execute immediate sqlStr;
  end if;
  sqlStr:='create index in_page_tranid_'||tableStr||' on nb_page_'||tableStr||'(tran_id) local
   (partition part_page_'||tableStr||'_25,
    partition part_page_'||tableStr||'_26,
    partition part_page_'||tableStr||'_27,
    partition part_page_'||tableStr||'_28,
    partition part_page_'||tableStr||'_29,
    partition part_page_'||tableStr||'_30,
    partition part_page_'||tableStr||'_31,
    partition part_page_'||tableStr||'_32,
    partition part_page_'||tableStr||'_33,
    partition part_page_'||tableStr||'_34,
    partition part_page_'||tableStr||'_35
    )tablespace netben_idx';
  execute immediate sqlStr;
    
  --8.创建物化视图日志
  sqlStr:='create materialized view log on NB_PAGE_'||tableStr||' with rowid,
		sequence (task_id,
			page_seq,
			city_id,
			isp_id,
			net_speed_id,
			error_code,
			is_noise,
			dest_ip,
			tm_hour,
			point_total,
			rate_download,
			ts_total,ts_page_base,
			ts_dns,ts_connect,
			ts_ssl,ts_redirect,
			ts_request,ts_first_packet,
			ts_client,ts_contents,ts_extra_data,
			ts_open_page,
			ts_user,
			ts_network,
			ts_close
			) including new values';  
    execute immediate sqlStr;  
    
     --9.创建物化视图			
sqlStr:='create materialized view MV_PAGE_'||tableStr||'
		refresh fast
		start with sysdate next sysdate + 4/24 
		as
		(select task_id,
		page_seq,
		city_id,
		isp_id,
		net_speed_id,
		error_code,
		is_noise,
		dest_ip,
		(tm_hour - mod(to_number(to_char(tm_hour, ''hh24'')) + 8, 8) / 24) as tm_hour8,
		(tm_hour - mod(to_number(to_char(tm_hour,''hh24'')) + 12, 12) / 24) as tm_hour12,
		trunc(tm_hour, ''dd'') as tm_day,
		count(*) as c1,
		count(point_total) as c2,
		count(rate_download) as c3,
		count(ts_total) as c4,
		count(ts_page_base) as c5,
		count(ts_dns) as c6,
		count(ts_connect) as c7,
		count(ts_ssl) as c8,
		count(ts_redirect) as c9,
		count(ts_request) as c10,
		count(ts_first_packet) as c11,
		count(ts_client) as c12,
		count(ts_contents) as c13,
		count(ts_extra_data) as c14,
		count(ts_open_page) as c15,
		count(ts_user) as c16,
		count(ts_network) as c17,
		count(ts_close) as c18,
		sum(point_total) as point_total,
		avg(rate_download) as rate_download,
		avg(ts_total) as ts_total,
		avg(ts_page_base) as ts_page_base,
		avg(ts_dns) as ts_dns,
		avg(ts_connect) as ts_connect,
		avg(ts_ssl) as ts_ssl,
		avg(ts_redirect) as ts_redirect,
		avg(ts_request) as ts_request,
		avg(ts_first_packet) as ts_first_packet,
		avg(ts_client) as ts_client,
		avg(ts_contents) as ts_contents,
		avg(ts_extra_data) as ts_extra_data,
		avg(ts_open_page) as ts_open_page,
		avg(ts_user) as ts_user,
		avg(ts_network) as ts_network,
		avg(ts_close) as ts_close
		from NB_PAGE_'||tableStr||' 
		group by task_id,
			page_seq,
			city_id,
			isp_id,
			net_speed_id,
			error_code,
			is_noise,
			dest_ip,
			(tm_hour - mod(to_number(to_char(tm_hour, ''hh24'')) + 8, 8) / 24),
			(tm_hour - mod(to_number(to_char(tm_hour, ''hh24'')) + 12, 12) / 24),
			trunc(tm_hour, ''dd''))';
      execute immediate sqlStr;  
      
--10.创建物化视图索引
	sqlStr:='create index IN_MV_PAGE_ERROR_'||tableStr||' on MV_PAGE_'||tableStr||' (TASK_ID,TM_HOUR8, ERROR_CODE, CITY_ID) tableSpace NETBEN_IDX'; 
  execute immediate sqlStr;  
	sqlStr:='create index IN_MV_PAGE_PERF_'||tableStr||' on MV_PAGE_'||tableStr||' (TASK_ID,TM_HOUR8, CITY_ID,ISP_ID) tableSpace NETBEN_IDX';       
  execute immediate sqlStr;  
        
end ALTER_PAGE_PART_S;


/

