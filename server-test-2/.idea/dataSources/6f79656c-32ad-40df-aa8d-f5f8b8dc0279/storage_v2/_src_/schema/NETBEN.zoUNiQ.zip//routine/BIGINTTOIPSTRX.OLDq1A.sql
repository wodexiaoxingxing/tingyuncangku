create FUNCTION          "BIGINTTOIPSTRX" (arg in NUMBER) return varchar2 is
 result varchar2(39);
num number;
p1 integer;
p2 integer;
p3 integer;
p4 integer;
begin
if (arg < 0) then
   num:=4294967296 + arg;
else
   num:=arg;
end if;
p1:=bitand(num, 4278190080)/16777216;
p2:=bitand(num, 16711680)/65536;
p3:=bitand(num, 65280)/256;
--p4:=bitand(num, 255);

result:=p1||'.'||p2||'.'||p3||'.x';

return(result);
end BIGINTTOIPSTRX;


/

