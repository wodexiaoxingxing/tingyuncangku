create PROCEDURE          "IN_TOP_CREATE_TABLE" 
  authid current_user
is
  sqlStr varchar2(4000);
  v_error_desc varchar2(4000);
  v_s number;
  partName varchar2(4000);
  partStr varchar2(4000);
begin
  create_procedure_log('in_top_create_table','in_top_create_table begin','test');

  --首先取出所有需要进行数据分析的表的后缀，前提必须保证此存储过程最先执行
  --(要判断是否该表已经建立，有可能只建立合同但没有建立任务，此时表还未生成)
  sqlStr := 'truncate table nb_top_table';
  execute immediate sqlStr;
  sqlStr := 'insert into nb_top_table value
               select distinct a.table_str
                 from nb_m_agreement a, nb_m_agree_detail d
                where a.id = d.agreement_id  and d.data_analyse = 1   and a.table_str is not null
                      and (select count(*) from user_tables tab where  tab.table_name =''NB_TRAN_''|| a.table_str)>0';
  execute immediate sqlStr ;
  commit;
  
  --对没有索引的表首先建立索引
  for tableName in(select table_str as name from nb_top_table) loop
     begin
       --判断是否指定的ELEM表已经建立索引
      select count(*)  INTO v_s FROM all_objects t where t.object_name = 'IN_ELEM_TASKTM_'||tableName.name;
      if v_s < 1 then
        create_procedure_log('in_top_elem_perf','in_elem_tasktm_'||tableName.name||' is not exist','no index');
        --建立索引
        partStr:='';
        for partName in(select partition_name as name from user_tab_partitions where table_name ='NB_ELEM_'||tableName.name) loop
            partStr := partStr||'partition '||partName.name||',';
        end loop;
        partStr:=substr(partStr,1,length(partStr)-1);
        sqlStr :=  'create index in_elem_tasktm_'||tableName.name||' on nb_elem_'||tableName.name||'(task_id,tm_base) local('
            ||partStr||')tablespace netben_idx';
        execute immediate sqlStr;
      end if;
      exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  tableName:' || tableName.Name ;
        DBMS_OUTPUT.PUT_LINE(sqlcode);
        create_procedure_log('in_top_create_table',v_error_desc,'error');
     end;
  end loop;
  -- nb_top_error 删除30天前的数据，所有top ten只保留30天数据
  sqlStr:='delete nb_top_error where tm_day < sysdate-70';
  execute immediate sqlStr;
  commit;
  --nb_top_host 删除30天前的数据，所有top ten只保留30天数据
  sqlStr:='delete nb_top_host where tm_day < sysdate-70';
  execute immediate sqlStr;
  commit;
  --nb_top_elem_perf 删除30天前的数据，所有top ten只保留30天数据
  sqlStr:='delete nb_top_elem_perf where tm_day < sysdate-70';
  execute immediate sqlStr;
  commit;
end in_top_create_table;


/

