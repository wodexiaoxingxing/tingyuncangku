create PROCEDURE          "DELETE_ELEM_PK" authid current_user
is
  sqlStr  varchar2(4000);  
  v_name varchar2(400);
  v_error_desc varchar2(4000);
  v_s number;
  CURSOR c_emp IS SELECT substr(t.table_name,9) FROM user_tables t where t.table_name like 'NB_ELEM_%';
begin
OPEN c_emp;
LOOP
  begin
    FETCH c_emp INTO v_name;
    EXIT WHEN c_emp%NOTFOUND;
    select count(*) into v_s from user_tab_columns t where t.TABLE_NAME = 'NB_ELEM_'||v_name;
    dbms_output.put_line(v_name ||'    '||v_s);
   --如果创建失败，则显示出失败的表
   exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:' || sqlStr;
        DBMS_OUTPUT.PUT_LINE(v_error_desc);
        create_procedure_log('delete_pk',v_error_desc,sqlcode);
    end;
END LOOP;
CLOSE c_emp;  
end delete_elem_pk;


/

