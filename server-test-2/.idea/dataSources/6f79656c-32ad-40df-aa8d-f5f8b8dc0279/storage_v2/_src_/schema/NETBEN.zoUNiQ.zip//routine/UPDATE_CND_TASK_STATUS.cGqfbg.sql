create procedure update_cnd_task_status authid current_user is
  sqlStr       varchar2(4000);
  errorDesc varchar2(4000);
begin
  create_procedure_log('update_cnd_task_status', 'begin', 'run');
    --循环，查寻出所有配置了正常cdn调优任务的主任务
        for task in (select id,status,expire from nb_m_task where id in (select binding_task_id from nb_m_task where type =1 and task_option='S'and expire > sysdate-1 and status =1 and binding_task_id is not null group by binding_task_id)) loop
          begin
               if task.status = -1 then 
                 begin
                    sqlStr := 'update nb_m_task set status = -1,mtime = sysdate where status =1 and expire > sysdate-1 and binding_task_id ='||task.id;
                  end; 
                  elsif task.status = 0 then 
                      begin 
                        sqlStr := 'update nb_m_task set status = 0,mtime = sysdate where status =1 and expire > sysdate-1 and binding_task_id ='||task.id; 
                       end; 
                    elsif task.status = 1 and task.expire < sysdate-1 then
                        begin 
                          sqlStr := 'update nb_m_task set status = 0,mtime = sysdate where status =1 and expire > sysdate-1 and binding_task_id ='||task.id;
                        end;
                end if;
                
                if length(sqlStr)>0 then
                  begin
                   execute immediate sqlStr;
                       commit;
                       exception when others then
                          errorDesc := sqlerrm||',tableName:nb_m_task';
                          create_procedure_log('update_cnd_task_status',errorDesc,'error');
                  end;
                  end if;                     
          end;
        end loop;
  create_procedure_log('update_cnd_task_status', 'end', 'run');
end update_cnd_task_status;
/

