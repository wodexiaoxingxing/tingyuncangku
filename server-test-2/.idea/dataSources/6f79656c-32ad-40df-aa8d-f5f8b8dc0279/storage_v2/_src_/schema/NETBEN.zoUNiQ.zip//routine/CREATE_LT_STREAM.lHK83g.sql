create PROCEDURE          "CREATE_LT_STREAM" (
       tableStr IN varchar2
) authid current_user
is
  sqlStr  varchar2(4000);  
begin
    --创建LT_Tran sequence 
    sqlStr:='create sequence SEQ_LT_STREAM_ID_'||tableStr||'
			minvalue 1
			maxvalue 9999999999999999999999999
			start with 1
			increment by 1
			cache 20';  
    execute   immediate   sqlStr;	
     sqlStr:='create table LT_STREAM_'||tableStr||'
		(
		  ID             NUMBER not null,
		  TASK_ID        NUMBER,
		  CITY_ID        NUMBER,
		  ISP_ID         NUMBER,
		  NET_SPEED_ID   NUMBER,
		  TM_DAY         DATE,
		  TM_DAY2        DATE,
		  TM_DAY4        DATE,
		  TM_DAY8        DATE,
		  TM_DAY16       DATE,
		  ERROR_CODE     NUMBER,
      POINT_TOTAL    NUMBER,
		  TS_TOTAL       NUMBER
		)';  
    execute   immediate   sqlStr;
    --主键  
    sqlStr:='alter table LT_STREAM_'||tableStr||'
		  add constraint PK_LT_STREAM_'||tableStr||' primary key (ID)
		  using index ';
    execute   immediate   sqlStr;
    --索引
	sqlStr:='create index IN_LT_STREAM_PERF_'||tableStr||' on LT_STREAM_'||tableStr||' (TM_DAY, CITY_ID, TASK_ID, ISP_ID) tableSpace NETBEN_IDX';
	execute   immediate   sqlStr;
end create_lt_stream;


/

