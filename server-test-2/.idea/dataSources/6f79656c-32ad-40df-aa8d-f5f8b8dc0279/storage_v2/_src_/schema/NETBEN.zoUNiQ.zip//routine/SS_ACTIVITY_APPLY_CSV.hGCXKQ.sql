create procedure ss_activity_apply_csv  is
   sql_query varchar2(4000);
   file_name varchar2(100);
begin
   sql_query :='
select * from saas.SS_ACTIVITY_APPLY
';
--dbms_output.put_line(sql_query);


--DUNP文件名，存于 /opt/backup/dump/liao11.csv
   file_name:='ss_activity_apply.csv';
 --dump文件到指定位置
netben.dump_to_csv(sql_query, 'DUMP', file_name);
 end ss_activity_apply_csv;


/

