create PROCEDURE          "MAN_ALTER_PING_ADD_SEQUENCE" 
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(400);
  tableStr VARCHAR2(18);
  v_s number;
  CURSOR c_emp IS SELECT substr(t.table_name,9) FROM user_tables t where t.table_name like 'NB_PING_%';
begin
OPEN c_emp;
LOOP
  begin
    FETCH c_emp INTO tableStr;
    EXIT WHEN c_emp%NOTFOUND;

--    select t.table_name as name from user_tables t where t.table_name like 'NB_PING_%' ) loop
      --删除主键
    /*select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='ID';
    if v_s = 1 then
       sqlStr:= 'alter table '||tableName.Name||' drop column ID';
       execute immediate sqlStr;
    end if;
    --删除tm_day2
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TM_DAY2';
    if v_s = 1 then
       sqlStr:= 'alter table '||tableName.Name||' drop column TM_DAY2';
       execute immediate sqlStr;
    end if;
    --删除tm_day4
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TM_DAY4';
    if v_s = 1 then
       sqlStr:= 'alter table '||tableName.Name||' drop column TM_DAY4';
       execute immediate sqlStr;
    end if;
    --删除tm_day8
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TM_DAY8';
    if v_s = 1 then
       sqlStr:= 'alter table '||tableName.Name||' drop column TM_DAY8';
       execute immediate sqlStr;
    end if;
    --删除tm_day16
    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TM_DAY16';
    if v_s = 1 then
       sqlStr:= 'alter table '||tableName.Name||' drop column TM_DAY16';
      
    end if;

   SELECT substr(t.table_name,9) FROM user_tables t where t.table_name like 'NB_TRAN_%';

    */
    select count(*)  INTO v_s from user_sequences t where t.SEQUENCE_NAME= 'SEQ_NB_PING_ID_'||tableStr;
    dbms_output.put_line(v_s);
        dbms_output.put_line('SEQ_NB_PING_ID_'||tableStr);
    if v_s < 1 then
            sqlStr:='create sequence SEQ_NB_PING_ID_'||tableStr||'
                  minvalue 1   maxvalue 9999999999999999999999999
                  start with 1      increment by 1    cache 500';
 execute immediate sqlStr;
end if;
 /*    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='BS_ID';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add BS_ID number';
      execute   immediate   sqlStr ;
  dbms_output.put_line(sqlStr);
      end if;

     select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='BS_VER_ID';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add BS_VER_ID number';
      execute   immediate   sqlStr ;
  dbms_output.put_line(sqlStr);
      end if;

    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='FLASH_VER';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add FLASH_VER varchar2(64)';
        execute   immediate   sqlStr ;
 dbms_output.put_line(sqlStr);
      end if;
 */
 
    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlStr);
        create_procedure_log('alter_lt_tran_add_field',v_error_desc,sqlcode);
  end;
  end loop;
end man_alter_ping_add_sequence;


/

