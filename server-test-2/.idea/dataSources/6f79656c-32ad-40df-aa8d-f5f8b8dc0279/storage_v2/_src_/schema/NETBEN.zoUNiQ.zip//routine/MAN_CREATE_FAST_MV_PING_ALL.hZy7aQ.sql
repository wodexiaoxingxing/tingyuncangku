create PROCEDURE          "MAN_CREATE_FAST_MV_PING_ALL" authid current_user
is
  sqlStr  varchar2(4000);
  v_name varchar2(400);
  v_error_desc varchar2(4000);
  v_s number;
  l_name varchar2(100);
  CURSOR c_emp IS SELECT substr(t.table_name,9) FROM user_tables t where t.table_name like 'NB_PING_%';
begin
OPEN c_emp;
LOOP
  begin
    --创建物化视图日志
    create_procedure_log('create_fast_mv_ping_all','create mv_ping_'||v_name,'message');
    FETCH c_emp INTO v_name;
    EXIT WHEN c_emp%NOTFOUND;
    select count(*)  INTO v_s FROM all_objects t where t.object_name = 'MLOG$_NB_PING_'||v_name;
    if v_s > 0 then
        sqlStr:=  'drop materialized view log on nb_ping_'||v_name;
        execute immediate sqlstr;
    DBMS_OUTPUT.PUT_LINE(sqlstr);
    end if;
        sqlStr:='create materialized view log on nb_ping_'||v_name||' with rowid,
         sequence (
             TASK_ID ,
             PAGE_SEQ,
             CITY_ID ,
             ISP_ID ,
             NET_SPEED_ID ,
             TM_BASE ,
             ERROR_CODE ,
             DEST_IP ,
             TS_TOTAL ,
             PING_PACKET_LOST ,
             POINT_TOTAL,
             IS_NOISE 
         ) including new values';
--    execute immediate sqlStr;
 l_name := 'creating materialized view log on nb_ping_'||v_name||'..... ';
 DBMS_OUTPUT.PUT_LINE(l_name);
--  DBMS_OUTPUT.PUT_LINE(sqlStr);
      execute immediate sqlStr;
  l_name := 'materialized view log on nb_ping_'||v_name||' created!';
 DBMS_OUTPUT.PUT_LINE(l_name);
    select count(*)  INTO v_s FROM all_objects t where t.object_name = 'MV_PING_'||v_name;
    if v_s > 0 then
    --删除物化视图
    --DBMS_OUTPUT.PUT_LINE('drop mv_tran_'||v_name);
    sqlStr:='drop materialized view mv_ping_'||v_name;
    execute immediate sqlStr;
    DBMS_OUTPUT.PUT_LINE(sqlStr);
    end if;
   --ping 物化视图
    create_procedure_log('create_fast_mv_ping_all','start materialized view  mv_ping_'||v_name,'message');
    sqlStr:='create materialized view MV_PING_'||v_name||'
    refresh fast
    start with sysdate next sysdate + 4/24
    as
    (
    select task_id,
        page_seq,
        city_id,
        isp_id,
        net_speed_id,
        error_code,
        dest_ip,
        is_noise,
        (tm_base - mod(to_number(to_char(tm_base, ''hh24'')) + 8, 8) / 24) as tm_hour8,
        count(*) as c1,
        count(point_total) as c2,
        count(ts_total) as c3,
        count(ping_packet_lost) as c4,
        sum(point_total) as point_total,
        avg(ts_total) as ts_total,
        avg(ping_packet_lost) as ping_packet_lost
    from NB_ping_'||v_name||'
    group by task_id,
           page_seq,
           city_id,
           isp_id,
           net_speed_id,
           error_code,
           dest_ip,
           is_noise,
           (tm_base - mod(to_number(to_char(tm_base, ''hh24'')) + 8, 8) / 24)
       )';

 --   execute   immediate   sqlStr;

  l_name := 'creating materialized view mv_ping_'||v_name;
 DBMS_OUTPUT.PUT_LINE(l_name);
      execute immediate sqlStr;
  l_name := 'materialized view mv_ping_'||v_name||'created!';
 DBMS_OUTPUT.PUT_LINE(l_name);
 DBMS_OUTPUT.PUT_LINE('###############################################');


  --索引
  sqlStr:='create index IN_MV_PING_ERROR_'||v_name||' on MV_PING_'||v_name||' (TASK_ID,TM_HOUR8,ERROR_CODE) tableSpace NETBEN_IDX';
   execute   immediate   sqlStr;
   
   --如果创建失败，则显示出失败的表
   exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:' || v_name;
        --DBMS_OUTPUT.PUT_LINE(v_error_desc);
        create_procedure_log('create_fast_mv_ping_all',v_error_desc,sqlcode);
        end;
END LOOP;

CLOSE c_emp;
end man_create_fast_mv_ping_all;


/

