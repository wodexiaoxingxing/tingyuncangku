create procedure Insert_Array is
type tab_numbers is table of number; -- 定义数组类型 
lt tab_numbers; -- 定义一个未初始化的数组 
begin
lt := tab_numbers(); -- 初始化一个空数组，无任何元素 
lt.extend; -- 扩展数组，扩展一个元素 
lt(1) := 100; -- 数组下标从1开始 
lt.extend(3); -- -- 扩展数组，扩展3个元素 
lt(2) := 1002; 
lt(3) := 1003; 
lt(4) := 1004; 
-- lt(5) := 0; 这里将不允许，因为不存在此下标之元素 
for i in 1..lt.count loop -- lt.count 取得数组元素个数 
dbms_output.put_line(lt(i)); 
end loop;
end Insert_Array;


/

