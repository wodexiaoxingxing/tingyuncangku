create procedure calc_cdn_task authid current_user is

  sqlStr    varchar2(4000);
  errorDesc varchar2(4000);
  expireDate date:= trunc(sysdate,'dd');
begin
  create_procedure_log('calc_cdn_task', 'begin', 'run');
  --循环，查寻出所有的cdn调优任务的主任务
  for cdnTask in (select k.id as id,k.expire as expire,k.status as status from nb_m_task k where k.id in (
                           select t.binding_task_id from nb_m_task t where t.type = 1 and t.task_option ='S'and t.binding_task_id is not null and t.expire > sysdate -1 and status =1)
                             and ((k.status =1 and k.expire < sysdate -1) or k.status =0)
                    ) loop
  begin
  if cdnTask.status = 1 then
      begin
          expireDate:=cdnTask.expire;
          sqlStr :='update nb_m_task set expire=:expireDate,mtime =sysdate where status =1 and expire > sysdate -1 and binding_task_id = '||cdnTask.id;
            execute immediate sqlStr using expireDate;
          commit;
          create_procedure_log('calc_cdn_task',sqlStr,'logger');     
        exception when others then
          errorDesc := sqlerrm||',tableName:nb_m_task' || sqlStr ;
          create_procedure_log('calc_cdn_task',errorDesc,'warning'); 
       end;   
  else 
     begin
          sqlStr :='update nb_m_task set status = 0,mtime = sysdate where status =1 and expire > sysdate -1 and binding_task_id = '||cdnTask.id;
          execute immediate sqlStr;
          commit;
          create_procedure_log('calc_cdn_task',sqlStr,'logger');     
        exception when others then
          errorDesc := sqlerrm||',tableName:nb_m_task' || sqlStr ;
          create_procedure_log('calc_cdn_task',errorDesc,'warning'); 
       end;   
  end if;     
  end;
  end loop;
  create_procedure_log('calc_cdn_task', 'end', 'run');
end calc_cdn_task;
/

