create PROCEDURE update_nb_page_1759_noise is 
sqlStr VARCHAR2(4000);
BEGIN
create_procedure_log('update_nb_page_1759_noise','begin','message');
for item in (select id,ts_total,task_id from nb_page_1759 t where t.task_id in  (58365)
and tm_base >= SYSDATE - 1/12 and ts_client > 2000 and is_noise = 0) loop
BEGIN
 create_procedure_log('update_nb_page_1759_noise','task_id:'||item.task_id,'message');

 sqlStr  := 'update nb_page_1759 set is_noise = 99 where id = :id';
 execute immediate   sqlStr using item.id;
 sqlStr  := 'insert into nb_page_1759_noise_tmp (page_id) values (:id)';
 execute immediate   sqlStr using item.id;
 commit;
 exception when  others then
    sqlStr := 'task_id ' || item.task_id || ' Error Code:'|| sqlcode || '  Sql:' ;
    create_procedure_log('update_nb_page_1759_noise',sqlStr,'error');
 end;
END loop;
create_procedure_log('update_nb_page_1759_noise','end','run');
END update_nb_page_1759_noise;
/

