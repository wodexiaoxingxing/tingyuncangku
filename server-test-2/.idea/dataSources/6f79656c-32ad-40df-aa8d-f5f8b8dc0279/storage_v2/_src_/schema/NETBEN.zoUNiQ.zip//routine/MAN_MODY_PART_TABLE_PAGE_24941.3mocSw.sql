create PROCEDURE          "MAN_MODY_PART_TABLE_PAGE_24941" 
    ( TAB_OWNER VARCHAR2 ,
      TAB_NAME  VARCHAR2
    )
    IS
        QUERY_STR  VARCHAR2(4000);
        Q_STR  VARCHAR2(4000);
        P_NAME   VARCHAR2(40);        --分区名字
        T_NAME   VARCHAR2(40);
        STR1     VARCHAR2(40);
        ERR_LOG     VARCHAR2(100);
        TDAY     DATE;
        TDAY2     DATE;
        TSTARTDAY   DATE;
        C INT;
        SPRE VARCHAR2(40);  ---文件名前缀

    BEGIN


DBMS_OUTPUT.PUT_LINE('Verify whether can be defined online ');
DBMS_REDEFINITION.CAN_REDEF_TABLE(TAB_OWNER,TAB_NAME,2);
DBMS_OUTPUT.PUT_LINE( TAB_NAME||'can be defined online ');
T_NAME := TAB_NAME;
 /*   (  "CDATE" DATE,   "HOST_ID" NUMBER,   "CITY_ID" NUMBER,   "ISP_ID" NUMBER,   "SPEED_ID" NUMBER,  "IS_NOISE" NUMBER,   "STATUS" NUMBER,   "CNUM" NUMBER   )*/
QUERY_STR :=  'CREATE TABLE '
           ||'NETBEN.T_NEW' --注意用户属性！
           ||'( id NUMBER primary key, tran_id NUMBER, task_id NUMBER, city_id NUMBER, isp_id NUMBER, net_speed_id NUMBER, tm_base DATE, tm_day DATE, tm_hour DATE, tm_half_hour DATE, probe_ip NUMBER, page_seq NUMBER, error_code NUMBER, error_path VARCHAR2(256), cont_err_total NUMBER, cont_ele_total NUMBER, redirect_total NUMBER, point_total NUMBER default 1, byte_total NUMBER, rate_download NUMBER, dest_ip VARCHAR2(39), ping_result VARCHAR2(512), tracert_result VARCHAR2(512), http_server VARCHAR2(256), http_via VARCHAR2(256), ts_total NUMBER, ts_page_base NUMBER, ts_dns NUMBER, ts_connect NUMBER, ts_ssl NUMBER, ts_redirect NUMBER, ts_request NUMBER, ts_first_packet NUMBER, ts_client NUMBER, ts_contents NUMBER, ts_extra_data NUMBER, ts_open_page NUMBER, ts_user NUMBER, ts_network NUMBER, ts_close NUMBER, is_noise NUMBER, nslookup_result VARCHAR2(512), script_error_result VARCHAR2(2000), dns_server VARCHAR2(128), byte_page_base NUMBER, rate_download_page_base NUMBER, num_first_elem NUMBER, byte_first NUMBER, num_host NUMBER, ts_dns_total NUMBER, num_connect NUMBER, ts_connect_total NUMBER, num_dom NUMBER, num_iframe NUMBER, num_no_compress_elem NUMBER, num_no_expire_elem NUMBER, num_no_etag_elem NUMBER, percent_cpu NUMBER, percent_cpu_task NUMBER, percent_mem NUMBER, percent_mem_task NUMBER, rate_avg NUMBER, version_id NUMBER, os_ver_id NUMBER, bs_id NUMBER, bs_ver_id NUMBER, flash_ver VARCHAR2(64), log_msg_result VARCHAR2(512))'
           ||'PARTITION BY RANGE (tm_base)'  --定义分区字段
           ||'(PARTITION '
           ||T_NAME
           ||'_111113 VALUES LESS THAN (TO_DATE(''2011-11-13'', ''YYYY-MM-DD'')),PARTITION '
           ||T_NAME
           ||'_111120 VALUES LESS THAN (TO_DATE(''2011-11-20'', ''YYYY-MM-DD'')),PARTITION '
           ||T_NAME
           ||'_111127 VALUES LESS THAN (TO_DATE(''2011-11-27'', ''YYYY-MM-DD'')),PARTITION '
           ||T_NAME
           ||'_111204 VALUES LESS THAN (TO_DATE(''2011-12-04'', ''YYYY-MM-DD'')),PARTITION '
           ||T_NAME
           ||'_111211 VALUES LESS THAN (TO_DATE(''2011-12-11'', ''YYYY-MM-DD'')),PARTITION '
           ||T_NAME
           ||'_111218 VALUES LESS THAN (TO_DATE(''2011-12-18'', ''YYYY-MM-DD'')),PARTITION '
           ||T_NAME
           ||'_111225 VALUES LESS THAN (TO_DATE(''2011-12-25'', ''YYYY-MM-DD'')),PARTITION '
           ||T_NAME
           ||'_120101 VALUES LESS THAN (TO_DATE(''2012-01-01'', ''YYYY-MM-DD'')),PARTITION '
           ||T_NAME
           ||'_120108 VALUES LESS THAN (TO_DATE(''2012-01-08'', ''YYYY-MM-DD'')),PARTITION '
           ||T_NAME
           ||'_120115 VALUES LESS THAN (TO_DATE(''2012-01-15'', ''YYYY-MM-DD'')),PARTITION '
           ||T_NAME
           ||'_120122 VALUES LESS THAN (TO_DATE(''2012-01-22'', ''YYYY-MM-DD'')),PARTITION '
           ||T_NAME
           ||'_120129 VALUES LESS THAN (TO_DATE(''2012-01-29'', ''YYYY-MM-DD'')),PARTITION '
           ||T_NAME
           ||'_120205 VALUES LESS THAN (TO_DATE(''2012-02-05'', ''YYYY-MM-DD'')),PARTITION '
           ||T_NAME
           ||'_120212 VALUES LESS THAN (TO_DATE(''2012-02-12'', ''YYYY-MM-DD'')),PARTITION '
           ||T_NAME
           ||'_120219 VALUES LESS THAN (TO_DATE(''2012-02-19'', ''YYYY-MM-DD'')),PARTITION '
           ||T_NAME
           ||'_120226 VALUES LESS THAN (TO_DATE(''2012-02-26'', ''YYYY-MM-DD'')),PARTITION '
           ||T_NAME
           ||'_120304 VALUES LESS THAN (TO_DATE(''2012-03-04'', ''YYYY-MM-DD'')))';

SELECT COUNT(*) INTO C FROM USER_TABLES WHERE TABLE_NAME='T_NEW' ;
IF C=1 THEN
EXECUTE IMMEDIATE ('DROP TABLE NETBEN.T_NEW PURGE');
DBMS_OUTPUT.PUT_LINE('DROP TABLE NETBEN.T_NEW PURGE');
END IF;

DBMS_OUTPUT.PUT_LINE(QUERY_STR);
EXECUTE IMMEDIATE (QUERY_STR);

DBMS_OUTPUT.PUT_LINE('Start define table online!');
DBMS_REDEFINITION.START_REDEF_TABLE(TAB_OWNER, TAB_NAME, 'T_NEW',null,2);
DBMS_OUTPUT.PUT_LINE('Define table online complete');

dbms_redefinition.sync_interim_table(TAB_OWNER, TAB_NAME, 'T_NEW');
--此处增加索引和约束
DBMS_OUTPUT.PUT_LINE('2222222222222');
DBMS_REDEFINITION.FINISH_REDEF_TABLE(TAB_OWNER, TAB_NAME, 'T_NEW');
DBMS_OUTPUT.PUT_LINE('33333333333333333333333');
 DBMS_OUTPUT.PUT_LINE('DROP TABLE T_NEW PURGE');
 EXECUTE IMMEDIATE ('DROP TABLE T_NEW PURGE');
/**/
end MAN_MODY_PART_TABLE_PAGE_24941;


/

