create PROCEDURE          "IN_TOP_ERROR_PAGE" (
  tablestr in varchar2
)  authid current_user
is
  sqlStr varchar2(4000);
  v_error_desc varchar2(4000);
  startDate date;
  endDate date;
begin
  create_procedure_log('in_top_error_page','in_top_error_page '|| tablestr||' begin','message');
  startDate := trunc(sysdate-1,'dd');
  endDate := trunc(sysdate,'dd');
  --删除指定日期内的所有生成数据，防止重复生成数据
  sqlStr:='delete nb_top_error where table_str=:tbstr and tm_day >= :sdate and tm_day <:edate and error_type = 3';
  execute immediate sqlStr using tablestr,startDate,endDate;
  commit;
    --开始生成页面错误数据
    sqlStr:='insert into nb_top_error (task_id,tm_day,page_seq,error_code,error_count,point_total,error_type,table_str)
                select s2.task_id,s2.tm_day,s2.page_seq,s2.error_code,s2.error_count,s2.point_total,3,:tableStr
                   from(
                     select s1.task_id,s1.page_seq,s1.tm_day,s1.error_code,s1.error_count,
                        sum(point_total) over(PARTITION BY s1.task_id, s1.page_seq, s1.tm_day) as point_total
                     from
                         (select p.task_id,p.page_seq,trunc(p.tm_base,''dd'') as tm_day,p.error_code,
                             sum(case when error_code >600000 then p.point_total else 0 end) as error_count,
                             sum(point_total) as point_total
                          from nb_page_'||tablestr||' p
                          where (tm_base between :startDate and :endDate) and p.is_noise = 0
                          group by p.task_id, p.page_seq,p.error_code, trunc(p.tm_base,''dd'')
                          ) s1
                      ) s2
                    where s2.error_code > 600000
                 ';
    execute immediate sqlStr using tablestr,startDate,endDate;
    commit;

    
    create_procedure_log('in_top_error_page','in_top_error_page'|| tablestr ||' end','message');
    --如果创建序列失败，则显示出失败代码
    exception when  others then
        v_error_desc := 'Error :'|| sqlerrm || '  table:' ||tablestr;
        dbms_output.put_line(v_error_desc);
        create_procedure_log('in_top_error_page',v_error_desc,'error');
end in_top_error_page;


/

