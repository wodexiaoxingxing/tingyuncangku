create procedure del_mt_page_data is

sqlStr varchar2(4000);
currDate date := trunc(sysdate,'dd');

begin
  
  --处理删除分区，将所有90天以前的分区均删除
  for tab in(select table_name from user_tables where table_name like 'MT_PAGE_%')
  loop
    begin
       sqlStr:='delete from '||tab.table_name;
       --dbms_output.put_line(sqlStr);
       execute immediate sqlStr;
       commit;
    exception
       when others then
       create_procedure_log('del_mt_page_data','dropError,sql:'||sqlStr||','||sqlerrm,'error');
    end;
  end loop;
  
end del_mt_page_data;


/

