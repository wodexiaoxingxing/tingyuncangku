create PROCEDURE CALC_POINT_COUNT AS 
BEGIN
  insert into nb_m_probe_count(city_id,isp_id,speed_id,member_id,member_type,mct,ct,ctime)
  select *
    from (select city_id, isp_id, speed_id,member_id,member_type, count(*) mct, sum(count(*)) over(partition by city_id, isp_id, speed_id) ct , sysdate ctime
            from (select *
                    from nb_m_proberuntime_log
                   where time_stamp =
                         (select max(time_stamp)
                            from nb_m_proberuntime_log
                           where time_stamp > sysdate - 1 / 24 / 3)
                     and time_stamp > sysdate - 1 / 24 / 3)
           group by city_id, isp_id, speed_id,member_id,member_type)
   order by ct desc, mct desc, city_id, isp_id ;
END CALC_POINT_COUNT;
/

