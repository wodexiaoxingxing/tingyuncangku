create procedure MAN_CREATE_INDEX_ET authid current_user is
  sqlStr  varchar2(8000);
  ---------------- 主变量 ---------------------------------------------------------------------------

  taskId  varchar2(128);
  c int;
begin
     -- 2.取出所有已经建立分区的et表后缀，开始循环 注：无分区的表不处理
   for et in  (SELECT distinct substr(t.table_name,7) task
               from user_tables t
               where table_name like 'NB_ET_5330'
               AND table_name NOT like 'NB_ET_URL%'
               AND table_name NOT like 'NB_ETT%'
               AND table_name NOT like 'NB_ETD%')
     loop
 begin
        taskid := et.task;

SELECT COUNT(*) INTO C FROM USER_INDEXES WHERE INDEX_NAME= 'IDX_ET_TCI_'||taskid ;
IF C<1 THEN
    --创建索引
    sqlStr:='create INDEX IDX_ET_TCI_'||taskid||' on NB_ET_'||taskid||' (tm_base,city_id,isp_id)    LOCAL parallel 4  tableSpace  NETBEN_IND nologging';

--DBMS_OUTPUT.PUT_LINE(sqlStr);
execute   immediate   sqlStr;
END IF;
-- CREATE INDEX  IDX_ET_PID_23862  ON  NB_ET_23862  ( PAGE_ID )  NOLOGGING    TABLESPACE  NETBEN_IND   LOCAL ;
SELECT COUNT(*) INTO C FROM USER_INDEXES WHERE INDEX_NAME= 'IDX_ET_PID_'||taskid ;
IF C<1 THEN
    --创建索引
    sqlStr:='create INDEX IDX_ET_PID_'||taskid||' on NB_ET_'||taskid||' (PAGE_ID)   LOCAL parallel 4  tableSpace  NETBEN_IND nologging';

--DBMS_OUTPUT.PUT_LINE(sqlStr);
execute   immediate   sqlStr;
--  CREATE INDEX  IDX_ET_UID_23862  ON  NB_ET_23862  ( URL_ID ,  TM_BASE )
END IF;

SELECT COUNT(*) INTO C FROM USER_INDEXES WHERE INDEX_NAME= 'IDX_ET_UID_'||taskid ;
IF C<1 THEN
    --创建索引
    sqlStr:='create INDEX IDX_ET_UID_'||taskid||' on NB_ET_'||taskid||' (URL_ID ,  TM_BASE)    LOCAL parallel 4  tableSpace  NETBEN_IND nologging';


--DBMS_OUTPUT.PUT_LINE(sqlStr);
execute   immediate   sqlStr;
END IF;


    exception when  others then
      MON_PC_ERROR_LOG('MAN_CREATE_INDEX_ET',sqlerrm,taskId);
     DBMS_OUTPUT.PUT_LINE(taskId||' ERROR!');
  end;
      end loop;

end MAN_CREATE_INDEX_ET;


/

