create procedure probe_summary_hour authid current_user is
    total number;
    dt    date := sysdate;

begin
    create_procedure_log('probe_summary_hour', '改用analyzer计算', 'begin');
--     create_procedure_log('probe_summary_hour',
--                          'probe_summary_hour begin',
--                          'begin');

--     select count(1)
--     into total
--     from nb_m_proberuntime_log_mobile
--     where time_stamp between (trunc(dt - 1/24, 'hh') + 1/86400) and
--               trunc(dt, 'hh');
--
--     if total > 0 then
--         insert into nb_m_probe_summary_hour
--         (host_id,
--          company_id,
--          user_name,
--          online_time,
--          system_flows,
--          app_flows,
--          app_wifi_flows,
--          sms_success_number,
--          total_dsp,
--          total_col,
--          calc_date,
--          member_id)
--         select p.host_id,
--                p.company_id,
--                p.user_name,
--                p.online_time,
--                p.system_flows,
--                p.app_flows,
--                p.app_wifi_flows,
--                p.sms_success_number,
--                DECODE(td.total_dsp, null, 0, td.total_dsp) as total_dsp,
--                DECODE(tc.total_col, null, 0, tc.total_col) as total_col,
--                p.calc_date,
--                member_id
--         from (select host_id,
--                      company_id,
--                      user_name,
--                      member_id,
--                      count(1) * 10 as online_time,
--                      sum(traffic_total) as system_flows,
--                      sum(traffic_app) as app_flows,
--                      sum(traffic_wifi_app) as app_wifi_flows,
--                      sum(sms_success_number) as sms_success_number,
--                      trunc(sysdate - 1/24, 'hh') as calc_date
--               from nb_m_proberuntime_log_mobile
--               where time_stamp between (trunc(sysdate - 1/24, 'hh') + 1/86400) and trunc(sysdate, 'hh')
--               group by host_id, company_id, user_name, member_id) p
--                  left outer join (select host_id, count(1) as total_dsp
--                                   from nb_m_ddc_log_dsp_mobile
--                                   where tm_base between trunc(sysdate - 1/24, 'hh') and (trunc(sysdate, 'hh') - 1/86400)
--                                   group by host_id) td
--                                  on p.host_id = td.host_id
--                  left outer join (select host_id, count(1) as total_col
--                                   from nb_m_ddc_log_col
--                                   where speed_id <= 4
--                                     and tm_base between trunc(sysdate - 1/24, 'hh') and (trunc(sysdate, 'hh') - 1/86400)
--                                   group by host_id) tc
--                                  on p.host_id = tc.host_id;
--         commit;

--     end if;
--     create_procedure_log('probe_summary_hour',
--                          'probe_summary_hour end',
--                          'end');

exception
    when others then
        --dbms_output.put_line(sqlerrm);
        create_procedure_log('probe_summary_hour', sqlerrm, 'error');

end probe_summary_hour;
/

