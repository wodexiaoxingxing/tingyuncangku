create procedure NB_P_NODE_SCORE is
  currDate date := sysdate;
  sqlStr   varchar2(4000);
begin
  
  --首先删除可能重复的数据
  sqlStr := 'delete from nb_m_score_balance where cdate = :cdate and reason = :reason';
  execute immediate sqlStr  using trunc(currDate - 1, 'dd'), 'DP';
  commit;
  --开始生成数据，根据不同的客户端类型分别生成0pc,1wifi,2手机网络相关数据
  for i in 0 .. 2 loop
    sqlStr := '
        INSERT INTO NB_M_SCORE_BALANCE
          (ID,
           MEMBER_ID,
           CDATE,
           SCORE,
           SCORE_BALANCE,
           DATA_POINTS,
           DATA_POINTS_TOTAL,
           REASON,
           net_id)
          SELECT SCORE_BAL_ID_SEQ.Nextval,
                 MEMBER_ID,
                 DD,
                 SCORE,
                 SCORE_BALANCE,
                 DP,
                 DP_TOTAL,
                 ''DP'',
                 net_id
            FROM (SELECT MEMBER_ID,
                         DD,
                         SCORE,
                         SUM(SCORE) OVER(partition by member_id ORDER BY DD) + SCORE_BAL SCORE_BALANCE,
                         DP,
                         SUM(DP) OVER(partition by member_id ORDER BY DD) + DP_TO DP_TOTAL,
                         net_id
                    FROM (SELECT T.member_id,
                                 trunc(T.CDATE, ''DD'') DD,
                                 SUM(T.SCORE) SCORE,
                                 SUM(T.DATA_POINTS) DP,
                                 case when T1.score_balance is null then 0 else t1.SCORE_BALANCE end SCORE_BAL,
                                 case when T1.data_Points_total is null then 0 else t1.DATA_POINTS_TOTAL end DP_TO,
                                 t.net_id
                            FROM NB_MBR_SCORE T, NB_V_SCORE_BALANCE_MAX T1
                           WHERE T.MEMBER_ID = T1.MEMBER_ID(+)
                             AND T.CDATE > = :cd
                             AND T.CDATE < :ld
                             AND T.net_id = :netid
                           GROUP BY T.member_id,
                                    TRUNC(T.CDATE, ''DD''),
                                    T1.score_balance,
                                    T1.data_Points_total,
                                    t.net_id
                           ORDER BY member_id, DD)
                   group BY MEMBER_ID, DD, SCORE, DP, SCORE_BAL, DP_TO, net_id
                   ORDER BY DD, MEMBER_ID)
          ';
    execute immediate sqlStr  using trunc(currDate - 1, 'dd'), trunc(currDate,'dd'), i;
    commit;
  end loop;
end NB_P_NODE_SCORE;


/

