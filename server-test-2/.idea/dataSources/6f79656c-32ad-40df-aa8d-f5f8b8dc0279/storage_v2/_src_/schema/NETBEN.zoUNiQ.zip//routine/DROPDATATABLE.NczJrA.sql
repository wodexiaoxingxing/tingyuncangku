create PROCEDURE dropDataTable
(
       tableStr IN varchar2
) authid current_user
is
  sqlStr  varchar2(4000);  
  c      int;
BEGIN
    -- EMPTY PROCEDURE
    execute immediate 'select 1 from dual';
END dropDataTable;
/

