create PROCEDURE "IN_TOP_EL_ERROR" (
  calcDate in date,
  taskId in number
) authid current_user
is
  sqlStr  varchar2(4000);
  s number;
  errorDesc varchar2(4000);
  tableStr number;
begin
   begin
      -- 如果日期是当天，不计算直接返回
      if (trunc(calcDate,'dd') = trunc(sysdate,'dd')) then DBMS_OUTPUT.PUT_LINE('当天不行'); return; end if;
      
      -- 从完成日志表中查看数据是否已经生成，如果生成则不再处理
      select count(*) into s from nb_top_done where task_id = taskId and tm_day = calcDate;
      if (s>0) then DBMS_OUTPUT.PUT_LINE('已经生成数据'); return; end if;
      
      -- 从正在执行日志表中查看数据是否已经生成，如果生成则不再处理
      select count(*) into s from nb_top_run where task_id = taskId and tm_day = calcDate;
      if (s>0) then DBMS_OUTPUT.PUT_LINE('正在生成数据'); return; end if;
      
      -- 删除指定日期内的所有生成数据，防止重复生成数据
      -- 开始计算
      sqlStr:='delete nb_top_elem_error where task_id = :tid and tm_day = :cdate';
      execute immediate sqlStr using taskId,calcDate;
      commit;
      -- 生成执行状态记录
      sqlStr:='insert into nb_top_run(tm_day,task_id,ctime)values(:cdate,:tid,sysdate)';
      execute immediate sqlStr using calcDate,taskId;
      commit;
      
      select table_str into tableStr from nb_m_agreement where id =(select agreement_id from nb_m_task where id=taskId);
      create_procedure_log('in_top_error','tableStr:' || tableStr || ' taskId:' || taskId || '  begin','run');
      
      
      sqlStr:='insert into nb_top_elem_error(tm_day,task_id,url_id,url,domain_id,domain,error_code,error_count,point_total,table_str,ctime)
               select s1.tm_day,'||taskId ||',s1.url_id,e.url,s1.domain_id,d.value,s1.error_code,s1.error_count,s1.point_total,'||tableStr||',sysdate
                from
                  (
                    select
                       tm_day,
                       url_id,
                       domain_id,
                       error_code,
                       sum(point_total) as error_count,
                       point_all as point_total
                    from
                      (select trunc(tm_base,''dd'') as tm_day,
                             url_id,
                             domain_id,
                             error_code,
                             point_total,
                             sum(point_total)over(partition by url_id,domain_id) as point_all
                       from nb_et_'||taskId||'
                      where
                         tm_base >= :sdate  and tm_base < :edate)
                    where error_code >600000
                    group by
                      url_id,
                      domain_id,
                      error_code,
                      tm_day,
                      point_all
                 )s1,
                   nb_el_url_'||tableStr||' e,
                   (select id,value from nb_el_domain_0
                       union all select id,value from nb_el_domain_1 
                       union all select id,value from nb_el_domain_2
                       union all select id,value from nb_el_domain_3) d
                 where s1.url_id = e.id and s1.domain_id = d.id
              ';
      execute immediate sqlStr using calcDate,calcDate+1;
      commit;
      -- 如果正常完成，则记录已经成功完成
      sqlStr:='insert into nb_top_done(tm_day,task_id,ctime)values(:cdate,:tid,sysdate)';
      execute immediate sqlStr using calcDate,taskId;
      commit;
      
      create_procedure_log('in_top_error','tableStr:' || tableStr || ' taskId:' || taskId || '  end','run');
      --如果创建序列失败，则显示出失败代码
      exception when  others then
          errorDesc := 'tableStr:' || tableStr || ' taskId:' || taskId ||',' || sqlerrm;
          --DBMS_OUTPUT.PUT_LINE(errorDesc);
          create_procedure_log('in_top_error',errorDesc,'error');
      end;    
  -- 无论正常完成还是出现异常,将执行状态记录清除
  sqlStr:='delete from nb_top_run where tm_day = :cdate and task_id =:tid';
  execute immediate sqlStr using calcDate,taskId;
  commit;
end in_top_el_error;


/

