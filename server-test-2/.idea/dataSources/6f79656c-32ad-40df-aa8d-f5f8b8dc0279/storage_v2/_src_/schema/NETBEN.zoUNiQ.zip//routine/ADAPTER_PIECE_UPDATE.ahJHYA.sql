create PROCEDURE          "ADAPTER_PIECE_UPDATE" authid current_user is
sqlStr varchar2(4000);
v_s number;
v_status number;
begin
--status状态 0计划等待 1正在执行 2成功返回 3返回错误 4  5任务超时未收到数据 
--comp_status状态 0 未完成 1 完成
--首先更新表中记录的状态,计划任务runtime超过了15分钟或立即执行任务ctime超过了30分钟时，且状态为正在执行
--设为超时；设status=5 且error_code = 1;并且完成状态设为 1 完成
sqlStr:='update nb_a_task_piece set status = 5,error_code = 1,comp_status=1
             where status = 1 and 
                  ((runtime is null and ctime < sysdate - 1/(24*2)) or runtime < sysdate - 1/(24*2))';
execute immediate sqlStr;
commit;
--然后将一些可能已经上传了数据，但数据是错误的，等待继续上传数据的任务，如果超时设置成完成
sqlStr:='update nb_a_task_piece set comp_status = 1
             where comp_status = 0 and 
                  ((runtime is null and ctime < sysdate - 1/(24*2)) or runtime < sysdate - 1/(24*2))';
execute immediate sqlStr;
commit;

--将这些超时的任务次数扣除
sqlStr:='insert into nb_a_count_tran value 
             select seq_nb_a_count.nextval,agreement_id,task_id,id,5,1,sysdate
                 from nb_a_task_piece where error_code = 1 and id not in(select tp_id from nb_a_count_tmp)';
execute immediate sqlStr;
commit;
--为了防止可能会被重复扣除，必须将已经扣除的做记录存放到一个临时表中 nb_a_count_tmp
sqlStr:='insert into nb_a_count_tmp value 
             select id
                 from nb_a_task_piece where error_code = 1 and id not in(select tp_id from nb_a_count_tmp)';
execute immediate sqlStr;
commit;

--将所有全部完成的数据从nb_a_task_piece 移到 nb_a_result 全部完成的数据是指所有字任务的状态均不是0和1
sqlStr:='insert into nb_a_result value
             select * from nb_a_task_piece where 
                  task_id in(
                      select task_id from nb_a_task_piece where task_id not in(
                           select distinct task_id from nb_a_task_piece where comp_status = 0
                      )
                   )';
execute immediate sqlStr;
commit;
--移走临时表中的tp_id
sqlStr:='delete from nb_a_count_tmp where tp_id in(
             select id from nb_a_task_piece where 
                  task_id in(
                      select task_id from nb_a_task_piece where task_id not in(
                           select distinct task_id from nb_a_task_piece where comp_status = 0
                      )
                   ))';
execute immediate sqlStr;
commit;
--将这些任务设置状态
for task in (select distinct task_id as id from nb_a_task_piece where task_id not in(
                           select distinct task_id from nb_a_task_piece where comp_status = 0
                      )) loop
   select count(*) into v_s from nb_a_task_piece where task_id = task.id and status != 2 ;
   if v_s > 0 then
       v_status:=3;
   else
       v_status:=2;
   end if;
   sqlStr:='update nb_a_task set run_status = :status where id = :id'; 
   execute immediate sqlStr using v_status,task.id;
end loop;
commit;
--删除piece中的记录
sqlStr:='delete from nb_a_task_piece where 
             task_id in(
                select task_id from nb_a_task_piece where task_id not in(
                    select distinct task_id from nb_a_task_piece where comp_status = 0
                )
              )';                  
execute immediate sqlStr;
commit;
end adapter_piece_update;


/

