create procedure createMobSmsTable(tableStr IN varchar2) authid current_user is
  sqlStr varchar2(4000);
begin
  --create sms sequence 
  sqlStr := 'create sequence SEQ_NB_MOB_SMS_ID_' || tableStr || ' minvalue 1 maxvalue 9999999999999999999999999 start with 1 increment by 1 cache 500';
  execute immediate sqlStr;

  sqlStr := 'create table NB_MOB_SMS_' || tableStr || '
  (
    ID                NUMBER,
    TASK_ID           NUMBER,
    PAGE_SEQ          NUMBER,
    CITY_ID           NUMBER,
    ISP_ID            NUMBER,
    NET_SPEED_ID      NUMBER,
    TM_BASE           DATE,
    PROBE_IP          NUMBER,
    MEMBER_ID         NUMBER,
    DNS_SERVER        VARCHAR2(128),
    ERROR_CODE        NUMBER,
    DEST_IP           VARCHAR2(39),
    DEST_CITY_ID      NUMBER,
	DEST_ISP_ID       NUMBER,
    TS_TOTAL          NUMBER,      
    TS_PING_START     NUMBER,
    TS_PING_MAX       NUMBER,
    TS_PING_MIN       NUMBER,
    PING_PACKET_LOST  NUMBER,
    PING_RESULT       VARCHAR2(512),
    IS_NOISE          NUMBER,
    POINT_TOTAL       NUMBER default 1,
    TRACERT_RESULT    VARCHAR2(512),
    NSLOOKUP_RESULT   VARCHAR2(512),
    CTIME             DATE       
  ) pctfree 0
  tablespace NETBEN_BG';
  execute immediate sqlStr;

  sqlStr := 'create index IN_MOB_SMS_ID_' || tableStr || ' on NB_MOB_SMS_' || tableStr || ' (ID) tableSpace NETBEN_IDX_NEW nologging';
  execute immediate sqlStr;

  sqlStr := 'create index IN_MOB_SMS_' || tableStr || ' on NB_MOB_SMS_' || tableStr || ' (TM_BASE,TASK_ID) tableSpace NETBEN_IDX_NEW nologging';
  execute immediate sqlStr;
  
end createMobSmsTable;
/

