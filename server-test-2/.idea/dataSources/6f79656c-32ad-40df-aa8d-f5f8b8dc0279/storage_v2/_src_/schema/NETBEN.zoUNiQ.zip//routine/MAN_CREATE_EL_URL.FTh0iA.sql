create procedure man_create_el_url authid current_user is
sqlStr varchar2(10000);
v_error_desc varchar2(10000);
  v_s number;
  begin

     for str in  (
select  DISTINCT ( CASE  WHEN TABLE_NAME  LIKE  'NB_PAGE%' THEN  SUBSTR(table_name,8) when TABLE_NAME  LIKE  'NB_STREAM%' THEN  SUBSTR(table_name,10) end)as table_str
from user_tables where table_name like 'NB_PAGE%' OR table_name like 'NB_STREAM%' order by 1)
 
    loop
        begin
                select count(*) into v_s from user_tables t where t.table_name = 'NB_EL_URL'||str.table_str;
               if v_s < 1 then
                  sqlStr :=
                           'create table NB_EL_URL'||str.table_str||'
                           (
                             id    NUMBER,
                             url   VARCHAR2(4000),
                             ctime DATE
                           )

                           TABLESPACE "NETBEN"
                           PARTITION BY RANGE (ctime)
                          (
                          PARTITION "PART_EL_URL'||str.table_str||'_140126"  VALUES LESS THAN (TO_DATE(''2014-02-02 00:00:00'', ''SYYYY-MM-DD HH24:MI:SS'', ''NLS_CALENDAR=GREGORIAN'')),
                          PARTITION "PART_EL_URL'||str.table_str||'_140202"  VALUES LESS THAN (TO_DATE(''2014-02-09 00:00:00'', ''SYYYY-MM-DD HH24:MI:SS'', ''NLS_CALENDAR=GREGORIAN'')),
                          PARTITION "PART_EL_URL'||str.table_str||'_140209"  VALUES LESS THAN (TO_DATE(''2014-02-16 00:00:00'', ''SYYYY-MM-DD HH24:MI:SS'', ''NLS_CALENDAR=GREGORIAN'')) ,
                          PARTITION "PART_EL_URL'||str.table_str||'_140216"  VALUES LESS THAN (TO_DATE(''2014-02-23 00:00:00'', ''SYYYY-MM-DD HH24:MI:SS'', ''NLS_CALENDAR=GREGORIAN''))
                           ) '
                          ;
                 execute immediate sqlStr;
               --    DBMS_OUTPUT.PUT_LINE(sqlStr);

                    sqlStr :=
                          'create table NB_ELT_URL'||str.table_str||'
                          (
                            task_id NUMBER,
                            id      NUMBER,
                            element_url_id integer,
                            ctime   DATE
                          )
                            TABLESPACE "NETBEN"
                            PARTITION BY RANGE (ctime)
                           (
                           PARTITION "PART_ELT_URL'||str.table_str||'_140126"  VALUES LESS THAN (TO_DATE(''2014-02-02 00:00:00'', ''SYYYY-MM-DD HH24:MI:SS'', ''NLS_CALENDAR=GREGORIAN'')),
                           PARTITION "PART_ELT_URL'||str.table_str||'_140202"  VALUES LESS THAN (TO_DATE(''2014-02-09 00:00:00'', ''SYYYY-MM-DD HH24:MI:SS'', ''NLS_CALENDAR=GREGORIAN'')),
                           PARTITION "PART_ELT_URL'||str.table_str||'_140209"  VALUES LESS THAN (TO_DATE(''2014-02-16 00:00:00'', ''SYYYY-MM-DD HH24:MI:SS'', ''NLS_CALENDAR=GREGORIAN'')) ,
                           PARTITION "PART_ELT_URL'||str.table_str||'_140216"  VALUES LESS THAN (TO_DATE(''2014-02-23 00:00:00'', ''SYYYY-MM-DD HH24:MI:SS'', ''NLS_CALENDAR=GREGORIAN''))
                            ) '
                          ;
                     execute immediate sqlStr;
                 --      DBMS_OUTPUT.PUT_LINE(sqlStr);

                   else
                  -- 存在则写警告日志
                  v_error_desc:='table '||str.table_str||' have existed:';
                   dbms_output.put_line(v_error_desc);
                  create_procedure_log('man_create_el_url',v_error_desc,'warning');
              end if;
        exception when  others then
            v_error_desc := str.table_str ||'have error!'||SQLERRM;
            DBMS_OUTPUT.PUT_LINE(v_error_desc);
            create_procedure_log('man_create_el_url',v_error_desc,'str.table_str');
        end;
    end loop;
end man_create_el_url;


/

