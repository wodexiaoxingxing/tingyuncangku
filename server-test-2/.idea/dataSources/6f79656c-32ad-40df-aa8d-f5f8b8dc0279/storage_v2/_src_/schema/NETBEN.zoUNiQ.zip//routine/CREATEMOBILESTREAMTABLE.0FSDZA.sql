create procedure createMobileStreamTable(tableStr IN varchar2) authid current_user is
  sqlStr varchar2(4000);
begin
  -- 创建MOB_STREAM的ID序列
  sqlStr := 'create sequence SEQ_NB_MOB_STREAM_ID_' || tableStr || ' minvalue 1 maxvalue 9999999999999999999999999 start with 1 increment by 1 cache 500';
  execute immediate sqlStr;

  -- 以NB_MOB_STREAM_0为模板创建表
  sqlStr := 'create table NB_MOB_STREAM_' || tableStr || ' pctfree 0 tablespace NETBEN_BG as select * from NB_MOB_STREAM_0 where 1=2 ';
  execute immediate sqlStr;

  sqlStr := 'create index IN_MOB_STREAM_ID_' || tableStr || ' on NB_MOB_STREAM_' || tableStr || ' (ID) tableSpace NETBEN_IDX_NEW nologging';
  execute immediate sqlStr;

  sqlStr := 'create index IN_MOB_STREAM_PERF_' || tableStr || ' on NB_MOB_STREAM_' || tableStr || ' (TM_BASE,TASK_ID) tableSpace NETBEN_IDX_NEW nologging';
  execute immediate sqlStr;

  -- 以NB_MOB_STREAM_RATE_0为模板创建表
  sqlStr := 'create table NB_MOB_STREAM_RATE_' || tableStr || ' pctfree 0 tablespace NETBEN_BG as select * from NB_MOB_STREAM_RATE_0 where 1=2 ';
  execute immediate sqlStr;

  sqlStr := 'create index IN_MOB_STREAM_RATE_PERF_' || tableStr || ' on NB_MOB_STREAM_RATE_' || tableStr || ' (STREAM_ID) tableSpace NETBEN_IDX_NEW nologging';
  execute immediate sqlStr;

end createMobileStreamTable;
/

