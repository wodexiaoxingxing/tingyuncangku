create PROCEDURE "ALTER_EC_ADD_FIELD"
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(4000);
  v_s number;
begin
  for tableName in(select t.table_name as name from user_tables t where regexp_like( t.table_name,'^NB_EC_[0-9]')) loop
  begin

    select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='APPLICATION_ID';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add APPLICATION_ID INTEGER';
        execute   immediate   sqlStr ;
      end if;
      
      select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='APPLICATION_INSTANCE_ID';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add APPLICATION_INSTANCE_ID INTEGER';
        execute   immediate   sqlStr ;
      end if;
      
      select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='TRACE_GUID';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add TRACE_GUID VARCHAR2(512)';
        execute   immediate   sqlStr ;
      end if;
      
      select count(*)  INTO v_s FROM user_tab_columns t where t.table_name = tableName.Name and t.COLUMN_NAME='ACTION_NAME';
      if v_s < 1 then
        sqlStr := 'alter table '||tableName.Name||' add ACTION_NAME VARCHAR2(512)';
        execute   immediate   sqlStr ;
      end if;

    

    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlStr);
        create_procedure_log('alter_et_add_field',v_error_desc,sqlcode);
  end;
  end loop;
end alter_ec_add_field;


/

