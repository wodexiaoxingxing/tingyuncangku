create PROCEDURE          "RP_SNDA_DATA" authid current_user is
sqlStr varchar2(4000);
startDate date;
endDate date;
error_desc varchar2(4000);
begin
startDate := sysdate -1;
endDate := sysdate;
create_procedure_log('rp_snda_data','begin','run');
    --首先删除指定日期的数据
    sqlStr := 'delete from rp_snda_page where tm_day>=:sdate and tm_day < :edate';
    execute immediate sqlStr using trunc(startDate,'dd'),trunc(endDate,'dd');
    commit;

    sqlStr := 'insert into rp_snda_page(data_type,task_id,task_name,tm_day,ts_user,ts_total,rate_download,byte_total,cont_ele_total)
               select 1,p.task_id,t.name,
                   trunc(tm_base,''dd'') as tm_day,
                   round(avg(p.ts_user),0),
                   round(avg(p.ts_total),0),
                   round(avg(p.rate_download),0),
                   round(avg(p.byte_total),0),
                   round(avg(p.cont_ele_total),0)
               from
                  nb_page_24995 p,rp_snda_task t
               where
                     p.task_id = t.id
                 and p.is_noise = 0
                 and p.tm_base >= :sDate and p.tm_base < :eDate
                 and p.task_id in(select id from rp_snda_task)
                 and p.error_code < 600000
               group by p.task_id,t.name,trunc(tm_base,''dd'')
              ';
      execute immediate sqlStr using trunc(startDate,'dd'),trunc(endDate ,'dd');
      commit;
      sqlStr := 'insert into rp_snda_page(data_type,task_id,task_name,isp_id,isp_name,tm_day,ts_user,ts_total)
               select 2,p.task_id,t.name,p.isp_id,o.name,
                   trunc(tm_base,''dd'') as tm_day,
                   round(avg(p.ts_user),0),
                   round(avg(p.ts_total),0)
               from
                  nb_page_24995 p,rp_snda_task t,nb_m_option o
               where
                     p.task_id = t.id
                 and p.isp_id = o.id
                 and o.id in(16,17,25,26,27)
                 and p.is_noise = 0
                 and p.tm_base >= :sDate and p.tm_base < :eDate
                 and p.task_id in(select id from rp_snda_task)
                 and p.error_code < 600000
               group by p.task_id,t.name,p.isp_id,o.name,trunc(tm_base,''dd'')
              ';
      execute immediate sqlStr using trunc(startDate,'dd'),trunc(endDate ,'dd');
      commit;
      sqlStr := 'insert into rp_snda_page(data_type,task_id,task_name,city_id,city_name,isp_id,isp_name,tm_day,ts_user,ts_total)
               select 3,p.task_id,t.name,p.city_id,l.name,p.isp_id,o.name,
                   trunc(tm_base,''dd'') as tm_day,
                   round(avg(p.ts_user),0),
                   round(avg(p.ts_total),0)
               from
                 nb_page_24995 p,rp_snda_task t,nb_m_option o,nb_m_location l
               where
                     p.task_id = t.id
                 and p.isp_id = o.id
                 and o.id in(16,17,25,26,27)
                 and p.city_id = l.id
                 and p.is_noise = 0
                 and p.tm_base >= :sDate and p.tm_base < :eDate
                 and p.task_id in(select id from rp_snda_task)
                 and p.error_code < 600000
               group by p.task_id,t.name,p.city_id,l.name,p.isp_id,o.name,trunc(tm_base,''dd'')
              ';
      execute immediate sqlStr using trunc(startDate,'dd'),trunc(endDate ,'dd');
      commit;


      create_procedure_log('rp_snda_data','elem begin','run');
      --首先删除指定日期的数据
      sqlStr := 'delete from rp_snda_elem where tm_day>=:sdate and tm_day < :edate';
      execute immediate sqlStr using trunc(startDate,'dd'),trunc(endDate,'dd');
      commit;

      sqlStr:='insert into rp_snda_elem (data_type,task_id,task_name,isp_id,isp_name,tm_day,elem_url,ts_total,byte_total,point_succ)
                  select 1,un.task_id,t.name,un.isp_id,o.name,un.tm_day,un.url,un.perf,un.byte,un.point_succ
                      from (
                           select distinct * from
                                 (
                                  select
                                     row_.*,row_number()over(partition by task_id,isp_id order by perf desc nulls last) as num
                                  from (
                                       select trunc(e.tm_base, ''dd'') tm_day,
                                          e.task_id,
                                          e.isp_id,
                                          (e.url_protocol || ''://'' || e.url_host || '':'' || e.url_port || e.url_path) as url,
                                          round(avg(case when e.error_code > 600000 then null else e.ts_element end),0) as perf,
                                          round(avg(case when e.error_code > 600000 then null else e.byte_total end),0) as byte,
                                          sum(case when e.error_code > 600000 then 0 else 1 end) as point_succ
                                       from
                                          nb_elem_24995 e
                                       where     e.tm_base >= :startDate and e.tm_base < :endDate
                                             and e.task_id in(select id from rp_snda_task)
                                             and element_type is not null
                                             and e.isp_id in(16,17)
                                       group by e.task_id,
                                            e.isp_id,
                                            trunc(e.tm_base, ''dd''),
                                            e.url_protocol || ''://'' || e.url_host || '':'' || e.url_port || e.url_path
                                       )row_
                                  where point_succ > 3
                                )
                              where num <= 10
                            )un,nb_m_task t,nb_m_option o
                        where
                          un.task_id = t.id and un.isp_id = o.id
                   ';
      execute immediate sqlStr using trunc(startDate,'dd'),trunc(endDate ,'dd');
      commit;

      create_procedure_log('rp_snda_data','end','run');
      exception when  others then
        error_desc := 'Error Code:'|| sqlcode ;
        DBMS_OUTPUT.PUT_LINE(sqlcode);
        create_procedure_log('rp_snda_data',error_desc,'error');

end rp_snda_data;


/

