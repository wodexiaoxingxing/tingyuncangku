create PROCEDURE          "INSERT_LONGTERM_MOBAPP_PAGE" authid current_user
is
   sqlStr varchar2(4000);
   startDate date := trunc(sysdate-1,'dd');
   endDate date := trunc(sysdate,'dd');
   errorDesc varchar2(4000);
   v_s number;

begin
create_procedure_log('insert_longterm_mobapp_page','begin','message');
for item in (select substr(t.table_name, 16) as name from user_tables t where t.table_name like 'NB_MOBAPP_PAGE_%') loop
begin
   create_procedure_log('insert_longterm_mobapp_page','tableStr:'||item.name,'message');
   --DBMS_OUTPUT.PUT_LINE(item.name||'  '||to_char(sysdate,'hh24:mi:ss'));
   --判断是否该表已经创建
   select count(*) into v_s from user_tables t where t.table_name = 'LT_MOBAPP_PAGE_'||item.name;
   if (v_s<1) then
       --表不存在，创建新表
        sqlStr:='create table LT_MOBAPP_PAGE_'||item.name||'
		     (
		        TASK_ID        NUMBER NOT NULL,
            PAGE_SEQ       NUMBER NOT NULL,
		        CITY_ID        NUMBER NOT NULL,
		        ISP_ID         NUMBER NOT NULL,
		        NET_SPEED_ID   NUMBER NOT NULL,
            TM_DAY         DATE NOT NULL,
		        ERROR_CODE     NUMBER NOT NULL,
            POINT_TOTAL    NUMBER,
    		    TS_TOTAL       NUMBER ,
            BYTE_TOTAL     NUMBER ,
            BYTE_SENT      NUMBER
		      )';
         execute   immediate   sqlStr;
         --创建索引
	       sqlStr:='create index IN_LT_MOBAPP_PAGE_PERF_'||item.name||' on LT_MOBAPP_PAGE_'||item.name||' (task_id,tm_day,city_id,isp_id,error_code) tableSpace NETBEN_IDX';
	       execute   immediate   sqlStr;
     end if;

  --删除指定日期的长期库中的数据,防止重复数据
  sqlStr := 'delete from lt_mobapp_page_'||item.name||' where tm_day  >=:sDate and tm_day < :eDate';
  execute immediate sqlStr using startDate,endDate;
  commit;

  --从实时库中插入指定日期的数据
  sqlStr:='insert into lt_mobapp_page_'||item.name||'
           (task_id,page_seq,city_id,isp_id,net_speed_id,tm_day,error_code,
            point_total,ts_total,byte_total,byte_sent)
        select
		       task_id,
           page_seq,
		       city_id,
		       isp_id,
		       net_speed_id,
		       trunc(tm_base,''dd'') as tm_day,
           error_code,
		       sum(point_total),
           round(avg(ts_total),0) as ts_total,
           round(avg(byte_total),0) as byte_total,
           round(avg(byte_sent),0) as byte_sent
		    from nb_mobapp_page_'||item.name||'
           where tm_base >= :sDate and  tm_base < :eDate and is_noise = 0
		       group by task_id,
                    page_seq,
		                city_id,
		                isp_id,
		                net_speed_id,
                    trunc(tm_base,''dd''),
		                error_code
		    ';
       execute immediate sqlStr using startDate,endDate;
       commit;
     --删除超时数据，现定为两年
     sqlStr := 'delete from lt_mobapp_page_'||item.name||' where tm_day < sysdate - 2 * 365';
     execute   immediate   sqlStr ;
     commit;

     exception when  others then
        errorDesc := 'Tabel Str ' || item.name || ' Error :'|| sqlerrm  ;
        DBMS_OUTPUT.PUT_LINE(errorDesc);
        create_procedure_log('insert_longterm_mobapp_page',errorDesc,'error');
  end;
end loop;
create_procedure_log('insert_longterm_mobapp_page','end','message');
end insert_longterm_mobapp_page;


/

