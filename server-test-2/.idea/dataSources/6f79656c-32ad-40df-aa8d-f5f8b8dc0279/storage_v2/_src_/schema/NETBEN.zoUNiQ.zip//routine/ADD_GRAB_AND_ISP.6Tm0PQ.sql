create procedure add_grab_and_isp is

declare
cursor a_cursor is select s.GRP_ID, s.CONN_ID from Nb_m_grp_conn s left join NB_M_SPEED_GROUP t on s.CONN_ID = t.ID WHERE t.SPEED_ID = 8;
recordnum number;
TYPE t_cols IS TABLE OF NUMBER;
cols t_cols := t_cols (16,25);
begin
	for k in a_cursor loop
	 for i IN 1..cols.count loop
		SELECT COUNT(*) into recordnum FROM Nb_m_grp_isp T WHERE T.GRP_ID = k.GRP_ID AND T.ISP_ID =cols (i);
		 if recordnum < 1 then				
		 INSERT INTO Nb_m_grp_isp T(T.GRP_ID, T.ISP_ID) VALUES(k.GRP_ID, cols (i));
		 end if;
	 end loop;
 end loop;
end;

declare
begin
   add_grab_and_isp();
end;

declare
TYPE t_ids IS TABLE OF NUMBER;
ids t_ids := t_ids (1285, 1385);
recordnum number;
TYPE t_cols IS TABLE OF NUMBER;
cols t_cols := t_cols (16,17,25,27);
begin
	for k in 1..ids.count loop
	 for i IN 1..cols.count loop
		SELECT COUNT(*) into recordnum FROM Nb_m_grp_isp T WHERE T.GRP_ID = ids (k) AND T.ISP_ID =cols (i);
		 if recordnum < 1 then				
		 INSERT INTO Nb_m_grp_isp T(T.GRP_ID, T.ISP_ID) VALUES(ids (k), cols (i));
		 end if;
	 end loop;
 end loop;
end;
/

