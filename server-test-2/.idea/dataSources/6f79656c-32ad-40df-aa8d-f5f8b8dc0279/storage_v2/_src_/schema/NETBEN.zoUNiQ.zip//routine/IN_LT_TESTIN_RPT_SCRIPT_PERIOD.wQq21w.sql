create procedure in_lt_testin_rpt_script_period(sd date,days number) authid current_user
is
   sqlStr varchar2(4000);
   startDate date ;
   endDate date := trunc(sysdate,'dd');
   errorDesc varchar2(4000);
   v_s number;

begin
create_procedure_log('in_lt_testin_rpt_script_period','begin','run');
if sd is null or days is null then
  startDate:=trunc(sysdate-1,'dd');
  endDate:=startDate+1;
else
  startDate:=trunc(sd,'dd');
  endDate:=startDate+days;
end if;
for item in (select substr(t.table_name, 22) as name from user_tables t where t.table_name like 'NB_TESTIN_RPT_SCRIPT_%') loop
begin
   --判断是否该表已经创建
  create_procedure_log('insert_longterm_testin_rpt_script','tableStr:'||item.name,'run');
   --DBMS_OUTPUT.PUT_LINE(item.name||'  '||to_char(sysdate,'hh24:mi:ss'));
   select count(*) into v_s from user_tables t where t.table_name = 'LT_TESTIN_RPT_SCRIPT_'||item.name;
   if (v_s<1) then
       --表不存在，创建新表
       sqlStr:='create table LT_TESTIN_RPT_SCRIPT_'||item.name||'
		       (
      		 TASK_ID        NUMBER NOT NULL,
		       CITY_ID        NUMBER NOT NULL,
		       ISP_ID         NUMBER NOT NULL,
		       NET_SPEED_ID   NUMBER NOT NULL,
		       time_stamp     DATE NOT NULL,
					 SCRIPT_NO      NUMBER,
           ERROR_CODE     NUMBER,
           POINT_TOTAL    NUMBER,
					 TAKE_UP_TIME   NUMBER,                                 
					 MARK_TIME      NUMBER,                                 
					 MARK_COUNT     NUMBER, 
					 CRASH 					NUMBER
		       )';
         execute   immediate   sqlStr;
         --创建索引
         sqlStr:='create index IN_LT_TESTIN_SCRIPT_PERF_'||item.name||' on LT_TESTIN_RPT_SCRIPT_'||item.name||' (task_id,time_stamp,city_id,isp_id,error_code) tableSpace netben_ind';
	       execute   immediate   sqlStr;
     end if;

  --删除指定日期的长期库中的数据,防止重复数据
  sqlStr := 'delete from LT_TESTIN_RPT_SCRIPT_'||item.name||' where time_stamp  >=:sDate and time_stamp < :eDate';
  execute immediate sqlStr using startDate,endDate;
  commit;

  --从实时库中插入指定日期的数据
  sqlStr:='insert into LT_TESTIN_RPT_SCRIPT_'||item.name||'
           (task_id,city_id,isp_id,net_speed_id,time_stamp,error_code,script_no,
            point_total,TAKE_UP_TIME,MARK_TIME,MARK_COUNT,CRASH)
        select
		       task_id,
		       city_id,
		       isp_id,
		       net_speed_id,
		       trunc(time_stamp,''dd'') as time_stamp,
           error_code,
					 script_no,
		       count(*) as point_total,
           round(avg(TAKE_UP_TIME),0) as TAKE_UP_TIME,
           sum(MARK_TIME) as MARK_TIME,
		       sum(MARK_COUNT) as MARK_COUNT,
					 CRASH
		    from NB_TESTIN_RPT_SCRIPT_'||item.name||'
           where time_stamp >= :sDate and  time_stamp < :eDate and inline = 0
		       group by task_id,
		                city_id,
		                isp_id,
		                net_speed_id,
                    trunc(time_stamp,''dd''),
		                error_code,
										script_no,
										CRASH
		    ';
       execute immediate sqlStr using startDate,endDate;
       commit;
     exception when  others then
        errorDesc := 'Error Code:'|| sqlerrm || '  tablestr:'||item.name;
        create_procedure_log('in_lt_testin_rpt_script_period',errorDesc,'error');
  end;
end loop;
create_procedure_log('in_lt_testin_rpt_script_period','end','run');
end in_lt_testin_rpt_script_period;
/

