create view NB_V_PROBE_REQ_IDC as
select city.name as CITY, loc.location_id AS CITY_ID, sum(86400/t.interval)/24/50 as PROBE_REQ
from nb_m_task t, nb_m_grp_loc loc , nb_m_location city
where t.sla_citys_probes<>0 and t.probgrp_id=loc.grp_id and loc.location_id=city.id
and t.probgrp_id in (
select con.grp_id from nb_m_grp_conn con where con.conn_id=8
)
and t.status=1 and t.expire>sysdate
group by city.name, loc.location_id
order by loc.location_id


/

