create PROCEDURE          "MAN_ALTER_PING_ADD_FIELD_TEMP" 
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(4000);
  v_s number;
begin
  for tableName in(select t.table_name as name from user_tables t where t.table_name like 'NB_PING_%' ) loop
  begin
    create_procedure_log('alter_custom_add_field',tableName.name,'message');
dbms_output.put_line(v_s);
 --   select * from user_cons_columns where  AND
select COUNT(*) INTO V_S from user_tab_columns t where table_name LIKE 'NB_PING_UNKNOWN' and t.COLUMN_NAME='PING_ID'
  IF V_S <1 THEN
        sqlStr := 'alter table '||tableName.Name||'  add  ping_id int';
  --   execute   immediate   sqlStr ;
       dbms_output.put_line(sqlStr);
   END IF;
        sqlStr := 'create index ind_'||tableName.Name||'_pid on '||tableName.Name||'(ping_id) nologging parallel 2 tableSpace NETBEN_IDX';
         dbms_output.put_line(sqlStr);
  --    execute   immediate   sqlStr ;


    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlStr);
        create_procedure_log('alter_custom_add_field',v_error_desc,sqlcode);
  end;
  end loop;
end MAN_alter_ping_add_field_temp;


/

