create TYPE BODY          "HUMAN" as member function get_age return number as
v_months number;
begin
select floor(months_between(sysdate,birthday)/12) into v_months from dual;
return v_months;
end;
end;


/

