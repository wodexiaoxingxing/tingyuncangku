create PROCEDURE          "MY_PROCEDURE" (
  startDate IN date,
  endDate IN date
) authid current_user
is
  sqlStr  varchar2(4000);  
  v_name varchar2(400);
  v_s number;
  v_error_desc varchar2(400);
  CURSOR c_emp IS SELECT substr(t.object_name,8) FROM all_objects t where t.object_name like 'NB_PAGE_%';
begin
OPEN c_emp;
LOOP
    begin
    FETCH c_emp INTO v_name;
    EXIT WHEN c_emp%NOTFOUND;
    --首先生成页面错误数据
    sqlStr:='insert into nb_top_error value 
             select seq_top_error.nextval,row_.* 
             from 
             (select p.task_id,'''' as url,p.page_seq,p.tm_day,p.error_code,3,sum(p.point_total) as point_total
             from nb_page'||v_name||' p 
             where error_code in (select err_code from nb_m_error where err_type = 3) 
                   and (tm_day between :startDate and :endDate)
             group by p.task_id, p.page_seq,p.error_code, p.tm_day) row_';
            
    execute immediate sqlStr using startDate-1,endDate;	
     DBMS_OUTPUT.PUT_LINE('2 start');
    commit;
    --判断是否ELEM表已经建立索引
    
    select count(*)  INTO v_s FROM all_objects t where t.object_name = 'IN_ELEM_TMTASK'||v_name;
    if v_s = 1 then 
      begin
         DBMS_OUTPUT.PUT_LINE(' INDEX IN_ELEM_TMTASK'|| v_name||' already exist ');
      end;
    else
      begin
         sqlStr:='create index IN_ELEM_TMTASK'||v_name||' on NB_ELEM'||v_name||' (TM_BASE,TASK_ID) tableSpace NETBEN_IDX';  
         execute   immediate   sqlStr;
      end;
    end if;
    --然后生成内容错误数据
    DBMS_OUTPUT.PUT_LINE('begin');
    sqlStr:='insert into nb_top_error value
             select seq_top_error.nextval,row_.* from 
             (select p.task_id,(p.url_protocol || ''://'' || p.url_host || '':'' || p.url_port || p.url_path) as url,
                   0,trunc(p.tm_base, ''dd'') as tm_day,p.error_code,2,count(p.id) as point_total
             from nb_elem'||v_name||' p 
             where error_code in (select err_code from nb_m_error where err_type = 3)
                   and (tm_base between :startDate and :endDate)
             group by p.task_id, (p.url_protocol || ''://'' || p.url_host || '':'' || p.url_port || p.url_path),
                   p.error_code, trunc(p.tm_base, ''dd'')) row_';
    execute immediate sqlStr using startDate-1,endDate;
    commit;
    --如果创建序列失败，则显示出失败代码
    exception when  others then
        v_error_desc := ' insert error '||v_name|| '  sql:' ||sqlStr;
        DBMS_OUTPUT.PUT_LINE(v_error_desc);
        create_procedure_log('in_top_error',v_error_desc,sqlcode);
        
    end;
END LOOP;
CLOSE c_emp;
end my_procedure;


/

