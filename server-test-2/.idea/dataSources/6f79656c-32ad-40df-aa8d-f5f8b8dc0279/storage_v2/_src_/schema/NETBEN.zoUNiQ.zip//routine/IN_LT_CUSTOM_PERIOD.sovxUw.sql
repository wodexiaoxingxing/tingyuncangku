create procedure in_lt_custom_period(sd date,days number) authid current_user
is
   sqlStr varchar2(4000);
   startDate date;
   endDate date;
   errorDesc varchar2(4000);
   v_s number;
begin
create_procedure_log('in_lt_custom_period','begin','message');
if sd is null or days is null then
  startDate:=trunc(sysdate-1,'dd');
  endDate:=startDate+1;
else
  startDate:=trunc(sd,'dd');
  endDate:=startDate+days;
end if;
for item in (select substr(t.table_name, 11) as name from user_tables t where t.table_name like 'NB_CUSTOM_%') loop
begin
   create_procedure_log('in_lt_custom_period','tableStr:'||item.name,'message');
   --判断是否该表已经创建
   select count(*) into v_s from user_tables t where t.table_name = 'LT_CUSTOM_'||item.name;
   if (v_s<1) then
       --表不存在，创建新表
       sqlStr:='create table LT_CUSTOM_'||item.name||'
		       (
      		 TASK_ID        NUMBER NOT NULL,
		       CITY_ID        NUMBER NOT NULL,
		       ISP_ID         NUMBER NOT NULL,
		       NET_SPEED_ID   NUMBER NOT NULL,
					 dest_city_id   number,
					 dest_isp_id    number,
					 dest_ip        VARCHAR2(39),
		       TM_DAY         DATE,
           ERROR_CODE     NUMBER DEFAULT 0,
           POINT_TOTAL    NUMBER DEFAULT 1,
           TS_TOTAL       NUMBER DEFAULT 0,
           CUST_FIELD1    NUMBER,
           CUST_FIELD2    NUMBER,
           CUST_FIELD3    NUMBER,
           CUST_FIELD4    NUMBER,
           CUST_FIELD5    NUMBER,
           CUST_FIELD6    NUMBER,
           CUST_FIELD7    NUMBER,
           CUST_FIELD8    NUMBER,
           CUST_FIELD9    NUMBER,
           CUST_FIELD10   NUMBER,
           CUST_FIELD11   NUMBER,
           CUST_FIELD12   NUMBER,
           CUST_FIELD13   NUMBER,
           CUST_FIELD14   NUMBER,
           CUST_FIELD15   NUMBER,
           CUST_FIELD16   NUMBER,
           CUST_FIELD17   NUMBER,
           CUST_FIELD18   NUMBER,
           CUST_FIELD19   NUMBER,
           CUST_FIELD20   NUMBER,
           CUST_FIELD21   NUMBER,
           CUST_FIELD22   NUMBER,
           CUST_FIELD23   NUMBER,
           CUST_FIELD24   NUMBER,
           CUST_FIELD25   NUMBER,
           CUST_FIELD26   NUMBER,
           CUST_FIELD27   NUMBER,
           CUST_FIELD28   NUMBER,
           CUST_FIELD29   NUMBER,
           CUST_FIELD30   NUMBER
		       )';
         execute   immediate   sqlStr;

         --创建索引
         sqlStr:='create index IN_LT_CUSTOM_PERF_'||item.name||' on LT_CUSTOM_'||item.name||' (task_id,tm_day,city_id,isp_id,error_code) tableSpace netben_ind';
	       execute   immediate   sqlStr;
     end if;

  --删除指定日期的长期库中的数据,防止重复数据
  sqlStr := 'delete from LT_CUSTOM_'||item.name||' where tm_day  >=:sDate and tm_day < :eDate';
  execute immediate sqlStr using startDate,endDate;
  commit;
  --DBMS_OUTPUT.PUT_LINE('CREATE_TABLE');
  --从实时库中插入指定日期的数据
  sqlStr:='insert into lt_custom_'||item.name||'
           (task_id,city_id,isp_id,dest_city_id,dest_isp_id,dest_ip,net_speed_id,tm_day,error_code, point_total,ts_total,
           cust_field1,cust_field2,cust_field3,cust_field4,cust_field5,cust_field6,cust_field7,cust_field8,cust_field9,cust_field10,
           cust_field11,cust_field12,cust_field13,cust_field14,cust_field15,cust_field16,cust_field17,cust_field18,cust_field19,cust_field20,
           cust_field21,cust_field22,cust_field23,cust_field24,cust_field25,cust_field26,cust_field27,cust_field28,cust_field29,cust_field30)
        select
		       task_id,
		       city_id,
		       isp_id,
					 dest_city_id,
					 dest_isp_id,
					 dest_ip,
		       net_speed_id,
		       trunc(tm_base,''dd'') as tm_day,
           error_code,
		       sum(point_total),
           round(avg(ts_total),0) as ts_total,
		       round(avg(cust_field1),0) as cust_field1,
           round(avg(cust_field2),0) as cust_field2,
           round(avg(cust_field3),0) as cust_field3,
           round(avg(cust_field4),0) as cust_field4,
           round(avg(cust_field5),0) as cust_field5,
           round(avg(cust_field6),0) as cust_field6,
           round(avg(cust_field7),0) as cust_field7,
           round(avg(cust_field8),0) as cust_field8,
           round(avg(cust_field9),0) as cust_field9,
           round(avg(cust_field10),0) as cust_field10,
		       round(avg(cust_field11),0) as cust_field11,
           round(avg(cust_field12),0) as cust_field12,
           round(avg(cust_field13),0) as cust_field13,
           round(avg(cust_field14),0) as cust_field14,
           round(avg(cust_field15),0) as cust_field15,
           round(avg(cust_field16),0) as cust_field16,
           round(avg(cust_field17),0) as cust_field17,
           round(avg(cust_field18),0) as cust_field18,
           round(avg(cust_field19),0) as cust_field19,
           round(avg(cust_field20),0) as cust_field20,
		       round(avg(cust_field21),0) as cust_field21,
           round(avg(cust_field22),0) as cust_field22,
           round(avg(cust_field23),0) as cust_field23,
           round(avg(cust_field24),0) as cust_field24,
           round(avg(cust_field25),0) as cust_field25,
           round(avg(cust_field26),0) as cust_field26,
           round(avg(cust_field27),0) as cust_field27,
           round(avg(cust_field28),0) as cust_field28,
           round(avg(cust_field29),0) as cust_field29,
           round(avg(cust_field30),0) as cust_field30
		    from NB_CUSTOM_'||item.name||'
        where tm_base >= :sDate and  tm_base < :eDate and is_noise = 0
		       group by task_id,
		                city_id,
		                isp_id,
										dest_city_id,
										dest_isp_id,
										dest_ip,
		                net_speed_id,
                    trunc(tm_base,''dd''),
		                error_code
		    ';
       execute immediate sqlStr using startDate,endDate;
       commit;
     exception when  others then
        errorDesc := 'TableStr:'||item.name||' Error:'|| sqlcode || '  Sql:' ;
        create_procedure_log('in_lt_custom_period',errorDesc,'error');
  end;
end loop;
create_procedure_log('in_lt_custom_period','end','message');
end in_lt_custom_period;
/

