create PROCEDURE "MAN_ALTER_ELT_URL_ALTER_FIELD"
is
  sqlStr  varchar2(4000);
  v_error_desc varchar2(4000);
  v_s number;
begin
  for tableName in(select table_name from user_tab_columns where table_name like 'NB_ELT_URL_%' and column_name='ELEMENT_TYPE_IE' ) loop
  begin
 --alter table NB_ELT_URL_11111 rename column ELEMENT_URL_ID to ELEMENT_TYPE_IE;


        sqlStr := 'alter table '||tableName.table_name||'  rename column ELEMENT_TYPE_IE to ELEMENT_TYPE_ID';
        execute   immediate   sqlStr ;
 dbms_output.put_line(sqlStr);


    exception when  others then
        v_error_desc := 'Error Code:'|| sqlcode || '  Sql:'||sqlStr ;
        DBMS_OUTPUT.PUT_LINE(sqlStr);
        create_procedure_log('alter_custom_add_field',v_error_desc,sqlcode);
  end;
  end loop;
end MAN_ALTER_ELT_URL_ALTER_FIELD;


/

