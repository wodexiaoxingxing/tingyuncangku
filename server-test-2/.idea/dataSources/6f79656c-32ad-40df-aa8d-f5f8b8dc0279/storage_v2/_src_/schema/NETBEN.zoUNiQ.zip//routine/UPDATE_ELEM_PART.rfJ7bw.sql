create PROCEDURE update_elem_part authid current_user is
type tabType is table of varchar2(32) index by BINARY_INTEGER;
tabTypeImpl tabType;
DROP_ERROR exception;
ADD_ERROR exception;

sqlStr varchar2(4000);
currDate date := trunc(sysdate,'d');

partNameNew varchar2(64);
partValueNew varchar2(64);
partDate date;
begin
  DBMS_OUTPUT.ENABLE (1000000000);
 -- tabTypeImpl(1):='NB_EC';
  tabTypeImpl(1):='NB_EE';
  tabTypeImpl(2):='NB_ET';
  tabTypeImpl(3):='NB_ETT';
  tabTypeImpl(4):='NB_ETD';
  create_procedure_log('update_elem_part','begin','run');
  for s in 1..tabTypeImpl.count loop
    for tab in  (select t.partition_name partName,t.num partNum,t.table_name tabName from
      (select partition_name,decode(is_number(num),0,0,1,num) num,table_name from (select partition_name,substr(partition_name, instr(partition_name,'_',-1,1)+1) num, table_name from user_tab_partitions where table_name like tabTypeImpl(s)||'\_%'  escape '\')) t,
      (select order_num from nb_part_calendar where sunday <= currDate - 49) c
        where t.num = c.order_num) loop
        begin
          select sunday into partDate from nb_part_calendar where order_num = tab.partNum;
          if partDate > currDate - 49 then
            raise DROP_ERROR;
          end if;
          sqlStr:='alter table '||tab.tabName||' drop partition '||tab.partName;
          --dbms_output.put_line(sqlStr||';');
          execute immediate sqlStr;
          create_procedure_log('update_elem_part','Drop part,Table:'||tab.tabname||',partName:'||tab.partName,'run');
        exception
           when DROP_ERROR then null;
           when others then
           create_procedure_log('update_elem_part','dropError,Table:'||tab.tabname||','||sqlerrm,'error');
        end;
     end loop;

     for tab in(
          select a.table_name tabName,a.partition_name partName,decode(is_number(a.num),0,0,1,num) partNum,tablespace_name tablespaceName from
           (select table_name,partition_position,partition_name,substr(partition_name, instr(partition_name,'_',-1,1)+1) num,tablespace_name from user_tab_partitions where table_name like tabTypeImpl(s)||'\_%'  escape '\')a,
           (select table_name,max(partition_position) partition_position from user_tab_partitions where table_name like tabTypeImpl(s)||'\_%'  escape '\' group by table_name)b
           where a.table_name = b.table_name and a.partition_position = b.partition_position
     )loop
       begin
         select sunday into partDate from nb_part_calendar where order_num = tab.partNum;
          if partDate > currDate + 14 then
            raise ADD_ERROR;
          end if;
          partNameNew:=substr(tab.partName,1,instr(tab.partName,'_',-1,1))||(tab.partNum+1);
          partValueNew :='to_date('''||to_char(partDate+7,'yyyy-mm-dd')||''',''yyyy-mm-dd'')';
          sqlStr := 'ALTER TABLE '||tab.tabName || ' ADD PARTITION '||partNameNew||' VALUES LESS THAN('||partValueNew||') tablespace '||tab.tablespaceName;
          --dbms_output.put_line(sqlStr||';');
          execute immediate sqlStr;
          create_procedure_log('update_elem_part','Add Part,Table:'||tab.tabname||',partName:'||partNameNew,'run');
      exception
        when ADD_ERROR then null;
        when others then
          create_procedure_log('update_elem_part','addError,Table:'||tab.tabname||','||sqlerrm,'error');
      end;
    end loop;
  end loop;
  create_procedure_log('update_elem_part','end','run');
  exception when others then
    --dbms_output.put_line('aa,'||sqlerrm);
    create_procedure_log('update_elem_part','Outer error,'||sqlerrm,'error');
end update_elem_part;


/

