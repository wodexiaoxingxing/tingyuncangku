create view SS_V_CHECKBILL as
select rownum as id,
       decode(d.payments_id,null,0,d.payments_id) as payments_id,
       decode(d.user_id,null,0,d.user_id) as user_id,
       decode(d.type,null,-1,d.type) as type,
       decode(d.payments,null,0,d.payments) as payments,
       d.ctime,
       decode(a.merchant_out_order_no,null,0,a.merchant_out_order_no) as merchant_out_order_no,
       decode(a.trade_no,null,0,a.trade_no) as trade_no,
       decode(a.income,null,0,a.income) as income,
       decode(a.outcome,null,0,a.outcome) as outcome,
       decode(a.total_fee,null,0,a.total_fee) as total_fee,
       a.trans_date,
       /*decode( sign(a.total_fee - d.payments),0,1) as flag*/
       CASE WHEN a.total_fee = d.payments THEN 1
       ELSE 0
       END AS flag
  from SS_DEALS d
  full outer join SS_ALIPAY_FLOW a ON d.payments_id =
                                      a.merchant_out_order_no


/

