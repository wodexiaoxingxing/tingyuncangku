create procedure createSTREAM(tableStr IN varchar2,res OUT number) authid current_user is
  sqlStr varchar2(4000);
  errorDesc varchar2(4000);
begin

create_procedure_log('createSTREAM', 'create table:NB_STREAM_' || tableStr, 'run');

  --创建Stream 表
  sqlStr := 'create table NB_STREAM_' || tableStr || '
  (
  ID             NUMBER not null,
  TASK_ID        NUMBER,
  CITY_ID        NUMBER,
  ISP_ID         NUMBER,
  NET_SPEED_ID   NUMBER,
  TM_BASE        DATE,
  TM_DAY         DATE,
  TM_HOUR        DATE,
  TM_HALF_HOUR   DATE,
  PROBE_IP       NUMBER,
  MEMBER_ID      NUMBER,
  ERROR_CODE     NUMBER,
  ERROR_PATH     VARCHAR2(256),
  POINT_TOTAL    NUMBER default 1,
  BYTE_TOTAL     NUMBER,
  RATE_DOWNLOAD  NUMBER,
  DNS_SERVER     VARCHAR2(128),
  DNS_SERVER_IP   NUMBER,
  DEST_IP        VARCHAR2(39),
  PING_RESULT    VARCHAR2(512),
  TRACERT_RESULT VARCHAR2(512),
  NSLOOKUP_RESULT VARCHAR2(512),
  METATAGS       VARCHAR2(4000),
  ELEMENTS_RESULT VARCHAR2(512),
  HTTP_SERVER    VARCHAR2(256),
  HTTP_VIA       VARCHAR2(256),
  PROTOCOL_TYPE  VARCHAR2(256),
  RECE_PACKAGE   NUMBER,
  LOSE_PACKAGE   NUMBER,
  URL_SOURCE     VARCHAR2(2048),
  URL_DEST       VARCHAR2(2048),
  REBUFFER_DESC  VARCHAR2(1024),
  BUFFER_COUNT   NUMBER,
  TS_TOTAL       NUMBER,
  TS_SSL         NUMBER,
  TS_DNS         NUMBER,
  TS_CONNECT     NUMBER,
  TS_REDIRECT    NUMBER,
  TS_BUFFER      NUMBER,
  TS_REBUFFER    NUMBER,
  TS_FIRST_PLAY  NUMBER,
  TS_PLAY        NUMBER,
  TS_FULL        NUMBER,
  TS_USER        NUMBER,
  TS_CONNECT_TCP  NUMBER,
  TS_FIRST_PACKET NUMBER,
  TS_CONTENTS     NUMBER,
  TS_CAP_PLAYER NUMBER,
  VERSION_ID   INTEGER,
  OS_VER_ID   INTEGER,
  BS_ID      INTEGER,
  BS_VER_ID    INTEGER,
  FLASH_VER    VARCHAR2(32),
  PERCENT_CPU  NUMBER,
  PERCENT_CPU_TASK   NUMBER,  
  PERCENT_MEM   NUMBER,  
  PERCENT_MEM_TASK   NUMBER,  
  RATE_AVG     NUMBER,
  BAND_WIDTH   NUMBER,  
  FILE_SIZE    NUMBER,
  DURATION    NUMBER,
  DATA_RATE    INTEGER,
  PLAY_IN_5S  INTEGER,
  FLUENCY    INTEGER,
  OS_ID      INTEGER,
  HW_ID      INTEGER,
  MB_TYPE    INTEGER,
  BB_ID      INTEGER,
  WIFI      INTEGER,
  SCREEN_WIDTH  INTEGER,
  SCREEN_HEIGHT  INTEGER,
  IMEI      INTEGER,
  MOBILE_SIGNAL  INTEGER,
  IS_NOISE       NUMBER default 0,
  
  UVMOS                    NUMBER,  -- U-vMOS会话得分
  VIDEO_QUALITY            NUMBER,  -- 视频质量会话得分
  VIEWING_EXPERIENCE       NUMBER,  -- 观看体验会话得分
  INTERACTIVE_EXPERIENCE   NUMBER   -- 交互体验会话得分
  ) pctfree 0
  tablespace NETBEN';
  execute immediate sqlStr;

  sqlStr := 'alter table NB_STREAM_' || tableStr || '
    add constraint PK_NB_STREAM_' || tableStr ||
            ' primary key (ID)
    using index 
    tablespace NETBEN';
  execute immediate sqlStr;

  -- NB_STREAM 索引               
  sqlStr := 'create index IN_STREAM_PERF_' || tableStr || ' on NB_STREAM_' ||
            tableStr || ' (TM_BASE,TASK_ID) tableSpace NETBEN_IDX_NEW';
  execute immediate sqlStr;
  res:=0;
  
exception
  when others then
    errorDesc := 'Error :' || sqlerrm || '  tableStr:' || tableStr;
    --DBMS_OUTPUT.PUT_LINE(v_error_desc);
    create_procedure_log('createSTREAM', errorDesc, 'error');
    res:=1;
    
end createSTREAM;


/

