create procedure calc_sc_probe_online(cdate in date) is
  currDate date;
  sqlStr   varchar2(4000);
begin
  
  if cdate is null then
    currDate:=sysdate;
  else 
    currDate:=cdate;
  end if;
    
  create_procedure_log('calc_sc_probe_online','begin','run');
  
  -- 1 删除可能重复的数据
  sqlStr := 'delete from nb_sc_probe_online where calc_date = :cdate';
  execute immediate sqlStr  using trunc(currDate - 1);
  commit;
  create_procedure_log('calc_sc_probe_online','1 删除可能重复的数据完成','run');  
  
  -- 2 生成pc客户端每天在线时长
  sqlStr := 'insert into nb_sc_probe_online(calc_date,member_id,probe_id,online_time,ctime)
               select trunc(time_stamp),member_id,host_id,count(1)*10,sysdate
                 from nb_m_proberuntime_log
                 where time_stamp >= :st and time_stamp < :et
                 group by trunc(time_stamp),member_id,host_id
             ';
  execute immediate sqlStr  using trunc(currDate - 1), trunc(currDate);
  commit;
  create_procedure_log('calc_sc_probe_online','2 生成PC节点在线时长数据完成','run'); 
  
  -- 3 生成手机每天在线时长
  sqlStr:='insert into nb_sc_probe_online(calc_date,member_id,probe_id,online_time,ctime)
               select trunc(time_stamp),member_id,host_id,count(1)*10,sysdate
                 from nb_m_proberuntime_log_mobile
                 where time_stamp >= :st and time_stamp < :et and member_id > 0
                 group by trunc(time_stamp),member_id,host_id
             ';
  execute immediate sqlStr  using trunc(currDate - 1), trunc(currDate);
  commit;
  create_procedure_log('calc_sc_probe_online','3 生成mobile节点在线时长数据完成','run'); 
  
 --结束
 create_procedure_log('calc_sc_probe_online','end','run');
 exception when  others then
   create_procedure_log('calc_sc_probe_online',sqlerrm,'error');
end calc_sc_probe_online;


/

