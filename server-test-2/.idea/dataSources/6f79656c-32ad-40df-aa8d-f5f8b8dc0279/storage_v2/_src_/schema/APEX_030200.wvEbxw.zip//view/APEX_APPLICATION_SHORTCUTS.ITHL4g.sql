create view APEX_APPLICATION_SHORTCUTS as
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    s.SHORTCUT_NAME                  shortcut_name,
    --s.SHORTCUT_CONSIDERATION_SEQ     consideration_sequence,
    s.SHORTCUT_TYPE                  shortcut_type,
    nvl((select r from apex_standard_conditions where d = s.SHORTCUT_CONDITION_TYPE1),s.SHORTCUT_CONDITION_TYPE1)
                                     condition_type,
    s.SHORTCUT_CONDITION1            condition_expression1,
    --s.SHORTCUT_CONDITION_TYPE2       ,
    s.SHORTCUT_CONDITION2            condition_expression2,
    s.ERROR_TEXT                     error_text,
    (select case when s.build_option > 0 then PATCH_NAME else '{Not '||PATCH_NAME||'}' end PATCH_NAME
     from   wwv_flow_patches
     where  id =abs(s.BUILD_OPTION))      build_option,
    s.SHORTCUT                       shortcut,
    --
    decode(s.REFERENCE_ID,
    null,'No','Yes')                 is_subscribed,
    (select flow_id||'. '||name n
     from wwv_flow_shortcuts
     where id = s.reference_id)      subscribed_from,
    --
    s.LAST_UPDATED_BY                last_updated_by,
    s.LAST_UPDATED_ON                last_updated_on,
    s.COMMENTS                       component_comments,
    s.id                             shortcut_id,
    --
    s.SHORTCUT_NAME
    ||' '||s.SHORTCUT_TYPE
    ||' cond='||s.SHORTCUT_CONDITION_TYPE1
    ||substr(s.SHORTCUT_CONDITION1,1,30)||length(s.shortcut_condition1)||'.'
    ||substr(s.SHORTCUT_CONDITION2,1,30)||length(s.shortcut_condition2)
    ||' e='||substr(s.ERROR_TEXT,1,30)||length(s.ERROR_TEXT)
    ||' bo='||(select PATCH_NAME
     from   wwv_flow_patches
     where  id =abs(s.BUILD_OPTION))
    ||' s='||dbms_lob.substr(s.SHORTCUT,50,1)||dbms_lob.getlength(s.SHORTCUT)
    ||' r='||decode(s.REFERENCE_ID,null,'No','Yes')
    component_signature
from wwv_flow_shortcuts s,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas ws,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (ws.schema = user or user in ('SYS','SYSTEM', 'APEX_030200')  or d.sgid = ws.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      ws.security_group_id = w.PROVISIONING_COMPANY_ID and
      ws.schema = f.owner and
      f.id = s.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0 and
      (user in ('SYS','SYSTEM', 'APEX_030200') or w.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_APPLICATION_SHORTCUTS is 'Identifies Application Shortcuts which can be referenced "MY_SHORTCUT" syntax'
/

comment on column APEX_APPLICATION_SHORTCUTS.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_SHORTCUTS.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_SHORTCUTS.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_SHORTCUTS.SHORTCUT_NAME is 'Identifies the Shortcut Name, which can be referenced using "SHORTCUT_NAME" syntax'
/

comment on column APEX_APPLICATION_SHORTCUTS.SHORTCUT_TYPE is 'The shortcut type identifies how the Shortcut text is to be interpreted; for example it could by PL/SQL or HTML.'
/

comment on column APEX_APPLICATION_SHORTCUTS.CONDITION_TYPE is 'Identifies the condition type used to conditionally execute the shortcut'
/

comment on column APEX_APPLICATION_SHORTCUTS.CONDITION_EXPRESSION1 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_SHORTCUTS.CONDITION_EXPRESSION2 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_SHORTCUTS.ERROR_TEXT is 'Text to be displayed if this shortcut raises an exception'
/

comment on column APEX_APPLICATION_SHORTCUTS.BUILD_OPTION is 'Shortcut will be available if the Build Option is enabled'
/

comment on column APEX_APPLICATION_SHORTCUTS.SHORTCUT is 'Text and definition of this Shortcut'
/

comment on column APEX_APPLICATION_SHORTCUTS.IS_SUBSCRIBED is 'Identifies if this Shortcut is subscribed from another Shortcut'
/

comment on column APEX_APPLICATION_SHORTCUTS.SUBSCRIBED_FROM is 'Identifies the master component from which this component is subscribed'
/

comment on column APEX_APPLICATION_SHORTCUTS.LAST_UPDATED_BY is 'Apex developer who made last update'
/

comment on column APEX_APPLICATION_SHORTCUTS.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_SHORTCUTS.COMPONENT_COMMENTS is 'Developer comments'
/

comment on column APEX_APPLICATION_SHORTCUTS.SHORTCUT_ID is 'Primary Key of this Shortcut'
/

comment on column APEX_APPLICATION_SHORTCUTS.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

