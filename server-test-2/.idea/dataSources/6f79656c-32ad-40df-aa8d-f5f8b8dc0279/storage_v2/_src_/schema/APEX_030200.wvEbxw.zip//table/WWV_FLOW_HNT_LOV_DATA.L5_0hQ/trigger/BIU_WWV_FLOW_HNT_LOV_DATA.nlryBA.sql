create trigger BIU_WWV_FLOW_HNT_LOV_DATA
    before insert or update
    on WWV_FLOW_HNT_LOV_DATA
    for each row
begin
        if inserting and :new.id is null then
            :new.id := wwv_flow_id.next_val;
        end if;
        :new.last_updated_by := nvl(wwv_flow.g_user,user);
        :new.last_updated_on := sysdate;
    end;
/

