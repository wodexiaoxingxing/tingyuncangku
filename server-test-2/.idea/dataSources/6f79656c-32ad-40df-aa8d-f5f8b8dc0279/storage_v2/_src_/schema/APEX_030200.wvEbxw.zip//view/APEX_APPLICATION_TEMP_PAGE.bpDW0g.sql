create view APEX_APPLICATION_TEMP_PAGE as
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    t.NAME                           template_name,
    --t.LOOK
    --
    t.HEADER_TEMPLATE                ,
    t.BOX                            page_body,
    t.FOOTER_TEMPLATE                ,
    --
    t.SUCCESS_MESSAGE                ,
    t.CURRENT_TAB                    ,
    t.CURRENT_TAB_FONT_ATTR          ,
    t.NON_CURRENT_TAB                ,
    t.NON_CURRENT_TAB_FONT_ATTR      ,
    t.CURRENT_IMAGE_TAB              ,
    t.NON_CURRENT_IMAGE_TAB          ,
    t.TOP_CURRENT_TAB                Current_Parent_Tab,
    t.TOP_CURRENT_TAB_FONT_ATTR      Current_Parent_Tab_attr,
    t.TOP_NON_CURRENT_TAB            NonCurrent_Parent_Tab,
    t.TOP_NON_CURRENT_TAB_FONT_ATTR  NonCurrent_Parent_Tab_attr,
    --
    t.NAVIGATION_BAR                 ,
    t.NAVBAR_ENTRY                   ,
    --t.BODY_TITLE                     ,
    t.MESSAGE                        ,
    --t.ATTRIBUTE1                     ,
    --t.ATTRIBUTE2                     ,
    --t.ATTRIBUTE3                     ,
    --t.ATTRIBUTE4                     ,
    --t.ATTRIBUTE5                     ,
    --t.ATTRIBUTE6                     ,
    --t.DEFAULT_BUTTON_POSITION        ,
    --t.TABLE_BGCOLOR                  ,
    --t.HEADING_BGCOLOR                ,
    --t.TABLE_CATTRIBUTES              ,
    --t.FONT_SIZE                      ,
    --t.FONT_FACE                      ,
    t.REGION_TABLE_CATTRIBUTES         MultiColumn_Region_Table_Attr,
    --t.APP_TAB_BEFORE_TABS            ,
    --t.APP_TAB_CURRENT_TAB            ,
    --t.APP_TAB_NON_CURRENT_TAB        ,
    --t.APP_TAB_AFTER_TABS             ,
    t.ERROR_PAGE_TEMPLATE            ,
    --
    decode(t.REFERENCE_ID,
    null,'No','Yes')                 is_subscribed,
    (select flow_id||'. '||name
     from wwv_flow_templates
     where id = t.REFERENCE_ID)      subscribed_from,
    --
    --t.BREADCRUMB_DEF_REG_POS         ,
    --t.SIDEBAR_DEF_REG_POS            ,
    --t.REQUIRED_PATCH                 ,
    t.THEME_ID                       theme_number,
    decode(t.THEME_CLASS_ID,
      '1', 'One Level Tabs',
      '2', 'Two Level Tabs',
      '3', 'No Tabs',
      '4', 'Popup',
      '5', 'Printer Friendly',
      '6', 'Login',
      '7', 'Unknown',
      '8',  'Custom 1',
      '9',  'Custom 2',
      '10', 'Custom 3',
      '11', 'Custom 4',
      '12', 'Custom 5',
      '13', 'Custom 6',
      '14', 'Custom 7',
      '15', 'Custom 8',
      '16', 'One Level Tabs with Sidebar',
      '17', 'No Tabs with Sidebar',
      '18', 'Two Level Tabs with Sidebar',
      t.THEME_CLASS_ID)              theme_class,
    t.LAST_UPDATED_BY                last_updated_by,
    t.LAST_UPDATED_ON                last_updated_on,
    decode(
       t.TRANSLATE_THIS_TEMPLATE,
       'N','No','Y','Yes','Yes')     translatable,
    t.TEMPLATE_COMMENT               component_comment,
    t.id                             template_id,
    --
    substr(t.NAME,1,40)||'.'||length(t.NAME)
    ||' h='||dbms_lob.substr(t.HEADER_TEMPLATE                  ,40,1)||'.'||dbms_lob.getlength(t.HEADER_TEMPLATE                )
    ||' b='||dbms_lob.substr(t.BOX                              ,40,1)||'.'||dbms_lob.getlength(t.BOX                            )
    ||' f='||dbms_lob.substr(t.FOOTER_TEMPLATE                  ,40,1)||'.'||dbms_lob.getlength(t.FOOTER_TEMPLATE                )
    ||' s='||substr(t.SUCCESS_MESSAGE                  ,1,40)||'.'||length(t.SUCCESS_MESSAGE                )
    ||' t='||substr(t.CURRENT_TAB                      ,1,40)||'.'||length(t.CURRENT_TAB                    )
    ||' t='||substr(t.CURRENT_TAB_FONT_ATTR            ,1,40)||'.'||length(t.CURRENT_TAB_FONT_ATTR          )
    ||' n='||substr(t.NON_CURRENT_TAB                  ,1,40)||'.'||length(t.NON_CURRENT_TAB                )
    ||' n='||substr(t.NON_CURRENT_TAB_FONT_ATTR        ,1,40)||'.'||length(t.NON_CURRENT_TAB_FONT_ATTR      )
    ||' i='||substr(t.CURRENT_IMAGE_TAB                ,1,40)||'.'||length(t.CURRENT_IMAGE_TAB              )
    ||' i='||substr(t.NON_CURRENT_IMAGE_TAB            ,1,40)||'.'||length(t.NON_CURRENT_IMAGE_TAB          )
    ||' t='||substr(t.TOP_CURRENT_TAB                  ,1,40)||'.'||length(t.TOP_CURRENT_TAB                )
    ||' t='||substr(t.TOP_CURRENT_TAB_FONT_ATTR        ,1,40)||'.'||length(t.TOP_CURRENT_TAB_FONT_ATTR      )
    ||' t='||substr(t.TOP_NON_CURRENT_TAB              ,1,40)||'.'||length(t.TOP_NON_CURRENT_TAB            )
    ||' t='||substr(t.TOP_NON_CURRENT_TAB_FONT_ATTR    ,1,40)||'.'||length(t.TOP_NON_CURRENT_TAB_FONT_ATTR  )
    ||' n='||substr(t.NAVIGATION_BAR                   ,1,40)||'.'||length(t.NAVIGATION_BAR                 )
    ||' n='||substr(t.NAVBAR_ENTRY                     ,1,40)||'.'||length(t.NAVBAR_ENTRY                   )
    ||' m='||substr(t.MESSAGE                          ,1,40)||'.'||length(t.MESSAGE                        )
    ||' e='||substr(t.ERROR_PAGE_TEMPLATE              ,1,40)||'.'||length(t.ERROR_PAGE_TEMPLATE            )
    --
    ||' s='||decode(t.REFERENCE_ID,null,'No','Yes')
    ||' t='||t.THEME_ID
    ||' c='||decode(t.THEME_CLASS_ID,
      '1', 'One Level Tabs',
      '2', 'Two Level Tabs',
      '3', 'No Tabs',
      '4', 'Popup',
      '5', 'Printer Friendly',
      '6', 'Login',
      '7', 'Unknown',
      '8',  'Custom 1',
      '9',  'Custom 2',
      '10', 'Custom 3',
      '11', 'Custom 4',
      '12', 'Custom 5',
      '13', 'Custom 6',
      '14', 'Custom 7',
      '15', 'Custom 8',
      '16', 'One Level Tabs with Sidebar',
      '17', 'No Tabs with Sidebar',
      '18', 'Two Level Tabs with Sidebar',
      t.THEME_CLASS_ID)
    ||' t='||t.TRANSLATE_THIS_TEMPLATE
    component_signature
from wwv_flow_templates t,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_030200')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.id = t.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0 and
      (user in ('SYS','SYSTEM', 'APEX_030200') or w.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_APPLICATION_TEMP_PAGE is 'The Page Template which identifies the HTML used to organized and render a page content'
/

comment on column APEX_APPLICATION_TEMP_PAGE.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_TEMP_PAGE.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_TEMP_PAGE.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_TEMP_PAGE.TEMPLATE_NAME is 'Name of the Page Template'
/

comment on column APEX_APPLICATION_TEMP_PAGE.HEADER_TEMPLATE is 'In the Header is the first of 3 parts of the page template.  Enter the HTML that makes up the HEAD section of the HTML document.  That is, all the required HTML tags before the BODY of the HTML document.'
/

comment on column APEX_APPLICATION_TEMP_PAGE.PAGE_BODY is 'The Body is the second of 3 parts of the page template.  Enter HTML that makes up the BODY of the HTML document.'
/

comment on column APEX_APPLICATION_TEMP_PAGE.FOOTER_TEMPLATE is 'The Footer is the third template and displays after the body.'
/

comment on column APEX_APPLICATION_TEMP_PAGE.SUCCESS_MESSAGE is 'Enter HTML that will substitute the string #SUCCESS_MESSAGE# in the template body'
/

comment on column APEX_APPLICATION_TEMP_PAGE.CURRENT_TAB is 'Enter HTML or text that will be substituted for the currently selected standard tab, use #TAB_LINK#" and #TAB_LABEL# substitutions.'
/

comment on column APEX_APPLICATION_TEMP_PAGE.CURRENT_TAB_FONT_ATTR is 'This attribute is part of the Standard Tab subtemplate.  This value replaces the #TAB_FONT_ATTRIBUTES# substitution string.'
/

comment on column APEX_APPLICATION_TEMP_PAGE.NON_CURRENT_TAB is 'HTML or text that will be substituted for the unselected standard tabs, use #TAB_LINK#" and #TAB_LABEL# substitutions'
/

comment on column APEX_APPLICATION_TEMP_PAGE.NON_CURRENT_TAB_FONT_ATTR is 'This attribute is part of the Parent Tab subtemplate and expands the #PARENT_TAB_CELLS# substitution string.'
/

comment on column APEX_APPLICATION_TEMP_PAGE.CURRENT_IMAGE_TAB is 'HTML to be used to indicate that an image-based tab is currently selected'
/

comment on column APEX_APPLICATION_TEMP_PAGE.NON_CURRENT_IMAGE_TAB is 'HTML to be used to indicate that an image-based tab is not currently selected'
/

comment on column APEX_APPLICATION_TEMP_PAGE.CURRENT_PARENT_TAB is 'HTML or text that will be substituted for the selected parent tabs'
/

comment on column APEX_APPLICATION_TEMP_PAGE.CURRENT_PARENT_TAB_ATTR is 'This value replaces the #TAB_FONT_ATTRIBUTES# substitution string'
/

comment on column APEX_APPLICATION_TEMP_PAGE.NONCURRENT_PARENT_TAB is 'HTML or text that will be substituted for the unselected standard tabs, use #TAB_LINK# and #TAB_LABEL# substitutions'
/

comment on column APEX_APPLICATION_TEMP_PAGE.NONCURRENT_PARENT_TAB_ATTR is 'This value replaces the #TAB_FONT_ATTRIBUTES# substitution string'
/

comment on column APEX_APPLICATION_TEMP_PAGE.NAVIGATION_BAR is 'HTML or text that will be substituted when the string #NAVIGATION_BAR# is referenced in the template header, body or footer'
/

comment on column APEX_APPLICATION_TEMP_PAGE.NAVBAR_ENTRY is 'HTML or text that will be substituted into the navigation bar #BAR_BODY# for each navigation bar entry'
/

comment on column APEX_APPLICATION_TEMP_PAGE.MESSAGE is 'HTML or text that will be substituted when the string #NOTIFICATION_MESSAGE# is referenced in the template header, body or footer'
/

comment on column APEX_APPLICATION_TEMP_PAGE.MULTICOLUMN_REGION_TABLE_ATTR is 'This attribute controls the attributes of the HTML table tag used to display regions in multiple columns.'
/

comment on column APEX_APPLICATION_TEMP_PAGE.ERROR_PAGE_TEMPLATE is 'Used only when this page template will be designated as an error template.  Use #MESSAGE# to place the error message and #BACK_LINK# to display a link back to the previous page.'
/

comment on column APEX_APPLICATION_TEMP_PAGE.IS_SUBSCRIBED is 'Identifies if this template is subscribed from another template'
/

comment on column APEX_APPLICATION_TEMP_PAGE.SUBSCRIBED_FROM is 'Identifies the Application ID and Template Name this template is subscribed from'
/

comment on column APEX_APPLICATION_TEMP_PAGE.THEME_NUMBER is 'Identifies the theme number associated with all templates within the theme'
/

comment on column APEX_APPLICATION_TEMP_PAGE.THEME_CLASS is 'Identifies a specific usage for this template'
/

comment on column APEX_APPLICATION_TEMP_PAGE.LAST_UPDATED_BY is 'Apex developer who made last update'
/

comment on column APEX_APPLICATION_TEMP_PAGE.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_TEMP_PAGE.TRANSLATABLE is 'Identifies if this component is to be identified as translatable (yes or no)'
/

comment on column APEX_APPLICATION_TEMP_PAGE.COMPONENT_COMMENT is 'Developer comment'
/

comment on column APEX_APPLICATION_TEMP_PAGE.TEMPLATE_ID is 'Primary Key of this Page Template'
/

comment on column APEX_APPLICATION_TEMP_PAGE.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

