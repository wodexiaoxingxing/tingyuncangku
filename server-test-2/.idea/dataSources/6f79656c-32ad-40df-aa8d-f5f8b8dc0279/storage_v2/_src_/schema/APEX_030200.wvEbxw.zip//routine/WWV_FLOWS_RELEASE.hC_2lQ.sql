create function wwv_flows_release
return varchar2
as
begin
    return '3.2.1.00.12';
end;
/

