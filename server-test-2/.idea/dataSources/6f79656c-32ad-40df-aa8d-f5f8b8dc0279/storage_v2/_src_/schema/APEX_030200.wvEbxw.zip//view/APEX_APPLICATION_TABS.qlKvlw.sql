create view APEX_APPLICATION_TABS as
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    t.TAB_SET                        tab_set,
    t.TAB_SEQUENCE                   display_sequence,
    t.TAB_NAME                       tab_name,
    t.TAB_IMAGE                      when_current_tab_image,
    t.TAB_NON_CURRENT_IMAGE          when_not_current_tab_image,
    t.TAB_IMAGE_ATTRIBUTES           tab_image_attributes,
    t.TAB_TEXT                       tab_label,
    t.TAB_STEP                       tab_page,
    t.TAB_ALSO_CURRENT_FOR_PAGES     tab_also_current_for_pages,
    t.TAB_PARENT_TABSET              parent_tabset,
    --
    nvl((select r from apex_standard_conditions where d = t.DISPLAY_CONDITION_TYPE),t.DISPLAY_CONDITION_TYPE)
                                     condition_type,
    t.TAB_PLSQL_CONDITION            condition_expression1,
    t.TAB_DISP_COND_TEXT             condition_expression2,
    --
    (select case when t.required_patch > 0 then PATCH_NAME else '{Not '||PATCH_NAME||'}' end PATCH_NAME
     from   wwv_flow_patches
     where  id =abs(t.REQUIRED_PATCH))    build_option,
     --
    decode(substr(t.SECURITY_SCHEME,1,1),'!','Not ')||
    nvl((select name
     from    wwv_flow_security_schemes
     where   to_char(id)= ltrim(t.SECURITY_SCHEME,'!')
     and     flow_id = f.id),
     t.SECURITY_SCHEME)              authorization_scheme,
    t.SECURITY_SCHEME                authorization_scheme_id,
    --
    t.LAST_UPDATED_BY                last_updated_by,
    t.LAST_UPDATED_ON                last_updated_on,
    t.TAB_COMMENT                    component_comment,
    t.id                             tab_id,
    --
    t.TAB_SET
    ||' '||lpad(t.TAB_SEQUENCE,5,'00000')
    ||' '||t.TAB_NAME
    ||substr(t.TAB_IMAGE,1,30)||length(t.TAB_IMAGE)
    ||substr(t.TAB_NON_CURRENT_IMAGE,1,30)||length(t.TAB_NON_CURRENT_IMAGE)
    ||substr(t.TAB_IMAGE_ATTRIBUTES,1,30)||length(t.TAB_IMAGE_ATTRIBUTES)
    ||' text='||substr(t.TAB_TEXT,1,30)||length(t.TAB_TEXT)
    ||' p='||t.TAB_STEP
    ||' a='||substr(t.TAB_ALSO_CURRENT_FOR_PAGES,1,30)||length(t.TAB_ALSO_CURRENT_FOR_PAGES)
    ||substr(t.TAB_PARENT_TABSET,1,30)||length(t.TAB_PARENT_TABSET)
    ||' c='||t.DISPLAY_CONDITION_TYPE
    ||substr(t.TAB_PLSQL_CONDITION,1,30)||length(t.TAB_PLSQL_CONDITION)
    ||substr(t.TAB_DISP_COND_TEXT,1,30)||length(t.TAB_DISP_COND_TEXT)
    ||(select PATCH_NAME
     from   wwv_flow_patches
     where  id =abs(t.REQUIRED_PATCH))
    ||decode(substr(t.SECURITY_SCHEME,1,1),'!','Not ')||
    nvl((select name
     from    wwv_flow_security_schemes
     where   to_char(id)= ltrim(t.SECURITY_SCHEME,'!')
     and     flow_id = f.id),
     t.SECURITY_SCHEME)
    component_signature
from wwv_flow_tabs t,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_030200')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.id = t.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0 and
      (user in ('SYS','SYSTEM', 'APEX_030200') or w.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_APPLICATION_TABS is 'Identifies a set of tabs collected into tab sets which are associated with a Standard Tab Entry'
/

comment on column APEX_APPLICATION_TABS.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_TABS.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_TABS.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_TABS.TAB_SET is 'Identifies a collection of tabs that will be displayed together.  If an application uses tabs each page identifies the Tab Set to be displayed with the page.'
/

comment on column APEX_APPLICATION_TABS.DISPLAY_SEQUENCE is 'Identifies the display sequence of the Tab within the Tab Set'
/

comment on column APEX_APPLICATION_TABS.TAB_NAME is 'Identifies the name of the tab; which will be the value of the REQUEST when the tab is pressed'
/

comment on column APEX_APPLICATION_TABS.WHEN_CURRENT_TAB_IMAGE is 'For tabs displayed using images and not a Tab Label, identifies the current tab image'
/

comment on column APEX_APPLICATION_TABS.WHEN_NOT_CURRENT_TAB_IMAGE is 'For tabs displayed using images and not a Tab Label, identifies the non current tab image'
/

comment on column APEX_APPLICATION_TABS.TAB_IMAGE_ATTRIBUTES is 'Identifies the HTML IMG tag image attributes'
/

comment on column APEX_APPLICATION_TABS.TAB_LABEL is 'Identifies the display Tab Label for tabs that are not based on image'
/

comment on column APEX_APPLICATION_TABS.TAB_PAGE is 'Identifies the page which is current and associated with this tab.'
/

comment on column APEX_APPLICATION_TABS.TAB_ALSO_CURRENT_FOR_PAGES is 'Identifies one or more other page ID''s which are also current for this tab'
/

comment on column APEX_APPLICATION_TABS.PARENT_TABSET is 'Identifies the Parent Tab Tab-Set to be displayed when this tab is current.  Used only when using two levels of tabs.'
/

comment on column APEX_APPLICATION_TABS.CONDITION_TYPE is 'Identifies the condition type used to conditionally display the tab.'
/

comment on column APEX_APPLICATION_TABS.CONDITION_EXPRESSION1 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_TABS.CONDITION_EXPRESSION2 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_TABS.BUILD_OPTION is 'Tab will be displayed if the Build Option is enabled'
/

comment on column APEX_APPLICATION_TABS.AUTHORIZATION_SCHEME is 'An authorization scheme must evaluate to TRUE in order for this tab to be displayed'
/

comment on column APEX_APPLICATION_TABS.AUTHORIZATION_SCHEME_ID is 'Foreign Key'
/

comment on column APEX_APPLICATION_TABS.LAST_UPDATED_BY is 'Apex developer who made last update'
/

comment on column APEX_APPLICATION_TABS.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_TABS.COMPONENT_COMMENT is 'Developer comment'
/

comment on column APEX_APPLICATION_TABS.TAB_ID is 'Primary key of this tab'
/

comment on column APEX_APPLICATION_TABS.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

