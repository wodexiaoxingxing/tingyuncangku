create view APEX_APPLICATION_PAGE_RPT_COLS as
select
     w.short_name                          workspace,
     p.flow_id                             application_id,
     f.name                                application_name,
     p.id                                  page_id,
     p.name                                page_name,
     region.plug_Name                      region_name,
     --
     --r.QUERY_COLUMN_ID                     ,
     --r.FORM_ELEMENT_ID                     ,
     r.COLUMN_ALIAS                        column_alias,
     r.COLUMN_DISPLAY_SEQUENCE             display_sequence,
     r.COLUMN_HEADING                      heading,
     r.COLUMN_FORMAT                       format_mask,
     r.COLUMN_HTML_EXPRESSION              html_expression,
     r.COLUMN_CSS_CLASS                    css_class,
     r.COLUMN_CSS_STYLE                    css_style,
     r.COLUMN_HIT_HIGHLIGHT                highlight_words,
     --
     r.COLUMN_LINK                         column_link_url,
     r.COLUMN_LINKTEXT                     column_link_text,
     r.COLUMN_LINK_ATTR                    column_link_attributes,
     --
     r.COLUMN_LINK_CHECKSUM_TYPE           page_checksum,
     --
     r.COLUMN_ALIGNMENT                    column_alignment,
     r.HEADING_ALIGNMENT                   heading_alignment,
     --
     r.DEFAULT_SORT_COLUMN_SEQUENCE        default_sort_sequence,
     r.DEFAULT_SORT_DIR                    default_sort_direction,
     decode(r.DISABLE_SORT_COLUMN,
       'Y','Yes','N','No',
       r.DISABLE_SORT_COLUMN)              sortable_column,
     decode(r.SUM_COLUMN,
       'Y','Yes','N','No',
       r.SUM_COLUMN)                       sum_column,
     decode(r.HIDDEN_COLUMN ,
       'Y','Yes','N','No',
       r.HIDDEN_COLUMN )                   column_is_hidden,
     --
     r.DISPLAY_WHEN_COND_TYPE              condition_type,
     r.DISPLAY_WHEN_CONDITION              condition_expression1,
     r.DISPLAY_WHEN_CONDITION2             condition_expression2,
     --
     decode(substr(r.REPORT_COLUMN_REQUIRED_ROLE,1,1),'!','Not ')||
     nvl((select name
     from   wwv_flow_security_schemes
     where  to_char(id) = ltrim(r.REPORT_COLUMN_REQUIRED_ROLE,'!')
     and    flow_id = f.id),
            r.REPORT_COLUMN_REQUIRED_ROLE)
                                           authorization_scheme,
     r.REPORT_COLUMN_REQUIRED_ROLE         authorization_scheme_id,
     --
     r.LAST_UPDATED_BY                     last_updated_by,
     r.LAST_UPDATED_ON                     last_updated_on,
     --
     decode(r.DISPLAY_AS,
        'WITHOUT_MODIFICATION','Standard Report Column',
        'TEXT_FROM_LOV','Display as Text (based on LOV, does not save state)',
        'DISPLAY_AND_SAVE','Display as Text (saves state)',
        'ESCAPE_SC','Display as Text (escape special characters, does not save state)',
        'DATE_POPUP','Date Picker',
        'TEXT','Text Field',
        'TEXTAREA','Text Area',
        'SELECT_LIST','Select List (static LOV)',
        'SELECT_LIST_FROM_LOV','Select List (named LOV)',
        'SELECT_LIST_FROM_QUERY','Select List (query based LOV)',
        'HIDDEN','Hidden',
        'POPUP','Popup LOV (named LOV)',
        'POPUP_QUERY','Popup LOV (query based LOV)',
        r.DISPLAY_AS)                      display_as,
     --
     decode((select lov_name
      from wwv_flow_lists_of_values$
      where id = r.NAMED_LOV),null,null,
      (select lov_name
      from wwv_flow_lists_of_values$
      where id = r.NAMED_LOV))                            named_list_of_values,
     r.INLINE_LOV                          inline_list_of_values,
     decode(r.LOV_SHOW_NULLS,
       'YES','Yes','NO','No',
       r.LOV_SHOW_NULLS)                   LOV_SHOW_NULLS,
     decode(r.LOV_DISPLAY_EXTRA,
       'YES','Yes','NO','No',
       r.LOV_DISPLAY_EXTRA)                LOV_DISPLAY_EXTRA_VALUES,
     r.LOV_NULL_TEXT                       lov_null_text,
     r.LOV_NULL_VALUE                      lov_null_value,
     --
     r.COLUMN_WIDTH                        form_element_width,
     r.COLUMN_HEIGHT                       form_element_height,
     r.CATTRIBUTES                         form_Element_Attributes,
     r.CATTRIBUTES_ELEMENT                 form_Element_Option_Attributes,
     --
     --r.COLUMN_COMMENT                      ,
     r.PK_COL_SOURCE_TYPE                  primary_key_column_source_type,
     r.PK_COL_SOURCE                       primary_key_column_source,
     decode(r.DERIVED_COLUMN,
       'Y','Yes',
        r.DERIVED_COLUMN)                  derived_column,
     --
     r.COLUMN_DEFAULT                      column_default,
     r.COLUMN_DEFAULT_TYPE                 column_default_type,
     --
     r.REF_SCHEMA                          reference_schema,
     r.REF_TABLE_NAME                      reference_table_name,
     r.REF_COLUMN_NAME                     reference_column_name,
     --
     decode(include_in_export,'Y','Yes','N','No') include_in_export,
     print_col_width                       print_column_width,
     print_col_align                       print_column_alignment,
     COLUMN_COMMENT                        column_comment,
     --
     region.id                             region_id,
     r.id                                  region_report_column_id,
     --
     substr(r.COLUMN_ALIAS,1,30)
     ||' s='||r.COLUMN_DISPLAY_SEQUENCE
     ||' h='||substr(r.COLUMN_HEADING,1,15)||length(r.COLUMN_HEADING)
     ||substr(r.COLUMN_FORMAT,1,15)||length(r.COLUMN_FORMAT)
     ||' e='||substr(r.COLUMN_HTML_EXPRESSION,1,15)||length(r.COLUMN_HTML_EXPRESSION)
     ||substr(r.COLUMN_CSS_CLASS,1,20)
     ||substr(r.COLUMN_CSS_STYLE,1,20)
     ||substr(r.COLUMN_HIT_HIGHLIGHT,1,15)||length(r.COLUMN_HIT_HIGHLIGHT)
     ||' l='||substr(r.COLUMN_LINK,1,20)||length(r.COLUMN_LINK)
     ||substr(r.COLUMN_LINKTEXT,1,15)||length(r.COLUMN_LINKTEXT)
     ||substr(r.COLUMN_LINK_ATTR,1,15)||length(r.COLUMN_LINK_ATTR)
     ||substr(r.COLUMN_LINK_CHECKSUM_TYPE,1,15)
     ||' a='||substr(r.COLUMN_ALIGNMENT,1,6)||substr(r.HEADING_ALIGNMENT,1,6)
     ||' s='||DEFAULT_SORT_COLUMN_SEQUENCE
     ||substr(DEFAULT_SORT_DIR,1,6)
     ||substr(r.DISABLE_SORT_COLUMN,1,10)
     ||substr(r.SUM_COLUMN,1,10)
     ||substr(r.HIDDEN_COLUMN,1,15)
     ||' c='||substr(r.DISPLAY_WHEN_COND_TYPE,1,20)
	   ||substr(r.DISPLAY_WHEN_CONDITION,1,15)||length(r.DISPLAY_WHEN_CONDITION)
     ||substr(r.DISPLAY_WHEN_CONDITION2,1,15)||length(r.DISPLAY_WHEN_CONDITION2)
     ||' a='||substr(decode(substr(r.REPORT_COLUMN_REQUIRED_ROLE,1,1),'!','Not ')||
     nvl((select name
     from   wwv_flow_security_schemes
     where  to_char(id) = ltrim(r.REPORT_COLUMN_REQUIRED_ROLE,'!')
     and    flow_id = f.id),
            r.REPORT_COLUMN_REQUIRED_ROLE),1,30)
     ||' d='||substr(r.DISPLAY_AS,1,20)
     ||' l='||substr(decode((select lov_name
      from wwv_flow_lists_of_values$
      where id = r.NAMED_LOV),null,null,
      (select lov_name
      from wwv_flow_lists_of_values$
      where id = r.NAMED_LOV)),1,30)
     ||substr(r.INLINE_LOV,1,30)||substr(r.LOV_SHOW_NULLS,1,20)||substr(r.LOV_DISPLAY_EXTRA,1,6)||substr(r.LOV_NULL_VALUE,1,20)||r.COLUMN_WIDTH||r.COLUMN_HEIGHT
     ||' c='||substr(r.CATTRIBUTES,1,20)||length(r.CATTRIBUTES)
     ||' c='||substr(r.CATTRIBUTES_ELEMENT,1,20)||length(r.CATTRIBUTES_ELEMENT)
     ||' pk='||r.PK_COL_SOURCE_TYPE||dbms_lob.substr(r.PK_COL_SOURCE,20,1)||dbms_lob.getlength(r.PK_COL_SOURCE)
     ||' d='||substr(r.DERIVED_COLUMN,1,6)
     ||' d='||substr(r.COLUMN_DEFAULT,1,20)||length(r.COLUMN_DEFAULT)
     ||' t='||r.COLUMN_DEFAULT_TYPE||include_in_export||print_col_width||print_col_align
     component_signature
from WWV_FLOW_REGION_REPORT_COLUMN r,
     wwv_flow_steps p,
     wwv_flow_page_plugs region,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_030200')  or d.sgid = f.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = p.security_group_id and
      f.security_group_id = r.security_group_id and
      f.id = p.flow_id and
      f.id = region.flow_id and
      p.id = region.page_id and
      region.id = r.region_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0 and
      (user in ('SYS','SYSTEM', 'APEX_030200') or w.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_APPLICATION_PAGE_RPT_COLS is 'Report column definitions used for report regions'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.PAGE_ID is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.PAGE_NAME is 'Identifies a page within an application'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.REGION_NAME is 'Report region name'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.COLUMN_ALIAS is 'SQL query column alias'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.DISPLAY_SEQUENCE is 'Identifies the sequence in the report that this column is to be displayed'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.HEADING is 'Report column heading'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.FORMAT_MASK is 'Number or Date format mask'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.HTML_EXPRESSION is 'HTML column template used to display this column'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.CSS_CLASS is 'Use this CSS class in the HTML TD tag when displaying this report column'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.CSS_STYLE is 'Use this CSS style in the HTML TD tag when displaying this report column'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.HIGHLIGHT_WORDS is 'Identify keywords to highlight, for example "&P1_SEARCH."'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.COLUMN_LINK_URL is 'URL target of report column'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.COLUMN_LINK_TEXT is 'Text displayed for linked columns'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.COLUMN_LINK_ATTRIBUTES is 'HTML "A" tag attributes'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.PAGE_CHECKSUM is 'An appropriate checksum when linking to protected pages'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.COLUMN_ALIGNMENT is 'Report column alignment'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.HEADING_ALIGNMENT is 'Report heading alignment'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.DEFAULT_SORT_SEQUENCE is 'For reports with column heading sorting, identifies the default sort order'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.DEFAULT_SORT_DIRECTION is 'Default sort direction, ascending or descending'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.SORTABLE_COLUMN is 'Identifies if the column is column heading sortable'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.SUM_COLUMN is 'Identifies if this column is to be summed'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.COLUMN_IS_HIDDEN is 'Identifies the column as hidden, the values will be returned to the browser but they will not be displayed.'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.CONDITION_TYPE is 'Identifies the condition type used to conditionally display this Report Column'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.CONDITION_EXPRESSION1 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.CONDITION_EXPRESSION2 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.AUTHORIZATION_SCHEME is 'An authorization scheme must evaluate to TRUE in order for this component to be displayed'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.AUTHORIZATION_SCHEME_ID is 'Foreign Key'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.LAST_UPDATED_BY is 'Apex User Name that last updated this report column'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.DISPLAY_AS is 'Identifies how the report column is to be displayed'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.NAMED_LIST_OF_VALUES is 'Identifies the Shared List of Values to be used to display this report column'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.INLINE_LIST_OF_VALUES is 'Identifies an inline List of Values to display this column value'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.LOV_SHOW_NULLS is 'For column "Display As" '
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.LOV_DISPLAY_EXTRA_VALUES is 'Identifies if the column value is to be displayed if the List of Values domain does not include the column value.'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.LOV_NULL_TEXT is 'Identifies the text to be displayed for a null value'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.LOV_NULL_VALUE is 'Identifies the text to be returned for a null value'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.FORM_ELEMENT_WIDTH is 'For form elements, identifies the element width'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.FORM_ELEMENT_HEIGHT is 'For form elements, identifies the element height'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.FORM_ELEMENT_ATTRIBUTES is 'Identifies HTML attributes for the HTML form element'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.FORM_ELEMENT_OPTION_ATTRIBUTES is 'Identifies HTML attributes for the HTML form element options'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.PRIMARY_KEY_COLUMN_SOURCE_TYPE is 'Identifies the datatype of an updatable reports primary key.'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.PRIMARY_KEY_COLUMN_SOURCE is 'Identifies the source value for an updatable reports primary key.'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.DERIVED_COLUMN is 'Column is generated by the reporting engine and is not derived from the SQL query'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.COLUMN_DEFAULT is 'Identifies the default value source for this updatable report column'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.COLUMN_DEFAULT_TYPE is 'Identifies the default value source type for an updatable report column'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.REFERENCE_SCHEMA is 'Referenced column'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.REFERENCE_TABLE_NAME is 'Referenced column'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.REFERENCE_COLUMN_NAME is 'Referenced column'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.INCLUDE_IN_EXPORT is 'Include column in download'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.PRINT_COLUMN_WIDTH is 'Print column width for exact control'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.PRINT_COLUMN_ALIGNMENT is 'Print column alignment'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.COLUMN_COMMENT is 'Comment on Report Column'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.REGION_ID is 'Identifies the Primary Key of the report Region'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.REGION_REPORT_COLUMN_ID is 'Identifies the Primary Key of the Report Column Entry'
/

comment on column APEX_APPLICATION_PAGE_RPT_COLS.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

