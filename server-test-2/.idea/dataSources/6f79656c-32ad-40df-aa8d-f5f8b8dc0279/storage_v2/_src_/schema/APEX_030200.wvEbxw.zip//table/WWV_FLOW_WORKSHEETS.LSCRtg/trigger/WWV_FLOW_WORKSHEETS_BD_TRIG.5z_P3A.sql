create trigger WWV_FLOW_WORKSHEETS_BD_TRIG
    before delete
    on WWV_FLOW_WORKSHEETS
begin
    wwv_flow_worksheet.g_delete_in_progress := true;
end;
/

