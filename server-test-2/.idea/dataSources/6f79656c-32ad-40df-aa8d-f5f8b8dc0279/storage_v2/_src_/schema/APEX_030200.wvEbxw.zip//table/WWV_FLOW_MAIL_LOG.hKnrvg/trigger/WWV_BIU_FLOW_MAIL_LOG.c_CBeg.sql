create trigger WWV_BIU_FLOW_MAIL_LOG
    before insert
    on WWV_FLOW_MAIL_LOG
    for each row
begin
    :new.last_updated_on := sysdate;
end;
/

