create trigger WWV_FLOW_WORKSHEETS_AD_TRIG
    after delete
    on WWV_FLOW_WORKSHEETS
begin
    wwv_flow_worksheet.g_delete_in_progress := false;
end;
/

