create view APEX_APPLICATION_PAGE_IR_RPT as
select
w.short_name                 workspace,
f.id                         application_id,
f.name                       application_name,
r.page_id                    page_id,
r.worksheet_id               interactive_report_id,
r.id                         report_id,
r.application_user           application_user,
r.name                       report_name,
r.session_id                 ,
r.base_report_id             ,
r.description                report_description,
r.report_seq                 display_sequence,
r.report_type                report_view_mode,
r.status                     ,
r.category_id                ,
(case when r.is_default = 'Y' then 'DEFAULT'
      when r.session_id is null then 'USER SAVED'
 else 'SESSION' end)         report_type,
--
r.display_rows               ,
r.report_columns             ,
--
r.sort_column_1              ,
r.sort_direction_1           ,
r.sort_column_2              ,
r.sort_direction_2           ,
r.sort_column_3              ,
r.sort_direction_3           ,
r.sort_column_4              ,
r.sort_direction_4           ,
r.sort_column_5              ,
r.sort_direction_5           ,
r.sort_column_6              ,
r.sort_direction_6           ,
--
r.break_on                   ,
r.break_enabled_on           ,
--
r.sum_columns_on_break       ,
r.avg_columns_on_break       ,
r.max_columns_on_break       ,
r.min_columns_on_break       ,
r.median_columns_on_break    ,
r.count_columns_on_break     ,
--
r.flashback_mins_ago         flashback_minutes,
decode(r.flashback_enabled,'Y','Yes','N','No',r.flashback_enabled) flashback_enabled,
--
r.chart_type                 ,
r.chart_label_column         ,
r.chart_label_title          ,
r.chart_value_column         ,
r.chart_aggregate            ,
r.chart_value_title          ,
decode(r.chart_sorting,
       'DEFAULT','Default',
       'VALUE_DESC','Value - Descending',
       'VALUE_ASC','Value - Ascending',
       'LABEL_DESC','Label - Descending',
       'LAVEL_ASC','Label - Ascending',
       r.chart_sorting)  chart_sort_order,
--
r.created_on        ,
r.created_by        ,
r.updated_on        last_updated_on,
r.updated_by        last_updated_by
--
from wwv_flow_worksheet_rpts r,
     wwv_flow_worksheets ws,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_030200')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = r.security_group_id and
      f.id = ws.flow_id and ws.id = r.worksheet_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0 and
      (user in ('SYS','SYSTEM', 'APEX_030200') or w.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_APPLICATION_PAGE_IR_RPT is 'Identifies user-level report settings for an interactive report'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.PAGE_ID is 'Identifies page number'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.INTERACTIVE_REPORT_ID is 'ID of the interactive report'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.REPORT_ID is 'ID of the report'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.APPLICATION_USER is 'The user these report settings are used by'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.REPORT_NAME is 'The name of these report settings'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.SESSION_ID is 'For session-level report settings, the session ID associated with this record'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.BASE_REPORT_ID is 'For session-level report settings, the base report settings this record was derived from'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.REPORT_DESCRIPTION is 'The description given to the report'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.DISPLAY_SEQUENCE is 'The order the report will appear in a list'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.REPORT_VIEW_MODE is 'Identifies the current view settings of the report'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.STATUS is 'The shared status of these settings'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.CATEGORY_ID is 'The category_id of the report'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.REPORT_TYPE is 'Identifies whether this is a DEFAULT, USER SAVED, or SESSION based set of report settings'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.DISPLAY_ROWS is 'Number of rows to display in the report'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.REPORT_COLUMNS is 'List of columns to display in the report'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.SORT_COLUMN_1 is 'First column to sort by'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.SORT_DIRECTION_1 is 'Direction to use for first column sort'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.SORT_COLUMN_2 is 'First column to sort by'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.SORT_DIRECTION_2 is 'Direction to use for first column sort'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.SORT_COLUMN_3 is 'Second column to sort by'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.SORT_DIRECTION_3 is 'Direction to use for first column sort'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.SORT_COLUMN_4 is 'Third column to sort by'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.SORT_DIRECTION_4 is 'Direction to use for first column sort'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.SORT_COLUMN_5 is 'Fourth column to sort by'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.SORT_DIRECTION_5 is 'Direction to use for first column sort'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.SORT_COLUMN_6 is 'Fifth column to sort by'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.SORT_DIRECTION_6 is 'Direction to use for first column sort'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.BREAK_ON is 'Identifies a set of columns to break on'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.BREAK_ENABLED_ON is 'Identifies which control breaks are enabled'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.SUM_COLUMNS_ON_BREAK is 'Identifies which columns to aggregate with a sum'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.AVG_COLUMNS_ON_BREAK is 'Identifies which columns to aggregate with a avg'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.MAX_COLUMNS_ON_BREAK is 'Identifies which columns to aggregate with a max'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.MIN_COLUMNS_ON_BREAK is 'Identifies which columns to aggregate with a min'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.MEDIAN_COLUMNS_ON_BREAK is 'Identifies which columns to aggregate with a median'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.COUNT_COLUMNS_ON_BREAK is 'Identifies which columns to aggregate with a count'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.FLASHBACK_MINUTES is 'Identifies the number of minutes to flashback in the query'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.FLASHBACK_ENABLED is 'Identifies whether flashback is enabled'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.CHART_TYPE is 'Identifies the current chart type'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.CHART_LABEL_COLUMN is 'Identifies the alias of the column to use as labels in a chart'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.CHART_LABEL_TITLE is 'Text to use as the label axis title for a chart'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.CHART_VALUE_COLUMN is 'Identifies the alias of the column to use as values in a chart'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.CHART_AGGREGATE is 'Identifies an aggregation function to use on the values in the chart'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.CHART_VALUE_TITLE is 'Text to use as the value axis title for a chart'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.CHART_SORT_ORDER is 'Identifies the current chart sorting method'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.CREATED_ON is 'Auditing; date the record was created.'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.CREATED_BY is 'Auditing; user that created the record.'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.LAST_UPDATED_ON is 'Auditing; date the record was last modified.'
/

comment on column APEX_APPLICATION_PAGE_IR_RPT.LAST_UPDATED_BY is 'Auditing; user that last modified the record.'
/

