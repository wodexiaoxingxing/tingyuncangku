create view APEX_APPLICATION_SUPP_OBJ_SCR as
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    i.NAME                           script_name,
    i.SEQUENCE                       execution_sequence,
    decode(i.SCRIPT_TYPE,
           'UPGRADE','Upgrade',
           'INSTALL','Install',
           i.SCRIPT_TYPE)            script_type,
    --
    i.SCRIPT                         sql_script,
    --
    i.CONDITION_TYPE                 condition_type,
    i.CONDITION                      condition_expression1,
    i.CONDITION2                     condition_expression2,
    --
    i.LAST_UPDATED_BY                last_updated_by,
    i.LAST_UPDATED_ON                last_updated_on,
    i.CREATED_BY                     created_by,
    i.CREATED_ON                     created_on,
    --
    i.ID                             supporting_object_script_id
from wwv_flow_install_scripts i,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_030200')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      f.id = i.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0 and
      (user in ('SYS','SYSTEM', 'APEX_030200') or w.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_APPLICATION_SUPP_OBJ_SCR is 'Identifies the Supporting Object installation SQL Scripts'
/

comment on column APEX_APPLICATION_SUPP_OBJ_SCR.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_SUPP_OBJ_SCR.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_SUPP_OBJ_SCR.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_SUPP_OBJ_SCR.SCRIPT_NAME is 'Identifies the name of the installation SQL Script'
/

comment on column APEX_APPLICATION_SUPP_OBJ_SCR.EXECUTION_SEQUENCE is 'Identifies the execution of the installation SQL Script'
/

comment on column APEX_APPLICATION_SUPP_OBJ_SCR.SCRIPT_TYPE is 'Identifies whether this is an install or upgrade SQL Script'
/

comment on column APEX_APPLICATION_SUPP_OBJ_SCR.SQL_SCRIPT is 'Identifies the SQL Script.  Most basic SQL*plus syntax can be used to create database objects and load sample data.'
/

comment on column APEX_APPLICATION_SUPP_OBJ_SCR.CONDITION_TYPE is 'Identifies the condition type used to conditionally execute the Installation SQL Script'
/

comment on column APEX_APPLICATION_SUPP_OBJ_SCR.CONDITION_EXPRESSION1 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_SUPP_OBJ_SCR.CONDITION_EXPRESSION2 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_SUPP_OBJ_SCR.LAST_UPDATED_BY is 'Apex developer who made last update'
/

comment on column APEX_APPLICATION_SUPP_OBJ_SCR.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_SUPP_OBJ_SCR.CREATED_BY is 'Apex User Name of the developer who created this SQL Script'
/

comment on column APEX_APPLICATION_SUPP_OBJ_SCR.CREATED_ON is 'Date that this SQL Script was created'
/

comment on column APEX_APPLICATION_SUPP_OBJ_SCR.SUPPORTING_OBJECT_SCRIPT_ID is 'Primary Key of this SQL Script component'
/

