create TYPE SDO_POINT_TYPE
                                                                              
    AS OBJECT (
       X       NUMBER,
       Y       NUMBER,
       Z       NUMBER)
/

