create PACKAGE BODY       SDO_WFS_LOCK_GEN wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
d8 e7
7Y41tJY41IcIM6uHOPf50Wg9GvUwg+nwLdMVfHSEWE6UHARwKd2D+i5o8fYn1oaOe0O1tazh
YzDIuxq/JbJz4x01STg3dhoiknG3zi3L28sDxxA4IMwEK9aO8FlgBgRn+hhlR035GCM3lNyB
H8BYeyU8MiGin0tM6KIZcJ5C+tdbOzo/fnVB3wushRulu31cG+dEXpgffhMbge1CgzHHHnZS
VIH4KJaUVt80
/

