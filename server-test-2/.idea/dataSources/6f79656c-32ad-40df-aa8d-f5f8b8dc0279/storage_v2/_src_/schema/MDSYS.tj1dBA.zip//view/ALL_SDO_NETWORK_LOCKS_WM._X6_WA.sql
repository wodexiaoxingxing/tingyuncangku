create view ALL_SDO_NETWORK_LOCKS_WM as
SELECT  sdo_owner owner, lock_id, network, workspace,  original_node_filter,  original_link_filter,  original_path_filter, adjusted_node_filter, adjusted_link_filter, adjusted_path_filter
    FROM  sdo_network_locks_wm
/

