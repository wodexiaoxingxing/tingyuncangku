create trigger SDO_GEOM_TRIG_UPD1
    instead of update
    on USER_SDO_GEOM_METADATA
    for each row
declare
 tname varchar2(32);
BEGIN

  EXECUTE IMMEDIATE 'SELECT user FROM dual' into tname;

  mdsys.sdo_meta.change_all_sdo_geom_metadata(tname,
                                              :old.table_name,
                                              :old.column_name,
                                              :n.table_name,
                                              :n.column_name,
                                              :n.diminfo,
                                              :n.srid);

END;
/

