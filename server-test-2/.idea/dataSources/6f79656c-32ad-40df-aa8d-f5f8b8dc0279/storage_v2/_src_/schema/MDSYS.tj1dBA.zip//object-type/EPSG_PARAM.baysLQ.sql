create TYPE       epsg_param
AS OBJECT (
  id  NUMBER,
  val NUMBER,
  uom NUMBER);
/

