create TYPE SDO_RASTER
                                                                      
AS OBJECT
(
   rasterID          NUMBER,
   pyramidLevel      NUMBER,
   bandBlockNumber   NUMBER,
   rowBlockNumber    NUMBER,
   columnBlockNumber NUMBER,
   blockMBR          MDSYS.SDO_GEOMETRY,
   rasterBlock       BLOB)
/

