create trigger "LightSource3d773_TAB$xd"
    after update or delete
    on "LightSource3d773_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','LightSource3d773_TAB', :old.sys_nc_oid$, 'E4B70A3EC77813EFE043ACAAE80AA9DB' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','LightSource3d773_TAB', :old.sys_nc_oid$, 'E4B70A3EC77813EFE043ACAAE80AA9DB', user ); END IF; END;
/

