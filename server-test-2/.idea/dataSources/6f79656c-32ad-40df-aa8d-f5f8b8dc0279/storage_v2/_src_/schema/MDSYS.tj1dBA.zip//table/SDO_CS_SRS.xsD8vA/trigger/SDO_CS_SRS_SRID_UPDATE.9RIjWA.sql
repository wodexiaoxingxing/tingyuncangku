create trigger SDO_CS_SRS_SRID_UPDATE
    after update or delete
    on SDO_CS_SRS
    for each row
BEGIN
  mdsys.mdprvt_srid.sdo_invalidate_srid_metadata(:old.srid);
END;
/

