create view USER_SDO_NETWORK_METADATA as
SELECT NETWORK,
	 NETWORK_ID,
         NETWORK_CATEGORY,
	 GEOMETRY_TYPE,
	 NETWORK_TYPE,
	 NO_OF_HIERARCHY_LEVELS,
	 NO_OF_PARTITIONS,
	 LRS_TABLE_NAME,
	 LRS_GEOM_COLUMN,
         NODE_TABLE_NAME,
         NODE_GEOM_COLUMN,
         NODE_COST_COLUMN,
         NODE_PARTITION_COLUMN,
         NODE_DURATION_COLUMN,
         LINK_TABLE_NAME,
         LINK_GEOM_COLUMN,
	 LINK_DIRECTION,
	 LINK_COST_COLUMN,
         LINK_PARTITION_COLUMN,
	 LINK_DURATION_COLUMN,
	 PATH_TABLE_NAME,
	 PATH_GEOM_COLUMN,
	 PATH_LINK_TABLE_NAME,
	 SUBPATH_TABLE_NAME,
	 SUBPATH_GEOM_COLUMN,
         PARTITION_TABLE_NAME,
         PARTITION_BLOB_TABLE_NAME,
         COMPONENT_TABLE_NAME,
         NODE_LEVEL_TABLE_NAME,
	 TOPOLOGY,
         USER_DEFINED_DATA,
         EXTERNAL_REFERENCES
  FROM SDO_NETWORK_METADATA_TABLE
  	WHERE SDO_OWNER = sys_context('userenv','CURRENT_SCHEMA')
/

create trigger SDO_NETWORK_TRIG_INS
    instead of insert
    on USER_SDO_NETWORK_METADATA
    for each row
begin
    -- missing source code
end
/

create trigger SDO_NETWORK_TRIG_DEL
    instead of delete
    on USER_SDO_NETWORK_METADATA
    for each row
begin
    -- missing source code
end
/

create trigger SDO_NETWORK_TRIG_UPD
    instead of update
    on USER_SDO_NETWORK_METADATA
    for each row
begin
    -- missing source code
end
/

