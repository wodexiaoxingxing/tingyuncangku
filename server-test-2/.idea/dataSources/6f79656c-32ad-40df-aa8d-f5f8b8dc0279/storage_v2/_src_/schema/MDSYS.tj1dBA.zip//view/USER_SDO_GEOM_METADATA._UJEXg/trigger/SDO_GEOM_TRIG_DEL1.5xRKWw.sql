create trigger SDO_GEOM_TRIG_DEL1
    instead of delete
    on USER_SDO_GEOM_METADATA
    for each row
declare
 tname varchar2(32);
BEGIN

  EXECUTE IMMEDIATE 'SELECT user FROM dual' into tname;

  mdsys.sdo_meta.delete_all_sdo_geom_metadata(tname,
                                              :n.table_name,
                                              :n.column_name);

END;
/

