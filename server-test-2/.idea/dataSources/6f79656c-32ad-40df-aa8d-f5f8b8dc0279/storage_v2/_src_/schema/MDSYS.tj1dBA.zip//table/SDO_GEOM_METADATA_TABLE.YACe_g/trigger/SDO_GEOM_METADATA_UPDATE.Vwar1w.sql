create trigger SDO_GEOM_METADATA_UPDATE
    after update or delete
    on SDO_GEOM_METADATA_TABLE
    for each row
BEGIN
  mdsys.mdprvt_gmd.invalidate_geom_metadata(:old.sdo_owner,
                                            :old.sdo_table_name,
                                            :old.sdo_column_name);
END;
/

