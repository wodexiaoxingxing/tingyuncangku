create TYPE         "GridFile734_T" UNDER "GridFileType731_T"("creation" TIMESTAMP,"update" TIMESTAMP)FINAL INSTANTIABLE
/

