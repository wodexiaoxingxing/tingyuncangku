create view USER_SDO_TIN_PC_SYSDATA as
SELECT "OWNER","TABLE_NAME","COLUMN_NAME","DEP_TABLE_SCHEMA","DEP_TABLE_NAME"  FROM all_sdo_tin_pc_sysdata
WHERE owner = sys_context('userenv', 'CURRENT_SCHEMA')
/

