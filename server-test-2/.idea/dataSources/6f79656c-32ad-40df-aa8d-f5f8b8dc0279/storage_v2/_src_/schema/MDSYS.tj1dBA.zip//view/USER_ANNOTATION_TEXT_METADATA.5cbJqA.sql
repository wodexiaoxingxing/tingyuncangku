create view USER_ANNOTATION_TEXT_METADATA as
SELECT F_TABLE_NAME TABLE_NAME, F_TEXT_COLUMN COLUMN_NAME,
               MAP_BASE_SCALE,
               TEXT_DEFAULT_EXPRESSION TEXT_EXPRESSION ,
               TEXT_DEFAULT_ATTRIBUTES TEXT_ATTRIBUTES
FROM SDO_ANNOTATION_TEXT_METADATA
WHERE F_TABLE_SCHEMA =  sys_context('userenv', 'CURRENT_SCHEMA')
/

create trigger SDO_ANNOT_TRIG_INS1
    instead of insert or update or delete
    on USER_ANNOTATION_TEXT_METADATA
    for each row
begin
    -- missing source code
end
/

