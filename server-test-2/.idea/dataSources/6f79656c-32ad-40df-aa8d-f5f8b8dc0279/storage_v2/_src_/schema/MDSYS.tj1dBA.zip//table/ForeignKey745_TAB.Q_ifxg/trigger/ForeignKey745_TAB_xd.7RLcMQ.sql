create trigger "ForeignKey745_TAB$xd"
    after update or delete
    on "ForeignKey745_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','ForeignKey745_TAB', :old.sys_nc_oid$, 'E4B70A3EC77D13EFE043ACAAE80AA9DB' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','ForeignKey745_TAB', :old.sys_nc_oid$, 'E4B70A3EC77D13EFE043ACAAE80AA9DB', user ); END IF; END;
/

