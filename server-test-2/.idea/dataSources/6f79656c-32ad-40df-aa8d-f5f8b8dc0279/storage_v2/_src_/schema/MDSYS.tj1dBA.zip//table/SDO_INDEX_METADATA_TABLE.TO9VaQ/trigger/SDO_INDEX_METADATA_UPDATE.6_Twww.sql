create trigger SDO_INDEX_METADATA_UPDATE
    after update or delete
    on SDO_INDEX_METADATA_TABLE
    for each row
BEGIN


  mdsys.mdprvt_idx.invalidate_cache(:old.sdo_index_owner,
                                    :old.sdo_index_name,
                                    :old.sdo_index_partition,
                                    :old.sdo_index_table);
END;
/

