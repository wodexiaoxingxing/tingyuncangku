create trigger "Animation3d774_TAB$xd"
    after update or delete
    on "Animation3d774_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','Animation3d774_TAB', :old.sys_nc_oid$, 'E4B70A3EC77613EFE043ACAAE80AA9DB' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','Animation3d774_TAB', :old.sys_nc_oid$, 'E4B70A3EC77613EFE043ACAAE80AA9DB', user ); END IF; END;
/

