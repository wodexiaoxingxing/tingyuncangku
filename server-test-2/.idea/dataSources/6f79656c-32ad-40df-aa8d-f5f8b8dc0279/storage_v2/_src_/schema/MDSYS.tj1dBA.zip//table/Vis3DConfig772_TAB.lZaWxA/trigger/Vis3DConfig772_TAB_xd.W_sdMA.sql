create trigger "Vis3DConfig772_TAB$xd"
    after update or delete
    on "Vis3DConfig772_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','Vis3DConfig772_TAB', :old.sys_nc_oid$, 'E4B70A3EC77A13EFE043ACAAE80AA9DB' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','Vis3DConfig772_TAB', :old.sys_nc_oid$, 'E4B70A3EC77A13EFE043ACAAE80AA9DB', user ); END IF; END;
/

