create view ROWTOKENMAP$ as
select tokenId , tableName , rpointer , markedDeleted from  MDSYS.RowTokenMap_t$  where tokenId in (select tokenId from mdsys.TokenSessionMap$)
/

