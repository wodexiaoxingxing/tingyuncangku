create TYPE         "GridPropertiesType726_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","MinCoords" "CoordinatesType718_T","MaxCoords" "CoordinatesType718_T","CoordSpacing" "CoordinatesType718_T","CoordinateUnitOfMeasure" "UnitOfMeasureType714_T")NOT FINAL INSTANTIABLE
/

