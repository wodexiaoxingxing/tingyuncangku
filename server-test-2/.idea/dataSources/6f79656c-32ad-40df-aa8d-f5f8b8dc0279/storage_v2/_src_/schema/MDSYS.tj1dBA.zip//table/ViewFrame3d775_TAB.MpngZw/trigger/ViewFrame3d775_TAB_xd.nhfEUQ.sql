create trigger "ViewFrame3d775_TAB$xd"
    after update or delete
    on "ViewFrame3d775_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','ViewFrame3d775_TAB', :old.sys_nc_oid$, 'E4B70A3EC77413EFE043ACAAE80AA9DB' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','ViewFrame3d775_TAB', :old.sys_nc_oid$, 'E4B70A3EC77413EFE043ACAAE80AA9DB', user ); END IF; END;
/

