create trigger "Theme3d777_TAB$xd"
    after update or delete
    on "Theme3d777_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','Theme3d777_TAB', :old.sys_nc_oid$, 'E4B70A3EC76D13EFE043ACAAE80AA9DB' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','Theme3d777_TAB', :old.sys_nc_oid$, 'E4B70A3EC76D13EFE043ACAAE80AA9DB', user ); END IF; END;
/

