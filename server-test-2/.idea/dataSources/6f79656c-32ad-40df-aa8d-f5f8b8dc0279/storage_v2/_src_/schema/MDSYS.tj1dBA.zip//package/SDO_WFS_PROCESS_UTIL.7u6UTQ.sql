create PACKAGE       SDO_WFS_PROCESS_UTIL wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
7c 92
mCKsDXN1w7Nq2h2nekDmlOqWFecwg3lHf8upynSmZxcPs6p8XBZG42JhbEUItQ9XrSk/vkpS
xuZwoYuNeZ+NWsnHMHmpYYuvswp8juAJ9UXQK63ZoLaJzxYd0Avvsg+SPySnVwJD+xrmZrM=

/

