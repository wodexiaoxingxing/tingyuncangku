create trigger "GridFile735_TAB$xd"
    after update or delete
    on "GridFile735_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','GridFile735_TAB', :old.sys_nc_oid$, 'E4B70A3EC61413EFE043ACAAE80AA9DB' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','GridFile735_TAB', :old.sys_nc_oid$, 'E4B70A3EC61413EFE043ACAAE80AA9DB', user ); END IF; END;
/

