create trigger "Scene3d776_TAB$xd"
    after update or delete
    on "Scene3d776_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','Scene3d776_TAB', :old.sys_nc_oid$, 'E4B70A3EC77113EFE043ACAAE80AA9DB' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','Scene3d776_TAB', :old.sys_nc_oid$, 'E4B70A3EC77113EFE043ACAAE80AA9DB', user ); END IF; END;
/

