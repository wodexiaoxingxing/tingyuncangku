create view SDO_TOPO_TRANSACT_DATA$ as
select TOPOLOGY_ID,TOPO_ID, TOPO_TYPE, TOPO_OP, PARENT_ID
       from SDO_TOPO_TRANSACT_DATA
/

create trigger SDO_TOPO_TRIG_INS1
    instead of insert
    on SDO_TOPO_TRANSACT_DATA$
    for each row
begin
    -- missing source code
end
/

