create PACKAGE sdo_rdf_mig wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
102 d2
A6RgITWgzFg+fy0DHcZVPF9qA2swg/BKAJkVcHRGkHOUiJRucdqVFIMG+OmS1CoMLVfjDrUs
oEjgRCCtMMu54sqkCMqlBEg/LP8/7V+pKwVKN1lcCTIe6fv4bGezWRXo4RqsXHFCu38DNlTt
17ZgN9GvvY2jd805xbmsR6XqVRSXr+Ds+rA9ljRIIodLi5tyBw9M8VOTevsDZqIH
/

