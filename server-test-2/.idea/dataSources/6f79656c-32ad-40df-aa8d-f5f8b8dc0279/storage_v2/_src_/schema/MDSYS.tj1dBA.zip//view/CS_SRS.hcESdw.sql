create view CS_SRS as
(SELECT "CS_NAME","SRID","AUTH_SRID","AUTH_NAME","WKTEXT","CS_BOUNDS","WKTEXT3D" FROM MDSYS.SDO_CS_SRS)
/

create trigger CS_SRS_TRIGGER
    instead of insert or update or delete
    on CS_SRS
    for each row
begin
    -- missing source code
end
/

