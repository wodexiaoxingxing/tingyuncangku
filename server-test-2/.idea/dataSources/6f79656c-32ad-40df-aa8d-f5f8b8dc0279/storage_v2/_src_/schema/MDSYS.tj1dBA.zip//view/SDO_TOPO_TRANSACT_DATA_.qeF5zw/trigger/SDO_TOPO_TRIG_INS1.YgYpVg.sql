create trigger SDO_TOPO_TRIG_INS1
    instead of insert
    on SDO_TOPO_TRANSACT_DATA$
    for each row
declare
  user_name varchar2(32);
  topo_name varchar2(32);
  tname varchar2(100);
begin










   INSERT INTO SDO_TOPO_TRANSACT_DATA
      values(SDO_TOPO_TRANSACT_SUBSEQ.nextval, :n.topology_id, :n.topo_id,
                :n.topo_type, :n.topo_op, :n.parent_id);

end;
/

