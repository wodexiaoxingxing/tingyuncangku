create function SDO_Aggr_ConvexHull wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
b6 b2
634JY53wuXqZokpoKqunVsONbQAwg8eZgcfLCNL+XuefCNC/Wa6WGL//ctUMO6UW1/qzuPW/
KMAyv3RSMr+B/jKyvRjDjwnKmc5FNoA5Hvs7plgE04iP5b0hFoUqFCGFKKgf0EtESC3mEUuw
T5jh47uKux+Lq+7z/IYL16ama/LVEA==
/

