create view USER_SDO_NETWORK_TIMESTAMPS as
SELECT  network, table_name, last_dml_time
    FROM  sdo_network_timestamps
    WHERE owner = sys_context('USERENV', 'CURRENT_SCHEMA')
/

create trigger SDO_NETWORK_TIME_INS_TRIG
    instead of insert
    on USER_SDO_NETWORK_TIMESTAMPS
    for each row
begin
    -- missing source code
end
/

create trigger SDO_NETWORK_TIME_UPD_TRIG
    instead of update
    on USER_SDO_NETWORK_TIMESTAMPS
    for each row
begin
    -- missing source code
end
/

create trigger SDO_NETWORK_TIME_DEL_TRIG
    instead of delete
    on USER_SDO_NETWORK_TIMESTAMPS
    for each row
begin
    -- missing source code
end
/

