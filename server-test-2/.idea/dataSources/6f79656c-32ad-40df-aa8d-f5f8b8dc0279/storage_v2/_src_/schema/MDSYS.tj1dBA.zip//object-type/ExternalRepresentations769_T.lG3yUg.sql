create TYPE         "ExternalRepresentations769_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","GML" "SharedValueType754_T","CityGML" "SharedValueType754_T","KML" "SharedValueType754_T","X3D" "SharedValueType754_T","BIM" "SharedValueType754_T")FINAL INSTANTIABLE
/

