create TYPE         "Frustum3dType758_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","left" NUMBER,"right" NUMBER,"bottom" NUMBER,"top" NUMBER,"near" NUMBER,"far" NUMBER)NOT FINAL INSTANTIABLE
/

