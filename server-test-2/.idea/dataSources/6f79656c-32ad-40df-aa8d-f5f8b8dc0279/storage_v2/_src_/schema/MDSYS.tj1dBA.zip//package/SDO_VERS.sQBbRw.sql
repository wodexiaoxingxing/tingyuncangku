create package SDO_VERS wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
4c 85
TPvuiHuhg8z18NytyNMY9RBFZuAwg5m49TOf9b9c558I0CjHsp4ruHSyCKX1zLjLsp7AgZn0
KLKfsgm4dIsGCWmmZk3FJKoCfMbKFyjGyu+yCx0u9tHR6iQf9jmmROnT7g==
/

