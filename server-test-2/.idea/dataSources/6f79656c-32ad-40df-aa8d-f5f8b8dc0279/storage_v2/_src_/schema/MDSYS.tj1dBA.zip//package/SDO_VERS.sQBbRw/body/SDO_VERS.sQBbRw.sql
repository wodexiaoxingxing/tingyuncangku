create package body SDO_VERS wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
72 a2
Xx/L9yVaQrj9G8u70XqPyaxu/Nkwgyptf8tGfHQ2Jk4YzZvnovfbIuO5S/ekpFGXtao1Fsjo
E1jvjSCjiJMprLczJBPvQoU0K73d3TrGY+5/XERc7LwmfaUs66SJXsQIMAOZwdTUFkUs7dNv
2/fGrUtQelWJ7qT7
/

