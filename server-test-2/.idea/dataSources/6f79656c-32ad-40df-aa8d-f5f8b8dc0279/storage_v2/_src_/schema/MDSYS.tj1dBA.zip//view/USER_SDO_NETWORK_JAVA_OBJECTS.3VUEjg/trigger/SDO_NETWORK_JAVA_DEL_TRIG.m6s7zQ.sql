create trigger SDO_NETWORK_JAVA_DEL_TRIG
    instead of delete
    on USER_SDO_NETWORK_JAVA_OBJECTS
    for each row
DECLARE
  user_name    VARCHAR2(256);
BEGIN

  EXECUTE IMMEDIATE 'SELECT USER FROM DUAL' INTO user_name;

  DELETE
    FROM  sdo_network_constraints
    WHERE NLS_UPPER(SDO_OWNER) = NLS_UPPER(user_name)
      AND constraint = :o.name;

END;
/

