create view TOKENSESSIONMAP$ as
select sessionId , tokenId , expiryTime, expiryOffset from MDSYS.TokenSessionMap_t$ where (tokenId in (select tokenId from MDSYS.CurrentSessionTokenMap$ where sessionId in (select dbms_session.unique_session_id from dual))) or expiryTime < sysdate
/

