create TYPE         "ExternalTheme750_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","MapViewerTiles" "MapViewerTiles751_T","DigitalGlobeTiles" VARCHAR2(4000 CHAR))FINAL INSTANTIABLE
/

