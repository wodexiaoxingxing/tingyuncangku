create trigger "ViewPoint3d762_TAB$xd"
    after update or delete
    on "ViewPoint3d762_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','ViewPoint3d762_TAB', :old.sys_nc_oid$, 'E4B70A3EC77B13EFE043ACAAE80AA9DB' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','ViewPoint3d762_TAB', :old.sys_nc_oid$, 'E4B70A3EC77B13EFE043ACAAE80AA9DB', user ); END IF; END;
/

