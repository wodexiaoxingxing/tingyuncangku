create trigger "DefaultStyle757_TAB$xd"
    after update or delete
    on "DefaultStyle757_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','DefaultStyle757_TAB', :old.sys_nc_oid$, 'E4B70A3EC77C13EFE043ACAAE80AA9DB' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','DefaultStyle757_TAB', :old.sys_nc_oid$, 'E4B70A3EC77C13EFE043ACAAE80AA9DB', user ); END IF; END;
/

