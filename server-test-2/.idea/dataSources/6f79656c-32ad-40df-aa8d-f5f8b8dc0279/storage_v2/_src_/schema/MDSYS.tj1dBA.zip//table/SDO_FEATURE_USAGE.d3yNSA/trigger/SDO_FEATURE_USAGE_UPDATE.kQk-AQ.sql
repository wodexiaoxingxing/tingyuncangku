create trigger SDO_FEATURE_USAGE_UPDATE
    after update or delete
    on SDO_FEATURE_USAGE
    for each row
BEGIN
  mdsys.mdprvt_feature.sdo_invalidate_feature(:old.feature_name);
END;
/

