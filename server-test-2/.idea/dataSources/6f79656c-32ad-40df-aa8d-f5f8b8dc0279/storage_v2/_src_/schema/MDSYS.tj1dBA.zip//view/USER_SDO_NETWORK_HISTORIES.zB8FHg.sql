create view USER_SDO_NETWORK_HISTORIES as
SELECT  network, node_history_table, link_history_table, node_trigger, link_trigger
    FROM  sdo_network_histories
    WHERE owner = sys_context('USERENV', 'CURRENT_SCHEMA')
/

create trigger SDO_NETWORK_HIS_INS_TRIG
    instead of insert
    on USER_SDO_NETWORK_HISTORIES
    for each row
begin
    -- missing source code
end
/

create trigger SDO_NETWORK_HIS_UPD_TRIG
    instead of update
    on USER_SDO_NETWORK_HISTORIES
    for each row
begin
    -- missing source code
end
/

create trigger SDO_NETWORK_HIS_DEL_TRIG
    instead of delete
    on USER_SDO_NETWORK_HISTORIES
    for each row
begin
    -- missing source code
end
/

