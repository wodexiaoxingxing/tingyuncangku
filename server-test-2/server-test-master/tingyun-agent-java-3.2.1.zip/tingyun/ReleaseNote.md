#### 2019-07-01	*Version:3.2.1*

######新增
1. 支持抓取JDBC驱动中的executeUpdate的受影响行数
2. 支持报表配置中的“忽略异常类”设置，可忽略事务中抛出的指定异常或错误

######改进
1. 修改上传JDBC数据库地址格式，目前采用IP地址方式，之前采用host name方式

######修复
1. 修复在某些情况下，数据库插件造成应用死锁的问题
2. 修复在资源保护或者探针未连接到Collector情况下，探针造成内存泄露的问题
3. 修复单个应用容器中部署多应用情况下，应用命名不正确的问题

######已知Bug
1. 应用开启Browser自动嵌码，Tomcat、Weblogic容器在Chunk输出页面的情况下可能引起页面白屏


#### 2019-05-20	*Version:3.2.0*

######新增
1. 支持报表配置自定义类和方法嵌码，并上传对应的嵌码状态
2. 新增用户信息获取方式，所有获取方式支持getter chain
    * 方法参数
    * 方法返回值
    * 当前对象
    * Http Response Header
    * Web request path
3. 支持多个用户信息获取方式同时生效，并根据获取方式的优先级确认最终用户信息
4. 新增数据项数据获取方式，所有获取方式支持getter chain
    * Web request query string
    * Http request header
    * Http Post parameter
    * Http response header
    * Servlet session attribute
    * Web request URL
    * Web request path
5. 支持Feign插件，支持版本**9.5.0**到**10.2.3**
6. 支持Spring cloud openfeign插件，支持版本**2.0.0.RELEASE**到**2.1.1.RELEASE**

######改进
1. 优化探针连接方式，减少网络策略的开通

######修复
1. 修复ContextType获取失败时导致browser探针无法获取TINGYUN_DATA的问题


#### 2019-04-17	*Version:3.1.2*

######修复
1. 修复在资源保护情况下概率性出现类初始化失败的问题


#### 2019-04-12	*Version:3.1.1*

######修复
1. 修复在Servlet3.0异步情况下，应用概率性丢失请求参数的问题


#### 2019-03-27	*Version:3.1.0*

######新增
1. 支持CXF 3.1
2. 支持Glassfish Jersey 2.9
3. 支持Sun Jersey 1.19

######改进
1. 优化通信协议，大幅提高TPS，降低CPU使用率
2. 优化数据项功能，支持接口调用
3. 优化自定义嵌码功能，支持自动擦除无用的嵌码

######修复
1. 修复资源保护下采样率不准的问题
2. 修复探针部分性能指标丢失的问题
3. 修复Dubbo结合Spring动态代理使用后，事务命名不正确的问题
4. 修复采集Spring Boot的jar包时空指针的问题


#### 2019-02-18	*Version:3.0.1*

######新增
1. 对用户溯源采集的用户标识增加数据处理支持

######改进
1. 支持在接口中使用Spring注解的事务命名
2. 增强Browser嵌码的兼容性

######修复
1. 修复获取不到Glassfish版本号的问题
2. 修复异步请求下时间统计不正确的问题
3. 修复获取Resin端口不正确的问题
4. 修复Weblogic EJB调用的事务无法采集的问题
5. 修复获取不到Wildfly8版本号的问题
