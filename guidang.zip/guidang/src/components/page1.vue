<template>
  <div class="page1">
     {{ message }}
  <br>
    {{pageName}}
    <el-button type="primary" @click=jump2>跳转到页面2</el-button>
      <el-button type="primary" @click=jump3>跳转到页面3</el-button>
  </div>
</template>

<script>
import api from "@/api/api";
export default {
  name: "page1",
  data() {
    return {
      message: "欢迎来到页面1!",
      pageName: "页面1"
    };
  },
  created() {
  },

  methods: {
    jump2() {
      this.$router.push({name: 'page2'})
    },
    jump3() {
      this.$router.push({name: 'page3'})
    }
  },
  watch: {},
  mounted() {}
};
</script>

<style lang="scss" scoped>
</style>
