import { fetch } from "./config.js";
export default {
};
